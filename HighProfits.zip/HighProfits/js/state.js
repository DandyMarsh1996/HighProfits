/**
 * HighProfits - State Facade
 * Composes HP.StateCore and state/domains/* into a single HP.State API.
 * Load after: state/core.js and state/domains/*.js
 */
var HP = HP || {};

(function() {
    'use strict';
    var core = HP.StateCore;
    if (!core) {
        console.error('HP.StateCore not found. Load state/core.js and state/domains before state.js.');
        return;
    }
    core.init();
    var state = core._stateRef();
    var notify = core._notifyListeners();

    var api = {};
    var skip = { _stateRef: true, _notifyListeners: true };
    for (var key in core) {
        if (core.hasOwnProperty(key) && !skip[key]) {
            api[key] = core[key];
        }
    }

    if (HP.StateInventory) Object.assign(api, HP.StateInventory.create(state, notify));
    if (HP.StateWater) Object.assign(api, HP.StateWater.create(state, notify, api));
    if (HP.StateReputation) Object.assign(api, HP.StateReputation.create(state, notify));
    if (HP.StatePlots) Object.assign(api, HP.StatePlots.create(state, notify, api));
    if (HP.StateBusinesses) Object.assign(api, HP.StateBusinesses.create(state, notify, api));
    if (HP.StateStats) Object.assign(api, HP.StateStats.create(state, notify));
    if (HP.StateHeat) Object.assign(api, HP.StateHeat.create(state, notify, api));
    if (HP.StateAchievements) Object.assign(api, HP.StateAchievements.create(state, notify, api));
    if (HP.StateChallenges) Object.assign(api, HP.StateChallenges.create(state, notify));
    if (HP.StateWorkers) Object.assign(api, HP.StateWorkers.create(state, notify));
    if (HP.StateGenetics) Object.assign(api, HP.StateGenetics.create(state, notify));
    if (HP.StateTutorial) Object.assign(api, HP.StateTutorial.create(state, notify));
    if (HP.StateProgress) Object.assign(api, HP.StateProgress.create(state, notify));
    if (HP.StateCharacter) Object.assign(api, HP.StateCharacter.create(state, notify, api));
    if (HP.StateStrainMastery) Object.assign(api, HP.StateStrainMastery.create(state, notify));
    if (HP.StatePropertyUpgrades) Object.assign(api, HP.StatePropertyUpgrades.create(state, notify, api));
    if (HP.StateDailyGoals) Object.assign(api, HP.StateDailyGoals.create(state, notify));
    if (HP.StateContracts) Object.assign(api, HP.StateContracts.create(state, notify));
    if (HP.StateSmokeBuff) Object.assign(api, HP.StateSmokeBuff.create(state, notify));
    if (HP.StateLaundering) Object.assign(api, HP.StateLaundering.create(state, notify));
    if (HP.StateStockMarket) Object.assign(api, HP.StateStockMarket.create(state, notify));

    HP.State = api;
})();
