/**
 * HighProfits - State Management Module
 * Centralized game state with getter/setter methods
 */
var HP = HP || {};

HP.State = (function() {
    'use strict';

    // Get initial values from constants
    function getInitialState() {
        var constants = HP.Data.Constants;

        return {
            // Core resources
            money: constants.STARTING_MONEY,
            moneyCap: constants.STARTING_MONEY_CAP,

            // Statistics
            stats: {
                totalMoneyEarned: 0,
                totalHarvested: 0,
                totalSold: 0,
                totalSales: 0,           // Number of sale transactions (for tutorial)
                plantsGrown: 0,
                plantsWatered: 0,
                plantsPlanted: 0,
                plantsDied: 0,
                playTime: 0,
                // Extended stats for dashboard
                bestHarvest: 0,           // Largest single harvest (grams)
                biggestSale: 0,           // Largest single sale ($)
                raidsTotal: 0,            // Total raids survived
                heatPayOffsTotal: 0,      // Total times paid off heat
                harvestedByQuality: {     // Per-quality breakdown
                    low: 0,
                    medium: 0,
                    good: 0,
                    premium: 0
                }
            },

            // Inventory - items player owns
            inventory: {
                weed: {
                    low: 0,       // Low quality grams
                    medium: 0,    // Medium quality grams
                    good: 0,      // Good quality grams
                    premium: 0    // Premium quality grams
                },
                seeds: {},        // seedId: quantity
                equipment: {}     // equipmentId: quantity
            },

            // Genetics & breeding
            customStrains: {},    // hybridId: strain definition
            strainLibrary: [],    // Array of discovered strain IDs (for tracking)
            tutorialCompleted: false,
            tutorialStep: 0,

            // Water reservoir - timer adds 1 charge per interval; capacity from base + upgrades
            waterReservoir: {
                current: (constants && constants.WATER_RESERVOIR_BASE_CAPACITY != null) ? constants.WATER_RESERVOIR_BASE_CAPACITY : 50,
                refillAccumulator: 0
            },
            waterUpgradesOwned: [],
            heatReductionOwned: [],

            // Properties owned by player
            properties: {
                owned: ['closet'],  // Start with closet
                plots: {},          // propertyId: [plot objects]
                upgrades: {}        // propertyId: [upgradeIds]
            },

            // Experience and rank
            xp: 0,
            level: 1,
            rank: 'Street Hustler',

            // Heat system (raid resets level and heatPayOffCount)
            heat: {
                level: constants.STARTING_HEAT,
                maxLevel: constants.MAX_HEAT
            },
            heatPayOffCount: 0,  // Number of pay-offs since last raid; cost scales exponentially, resets on raid

            // Reputation (global - legacy)
            reputation: constants.STARTING_REPUTATION,

            // Per-customer reputation (customerId -> number). Affects bonuses when selling to that dealer.
            customerReputation: {},

            // Achievements
            achievements: {
                unlocked: [],  // Array of achievement IDs
                notifications: []  // Recently unlocked (for display)
            },

            // Challenges
            challenges: {
                active: [],
                completed: []
            },

            // Grower Workers - assigned to plots for automation
            growerWorkers: {
                // Array of worker instances
                // Each worker: { id, workerTypeId, assignedPlot: {propertyId, plotIndex}, config: {seedId, soilId, fertilizerId}, status: 'active'|'paused', lastNotification: null }
                instances: []
            },

            // Timestamps
            lastSave: null,
            lastTick: null
        };
    }

    // Private state object
    var state = null;

    // Initialize state
    function initializeState() {
        state = getInitialState();
        
        // Initialize starting property plots and upgrades
        var closet = HP.Data.Properties.get('closet');
        if (closet) {
            state.properties.plots['closet'] = [];
            state.properties.upgrades['closet'] = [];
            for (var i = 0; i < closet.plotCapacity; i++) {
                state.properties.plots['closet'].push(HP.Growing.createEmptyPlot());
            }
        }
    }

    // Listeners for state changes
    var listeners = [];

    // Notify all listeners of state change
    function notifyListeners(key, value) {
        for (var i = 0; i < listeners.length; i++) {
            listeners[i](key, value, state);
        }
    }

    // Deep clone helper
    function deepClone(obj) {
        return JSON.parse(JSON.stringify(obj));
    }

    // Public API
    return {
        // Initialize (must be called after HP.Growing is loaded)
        init: function() {
            if (!state) {
                initializeState();
            }
        },

        // Get entire state (clone to prevent direct mutation)
        getState: function() {
            return deepClone(state);
        },

        // Get specific state value
        get: function(key) {
            if (state.hasOwnProperty(key)) {
                var value = state[key];
                return (typeof value === 'object') ? deepClone(value) : value;
            }
            return undefined;
        },

        // Set specific state value
        set: function(key, value) {
            if (state.hasOwnProperty(key)) {
                state[key] = value;
                notifyListeners(key, value);
            }
        },

        // ===================
        // MONEY OPERATIONS
        // ===================

        getMoney: function() {
            return state.money;
        },

        setMoney: function(amount) {
            state.money = Math.min(amount, state.moneyCap);
            notifyListeners('money', state.money);
        },

        addMoney: function(amount) {
            var newAmount = Math.min(state.money + amount, state.moneyCap);
            var actualAdded = newAmount - state.money;
            state.money = newAmount;
            if (actualAdded > 0) {
                state.stats.totalMoneyEarned += actualAdded;
            }
            notifyListeners('money', state.money);
            return actualAdded;
        },

        spendMoney: function(amount) {
            if (state.money >= amount) {
                state.money -= amount;
                notifyListeners('money', state.money);
                return true;
            }
            return false;
        },

        canAfford: function(amount) {
            return state.money >= amount;
        },

        getMoneyCap: function() {
            return state.moneyCap;
        },

        setMoneyCap: function(cap) {
            state.moneyCap = cap;
            notifyListeners('moneyCap', state.moneyCap);
        },

        // ===================
        // INVENTORY OPERATIONS
        // ===================

        getInventory: function() {
            return deepClone(state.inventory);
        },

        // Weed inventory
        getWeed: function(quality) {
            if (quality) {
                return state.inventory.weed[quality] || 0;
            }
            return deepClone(state.inventory.weed);
        },

        addWeed: function(quality, amount) {
            if (!state.inventory.weed[quality]) {
                state.inventory.weed[quality] = 0;
            }
            state.inventory.weed[quality] += amount;
            state.stats.totalHarvested += amount;
            notifyListeners('inventory', state.inventory);
        },

        removeWeed: function(quality, amount) {
            var current = state.inventory.weed[quality] || 0;
            var removed = Math.min(current, amount);
            state.inventory.weed[quality] = current - removed;
            notifyListeners('inventory', state.inventory);
            return removed;
        },

        getTotalWeed: function() {
            var total = 0;
            for (var q in state.inventory.weed) {
                total += state.inventory.weed[q];
            }
            return total;
        },

        // Seeds inventory
        getSeeds: function(seedId) {
            if (seedId) {
                return state.inventory.seeds[seedId] || 0;
            }
            return deepClone(state.inventory.seeds);
        },

        addSeeds: function(seedId, amount) {
            if (!state.inventory.seeds[seedId]) {
                state.inventory.seeds[seedId] = 0;
            }
            state.inventory.seeds[seedId] += amount;
            notifyListeners('inventory', state.inventory);
        },

        removeSeeds: function(seedId, amount) {
            var current = state.inventory.seeds[seedId] || 0;
            var removed = Math.min(current, amount);
            state.inventory.seeds[seedId] = current - removed;
            notifyListeners('inventory', state.inventory);
            return removed;
        },

        // Equipment inventory
        getEquipment: function(equipmentId) {
            if (equipmentId) {
                return state.inventory.equipment[equipmentId] || 0;
            }
            return deepClone(state.inventory.equipment);
        },

        addEquipment: function(equipmentId, amount) {
            if (!state.inventory.equipment[equipmentId]) {
                state.inventory.equipment[equipmentId] = 0;
            }
            state.inventory.equipment[equipmentId] += amount;
            notifyListeners('inventory', state.inventory);
        },

        removeEquipment: function(equipmentId, amount) {
            var current = state.inventory.equipment[equipmentId] || 0;
            var removed = Math.min(current, amount);
            state.inventory.equipment[equipmentId] = current - removed;
            notifyListeners('inventory', state.inventory);
            return removed;
        },

        // ===================
        // WATER RESERVOIR (timer adds 1 charge per interval; upgrades increase capacity)
        // ===================
        getWaterCapacity: function() {
            var base = (HP.Data.Constants && HP.Data.Constants.WATER_RESERVOIR_BASE_CAPACITY != null) ? HP.Data.Constants.WATER_RESERVOIR_BASE_CAPACITY : 50;
            var owned = state.waterUpgradesOwned || [];
            var bonus = 0;
            if (HP.Data.WaterUpgrades) {
                for (var i = 0; i < owned.length; i++) {
                    var up = HP.Data.WaterUpgrades.get(owned[i]);
                    if (up && up.capacityBonus) bonus += up.capacityBonus;
                }
            }
            return base + bonus;
        },
        getWaterReservoir: function() {
            var w = state.waterReservoir;
            var capacity = this.getWaterCapacity();
            var current = Math.min(w.current || 0, capacity);
            if (current !== (w.current || 0)) state.waterReservoir.current = current;
            return { capacity: capacity, current: current, refillAccumulator: w.refillAccumulator || 0 };
        },
        useWater: function(amount) {
            amount = amount || (HP.Data.Constants && HP.Data.Constants.WATER_COST_PER_USE != null ? HP.Data.Constants.WATER_COST_PER_USE : 1);
            var current = state.waterReservoir.current || 0;
            if (current < amount) return false;
            state.waterReservoir.current = current - amount;
            notifyListeners('waterReservoir', state.waterReservoir);
            return true;
        },
        tickWaterRefill: function(deltaTime) {
            var interval = (HP.Data.Constants && HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS != null) ? HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS : 8;
            var cap = this.getWaterCapacity();
            var w = state.waterReservoir;
            var current = w.current || 0;
            if (current >= cap) return; // Timer only runs when not at full capacity
            w.refillAccumulator = (w.refillAccumulator || 0) + deltaTime;
            while (w.refillAccumulator >= interval && (w.current || 0) < cap) {
                w.refillAccumulator -= interval;
                w.current = Math.min((w.current || 0) + 1, cap);
            }
            if (w.refillAccumulator >= interval) w.refillAccumulator = w.refillAccumulator % interval;
            notifyListeners('waterReservoir', state.waterReservoir);
        },
        getWaterUpgradesOwned: function() {
            return (state.waterUpgradesOwned || []).slice();
        },
        buyWaterUpgrade: function(upgradeId) {
            if (!HP.Data.WaterUpgrades) return false;
            var up = HP.Data.WaterUpgrades.get(upgradeId);
            if (!up || !state.waterUpgradesOwned) return false;
            if (state.waterUpgradesOwned.indexOf(upgradeId) !== -1) return false;
            if ((state.money || 0) < up.cost) return false;
            state.money -= up.cost;
            state.waterUpgradesOwned.push(upgradeId);
            var cap = this.getWaterCapacity();
            if ((state.waterReservoir.current || 0) > cap) state.waterReservoir.current = cap;
            notifyListeners('waterReservoir', state.waterReservoir);
            notifyListeners('money', state.money);
            return true;
        },

        getHeatReductionOwned: function() {
            return (state.heatReductionOwned || []).slice();
        },
        buyHeatReduction: function(itemId) {
            if (!HP.Data.HeatReduction) return false;
            var item = HP.Data.HeatReduction.get(itemId);
            if (!item || !state.heatReductionOwned) return false;
            if (state.heatReductionOwned.indexOf(itemId) !== -1) return false;
            if ((state.money || 0) < item.cost) return false;
            state.money -= item.cost;
            state.heatReductionOwned.push(itemId);
            notifyListeners('money', state.money);
            return true;
        },

        // ===================
        // CUSTOMER REPUTATION (per-dealer)
        // ===================
        getCustomerReputation: function(customerId) {
            if (!state.customerReputation) state.customerReputation = {};
            return state.customerReputation[customerId] || 0;
        },
        addCustomerReputation: function(customerId, delta) {
            if (!state.customerReputation) state.customerReputation = {};
            var current = state.customerReputation[customerId] || 0;
            state.customerReputation[customerId] = current + delta;
            notifyListeners('customerReputation', state.customerReputation);
            return state.customerReputation[customerId];
        },

        // ===================
        // PROPERTY OPERATIONS
        // ===================

        getOwnedProperties: function() {
            return state.properties.owned.slice();
        },

        ownsProperty: function(propertyId) {
            return state.properties.owned.indexOf(propertyId) !== -1;
        },

        buyProperty: function(propertyId) {
            if (this.ownsProperty(propertyId)) {
                return { success: false, message: 'Already owned' };
            }

            var property = HP.Data.Properties.get(propertyId);
            if (!property) {
                return { success: false, message: 'Invalid property' };
            }

            if (!this.spendMoney(property.cost)) {
                return { success: false, message: 'Not enough money' };
            }

            // Add property
            state.properties.owned.push(propertyId);

            // Create plots
            state.properties.plots[propertyId] = [];
            state.properties.upgrades[propertyId] = [];
            for (var i = 0; i < property.plotCapacity; i++) {
                state.properties.plots[propertyId].push(HP.Growing.createEmptyPlot());
            }

            notifyListeners('properties', state.properties);
            return { success: true, message: 'Purchased ' + property.name };
        },

        // ===================
        // PLOT OPERATIONS
        // ===================

        getPlots: function(propertyId) {
            if (propertyId) {
                return state.properties.plots[propertyId] || [];
            }
            return state.properties.plots;
        },

        getPlot: function(propertyId, plotIndex) {
            var plots = state.properties.plots[propertyId];
            if (plots && plots[plotIndex]) {
                return plots[plotIndex];
            }
            return null;
        },

        getAllPlots: function() {
            var allPlots = [];
            for (var propId in state.properties.plots) {
                var plots = state.properties.plots[propId];
                for (var i = 0; i < plots.length; i++) {
                    allPlots.push({
                        propertyId: propId,
                        plotIndex: i,
                        plot: plots[i]
                    });
                }
            }
            return allPlots;
        },

        updatePlot: function(propertyId, plotIndex, updates) {
            var plot = this.getPlot(propertyId, plotIndex);
            if (!plot) return false;

            for (var key in updates) {
                plot[key] = updates[key];
            }
            notifyListeners('plots', state.properties.plots);
            return true;
        },

        // ===================
        // ROOM UPGRADE OPERATIONS
        // ===================

        getRoomUpgrades: function(propertyId) {
            if (!state.properties.upgrades[propertyId]) {
                state.properties.upgrades[propertyId] = [];
            }
            return state.properties.upgrades[propertyId].slice();
        },

        hasRoomUpgrade: function(propertyId, upgradeId) {
            var upgrades = this.getRoomUpgrades(propertyId);
            return upgrades.indexOf(upgradeId) !== -1;
        },

        addRoomUpgrade: function(propertyId, upgradeId) {
            if (!state.properties.upgrades[propertyId]) {
                state.properties.upgrades[propertyId] = [];
            }
            
            var upgrade = HP.Data.RoomUpgrades.get(upgradeId);
            if (!upgrade) return false;
            
            // Check if there's already an upgrade in this category
            var existing = this.getRoomUpgrades(propertyId);
            for (var i = 0; i < existing.length; i++) {
                var existingUpgrade = HP.Data.RoomUpgrades.get(existing[i]);
                if (existingUpgrade && existingUpgrade.category === upgrade.category) {
                    // Remove the old one before adding new one (replacement)
                    this.removeRoomUpgrade(propertyId, existing[i]);
                    break;
                }
            }
            
            if (existing.indexOf(upgradeId) === -1) {
                state.properties.upgrades[propertyId].push(upgradeId);
                notifyListeners('roomUpgrades', state.properties.upgrades);
                return true;
            }
            return false;
        },

        removeRoomUpgrade: function(propertyId, upgradeId) {
            if (!state.properties.upgrades[propertyId]) return false;
            
            var index = state.properties.upgrades[propertyId].indexOf(upgradeId);
            if (index !== -1) {
                state.properties.upgrades[propertyId].splice(index, 1);
                notifyListeners('roomUpgrades', state.properties.upgrades);
                return true;
            }
            return false;
        },

        getRoomBonuses: function(propertyId) {
            var upgrades = this.getRoomUpgrades(propertyId);
            return HP.Data.RoomUpgrades.calculateBonuses(upgrades);
        },

        // ===================
        // XP AND RANK OPERATIONS
        // ===================

        getXP: function() {
            return state.xp;
        },

        addXP: function(amount) {
            state.xp += amount;
            var newRank = HP.Data.Ranks.getForXP(state.xp);

            if (newRank.level > state.level) {
                state.level = newRank.level;
                state.rank = newRank.name;

                notifyListeners('levelUp', {
                    level: state.level,
                    rank: state.rank
                });
            }
            notifyListeners('xp', state.xp);
        },

        getLevel: function() {
            return state.level;
        },

        getRank: function() {
            return state.rank;
        },

        // ===================
        // STATS OPERATIONS
        // ===================

        getStats: function() {
            return deepClone(state.stats);
        },

        incrementStat: function(statName, amount) {
            if (state.stats.hasOwnProperty(statName)) {
                state.stats[statName] += amount;
                notifyListeners('stats', state.stats);
            }
        },

        // ===================
        // HEAT OPERATIONS
        // ===================

        getHeat: function() {
            return state.heat.level;
        },

        addHeat: function(amount) {
            state.heat.level = Math.min(state.heat.level + amount, state.heat.maxLevel);
            notifyListeners('heat', state.heat);
        },

        reduceHeat: function(amount) {
            state.heat.level = Math.max(state.heat.level - amount, 0);
            notifyListeners('heat', state.heat);
        },

        getHeatPayOffCount: function() {
            return state.heatPayOffCount || 0;
        },

        /**
         * Apply a heat reduction action (bribe, hide, cleaners). Cost scales exponentially with pay-off count.
         * @param {string} actionId - 'bribe' | 'hide' | 'cleaners'
         * @returns {Object} { success, cost, reduction } or { success: false, reason }
         */
        applyHeatReduction: function(actionId) {
            var result = HP.Heat && HP.Heat.getReductionCost ? HP.Heat.getReductionCost(actionId, state.heatPayOffCount || 0) : null;
            if (!result || result.cost === undefined) return { success: false, reason: 'unknown_action' };
            if (state.money < result.cost) return { success: false, reason: 'cant_afford', cost: result.cost };
            state.money -= result.cost;
            state.heatPayOffCount = (state.heatPayOffCount || 0) + 1;
            if (state.stats.heatPayOffsTotal != null) state.stats.heatPayOffsTotal++;
            state.heat.level = Math.max(state.heat.level - result.reduction, 0);
            notifyListeners('money', state.money);
            notifyListeners('heat', state.heat);
            return { success: true, cost: result.cost, reduction: result.reduction };
        },

        /**
         * Trigger a raid: lose % of money and product, reset heat and pay-off count.
         * @returns {Object} { moneyLost, productLost, newHeat }
         */
        triggerRaid: function() {
            var constants = HP.Data.Constants;
            var moneyPercent = (constants && constants.RAID_MONEY_LOSS_PERCENT != null) ? constants.RAID_MONEY_LOSS_PERCENT : 25;
            var productPercent = (constants && constants.RAID_PRODUCT_LOSS_PERCENT != null) ? constants.RAID_PRODUCT_LOSS_PERCENT : 30;
            var currentMoney = state.money || 0;
            var moneyLost = Math.floor(currentMoney * (moneyPercent / 100));
            state.money = Math.max(0, currentMoney - moneyLost);

            var weed = state.inventory.weed || {};
            var qualities = ['low', 'medium', 'good', 'premium'];
            var productLost = { low: 0, medium: 0, good: 0, premium: 0 };
            for (var q = 0; q < qualities.length; q++) {
                var qual = qualities[q];
                var amt = weed[qual] || 0;
                productLost[qual] = Math.floor(amt * (productPercent / 100));
                state.inventory.weed[qual] = Math.max(0, amt - productLost[qual]);
            }

            state.heat.level = 0;
            state.heatPayOffCount = 0;
            if (state.stats.raidsTotal != null) state.stats.raidsTotal++;
            notifyListeners('money', state.money);
            notifyListeners('inventory', state.inventory);
            notifyListeners('heat', state.heat);
            return {
                moneyLost: moneyLost,
                productLost: productLost,
                newHeat: 0
            };
        },

        // ===================
        // REPUTATION OPERATIONS
        // ===================

        getReputation: function() {
            return state.reputation;
        },

        setReputation: function(value) {
            state.reputation = Math.max(0, Math.min(100, value));
            notifyListeners('reputation', state.reputation);
        },

        // ===================
        // TIMESTAMP OPERATIONS
        // ===================

        setLastTick: function(timestamp) {
            state.lastTick = timestamp;
        },

        getLastTick: function() {
            return state.lastTick;
        },

        // ===================
        // LISTENER OPERATIONS
        // ===================

        addListener: function(callback) {
            listeners.push(callback);
        },

        removeListener: function(callback) {
            var index = listeners.indexOf(callback);
            if (index > -1) {
                listeners.splice(index, 1);
            }
        },

        // ===================
        // SAVE/LOAD OPERATIONS
        // ===================

        exportState: function() {
            state.lastSave = Date.now();
            return deepClone(state);
        },

        importState: function(newState) {
            var keys = Object.keys(state);
            for (var i = 0; i < keys.length; i++) {
                var key = keys[i];
                if (newState.hasOwnProperty(key)) {
                    state[key] = newState[key];
                }
            }
            notifyListeners('stateLoaded', state);
        },

        // ===================
        // ACHIEVEMENT OPERATIONS
        // ===================

        getAchievements: function() {
            return {
                unlocked: state.achievements.unlocked.slice(),
                notifications: state.achievements.notifications.slice()
            };
        },

        isAchievementUnlocked: function(achievementId) {
            return state.achievements.unlocked.indexOf(achievementId) !== -1;
        },

        unlockAchievement: function(achievementId) {
            if (this.isAchievementUnlocked(achievementId)) {
                return false;
            }

            var achievement = HP.Data.Achievements.get(achievementId);
            if (!achievement) return false;

            state.achievements.unlocked.push(achievementId);
            state.achievements.notifications.push(achievementId);

            // Award XP if achievement has reward
            if (achievement.xpReward) {
                this.addXP(achievement.xpReward);
            }

            notifyListeners('achievement', {
                id: achievementId,
                achievement: achievement
            });

            return true;
        },

        checkAchievements: function() {
            var currentUnlocked = state.achievements.unlocked.slice();
            var newlyUnlocked = HP.Data.Achievements.checkAchievements(state, currentUnlocked);

            for (var i = 0; i < newlyUnlocked.length; i++) {
                this.unlockAchievement(newlyUnlocked[i]);
            }

            return newlyUnlocked.length;
        },

        clearAchievementNotifications: function() {
            state.achievements.notifications = [];
        },

        // ===================
        // CHALLENGE OPERATIONS
        // ===================

        getChallenges: function() {
            return {
                active: state.challenges.active.slice(),
                completed: state.challenges.completed.slice()
            };
        },

        addChallenge: function(challenge) {
            state.challenges.active.push(challenge);
            notifyListeners('challenge', state.challenges);
        },

        completeChallenge: function(challengeId) {
            var index = state.challenges.active.findIndex(function(c) {
                return c.id === challengeId;
            });
            if (index === -1) return false;

            var challenge = state.challenges.active[index];
            state.challenges.active.splice(index, 1);
            state.challenges.completed.push(challengeId);
            notifyListeners('challengeCompleted', challenge);
            return true;
        },

        // ===================
        // GROWER WORKER OPERATIONS
        // ===================

        getGrowerWorkers: function() {
            return state.growerWorkers.instances.slice();
        },

        addGrowerWorker: function(workerTypeId, assignedPlot, config) {
            var worker = {
                id: 'worker_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
                workerTypeId: workerTypeId,
                assignedPlot: assignedPlot,
                config: config || {
                    seedId: null,
                    soilId: null,
                    fertilizerId: null
                },
                status: 'active',
                lastNotification: null
            };
            state.growerWorkers.instances.push(worker);
            notifyListeners('growerWorkers', state.growerWorkers);
            return worker;
        },

        removeGrowerWorker: function(workerId) {
            var index = state.growerWorkers.instances.findIndex(function(w) {
                return w.id === workerId;
            });
            if (index > -1) {
                state.growerWorkers.instances.splice(index, 1);
                notifyListeners('growerWorkers', state.growerWorkers);
                return true;
            }
            return false;
        },

        getWorkerByPlot: function(propertyId, plotIndex) {
            return state.growerWorkers.instances.find(function(w) {
                return w.assignedPlot &&
                       w.assignedPlot.propertyId === propertyId &&
                       w.assignedPlot.plotIndex === plotIndex;
            });
        },

        updateWorkerConfig: function(workerId, config) {
            var worker = state.growerWorkers.instances.find(function(w) {
                return w.id === workerId;
            });
            if (worker) {
                worker.config = config;
                notifyListeners('growerWorkers', state.growerWorkers);
                return true;
            }
            return false;
        },

        updateWorkerStatus: function(workerId, status) {
            var worker = state.growerWorkers.instances.find(function(w) {
                return w.id === workerId;
            });
            if (worker) {
                worker.status = status;
                notifyListeners('growerWorkers', state.growerWorkers);
                return true;
            }
            return false;
        },

        setWorkerNotification: function(workerId, timestamp) {
            var worker = state.growerWorkers.instances.find(function(w) {
                return w.id === workerId;
            });
            if (worker) {
                worker.lastNotification = timestamp;
                return true;
            }
            return false;
        },

        // ===================
        // GENETICS & BREEDING
        // ===================

        getCustomStrains: function() {
            return state.customStrains || {};
        },

        addCustomStrain: function(strainDef) {
            if (!state.customStrains) state.customStrains = {};
            state.customStrains[strainDef.id] = strainDef;
            
            // Add to library if not already there
            if (!state.strainLibrary) state.strainLibrary = [];
            if (state.strainLibrary.indexOf(strainDef.id) === -1) {
                state.strainLibrary.push(strainDef.id);
            }
            
            notifyListeners('customStrains', state.customStrains);
            return true;
        },

        getStrainLibrary: function() {
            return (state.strainLibrary || []).slice();
        },

        hasStrain: function(strainId) {
            // Check both regular seeds and custom strains
            if (HP.Data.Seeds.get(strainId)) return true;
            if (state.customStrains && state.customStrains[strainId]) return true;
            return false;
        },

        // ===================
        // TUTORIAL
        // ===================

        getTutorialStep: function() {
            return state.tutorialStep || 0;
        },

        setTutorialStep: function(step) {
            state.tutorialStep = step;
            notifyListeners('tutorial', state.tutorialStep);
        },

        isTutorialCompleted: function() {
            return state.tutorialCompleted || false;
        },

        completeTutorial: function() {
            state.tutorialCompleted = true;
            notifyListeners('tutorial', state.tutorialCompleted);
        },

        // ===================
        // RESET
        // ===================

        reset: function() {
            initializeState();
            notifyListeners('reset', state);
        }
    };
})();
