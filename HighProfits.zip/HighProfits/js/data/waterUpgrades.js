/**
 * HighProfits - Water Reservoir Upgrades
 * One-time purchases that increase water pool capacity (sold at Hardware Store)
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.WaterUpgrades = (function() {
    'use strict';

    var definitions = {
        water_tank: {
            id: 'water_tank',
            name: 'Water Tank',
            description: 'Extra storage for your water supply. +8 capacity.',
            icon: '🪣',
            store: 'hardware_store',
            cost: 75,
            unlockLevel: 1,
            capacityBonus: 8
        },
        large_water_tank: {
            id: 'large_water_tank',
            name: 'Large Water Tank',
            description: 'Bigger reservoir. +15 capacity.',
            icon: '🛢️',
            store: 'hardware_store',
            cost: 200,
            unlockLevel: 4,
            capacityBonus: 15
        },
        industrial_reservoir: {
            id: 'industrial_reservoir',
            name: 'Industrial Reservoir',
            description: 'Heavy-duty water storage. +25 capacity.',
            icon: '🏭',
            store: 'hardware_store',
            cost: 600,
            unlockLevel: 8,
            capacityBonus: 25
        },
        mega_tank: {
            id: 'mega_tank',
            name: 'Mega Water Tank',
            description: 'Massive capacity. +50 capacity.',
            icon: '🌊',
            store: 'hardware_store',
            cost: 1500,
            unlockLevel: 14,
            capacityBonus: 50
        }
    };

    function get(id) {
        return definitions[id] || null;
    }

    function getForStore(storeId) {
        var list = [];
        for (var id in definitions) {
            if (definitions[id].store === storeId) list.push(definitions[id]);
        }
        return list;
    }

    function getUnlocked(playerLevel) {
        var list = [];
        for (var id in definitions) {
            if (definitions[id].unlockLevel <= playerLevel) list.push(definitions[id]);
        }
        return list;
    }

    return {
        get: get,
        getForStore: getForStore,
        getUnlocked: getUnlocked
    };
})();
