/**
 * Strain effects – named gameplay modifiers for seeds/hybrids.
 * Effects apply to growth, yield, heat, water, sale price, reputation, etc.
 * Used by growing.js, gameLoop (heat), customers (price), marketActions (rep).
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.StrainEffects = (function() {
    'use strict';

    var registry = {
        fast_growth:    { id: 'fast_growth',    name: 'Fast Growth',    description: '15% faster growth time',           type: 'growth',   growthMult: 0.85 },
        high_yield:     { id: 'high_yield',     name: 'High Yield',     description: '20% more harvest yield',           type: 'yield',    yieldMult: 1.2 },
        water_efficient:{ id: 'water_efficient', name: 'Water Efficient', description: '20% less water consumption',     type: 'water',    waterMult: 0.8 },
        hardy:          { id: 'hardy',          name: 'Hardy',          description: '50% lower chance to die from neglect', type: 'failure', failureMult: 0.5 },
        premium_genes:  { id: 'premium_genes',  name: 'Premium Genes',  description: '+15 quality bias (better tier rolls)', type: 'quality', qualityBias: 15 },
        heat_low:       { id: 'heat_low',       name: 'Low Profile',    description: '30% less heat generated while growing', type: 'heat',   heatMult: 0.7 },
        sale_premium:   { id: 'sale_premium',   name: 'In Demand',      description: '10% higher sale price',               type: 'sale',    saleMult: 1.1 },
        rep_boost:      { id: 'rep_boost',      name: 'Dealer Friendly', description: '+1 extra reputation when sold',      type: 'rep',     repBonus: 1 }
    };

    function getEffects(seed) {
        if (!seed) return [];
        if (seed.effects && Array.isArray(seed.effects)) return seed.effects;
        return [];
    }

    function hasEffect(seed, effectId) {
        return getEffects(seed).indexOf(effectId) > -1;
    }

    function getInfo(effectId) {
        return registry[effectId] || { id: effectId, name: effectId, description: '', type: '' };
    }

    function getAll() {
        return registry;
    }

    /** Growth time multiplier (1 = normal, &lt;1 = faster) */
    function getGrowthMultiplier(seed) {
        var mult = 1;
        var effects = getEffects(seed);
        for (var i = 0; i < effects.length; i++) {
            var e = registry[effects[i]];
            if (e && e.growthMult != null) mult *= e.growthMult;
        }
        return mult;
    }

    /** Yield multiplier (1 = normal, &gt;1 = more) */
    function getYieldMultiplier(seed) {
        var mult = 1;
        var effects = getEffects(seed);
        for (var i = 0; i < effects.length; i++) {
            var e = registry[effects[i]];
            if (e && e.yieldMult != null) mult *= e.yieldMult;
        }
        return mult;
    }

    /** Water consumption multiplier (1 = normal, &lt;1 = less) */
    function getWaterMultiplier(seed) {
        var mult = 1;
        var effects = getEffects(seed);
        for (var i = 0; i < effects.length; i++) {
            var e = registry[effects[i]];
            if (e && e.waterMult != null) mult *= e.waterMult;
        }
        return mult;
    }

    /** Failure chance multiplier (1 = normal, &lt;1 = less likely to die) */
    function getFailureMultiplier(seed) {
        var mult = 1;
        var effects = getEffects(seed);
        for (var i = 0; i < effects.length; i++) {
            var e = registry[effects[i]];
            if (e && e.failureMult != null) mult *= e.failureMult;
        }
        return mult;
    }

    /** Extra quality bias (added to seed.qualityBias) */
    function getQualityBiasBonus(seed) {
        var bonus = 0;
        var effects = getEffects(seed);
        for (var i = 0; i < effects.length; i++) {
            var e = registry[effects[i]];
            if (e && e.qualityBias != null) bonus += e.qualityBias;
        }
        return bonus;
    }

    /** Heat contribution multiplier (1 = normal, &lt;1 = less heat from this strain) */
    function getHeatMultiplier(seed) {
        var mult = 1;
        var effects = getEffects(seed);
        for (var i = 0; i < effects.length; i++) {
            var e = registry[effects[i]];
            if (e && e.heatMult != null) mult *= e.heatMult;
        }
        return mult;
    }

    /** Sale price multiplier (1 = normal, &gt;1 = higher price) */
    function getSalePriceMultiplier(seed) {
        var mult = 1;
        var effects = getEffects(seed);
        for (var i = 0; i < effects.length; i++) {
            var e = registry[effects[i]];
            if (e && e.saleMult != null) mult *= e.saleMult;
        }
        return mult;
    }

    /** Extra rep when sold (added to deal rep) */
    function getRepBonus(seed) {
        var bonus = 0;
        var effects = getEffects(seed);
        for (var i = 0; i < effects.length; i++) {
            var e = registry[effects[i]];
            if (e && e.repBonus != null) bonus += e.repBonus;
        }
        return bonus;
    }

    return {
        getEffects: getEffects,
        hasEffect: hasEffect,
        getInfo: getInfo,
        getAll: getAll,
        getGrowthMultiplier: getGrowthMultiplier,
        getYieldMultiplier: getYieldMultiplier,
        getWaterMultiplier: getWaterMultiplier,
        getFailureMultiplier: getFailureMultiplier,
        getQualityBiasBonus: getQualityBiasBonus,
        getHeatMultiplier: getHeatMultiplier,
        getSalePriceMultiplier: getSalePriceMultiplier,
        getRepBonus: getRepBonus
    };
})();
