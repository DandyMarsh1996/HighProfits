/**
 * HighProfits - Achievements System
 * Tracks player achievements and milestones
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Achievements = (function() {
    'use strict';

    // Achievement definitions
    var definitions = {
        firstHarvest: {
            id: 'firstHarvest',
            name: 'First Harvest',
            description: 'Harvest your first plant',
            emoji: '🌿',
            category: 'Harvesting',
            subCategory: 'First Steps',
            xpReward: 10,
            check: function(state) {
                return state.stats.totalHarvested > 0;
            }
        },
        firstSale: {
            id: 'firstSale',
            name: 'First Sale',
            description: 'Make your first sale',
            emoji: '💰',
            category: 'Sales',
            subCategory: 'First Steps',
            xpReward: 15,
            check: function(state) {
                return state.stats.totalSold > 0;
            }
        },
        hundredDollars: {
            id: 'hundredDollars',
            name: 'Hundredaire',
            description: 'Earn $100 total',
            emoji: '💵',
            category: 'Money',
            subCategory: 'First Steps',
            xpReward: 20,
            check: function(state) {
                return state.stats.totalMoneyEarned >= 100;
            }
        },
        thousandDollars: {
            id: 'thousandDollars',
            name: 'Thousandaire',
            description: 'Earn $1,000 total',
            emoji: '💸',
            category: 'Money',
            subCategory: 'Milestones',
            xpReward: 50,
            check: function(state) {
                return state.stats.totalMoneyEarned >= 1000;
            }
        },
        tenPlants: {
            id: 'tenPlants',
            name: 'Green Thumb',
            description: 'Grow 10 plants',
            emoji: '🌱',
            category: 'Harvesting',
            subCategory: 'Milestones',
            xpReward: 25,
            check: function(state) {
                return state.stats.plantsGrown >= 10;
            }
        },
        levelFive: {
            id: 'levelFive',
            name: 'Rising Star',
            description: 'Reach level 5',
            emoji: '⭐',
            category: 'Progression',
            subCategory: 'Milestones',
            xpReward: 30,
            check: function(state) {
                return state.level >= 5;
            }
        },
        levelTen: {
            id: 'levelTen',
            name: 'Veteran',
            description: 'Reach level 10',
            emoji: '🌟',
            category: 'Progression',
            subCategory: 'Milestones',
            xpReward: 75,
            check: function(state) {
                return state.level >= 10;
            }
        },
        firstProperty: {
            id: 'firstProperty',
            name: 'Property Owner',
            description: 'Buy your first property',
            emoji: '🏠',
            category: 'Properties',
            subCategory: 'First Steps',
            xpReward: 40,
            check: function(state) {
                return state.properties.owned.length > 1; // More than just closet
            }
        }
    };

    // ==========================
    // Additional achievements
    // ==========================

    function countRoomUpgrades(state) {
        var upgradesByProp = state && state.properties ? state.properties.upgrades : null;
        if (!upgradesByProp) return 0;
        var total = 0;
        for (var propId in upgradesByProp) {
            var list = upgradesByProp[propId];
            if (Array.isArray(list)) total += list.length;
        }
        return total;
    }

    function hasProperty(state, propertyId) {
        var owned = state && state.properties ? state.properties.owned : null;
        return Array.isArray(owned) && owned.indexOf(propertyId) !== -1;
    }

    function countGrowerWorkers(state) {
        var workers = state && state.growerWorkers ? state.growerWorkers.instances : null;
        return Array.isArray(workers) ? workers.length : 0;
    }

    function addAchievement(def) {
        if (!def || !def.id) return;
        if (definitions[def.id]) return;
        definitions[def.id] = def;
    }

    function addTiered(prefix, tiers, category, subCategory, makeDef) {
        for (var i = 0; i < tiers.length; i++) {
            var def = makeDef(prefix, tiers[i], i);
            if (def) {
                if (!def.category) def.category = category;
                if (!def.subCategory) def.subCategory = subCategory;
                addAchievement(def);
            }
        }
    }

    // Money earned milestones
    addTiered('moneyEarned', [5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000], 'Money', 'Milestones', function(prefix, target) {
        return {
            id: prefix + '_' + target,
            name: 'Earn $' + target,
            description: 'Earn $' + target + ' total',
            emoji: '💵',
            xpReward: Math.max(50, Math.floor(target / 200)),
            check: function(state) {
                return (state.stats.totalMoneyEarned || 0) >= target;
            }
        };
    });

    // Total grams sold milestones
    addTiered('gramsSold', [100, 500, 1000, 5000, 10000, 25000, 50000, 100000, 250000, 500000], 'Sales', 'Milestones', function(prefix, target) {
        return {
            id: prefix + '_' + target,
            name: 'Move ' + target + 'g',
            description: 'Sell ' + target + ' grams total',
            emoji: '📦',
            xpReward: Math.max(40, Math.floor(target / 100)),
            check: function(state) {
                return (state.stats.totalSold || 0) >= target;
            }
        };
    });

    // Plants harvested milestones (uses plantsGrown which now increments on harvest)
    addTiered('plantsHarvested', [25, 50, 100, 250, 500, 1000, 2500, 5000, 10000], 'Harvesting', 'Milestones', function(prefix, target) {
        return {
            id: prefix + '_' + target,
            name: target + ' Harvests',
            description: 'Harvest ' + target + ' plants',
            emoji: '🌿',
            xpReward: Math.max(30, Math.floor(target / 2)),
            check: function(state) {
                return (state.stats.plantsGrown || 0) >= target;
            }
        };
    });

    // Level milestones (beyond the basic ones)
    addTiered('reachLevel', [12, 15, 18, 20, 22, 24, 25], 'Progression', 'Milestones', function(prefix, level) {
        return {
            id: prefix + '_' + level,
            name: 'Reach Level ' + level,
            description: 'Reach level ' + level,
            emoji: '⭐',
            xpReward: level * 250,
            check: function(state) {
                return (state.level || 1) >= level;
            }
        };
    });

    // Properties owned milestones
    addTiered('ownProperties', [2, 3, 5, 8, 10, 13], 'Properties', 'Milestones', function(prefix, target) {
        return {
            id: prefix + '_' + target,
            name: 'Own ' + target + ' Properties',
            description: 'Own ' + target + ' properties',
            emoji: '🏠',
            xpReward: target * 400,
            check: function(state) {
                var owned = state.properties.owned || [];
                return owned.length >= target;
            }
        };
    });

    // Specific property milestones
    addAchievement({
        id: 'own_greenhouse',
        name: 'Greenhouse Operator',
        description: 'Own the Commercial Greenhouse',
        emoji: '🌿',
        category: 'Properties',
        subCategory: 'Specific',
        xpReward: 2500,
        check: function(state) { return hasProperty(state, 'greenhouse'); }
    });
    addAchievement({
        id: 'own_industrial_complex',
        name: 'Industrial Scale',
        description: 'Own the Industrial Complex',
        emoji: '🏗️',
        category: 'Properties',
        subCategory: 'Specific',
        xpReward: 6000,
        check: function(state) { return hasProperty(state, 'industrial_complex'); }
    });
    addAchievement({
        id: 'own_remote_compound',
        name: 'Off-Grid Legend',
        description: 'Own the Remote Compound',
        emoji: '🛰️',
        category: 'Properties',
        subCategory: 'Specific',
        xpReward: 15000,
        check: function(state) { return hasProperty(state, 'remote_compound'); }
    });
    addAchievement({
        id: 'own_mega_facility',
        name: 'Mega Facility Owner',
        description: 'Own the Mega Facility',
        emoji: '🏭',
        category: 'Properties',
        subCategory: 'Specific',
        xpReward: 25000,
        check: function(state) { return hasProperty(state, 'mega_facility'); }
    });

    // Room upgrades installed milestones (across all properties)
    addTiered('roomUpgrades', [1, 3, 6, 12, 24, 36], 'Upgrades', 'Milestones', function(prefix, target) {
        return {
            id: prefix + '_' + target,
            name: 'Room Engineer (' + target + ')',
            description: 'Install ' + target + ' room upgrades total',
            emoji: '⚙️',
            xpReward: target * 300,
            check: function(state) {
                return countRoomUpgrades(state) >= target;
            }
        };
    });

    // Grower workers milestones
    addTiered('growerWorkers', [1, 2, 3, 5, 10], 'Workers', 'Milestones', function(prefix, target) {
        return {
            id: prefix + '_' + target,
            name: 'Hire ' + target + ' Grower' + (target !== 1 ? 's' : ''),
            description: 'Hire ' + target + ' grower workers',
            emoji: '👷',
            xpReward: target * 500,
            check: function(state) {
                return countGrowerWorkers(state) >= target;
            }
        };
    });

    // Inventory milestones (total counts owned right now)
    addTiered('stockpileSeeds', [25, 50, 100, 250, 500], 'Inventory', 'Stockpiles', function(prefix, target) {
        return {
            id: prefix + '_' + target,
            name: 'Seed Stockpile (' + target + ')',
            description: 'Have ' + target + ' seeds in your inventory at once',
            emoji: '🌱',
            xpReward: target * 20,
            check: function(state) {
                var seeds = state.inventory && state.inventory.seeds ? state.inventory.seeds : {};
                return HP.Helpers && HP.Helpers.sumRecord ? HP.Helpers.sumRecord(seeds) >= target : false;
            }
        };
    });

    addTiered('stockpileEquipment', [10, 25, 50, 100, 200], 'Inventory', 'Stockpiles', function(prefix, target) {
        return {
            id: prefix + '_' + target,
            name: 'Gear Hoarder (' + target + ')',
            description: 'Have ' + target + ' equipment items in your inventory at once',
            emoji: '🧰',
            xpReward: target * 25,
            check: function(state) {
                var eq = state.inventory && state.inventory.equipment ? state.inventory.equipment : {};
                return HP.Helpers && HP.Helpers.sumRecord ? HP.Helpers.sumRecord(eq) >= target : false;
            }
        };
    });

    // Play time milestones (seconds)
    addTiered('playTime', [600, 1800, 3600, 7200, 14400], 'Time', 'Milestones', function(prefix, seconds) {
        var mins = Math.floor(seconds / 60);
        return {
            id: prefix + '_' + seconds,
            name: 'On the Grind (' + mins + 'm)',
            description: 'Play for ' + mins + ' minutes total',
            emoji: '⏱️',
            xpReward: Math.floor(mins * 15),
            check: function(state) {
                return (state.stats.playTime || 0) >= seconds;
            }
        };
    });

    /**
     * Get all achievement definitions
     */
    function getAll() {
        return definitions;
    }

    /**
     * Get a specific achievement by ID
     */
    function get(id) {
        return definitions[id] || null;
    }

    /**
     * Get all achievement IDs
     */
    function getIds() {
        return Object.keys(definitions);
    }

    /**
     * Check which achievements should be unlocked based on current state
     * @param {Object} state - Current game state
     * @param {Array} unlockedIds - Array of already unlocked achievement IDs
     * @returns {Array} Array of newly unlocked achievement IDs
     */
    function checkAchievements(state, unlockedIds) {
        var newlyUnlocked = [];
        unlockedIds = unlockedIds || [];

        for (var id in definitions) {
            // Skip if already unlocked
            if (unlockedIds.indexOf(id) !== -1) {
                continue;
            }

            var achievement = definitions[id];
            if (achievement.check && achievement.check(state)) {
                newlyUnlocked.push(id);
            }
        }

        return newlyUnlocked;
    }

    return {
        getAll: getAll,
        get: get,
        getIds: getIds,
        checkAchievements: checkAchievements
    };
})();
