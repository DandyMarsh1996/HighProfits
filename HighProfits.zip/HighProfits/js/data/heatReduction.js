/**
 * HighProfits - Heat Reduction Items
 * One-time purchases at Hardware Store that reduce the rate heat builds up while growing
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.HeatReduction = (function() {
    'use strict';

    var definitions = {
        curtains: {
            id: 'curtains',
            name: 'Blackout Curtains',
            description: 'Block light leaks. Less visible from outside.',
            icon: '🪟',
            store: 'hardware_store',
            cost: 80,
            unlockLevel: 1,
            heatReduction: 0.03
        },
        vent_cover: {
            id: 'vent_cover',
            name: 'Vent Cover',
            description: 'Conceal ventilation. Reduces odor and visibility.',
            icon: '🌀',
            store: 'hardware_store',
            cost: 150,
            unlockLevel: 3,
            heatReduction: 0.04
        },
        odor_blocks: {
            id: 'odor_blocks',
            name: 'Odor Neutralizers',
            description: 'Carbon blocks and gels. Cuts smell and suspicion.',
            icon: '🧴',
            store: 'hardware_store',
            cost: 350,
            unlockLevel: 6,
            heatReduction: 0.05
        },
        dummy_boxes: {
            id: 'dummy_boxes',
            name: 'Storage Boxes',
            description: 'Innocent-looking boxes to hide equipment from view.',
            icon: '📦',
            store: 'hardware_store',
            cost: 120,
            unlockLevel: 4,
            heatReduction: 0.03
        },
        silent_fans: {
            id: 'silent_fans',
            name: 'Quiet Fans',
            description: 'Low-noise ventilation. Less attention from neighbors.',
            icon: '🔇',
            store: 'hardware_store',
            cost: 280,
            unlockLevel: 7,
            heatReduction: 0.04
        },
        secure_wiring: {
            id: 'secure_wiring',
            name: 'Secure Wiring',
            description: 'Hidden cables and surge protection. No suspicious spikes.',
            icon: '🔌',
            store: 'hardware_store',
            cost: 500,
            unlockLevel: 9,
            heatReduction: 0.05
        },
        privacy_screens: {
            id: 'privacy_screens',
            name: 'Privacy Screens',
            description: 'Window and door screens. Keeps prying eyes out.',
            icon: '🛡️',
            store: 'hardware_store',
            cost: 220,
            unlockLevel: 5,
            heatReduction: 0.04
        },
        pro_filter: {
            id: 'pro_filter',
            name: 'Pro Carbon Filter',
            description: 'Heavy-duty odor and particle filter. Major heat reduction.',
            icon: '🔘',
            store: 'hardware_store',
            cost: 800,
            unlockLevel: 12,
            heatReduction: 0.07
        },
        insulated_ducting: {
            id: 'insulated_ducting',
            name: 'Insulated Ducting',
            description: 'Quiet, efficient ductwork. Less thermal signature.',
            icon: '📐',
            store: 'hardware_store',
            cost: 450,
            unlockLevel: 10,
            heatReduction: 0.05
        },
        smart_timer: {
            id: 'smart_timer',
            name: 'Smart Timer',
            description: 'Randomize light schedules. Looks like normal household use.',
            icon: '⏰',
            store: 'hardware_store',
            cost: 180,
            unlockLevel: 4,
            heatReduction: 0.03
        },
        safe_storage: {
            id: 'safe_storage',
            name: 'Hidden Safe',
            description: 'Conceal harvest and cash. Nothing to find if they look.',
            icon: '🔐',
            store: 'hardware_store',
            cost: 1200,
            unlockLevel: 14,
            heatReduction: 0.06
        },
        soundproof_tiles: {
            id: 'soundproof_tiles',
            name: 'Soundproof Tiles',
            description: 'Absorb noise from fans and equipment.',
            icon: '🧱',
            store: 'hardware_store',
            cost: 650,
            unlockLevel: 11,
            heatReduction: 0.05
        },
        decoy_room: {
            id: 'decoy_room',
            name: 'Decoy Setup',
            description: 'Fake “normal” room visible from door. Real op hidden.',
            icon: '🪑',
            store: 'hardware_store',
            cost: 2000,
            unlockLevel: 18,
            heatReduction: 0.08
        },
        legal_docs: {
            id: 'legal_docs',
            name: 'Legal Paperwork',
            description: 'Plausible permits and paperwork. Buys time if questioned.',
            icon: '📄',
            store: 'hardware_store',
            cost: 950,
            unlockLevel: 13,
            heatReduction: 0.05
        },
        backup_power: {
            id: 'backup_power',
            name: 'Backup Power',
            description: 'Battery backup. No suspicious outages.',
            icon: '🔋',
            store: 'hardware_store',
            cost: 1500,
            unlockLevel: 16,
            heatReduction: 0.06
        },
        scout_cam: {
            id: 'scout_cam',
            name: 'Scout Camera',
            description: 'See who’s at the door before they see you.',
            icon: '📹',
            store: 'hardware_store',
            cost: 400,
            unlockLevel: 8,
            heatReduction: 0.04
        },
        clean_supply: {
            id: 'clean_supply',
            name: 'Clean Supply Chain',
            description: 'Source equipment through clean channels. Less trail.',
            icon: '🚚',
            store: 'hardware_store',
            cost: 3500,
            unlockLevel: 20,
            heatReduction: 0.09
        },
        bunker_vent: {
            id: 'bunker_vent',
            name: 'Bunker Ventilation',
            description: 'Military-grade hidden ventilation. Minimal signature.',
            icon: '🕳️',
            store: 'hardware_store',
            cost: 2800,
            unlockLevel: 19,
            heatReduction: 0.08
        },
        ghost_network: {
            id: 'ghost_network',
            name: 'Ghost Network',
            description: 'Isolated smart home. No suspicious cloud traffic.',
            icon: '📡',
            store: 'hardware_store',
            cost: 1800,
            unlockLevel: 17,
            heatReduction: 0.07
        },
        full_cover: {
            id: 'full_cover',
            name: 'Full Cover Package',
            description: 'End-to-end operational security. Maximum heat reduction.',
            icon: '🏆',
            store: 'hardware_store',
            cost: 8000,
            unlockLevel: 25,
            heatReduction: 0.12
        },
        elite_filter: {
            id: 'elite_filter',
            name: 'Elite Filtration',
            description: 'Industrial odor and particle control. Near-invisible footprint.',
            icon: '💎',
            store: 'hardware_store',
            cost: 4500,
            unlockLevel: 22,
            heatReduction: 0.10
        },
        max_security: {
            id: 'max_security',
            name: 'Max Security Suite',
            description: 'Everything: filters, timers, storage, decoys. Stay under the radar.',
            icon: '👑',
            store: 'hardware_store',
            cost: 12000,
            unlockLevel: 24,
            heatReduction: 0.11
        }
    };

    function get(id) {
        return definitions[id] || null;
    }

    function getForStore(storeId) {
        var list = [];
        for (var id in definitions) {
            if (definitions[id].store === storeId) list.push(definitions[id]);
        }
        list.sort(function(a, b) { return (a.unlockLevel || 0) - (b.unlockLevel || 0); });
        return list;
    }

    function getUnlocked(playerLevel) {
        var list = [];
        for (var id in definitions) {
            if (definitions[id].unlockLevel <= playerLevel) list.push(definitions[id]);
        }
        return list;
    }

    return {
        get: get,
        getForStore: getForStore,
        getUnlocked: getUnlocked
    };
})();
