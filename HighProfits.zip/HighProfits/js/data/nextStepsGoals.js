/**
 * Next steps / onboarding goals. Each goal has id, label, view to open, and a check for completion.
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.NextStepsGoals = (function() {
    'use strict';

    function hasSeeds() {
        var inv = HP.State && HP.State.getInventory ? HP.State.getInventory() : null;
        return inv && inv.seeds && Object.keys(inv.seeds).length > 0;
    }

    function hasPlantedPlot() {
        var props = HP.State && HP.State.getProperties ? HP.State.getProperties() : null;
        if (!props || !props.plots) return false;
        for (var propId in props.plots) {
            var plots = props.plots[propId];
            if (!Array.isArray(plots)) continue;
            for (var i = 0; i < plots.length; i++) {
                if (plots[i] && plots[i].status === 'growing') return true;
                if (plots[i] && plots[i].status === 'harvest') return true;
            }
        }
        return false;
    }

    function totalHarvested() {
        var stats = HP.State && HP.State.getStats ? HP.State.getStats() : null;
        return (stats && stats.totalHarvested != null) ? stats.totalHarvested : 0;
    }

    function totalSales() {
        var stats = HP.State && HP.State.getStats ? HP.State.getStats() : null;
        return (stats && stats.totalSales != null) ? stats.totalSales : 0;
    }

    var GOALS = [
        {
            id: 'first_seeds',
            label: 'Buy your first seeds',
            viewId: 'dealer',
            triggerId: 'goal_first_seeds',
            isComplete: function() { return hasSeeds(); }
        },
        {
            id: 'first_plot',
            label: 'Set up a plot and plant',
            viewId: 'grow',
            triggerId: 'goal_first_plot',
            isComplete: function() { return hasPlantedPlot(); }
        },
        {
            id: 'first_harvest',
            label: 'Harvest your first plant',
            viewId: 'grow',
            triggerId: 'goal_first_harvest',
            isComplete: function() { return totalHarvested() >= 1; }
        },
        {
            id: 'first_sale',
            label: 'Sell product on the Market',
            viewId: 'market',
            viewIdAlt: 'inventory',
            triggerId: 'goal_first_sale',
            isComplete: function() { return totalSales() >= 1; }
        },
        {
            id: 'harvest_10',
            label: 'Harvest 10 plants total',
            viewId: 'grow',
            triggerId: 'goal_harvest_10',
            isComplete: function() { return totalHarvested() >= 10; }
        }
    ];

    return {
        getAll: function() { return GOALS.slice(); },
        getIncomplete: function() {
            var list = [];
            for (var i = 0; i < GOALS.length; i++) {
                var g = GOALS[i];
                if (HP.State && HP.State.hasProgressTrigger && HP.State.hasProgressTrigger(g.triggerId)) continue;
                if (g.isComplete && g.isComplete()) {
                    if (HP.State && HP.State.setProgressTrigger) HP.State.setProgressTrigger(g.triggerId, true);
                    continue;
                }
                list.push(g);
            }
            return list;
        }
    };
})();
