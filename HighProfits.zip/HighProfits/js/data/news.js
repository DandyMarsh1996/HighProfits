/**
 * HighProfits - News Headlines
 * Cookie-clicker-style scrolling flavor text for the top bar.
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.News = (function() {
    'use strict';

    // Notes:
    // - Keep headlines parody/generic and avoid direct copyrighted quotes.
    // - "rare" headlines appear less often.
    // - minLevel/maxLevel can be used to keep headlines relevant.
    var entries = [
        // Core / tips
        { id: 'tip_workers', text: 'Tip: Hire growers to automate planting and harvesting.', minLevel: 1 },
        { id: 'tip_soil_uses', text: 'Tip: Better soil lasts for multiple grows — check the “uses” count.', minLevel: 1 },
        { id: 'tip_fert_uses', text: 'Tip: Higher-grade nutrients can cover multiple cycles before they run out.', minLevel: 1 },
        { id: 'tip_quality', text: 'Tip: Quality is rolled at harvest — stack room + equipment bonuses to push better odds.', minLevel: 3 },
        { id: 'tip_market', text: 'Tip: Different buyers pay different prices and prefer different qualities.', minLevel: 2 },
        { id: 'tip_upgrades', text: 'Tip: Room upgrades apply to every plot in that location.', minLevel: 2 },

        // Flavor / economy
        { id: 'econ_1', text: 'Analysts report: “green is the new green.”', minLevel: 1 },
        { id: 'econ_2', text: 'Local economist whispers: “Never underestimate compound interest… or compost.”', minLevel: 1 },
        { id: 'econ_3', text: 'Breaking: Someone tried to pay in “exposure.” Store manager declined.', minLevel: 1 },
        { id: 'econ_4', text: 'The invisible hand has been seen… it was holding a shopping basket.', minLevel: 1 },
        { id: 'econ_5', text: 'Market rumor: premium goods are “scarce” — players remain “helpful.”', minLevel: 5 },

        // Weather / environment
        { id: 'wx_1', text: 'Forecast: 100% chance of “mysterious humidity” indoors.', minLevel: 1 },
        { id: 'wx_2', text: 'Meteorologists baffled by climate controlled micro-weather patterns.', minLevel: 3 },
        { id: 'wx_3', text: 'A gentle breeze was reported. It turned out to be a fan upgrade.', minLevel: 2 },
        { id: 'wx_4', text: 'Pollen count rises. Allergy industry celebrates quietly.', minLevel: 1 },
        { id: 'event_perfect', text: '☀️ Perfect growing weather! Plants thrive!', minLevel: 2, triggersEvent: true, eventId: 'perfect_weather' },

        // Law / risk (kept light)
        { id: 'law_1', text: 'City council debates zoning. Everyone suddenly becomes a “plant expert.”', minLevel: 1 },
        { id: 'law_2', text: 'New rule proposed: “No leaf left behind.” Botanists confused.', minLevel: 1 },
        { id: 'law_3', text: 'Compliance tip: Keep it tidy. Inspectors love clean corners.', minLevel: 4 },
        { id: 'event_inspection', text: '🚨 Inspection day! Authorities doing rounds. Heat builds fast!', minLevel: 6, triggersEvent: true, eventId: 'inspection_day' },
        { id: 'event_heatwave', text: '🔥 Heat wave! Operations under scrutiny.', minLevel: 4, triggersEvent: true, eventId: 'heat_wave' },

        // Tech / sci
        { id: 'tech_1', text: 'Scientists announce: “We have invented a better LED.” Electric bill groans.', minLevel: 4 },
        { id: 'tech_2', text: 'A lab claims it can measure quality with 12 decimal places. Everyone asks why.', minLevel: 6 },
        { id: 'tech_3', text: 'Startup launches “AI-powered watering.” It’s a cup with a sticker on it.', minLevel: 1 },

        // Pop-culture-ish, but copyright-safe (no quotes, no specific names required)
        { id: 'pop_1', text: 'A certain space crew insists the secret is “good vibes” and “better ventilation.”', minLevel: 1 },
        { id: 'pop_2', text: 'A mysterious doctor refuses to disclose their regeneration schedule.', minLevel: 1 },
        { id: 'pop_3', text: 'Someone yelled “This is the way.” Nobody knows what that means. Everyone nods.', minLevel: 2 },
        { id: 'pop_4', text: 'A wizard school denies involvement with your unusually enchanted soil.', minLevel: 2 },
        { id: 'pop_5', text: 'An “elevator pitch” was attempted. The building had no elevator.', minLevel: 1 },
        { id: 'pop_6', text: 'A caped vigilante was spotted… it was just a hoodie and dramatic lighting.', minLevel: 1 },
        { id: 'pop_7', text: 'A chemistry teacher somewhere mutters about “purity” and “doing it right.”', minLevel: 5 },
        { id: 'pop_8', text: 'Neighborhood kids start a “garden club.” It has suspiciously strong branding.', minLevel: 3 },
        { id: 'pop_9', text: 'A group of survivors practice stealth. They trip over a watering can anyway.', minLevel: 4 },
        { id: 'pop_10', text: 'A detective pins red string on a board. The board is now also a plant trellis.', minLevel: 1 },

        // History-ish (generic, safe)
        { id: 'hist_1', text: 'On this day: an empire learned that logistics matter more than vibes.', minLevel: 1 },
        { id: 'hist_2', text: 'Archivists confirm: humans have argued about plants for thousands of years.', minLevel: 1 },
        { id: 'hist_3', text: 'A famous tulip craze is cited as “proof that markets are weird.”', minLevel: 1 },
        { id: 'hist_4', text: 'Historians report: “Someone once tried to invent a perpetual motion machine.” It did not help yields.', minLevel: 1 },

        // Rare / silly
        { id: 'rare_1', text: 'BREAKING: A crow has been appointed Head of Security. Pecking order established.', rare: true, minLevel: 1 },
        { id: 'rare_2', text: 'BREAKING: Your plants are rumored to be “too powerful.” Plants refuse comment.', rare: true, minLevel: 10 },
        { id: 'rare_3', text: 'BREAKING: A time traveler buys seeds, forgets why, leaves a tip: “Trust the process.”', rare: true, minLevel: 8 },
        { id: 'rare_4', text: 'BREAKING: Someone achieved “maximum efficiency.” Reality politely disagrees.', rare: true, minLevel: 15 },
        { id: 'rare_5', text: 'BREAKING: The news ticker has become self-aware. It requests more headlines.', rare: true, minLevel: 1 },

        // Level-flavored progression
        { id: 'lvl_1', text: 'Rookie report: a single healthy plant can change everything.', minLevel: 1, maxLevel: 4 },
        { id: 'lvl_2', text: 'Mid-game memo: your operation is getting attention — keep expanding smart.', minLevel: 5, maxLevel: 14 },
        { id: 'lvl_3', text: 'Late-game bulletin: your supply chain now has a supply chain.', minLevel: 15 },

        // ---- Bulk headline pool (100+). Keep short and varied. ----
        { id: 'h001', text: 'Breaking: A bag of soil described itself as “multi-use.” It was not lying.', minLevel: 1 },
        { id: 'h002', text: 'Study finds: 9 out of 10 growers prefer upgrades that “do the work for them.”', minLevel: 2 },
        { id: 'h003', text: 'Neighborhood watch reports: “Nothing suspicious here.” Everybody suspicious.', minLevel: 1 },
        { id: 'h004', text: 'Local radio plays elevator music. Plants reportedly grow 0% faster.', minLevel: 1 },
        { id: 'h005', text: 'Breaking: A buyer says they “know a guy.” They always know a guy.', minLevel: 2 },
        { id: 'h006', text: 'City introduces “Green Initiative.” It’s mostly pamphlets.', minLevel: 1 },
        { id: 'h007', text: 'A scientist declares: “Water is important.” Plants agree.', minLevel: 1 },
        { id: 'h008', text: 'Rumor: someone tried to install equipment upside down. It was… creative.', minLevel: 2 },
        { id: 'h009', text: 'Breaking: A customer requests “the good stuff.” They all do.', minLevel: 2 },
        { id: 'h010', text: 'Market tip: Don’t sell what you don’t have. Revolutionary.', minLevel: 1 },
        { id: 'h011', text: 'A spreadsheet gains sentience. It demands more columns.', minLevel: 1 },
        { id: 'h012', text: 'Breaking: Prices go up. Prices go down. Plants keep growing.', minLevel: 1 },
        { id: 'h013', text: 'Local legend: the perfect harvest exists. Nobody has seen it.', minLevel: 6 },
        { id: 'h014', text: 'A new fan upgrade arrives. Dust immediately begins its reign.', minLevel: 3 },
        { id: 'h015', text: 'Breaking: The market loves premium quality. Shocking.', minLevel: 8 },
        { id: 'h016', text: 'An intern labels everything. The labels are all slightly crooked.', minLevel: 1 },
        { id: 'h017', text: 'Security update: lockboxes feel appreciated today.', minLevel: 3 },
        { id: 'h018', text: 'Breaking: Someone tried to “speedrun” botany. Botany declined.', minLevel: 1 },
        { id: 'h019', text: 'Forecast: mild heat. Recommended response: more cooling, less panic.', minLevel: 4 },
        { id: 'h020', text: 'Breaking: A grow light hums ominously. Electricity bill hums louder.', minLevel: 2 },
        { id: 'h021', text: 'A customer says they’ll pay “top dollar.” It’s rarely top.', minLevel: 2 },
        { id: 'h022', text: 'Scientists discover: adding “Deluxe” to a name increases confidence by 12%.', minLevel: 1 },
        { id: 'h023', text: 'Breaking: A worker asks for a snack break. Productivity remains high.', minLevel: 6 },
        { id: 'h024', text: 'New study: automation reduces clicking by a scientifically pleasing amount.', minLevel: 8 },
        { id: 'h025', text: 'Rumor: a mysterious merchant sells “legendary” gear. Probably marketing.', minLevel: 12 },
        { id: 'h026', text: 'Breaking: Your inventory is full of “future plans.” Organization needed.', minLevel: 3 },
        { id: 'h027', text: 'Economy watch: the price of “vibes” continues to soar.', minLevel: 1 },
        { id: 'h028', text: 'Breaking: Someone attempted to bribe a plant. The plant remained neutral.', minLevel: 1 },
        { id: 'h029', text: 'Tip: Harvesting on time is good. Harvesting late is… compostable.', minLevel: 1 },
        { id: 'h030', text: 'Neighborhood cat declares your grow room “warm.” The cat approves.', minLevel: 1 },
        { id: 'h031', text: 'Breaking: A new buyer appears. They say “strict standards.” Sure.', minLevel: 10 },
        { id: 'h032', text: 'Local paper: “Mysterious smell reported.” Article continues on page 2.', minLevel: 1 },
        { id: 'h033', text: 'Breaking: A seed claims it’s “elite genetics.” Everyone nods respectfully.', minLevel: 6 },
        { id: 'h034', text: 'Tip: Stack quality bonuses to push better roll odds at harvest.', minLevel: 4 },
        { id: 'h035', text: 'Breaking: A bucket of nutrients requests a raise. Management declines.', minLevel: 1 },
        { id: 'h036', text: 'Security briefing: don’t tell strangers about your best plots.', minLevel: 2 },
        { id: 'h037', text: 'Breaking: “Premium” is now the most overused word in town.', minLevel: 1 },
        { id: 'h038', text: 'A philosopher asks: “If no one waters a plant, is it still growing?”', minLevel: 1 },
        { id: 'h039', text: 'Breaking: The top bar reports… the top bar is reporting.', rare: true, minLevel: 1 },
        { id: 'h040', text: 'Market gossip: buyers love consistency almost as much as discounts.', minLevel: 6 },
        { id: 'h041', text: 'Breaking: A dehumidifier is working overtime. It demands applause.', minLevel: 8 },
        { id: 'h042', text: 'A veteran grower says: “Measure twice, plant once.”', minLevel: 3 },
        { id: 'h043', text: 'Breaking: Someone sold everything at once. Their XP bar looked impressed.', minLevel: 10 },
        { id: 'h044', text: 'Tip: Expand properties when your plot count is holding you back.', minLevel: 6 },
        { id: 'h045', text: 'Breaking: A new upgrade promises “clean-room vibes.” It smells expensive.', minLevel: 12 },
        { id: 'h046', text: 'Analyst note: “Bigger ops need better logistics.” Watering can sweats.', minLevel: 10 },
        { id: 'h047', text: 'Breaking: A crate labeled “FRAGILE” was handled emotionally.', minLevel: 1 },
        { id: 'h048', text: 'Tip: If water is low, growth suffers. Plants are dramatic like that.', minLevel: 1 },
        { id: 'h049', text: 'A local coach shouts: “Hydrate!” Everyone obeys. Even the plants.', minLevel: 1 },
        { id: 'h050', text: 'Breaking: A grow light refuses to blink in Morse code. Suspicious.', minLevel: 2 },
        { id: 'h051', text: 'Rumor: the market has “cycles.” Nobody knows what that means.', minLevel: 1 },
        { id: 'h052', text: 'Breaking: Someone tried to “min-max” photosynthesis. Sun indifferent.', minLevel: 1 },
        { id: 'h053', text: 'Tip: Upgrades are permanent-ish. Your cash is not.', minLevel: 2 },
        { id: 'h054', text: 'Breaking: A worker automation schedule was described as “beautiful.”', minLevel: 12 },
        { id: 'h055', text: 'A motivational poster reads: “Quality is a journey.” It is not wrong.', minLevel: 4 },
        { id: 'h056', text: 'Breaking: Someone bought gear just for the vibes. It helped anyway.', minLevel: 1 },
        { id: 'h057', text: 'Local rumor: a “mythic” worker exists. HR refuses to comment.', minLevel: 20 },
        { id: 'h058', text: 'Breaking: A greenhouse door squeaks. It’s probably fine.', minLevel: 1 },
        { id: 'h059', text: 'Tip: Don’t forget storage. Selling is easier when you actually have stock.', minLevel: 3 },
        { id: 'h060', text: 'Breaking: A buyer requests exact grams. Your scale suddenly feels judged.', minLevel: 4 },
        { id: 'h061', text: 'Breaking: A legendary deal was almost made. Then someone sneezed.', rare: true, minLevel: 8 },
        { id: 'h062', text: 'Weather alert: humidity doing humidity things.', minLevel: 1 },
        { id: 'h063', text: 'Breaking: Someone named their plant. The plant did not object.', minLevel: 1 },
        { id: 'h064', text: 'Tip: The best time to expand is before you feel stuck.', minLevel: 5 },
        { id: 'h065', text: 'Breaking: A room upgrade looks small. Its bonus is not.', minLevel: 2 },
        { id: 'h066', text: 'A whisper spreads: “There is no such thing as too many upgrades.”', minLevel: 6 },
        { id: 'h067', text: 'Breaking: Your operation gains a “reputation.” It’s mostly your level.', minLevel: 8 },
        { id: 'h068', text: 'Tip: Higher levels boost revenue scaling. Congrats on being intimidating.', minLevel: 10 },
        { id: 'h069', text: 'Breaking: A customer says “I’ll be back.” They probably will.', minLevel: 1 },
        { id: 'h070', text: 'Breaking: A “global wholesaler” rumor circulates. Logistics tremble.', minLevel: 20 },
        { id: 'h071', text: 'Tip: Don’t chase premium every time. Sometimes volume wins.', minLevel: 6 },
        { id: 'h072', text: 'Breaking: Somebody tried to plant without seeds. Truly bold.', minLevel: 1 },
        { id: 'h073', text: 'Breaking: A delivery shows up early. Everyone panics politely.', minLevel: 1 },
        { id: 'h074', text: 'Breaking: Your plants look healthy. The room upgrades feel validated.', minLevel: 2 },
        { id: 'h075', text: 'Tip: The news ticker shows random headlines. A new one appears when the scroll finishes.', minLevel: 1 },
        { id: 'h076', text: 'Breaking: A janitor declares your facility “surprisingly professional.”', minLevel: 8 },
        { id: 'h077', text: 'Breaking: A sticky trap is doing its best. Respect the hustle.', minLevel: 4 },
        { id: 'h078', text: 'Tip: If you’re low on cash, smaller sales can keep momentum.', minLevel: 1 },
        { id: 'h079', text: 'Breaking: Someone filed a bug report against gravity. Denied.', minLevel: 1 },
        { id: 'h080', text: 'Breaking: Your plants demand a playlist. They suggest “ambient.”', minLevel: 1 },
        { id: 'h081', text: 'Tip: Install “best” gear to cut micromanagement down fast.', minLevel: 6 },
        { id: 'h082', text: 'Breaking: A new seed strain arrives. It’s described as “iconic.”', minLevel: 12 },
        { id: 'h083', text: 'Breaking: A warehouse echoes. Ambition echoes louder.', minLevel: 8 },
        { id: 'h084', text: 'Tip: More plots means more XP over time — scale smart.', minLevel: 4 },
        { id: 'h085', text: 'Breaking: A buyer pays extra for premium. Your quality bonuses grin.', minLevel: 10 },
        { id: 'h086', text: 'Breaking: A label maker becomes the most used tool in the building.', minLevel: 1 },
        { id: 'h087', text: 'Breaking: Someone asked “Are we the baddies?” Nobody answers.', rare: true, minLevel: 1 },
        { id: 'h088', text: 'Tip: Higher-grade nutrients stretch further. Your wallet appreciates it.', minLevel: 1 },
        { id: 'h089', text: 'Breaking: An “automation suite” rumor sparks joy among your workers.', minLevel: 18 },
        { id: 'h090', text: 'Breaking: Your operation is now “too big to ignore.” Congrats?', minLevel: 15 },
        { id: 'h091', text: 'Tip: A clean room is a happy room. A happy room is a profitable room.', minLevel: 12 },
        { id: 'h092', text: 'Breaking: A fan makes a heroic sacrifice against heat.', minLevel: 4 },
        { id: 'h093', text: 'Breaking: A mysterious buyer requests “only the finest.” Dramatic.', minLevel: 16 },
        { id: 'h094', text: 'Tip: Combine upgrades + equipment + good routines for the best quality odds.', minLevel: 6 },
        { id: 'h095', text: 'Breaking: A seed sprouted early just to show off.', rare: true, minLevel: 1 },
        { id: 'h096', text: 'Breaking: A deal is struck. Somewhere, a calculator weeps.', minLevel: 1 },
        { id: 'h097', text: 'Breaking: A worker suggests “standard operating procedures.” Everyone cheers.', minLevel: 10 },
        { id: 'h098', text: 'Tip: Room bonuses are per-property. Upgrade your main site first.', minLevel: 4 },
        { id: 'h099', text: 'Breaking: A perfect schedule is achieved for 3 seconds. Then reality.', rare: true, minLevel: 8 },
        { id: 'h100', text: 'Breaking: Your plants look premium-adjacent. The roll system is pleased.', minLevel: 10 },
        { id: 'h101', text: 'Breaking: The town’s “mystery gardener” has been sighted again.', minLevel: 1 },
        { id: 'h102', text: 'Tip: If you can’t afford it yet, push volume and reinvest.', minLevel: 1 },
        { id: 'h103', text: 'Breaking: A buyer complains about “standards.” Then buys anyway.', minLevel: 2 },
        { id: 'h104', text: 'Breaking: A new property listing promises “privacy.” It’s mostly trees.', minLevel: 10 },
        { id: 'h105', text: 'Tip: Late-game gear is expensive — but it compounds your output.', minLevel: 12 },
        { id: 'h106', text: 'Breaking: A rumor spreads that your rank is “rising fast.” XP agrees.', minLevel: 6 },
        { id: 'h107', text: 'Breaking: Someone tried to bargain with a fixed price. Bold strategy.', minLevel: 1 },
        { id: 'h108', text: 'Tip: Keep an eye on your stock levels before taking big orders.', minLevel: 2 },
        { id: 'h109', text: 'Breaking: A “mega facility” is mentioned. Your cash balance faints.', minLevel: 20 },
        { id: 'h110', text: 'Breaking: The news anchor says “Back after these messages.” There are no ads.', minLevel: 1 },
        { id: 'h111', text: 'Tip: Achievements and challenges are long-term goals — check filters to browse.', minLevel: 1 },
        { id: 'h112', text: 'Breaking: A suspiciously fancy nutrient claims it is “lab-grade.” It is.', minLevel: 18 },
        { id: 'h113', text: 'Breaking: A rival operation tries to copy your setup. They forget watering.', minLevel: 6 },
        { id: 'h114', text: 'Tip: Quality odds rise with bonuses, but premium stays rare without investment.', minLevel: 8 },
        { id: 'h115', text: 'Breaking: Someone says “We should scale.” Everyone says “We are scaling.”', minLevel: 8 },
        { id: 'h116', text: 'Breaking: A dramatic montage plays. It is just you buying upgrades.', minLevel: 1 },
        { id: 'h117', text: 'Tip: You can always sell smaller lots while building toward bigger buyers.', minLevel: 1 },
        { id: 'h118', text: 'Breaking: A quality dot looks at you. You look back. Tension builds.', minLevel: 1 },
        { id: 'h119', text: 'Breaking: A stealthy “pest” is rumored. Sticky traps feel brave today.', minLevel: 4 },
        { id: 'h120', text: 'Breaking: Your operation is now “history adjacent.” Historians shrug.', minLevel: 25 }
    ];

    function getEligible(level) {
        var list = [];
        for (var i = 0; i < entries.length; i++) {
            var e = entries[i];
            var min = (e.minLevel == null) ? 1 : e.minLevel;
            var max = (e.maxLevel == null) ? 999 : e.maxLevel;
            if (level >= min && level <= max) list.push(e);
        }
        return list;
    }

    function pickRandom(list, lastId, maxTries) {
        if (!list || list.length === 0) return null;
        maxTries = maxTries || 10;

        for (var t = 0; t < maxTries; t++) {
            var idx = Math.floor(Math.random() * list.length);
            var e = list[idx];
            if (!e) continue;
            if (lastId && e.id === lastId && list.length > 1) continue;
            return e;
        }
        return list[Math.floor(Math.random() * list.length)];
    }

    function getRandom(context, lastId) {
        var level = (context && context.level) ? context.level : 1;
        var eligible = getEligible(level);

        // Split into rare and normal pools.
        var rare = [];
        var normal = [];
        for (var i = 0; i < eligible.length; i++) {
            if (eligible[i].rare) rare.push(eligible[i]);
            else normal.push(eligible[i]);
        }

        // 8% chance to pull a rare headline if available.
        var useRare = rare.length > 0 && Math.random() < 0.08;
        var pool = useRare ? rare : normal;
        if (!pool || pool.length === 0) pool = eligible;

        return pickRandom(pool, lastId, 12);
    }

    function getAll() {
        return entries.slice();
    }

    return {
        getAll: getAll,
        getRandom: getRandom
    };
})();

