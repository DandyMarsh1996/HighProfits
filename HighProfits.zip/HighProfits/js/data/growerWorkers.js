/**
 * HighProfits - Grower Worker Definitions
 * Workers that can automate plot management (planting, watering, harvesting)
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.GrowerWorkers = (function() {
    'use strict';

    var definitions = {
        apprentice_grower: {
            id: 'apprentice_grower',
            name: 'Apprentice Grower',
            description: 'Basic grower. Works slowly but gets the job done.',
            icon: '🌱',
            baseCost: 500,
            costMultiplier: 1.2,
            unlockLevel: 1,
            efficiency: 1.0,  // Base efficiency multiplier
            wateringSpeed: 1.0  // How fast they water plants
        },
        experienced_grower: {
            id: 'experienced_grower',
            name: 'Experienced Grower',
            description: 'Skilled grower. Faster and more efficient.',
            icon: '👨‍🌾',
            baseCost: 2000,
            costMultiplier: 1.25,
            unlockLevel: 8,
            efficiency: 1.5,
            wateringSpeed: 1.3
        },
        master_grower: {
            id: 'master_grower',
            name: 'Master Grower',
            description: 'Expert grower. Maximum efficiency and speed.',
            icon: '👨‍🔬',
            baseCost: 10000,
            costMultiplier: 1.3,
            unlockLevel: 15,
            efficiency: 2.0,
            wateringSpeed: 1.5
        },
        senior_grower: {
            id: 'senior_grower',
            name: 'Senior Grower',
            description: 'Veteran grower. Handles big rooms efficiently.',
            icon: '🧑‍🌾',
            baseCost: 50000,
            costMultiplier: 1.35,
            unlockLevel: 20,
            efficiency: 2.6,
            wateringSpeed: 1.8
        },
        legendary_grower: {
            id: 'legendary_grower',
            name: 'Legendary Grower',
            description: 'Endgame expert. Peak efficiency and consistency.',
            icon: '🏆',
            baseCost: 220000,
            costMultiplier: 1.38,
            unlockLevel: 24,
            efficiency: 3.5,
            wateringSpeed: 2.2
        },
        mythic_grower: {
            id: 'mythic_grower',
            name: 'Mythic Grower',
            description: 'The best of the best. Runs like a machine.',
            icon: '👑',
            baseCost: 900000,
            costMultiplier: 1.42,
            unlockLevel: 25,
            efficiency: 4.2,
            wateringSpeed: 2.6
        }
    };

    return {
        getAll: function() {
            return definitions;
        },
        get: function(id) {
            return definitions[id] || null;
        },
        getIds: function() {
            return Object.keys(definitions);
        },
        getUnlocked: function(playerLevel) {
            var unlocked = [];
            for (var id in definitions) {
                if (definitions[id].unlockLevel <= playerLevel) {
                    unlocked.push(definitions[id]);
                }
            }
            return unlocked;
        }
    };
})();
