/**
 * HighProfits - Grower Worker Definitions
 * Workers that can automate plot management (planting, watering, harvesting)
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.GrowerWorkers = (function() {
    'use strict';

    var definitions = {
        apprentice_grower: {
            id: 'apprentice_grower',
            name: 'Apprentice Grower',
            description: 'Basic grower. Works slowly but gets the job done.',
            icon: '🌱',
            baseCost: 500,
            costMultiplier: 1.2,
            unlockLevel: 1,
            efficiency: 1.0,
            wateringSpeed: 1.0,
            wagePerDay: 220,   // Paid from wage fund each game day (12 min); tuned vs plot revenue
            traits: []
        },
        experienced_grower: {
            id: 'experienced_grower',
            name: 'Experienced Grower',
            description: 'Skilled grower. Faster and more efficient.',
            icon: '👨‍🌾',
            baseCost: 2000,
            costMultiplier: 1.25,
            unlockLevel: 8,
            efficiency: 1.5,
            wateringSpeed: 1.3,
            wagePerDay: 780,
            traits: ['speedFocus']
        },
        master_grower: {
            id: 'master_grower',
            name: 'Master Grower',
            description: 'Expert grower. Maximum efficiency and speed.',
            icon: '👨‍🔬',
            baseCost: 10000,
            costMultiplier: 1.3,
            unlockLevel: 15,
            efficiency: 2.0,
            wateringSpeed: 1.5,
            wagePerDay: 2600,
            traits: ['qualityFocus', 'speedFocus']
        },
        senior_grower: {
            id: 'senior_grower',
            name: 'Senior Grower',
            description: 'Veteran grower. Handles big rooms efficiently.',
            icon: '🧑‍🌾',
            baseCost: 50000,
            costMultiplier: 1.35,
            unlockLevel: 20,
            efficiency: 2.6,
            wateringSpeed: 1.8,
            wagePerDay: 11000,
            traits: ['qualityFocus', 'waterSaver']
        },
        legendary_grower: {
            id: 'legendary_grower',
            name: 'Legendary Grower',
            description: 'Endgame expert. Peak efficiency and consistency.',
            icon: '🏆',
            baseCost: 220000,
            costMultiplier: 1.38,
            unlockLevel: 24,
            efficiency: 3.5,
            wateringSpeed: 2.2,
            wagePerDay: 68400,
            traits: ['qualityFocus', 'speedFocus', 'waterSaver']
        },
        mythic_grower: {
            id: 'mythic_grower',
            name: 'Mythic Grower',
            description: 'The best of the best. Runs like a machine.',
            icon: '👑',
            baseCost: 900000,
            costMultiplier: 1.42,
            unlockLevel: 25,
            efficiency: 4.2,
            wateringSpeed: 2.6,
            wagePerDay: 165000,
            traits: ['qualityFocus', 'speedFocus', 'waterSaver']
        }
    };

    var TRAIT_LABELS = {
        qualityFocus: { name: 'Quality focus', icon: '⭐', desc: 'Slight harvest quality bonus' },
        speedFocus: { name: 'Speed focus', icon: '⚡', desc: 'Faster action cooldowns' },
        waterSaver: { name: 'Water saver', icon: '💧', desc: 'Uses less reservoir per water' }
    };

    return {
        getAll: function() {
            return definitions;
        },
        get: function(id) {
            return definitions[id] || null;
        },
        getIds: function() {
            return Object.keys(definitions);
        },
        getUnlocked: function(playerLevel) {
            var unlocked = [];
            for (var id in definitions) {
                if (definitions[id].unlockLevel <= playerLevel) {
                    unlocked.push(definitions[id]);
                }
            }
            return unlocked;
        },
        /** Worker types not yet unlocked (unlockLevel > playerLevel), sorted by unlock level for "next" display */
        getLocked: function(playerLevel) {
            var locked = [];
            for (var id in definitions) {
                if (definitions[id].unlockLevel > playerLevel) {
                    locked.push(definitions[id]);
                }
            }
            locked.sort(function(a, b) { return a.unlockLevel - b.unlockLevel; });
            return locked;
        },
        /** Next tier (higher unlockLevel) for upgrading; null if current is max */
        getNextTier: function(workerTypeId) {
            var current = definitions[workerTypeId];
            if (!current) return null;
            var ordered = Object.keys(definitions)
                .map(function(id) { return definitions[id]; })
                .sort(function(a, b) { return a.unlockLevel - b.unlockLevel || a.id.localeCompare(b.id); });
            var idx = ordered.findIndex(function(t) { return t.id === workerTypeId; });
            if (idx < 0 || idx >= ordered.length - 1) return null;
            return ordered[idx + 1];
        },
        getTraitLabels: function() {
            return TRAIT_LABELS;
        },
        hasTrait: function(workerType, traitId) {
            var t = workerType && workerType.traits;
            return Array.isArray(t) && t.indexOf(traitId) !== -1;
        }
    };
})();
