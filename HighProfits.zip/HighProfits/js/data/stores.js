/**
 * HighProfits - Store Definitions
 * Different stores where players can buy items
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Stores = (function() {
    'use strict';

    var definitions = {
        hardware_store: {
            id: 'hardware_store',
            name: 'Hardware Store',
            description: 'Electrical supplies, fans, and lighting equipment.',
            icon: '🔧',
            unlockLevel: 1,
            categories: ['lighting', 'environment'],
            // Items are defined in equipment.js with store reference
        },
        garden_centre: {
            id: 'garden_centre',
            name: 'Garden Centre',
            description: 'Pots, soil, and plant nutrients.',
            icon: '🌻',
            unlockLevel: 1,
            categories: ['essential', 'nutrients']
        },
        dealer: {
            id: 'dealer',
            name: 'Seed Dealer',
            description: 'Your connection for seeds. Meets behind the gas station.',
            icon: '🕵️',
            unlockLevel: 1,
            categories: ['seeds'],
            heatOnPurchase: 0.5  // Buying from dealer adds heat
        },
        real_estate: {
            id: 'real_estate',
            name: 'Real Estate',
            description: 'Properties for expanding your operation.',
            icon: '🏢',
            unlockLevel: 1,
            categories: ['properties']
        }
    };

    return {
        getAll: function() {
            return definitions;
        },

        get: function(id) {
            return definitions[id] || null;
        },

        getIds: function() {
            return Object.keys(definitions);
        },

        getUnlocked: function(playerLevel) {
            var unlocked = [];
            for (var id in definitions) {
                if (definitions[id].unlockLevel <= playerLevel) {
                    unlocked.push(definitions[id]);
                }
            }
            return unlocked;
        },

        // Get all items available at a store
        getStoreItems: function(storeId) {
            var store = definitions[storeId];
            if (!store) return [];

            var items = [];

            // Get equipment from this store
            if (storeId !== 'dealer' && storeId !== 'real_estate') {
                var equipment = HP.Data.Equipment.getByStore(storeId);
                items = items.concat(equipment);
            }

            // Get seeds from dealer
            if (storeId === 'dealer') {
                var seeds = HP.Data.Seeds.getAll();
                for (var id in seeds) {
                    items.push(seeds[id]);
                }
            }

            // Get properties from real estate
            if (storeId === 'real_estate') {
                var properties = HP.Data.Properties.getAll();
                for (var id in properties) {
                    items.push(properties[id]);
                }
            }

            return items;
        }
    };
})();
