/**
 * HighProfits - Changelog
 * Version notes displayed on the main menu
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Changelog = (function() {
    'use strict';

    var entries = [
        {
            version: '0.3.0',
            date: '2025-01-28',
            changes: [
                'Property-based cash & bank caps – bigger properties add more capacity',
                'Per-property cap bonuses – warehouse, farm, mega facility each add unique amounts',
                'Raid & heat rebalancing – slower heat gain, lighter raid penalties (18% money, 22% product)',
                'Challenge rewards – titles unlock for Harvest Master, Money Maker, Property Mogul, Real Estate King, Veteran',
                'More journal entries – first harvest, first worker, property tiers, water/heat milestones',
                'Expanded Rais tutorial – water, heat, workers, laundering tips via level hints',
                'Real changelog – version notes on main menu'
            ]
        },
        {
            version: '0.2.0',
            date: '2025-01-27',
            changes: [
                'Dual currency – cash (street) and bank (legitimate) with laundering & withdrawal',
                'Welcome tour for new characters',
                'Keyboard shortcuts – number keys for views, hotkeys for actions',
                'Sound – UI clicks, ambient loops, raid/low water warnings',
                'Save/load/export/import in Settings',
                'Character deletion with name confirmation',
                'Journal shows unlocked titles'
            ]
        },
        {
            version: '0.1.0',
            date: '2025-01-20',
            changes: [
                'Multi-character saves with character select screen',
                'Grow, harvest, sell, breed strains',
                'Properties, workers, heat system, raids',
                'Journal, titles, challenges, achievements',
                'Water reservoir, room upgrades'
            ]
        }
    ];

    function getAll() {
        return entries.slice();
    }

    return { getAll: getAll };
})();
