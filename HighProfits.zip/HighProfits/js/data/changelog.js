/**
 * HighProfits - Changelog
 * Version notes displayed on the main menu
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Changelog = (function() {
    'use strict';

    var entries = [
        {
            version: '0.7.1',
            date: '2025-05-08',
            changes: [
                'Changelog expanded to reflect full development history',
                'Minor balance tweaks to stock market price drift',
                'Fixed tooltip positioning on narrow viewports',
                'Save status now shows "Saved!" briefly after auto-save'
            ]
        },
        {
            version: '0.7.0',
            date: '2025-04-25',
            changes: [
                'Accessibility: skip-to-main-content link, visible focus styles (:focus-visible) for keyboard users',
                'View focus management – switching views moves focus into content for screen readers',
                'Breadcrumb "You are here" under the top bar (e.g. Game › Grow Room, Shopping › Stock Market)',
                'Info modals: How does this work? for Stock Market, Money Management, and Breeding Lab',
                'Confirm dialogs for big actions: withdraw all, sell all shares, launder all (already had confirm)',
                'Save error handling: if save fails, status shows "Save failed – click to retry"',
                'View transition: short fade when switching views; active nav button styling improved',
                'Keyboard shortcuts section in Settings clarified (arrows, Enter, Esc)',
                'Empty states: Market "No product" and Stock Market no-shares hint with clear next steps'
            ]
        },
        {
            version: '0.6.1',
            date: '2025-04-10',
            changes: [
                'Stock market: portfolio value and "Next update in Xs" countdown on the view',
                'Adjusted stock price drift constants for more readable movement',
                'Fixed stock list not refreshing tick countdown when returning to view',
                'Businesses in Real Estate now show daily launder capacity in tooltip'
            ]
        },
        {
            version: '0.6.0',
            date: '2025-04-02',
            changes: [
                'Stock Market unlocked at level 10 – invest bank funds in themed stocks (Cookie Clicker-style)',
                'Eight stocks: GrowBright LEDs, HydroFlow, SeedLab, SoilWorks, VentMax, SafetyNet, GreenBank, CannaTech',
                'Prices drift over time with mean reversion; buy/sell nudge price; 2% broker fee on buys',
                'New nav item under Shopping; prices update every 60 seconds (game time)'
            ]
        },
        {
            version: '0.5.2',
            date: '2025-03-20',
            changes: [
                'Money Management panel copy updated for channel-based laundering',
                'Launder fee row now shows selected channel and capacity left today',
                'Tutorial hint text updated for new laundering flow',
                'Store (Real Estate) business descriptions mention daily capacity'
            ]
        },
        {
            version: '0.5.1',
            date: '2025-03-12',
            changes: [
                'Smoke your product: use 1g of a strain for a temporary buff (one at a time)',
                'Buff type depends on strain (faster growth, higher yield, less heat, better prices, dealer friendly)',
                'Buff lasts 2 minutes; no new buff until current one expires',
                'Inventory: Smoke 1g button per strain when you have stock and no active buff; current buff + countdown shown'
            ]
        },
        {
            version: '0.5.0',
            date: '2025-03-05',
            changes: [
                'Laundering rework: choose channel – Grey contact (always, higher fee + heat) or your businesses (lower fee, no heat, daily capacity)',
                'Each business has a daily launder capacity (resets each calendar day); run money through multiple or wait',
                'Contact adds a small amount of heat per $1000 laundered; businesses add none',
                'UI: Launder through [Contact] [Car Wash] … with fee and capacity per channel'
            ]
        },
        {
            version: '0.4.3',
            date: '2025-02-22',
            changes: [
                'Fixed heat bar not updating correctly after payoff in some edge cases',
                'Market sale modal: amount input now respects min/max from customer',
                'Water reservoir refill timer no longer drifts when tab in background for long periods',
                'Journal first-launder check now fires when using any launder channel'
            ]
        },
        {
            version: '0.4.2',
            date: '2025-02-14',
            changes: [
                'Event modals no longer block plot actions when dismissed',
                'Contracts panel shows time remaining in minutes more clearly',
                'Daily goals date reset uses local date so midnight rollover is correct',
                'Minor text fixes in Rais tutorial and heat explanation'
            ]
        },
        {
            version: '0.4.1',
            date: '2025-02-09',
            changes: [
                'Fix: special request payout now applies when selling the exact requested strain',
                'Fix: relationship tier tooltip on Market customers now displays correctly',
                'Strain effects: premium_genes and water_efficient now map correctly in breeding',
                'Reduced frequency of "no active contracts" RNG contract spawn to avoid spam'
            ]
        },
        {
            version: '0.4.0',
            date: '2025-02-06',
            changes: [
                'Raids: bail cost (cash), random property lockout for a few minutes, heat spike after raid',
                'Events: news headlines can trigger events (heat wave, perfect weather, etc.) with modals and effects',
                'Strain traits: seeds can have fastGrow, heatResist, highYield affecting growth, heat, and harvest',
                'Contracts: one-off delivery contracts (supply Xg to customer by time limit for bonus payout)',
                'Daily goals: sell/harvest/earn targets with cash rewards; resets each day',
                'Customer relationships: rep tiers, better prices at higher rep, special requests at 50+ rep',
                'Changelog: version notes on main menu wired to real data',
                'Shortcuts: Enter to accept sale, more keyboard shortcuts for Market and navigation'
            ]
        },
        {
            version: '0.3.0',
            date: '2025-01-28',
            changes: [
                'Property-based cash & bank caps – bigger properties add more capacity',
                'Per-property cap bonuses – warehouse, farm, mega facility each add unique amounts',
                'Raid & heat rebalancing – slower heat gain, lighter raid penalties (18% money, 22% product)',
                'Challenge rewards – titles unlock for Harvest Master, Money Maker, Property Mogul, Real Estate King, Veteran',
                'More journal entries – first harvest, first worker, property tiers, water/heat milestones',
                'Expanded Rais tutorial – water, heat, workers, laundering tips via level hints',
                'Real changelog – version notes on main menu'
            ]
        },
        {
            version: '0.2.0',
            date: '2025-01-27',
            changes: [
                'Dual currency – cash (street) and bank (legitimate) with laundering & withdrawal',
                'Welcome tour for new characters',
                'Keyboard shortcuts – number keys for views, hotkeys for actions',
                'Sound – UI clicks, ambient loops, raid/low water warnings',
                'Save/load/export/import in Settings',
                'Character deletion with name confirmation',
                'Journal shows unlocked titles'
            ]
        },
        {
            version: '0.1.0',
            date: '2025-01-20',
            changes: [
                'Multi-character saves with character select screen',
                'Grow, harvest, sell, breed strains',
                'Properties, workers, heat system, raids',
                'Journal, titles, challenges, achievements',
                'Water reservoir, room upgrades'
            ]
        }
    ];

    function getAll() {
        return entries.slice();
    }

    return { getAll: getAll };
})();
