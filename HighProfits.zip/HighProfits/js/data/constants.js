/**
 * HighProfits - Game Constants
 * Central location for all game balance values and configuration
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Constants = (function() {
    'use strict';

    return {
        // ===================
        // GAME TIMING
        // ===================
        TICK_RATE: 1000,              // Game tick in milliseconds
        AUTO_SAVE_INTERVAL: 60000,    // Auto-save every 60 seconds
        OFFLINE_MAX_SECONDS: 3600,    // Max offline progress (1 hour)
        
        // ===================
        // STARTING VALUES
        // ===================
        STARTING_MONEY: 100,           // Legacy; use STARTING_CASH + STARTING_BANK
        STARTING_MONEY_CAP: 1000,
        STARTING_CASH: 100,            // Dirty money (street sales, cash-only purchases)
        STARTING_BANK: 100,            // Clean money (legitimate stores)
        CASH_CAP_BASE: 5000,           // Base cash cap (1 property)
        CASH_CAP_PER_PROPERTY: 5000,   // +cash cap per property owned
        BANK_CAP_BASE: 10000,          // Base bank cap (1 property)
        BANK_CAP_PER_PROPERTY: 10000,  // +bank cap per property owned

        // ===================
        // MONEY LAUNDERING (strategic: choose channel; businesses have daily capacity)
        // ===================
        LAUNDERING_FEE_PERCENT: 25,       // Base fee for businesses (reduced by owning businesses)
        LAUNDER_CONTACT_FEE_PERCENT: 28,  // Grey contact: always available, higher fee
        LAUNDER_CONTACT_HEAT_PER_1000: 0.4,  // Heat added per $1000 laundered via contact (businesses = 0)

        // ===================
        // STOCK MARKET (Cookie Clicker-style: prices drift, mean-revert; buy/sell nudge price)
        // ===================
        STOCK_MARKET_UNLOCK_LEVEL: 10,
        STOCK_PRICE_MIN: 1,
        STOCK_PRICE_FLOOR_BUMP: 5,       // When price < this, nudge toward it (Cookie Clicker style)
        STOCK_BROKER_FEE_PERCENT: 2,    // Fee on buy (sell is at full price)
        STOCK_MEAN_REVERT_RATE: 0.01,   // Per tick: price moves this fraction toward basePrice
        STOCK_RANDOM_RANGE: 2,          // Max random +/- per tick
        STOCK_BUY_IMPACT: 0.0003,       // price *= 1 + shares * this when buying
        STOCK_SELL_IMPACT: 0.00015,     // price *= 1 - shares * this when selling
        STOCK_TICK_INTERVAL_SEC: 60,    // Price update every N seconds (game time)

        STARTING_STORAGE_CAPACITY: 100,
        STARTING_REPUTATION: 50,      // 0-100, 50 is neutral
        STARTING_HEAT: 0,
        MAX_HEAT: 100,

        // Water reservoir - timer refill (1 charge per interval); upgrades increase capacity
        // Rebalanced so water is scarce: small base, slower refill, meaningful upgrades
        WATER_RESERVOIR_BASE_CAPACITY: 12,
        WATER_REFILL_INTERVAL_SECONDS: 12,
        WATER_COST_PER_USE: 1,
        
        // ===================
        // XP REWARDS (Smooth 1–25 curve; fallback when Progression.calculateXP* not used)
        // ===================
        XP_PER_PLANT_READY: 8,
        XP_PER_HARVEST: 18,           // Bumped for smoother late-game leveling
        XP_PER_SALE: 3,               // Bumped for smoother progression
        XP_PER_PROPERTY: 50,
        XP_PER_EQUIPMENT_INSTALL: 3,
        XP_PER_SEED_PLANTED: 2,
        
        // ===================
        // HEAT SYSTEM
        // ===================
        HEAT_PER_SALE: 0.08,
        HEAT_PER_MANUAL_SALE: 0.04,
        HEAT_DECAY_RATE: 0,           // Passive decay disabled – raids are inevitable; only pay-offs reduce heat
        // Heat from actively growing plots (per plot per second, 0–100 scale). Kept low so early game isn’t punishing.
        HEAT_PER_GROWING_PLOT_PER_SECOND: 0.04,
        // Pay-off cost multiplier: each bribe/hide/cleaners is this much more expensive (resets after raid)
        HEAT_PAYOFF_COST_MULTIPLIER: 1.5,
        // Security room upgrades reduce heat gain (e.g. 0.04 = 4% less per upgrade, min multiplier 0.5)
        HEAT_SECURITY_REDUCTION_PER_UPGRADE: 0.04,
        // Raid: when heat hits 100, lose this % of money and product (balanced for fairer recovery)
        RAID_MONEY_LOSS_PERCENT: 18,
        RAID_PRODUCT_LOSS_PERCENT: 22,
        RAID_BAIL_PERCENT: 12,           // Bail paid from cash (reduces cash loss slightly but still costly)
        RAID_PROPERTY_LOCK_MINUTES: 3,  // One random property locked this long after a raid
        RAID_HEAT_AFTER: 15,            // Heat set to this after raid (spike so not immediately safe)
        RAID_MIN_MONEY_AFTER: 100,      // Never leave player with less than this (cash + bank) so they can recover
        RAID_MIN_PRODUCT_LEFT: 1,        // If they had any product, leave at least this many grams of one strain

        // Heat reduction base costs (before exponential scaling)
        HEAT_BRIBE_COST: 500,
        HEAT_BRIBE_REDUCTION: 10,
        HEAT_HIDE_COST: 2000,
        HEAT_HIDE_REDUCTION: 25,
        HEAT_CLEANERS_COST: 10000,
        HEAT_CLEANERS_REDUCTION: 50,

        // ===================
        // CUSTOMER REPUTATION (per-dealer)
        // ===================
        // Deal type when selling: discount = sell cheaper for more rep, normal = small rep, overcharge = more $ but lose rep
        REP_DEAL_DISCOUNT_PRICE_MULT: 0.85,
        REP_DEAL_DISCOUNT_REP_GAIN: 3,
        REP_DEAL_NORMAL_REP_GAIN: 1,
        REP_DEAL_OVERCHARGE_PRICE_MULT: 1.20,
        REP_DEAL_OVERCHARGE_REP_LOSS: 2,
        // Reputation thresholds (rep points) -> price bonus when trading with that dealer (multiplier, e.g. 1.05 = +5%)
        REP_THRESHOLDS: [10, 25, 50, 100, 200],
        REP_BONUS_PER_THRESHOLD: 0.03,
        
        // ===================
        // STORAGE
        // ===================
        STORAGE_BASE_COST: 200,
        STORAGE_COST_MULTIPLIER: 1.2,
        STORAGE_CAPACITY_PER_LEVEL: 100,
        
        // ===================
        // ECONOMY
        // ===================
        DEFAULT_COST_MULTIPLIER: 1.15,  // Cost scaling for workers

        // Fallback when player is completely broke (emergency cash)
        FALLBACK_HUSTLE_CASH: 75,           // Cash granted (enough for seeds + buffer)
        FALLBACK_HUSTLE_COOLDOWN_MS: 300000, // 5 minutes real-time between uses
        FALLBACK_HUSTLE_THRESHOLD: 100,     // Only available when total money (cash + bank) is below this

        // Smoke product buff (one at a time, consumes weed)
        SMOKE_GRAMS_PER_USE: 1,
        SMOKE_BUFF_DURATION_MS: 120000,     // 2 minutes real-time
        SMOKE_BUFF_GROWTH_MULT: 0.9,        // 10% faster growth
        SMOKE_BUFF_YIELD_MULT: 1.1,         // 10% more yield
        SMOKE_BUFF_HEAT_MULT: 0.85,         // 15% less heat gain
        SMOKE_BUFF_SALE_MULT: 1.1,          // 10% higher sale price
        SMOKE_BUFF_REP_BONUS: 1,            // +1 rep per sale

        // ===================
        // SAVE SYSTEM
        // ===================
        SAVE_KEY: 'highprofits_save',
        SAVE_VERSION: 2,
        DRAFT_CHARACTER_NAME_KEY: 'highprofits_draft_character_name'
    };
})();
