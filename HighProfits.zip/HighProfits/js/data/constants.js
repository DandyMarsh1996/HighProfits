/**
 * HighProfits - Game Constants
 * Central location for all game balance values and configuration
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Constants = (function() {
    'use strict';

    return {
        // ===================
        // GAME TIMING
        // ===================
        TICK_RATE: 1000,              // Game tick in milliseconds
        AUTO_SAVE_INTERVAL: 60000,    // Auto-save every 60 seconds
        OFFLINE_MAX_SECONDS: 3600,    // Max offline progress (1 hour)
        
        // ===================
        // STARTING VALUES
        // ===================
        STARTING_MONEY: 100,
        STARTING_MONEY_CAP: 1000,
        STARTING_STORAGE_CAPACITY: 100,
        STARTING_REPUTATION: 50,      // 0-100, 50 is neutral
        STARTING_HEAT: 0,
        MAX_HEAT: 100,

        // Water reservoir - timer refill (1 charge per interval); upgrades increase capacity
        // Rebalanced so water is scarce: small base, slower refill, meaningful upgrades
        WATER_RESERVOIR_BASE_CAPACITY: 12,
        WATER_REFILL_INTERVAL_SECONDS: 12,
        WATER_COST_PER_USE: 1,
        
        // ===================
        // XP REWARDS (Smooth 1–25 curve; fallback when Progression.calculateXP* not used)
        // ===================
        XP_PER_PLANT_READY: 8,
        XP_PER_HARVEST: 18,           // Bumped for smoother late-game leveling
        XP_PER_SALE: 3,               // Bumped for smoother progression
        XP_PER_PROPERTY: 50,
        XP_PER_EQUIPMENT_INSTALL: 3,
        XP_PER_SEED_PLANTED: 2,
        
        // ===================
        // HEAT SYSTEM
        // ===================
        HEAT_PER_SALE: 0.1,
        HEAT_PER_MANUAL_SALE: 0.05,
        HEAT_DECAY_RATE: 0.005,       // Per second (0.5%)
        // Heat from actively growing plots (per plot per second)
        HEAT_PER_GROWING_PLOT_PER_SECOND: 0.015,
        // Pay-off cost multiplier: each bribe/hide/cleaners is this much more expensive (resets after raid)
        HEAT_PAYOFF_COST_MULTIPLIER: 1.5,
        // Security room upgrades reduce heat gain (e.g. 0.04 = 4% less per upgrade, min multiplier 0.5)
        HEAT_SECURITY_REDUCTION_PER_UPGRADE: 0.04,
        // Raid: when heat hits 100, lose this % of money and product
        RAID_MONEY_LOSS_PERCENT: 25,
        RAID_PRODUCT_LOSS_PERCENT: 30,

        // Heat reduction base costs (before exponential scaling)
        HEAT_BRIBE_COST: 500,
        HEAT_BRIBE_REDUCTION: 10,
        HEAT_HIDE_COST: 2000,
        HEAT_HIDE_REDUCTION: 25,
        HEAT_CLEANERS_COST: 10000,
        HEAT_CLEANERS_REDUCTION: 50,

        // ===================
        // CUSTOMER REPUTATION (per-dealer)
        // ===================
        // Deal type when selling: discount = sell cheaper for more rep, normal = small rep, overcharge = more $ but lose rep
        REP_DEAL_DISCOUNT_PRICE_MULT: 0.85,
        REP_DEAL_DISCOUNT_REP_GAIN: 3,
        REP_DEAL_NORMAL_REP_GAIN: 1,
        REP_DEAL_OVERCHARGE_PRICE_MULT: 1.20,
        REP_DEAL_OVERCHARGE_REP_LOSS: 2,
        // Reputation thresholds (rep points) -> price bonus when trading with that dealer (multiplier, e.g. 1.05 = +5%)
        REP_THRESHOLDS: [10, 25, 50, 100, 200],
        REP_BONUS_PER_THRESHOLD: 0.03,
        
        // ===================
        // STORAGE
        // ===================
        STORAGE_BASE_COST: 200,
        STORAGE_COST_MULTIPLIER: 1.2,
        STORAGE_CAPACITY_PER_LEVEL: 100,
        
        // ===================
        // ECONOMY
        // ===================
        DEFAULT_COST_MULTIPLIER: 1.15,  // Cost scaling for workers
        
        // ===================
        // SAVE SYSTEM
        // ===================
        SAVE_KEY: 'highprofits_save',
        SAVE_VERSION: 1
    };
})();
