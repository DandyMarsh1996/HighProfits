/**
 * HighProfits - Equipment Definitions
 * Items needed to set up and maintain grow plots
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Equipment = (function() {
    'use strict';

    // Store sections for organization
    var storeSections = {
        hardware_store: [
            { id: 'lighting', name: '💡 Lighting', description: 'Light sources for your plants' },
            { id: 'watering', name: '💧 Watering', description: 'Keep your plants hydrated' },
            { id: 'ventilation', name: '💨 Ventilation', description: 'Air circulation and climate' }
        ],
        garden_centre: [
            { id: 'containers', name: '🪴 Containers', description: 'Pots and planters' },
            { id: 'soil', name: '🟫 Soil & Growing Medium', description: 'Where your plants grow' },
            { id: 'fertilizers', name: '🧪 Fertilizers', description: 'Boost growth and yields' },
            { id: 'mixing', name: '🧪 Mixing', description: 'Upgrade your blend lab' }
        ]
    };

    var definitions = {
        // ================================
        // HARDWARE STORE - LIGHTING
        // ================================
        basic_bulb: {
            id: 'basic_bulb',
            name: 'CFL Bulb',
            description: 'Cheap fluorescent light. Gets the job done.',
            section: 'lighting',
            store: 'hardware_store',
            cost: 15,
            unlockLevel: 1,
            icon: '💡',
            slot: 'light',
            growthBonus: 0,
            yieldBonus: 0
        },
        led_light: {
            id: 'led_light',
            name: 'LED Grow Light',
            description: 'Efficient LED panel. Better light spectrum.',
            section: 'lighting',
            store: 'hardware_store',
            cost: 150,
            unlockLevel: 5,
            icon: '🔆',
            slot: 'light',
            growthBonus: 15,
            yieldBonus: 20
        },
        hps_light: {
            id: 'hps_light',
            name: 'HPS Light',
            description: 'High Pressure Sodium. Professional grade.',
            section: 'lighting',
            store: 'hardware_store',
            cost: 300,
            unlockLevel: 9,
            icon: '☀️',
            slot: 'light',
            growthBonus: 25,
            yieldBonus: 40
        },

        // ================================
        // HARDWARE STORE - WATERING
        // ================================
        small_watering_can: {
            id: 'small_watering_can',
            name: 'Small Watering Can',
            description: 'Basic 1L watering can. Waters one plant.',
            section: 'watering',
            store: 'hardware_store',
            cost: 10,
            unlockLevel: 1,
            icon: '🚿',
            slot: 'watering_can',
            waterAmount: 30,       // Seconds of hydration per use
            uses: 1                // Plants watered per use
        },
        watering_can: {
            id: 'watering_can',
            name: 'Watering Can',
            description: '5L watering can. Longer hydration.',
            section: 'watering',
            store: 'hardware_store',
            cost: 35,
            unlockLevel: 3,
            icon: '🚿',
            slot: 'watering_can',
            waterAmount: 60,
            uses: 1
        },
        large_watering_can: {
            id: 'large_watering_can',
            name: 'Large Watering Can',
            description: '10L can. Extended hydration time.',
            section: 'watering',
            store: 'hardware_store',
            cost: 75,
            unlockLevel: 6,
            icon: '🚿',
            slot: 'watering_can',
            waterAmount: 120,
            uses: 1
        },
        garden_hose: {
            id: 'garden_hose',
            name: 'Garden Hose',
            description: 'Water multiple plants at once.',
            section: 'watering',
            store: 'hardware_store',
            cost: 150,
            unlockLevel: 8,
            icon: '🔌',
            slot: 'watering_can',
            waterAmount: 90,
            uses: 4
        },
        drip_system: {
            id: 'drip_system',
            name: 'Drip Irrigation',
            description: 'Automated watering system. Slow but steady.',
            section: 'watering',
            store: 'hardware_store',
            cost: 400,
            unlockLevel: 11,
            icon: '💧',
            slot: 'watering_can',
            waterAmount: 180,
            uses: 8,
            autoWater: true        // Can be installed for passive watering
        },

        // ================================
        // HARDWARE STORE - VENTILATION
        // ================================
        desk_fan: {
            id: 'desk_fan',
            name: 'Desk Fan',
            description: 'Basic air circulation. Helps plant strength.',
            section: 'ventilation',
            store: 'hardware_store',
            cost: 20,
            unlockLevel: 1,
            icon: '🌀',
            slot: 'fan',
            growthBonus: 5,
            yieldBonus: 5
        },
        oscillating_fan: {
            id: 'oscillating_fan',
            name: 'Oscillating Fan',
            description: 'Better coverage for larger grows.',
            section: 'ventilation',
            store: 'hardware_store',
            cost: 60,
            unlockLevel: 5,
            icon: '🌀',
            slot: 'fan',
            growthBonus: 10,
            yieldBonus: 10
        },
        exhaust_fan: {
            id: 'exhaust_fan',
            name: 'Exhaust System',
            description: 'Removes heat and odor. With carbon filter.',
            section: 'ventilation',
            store: 'hardware_store',
            cost: 200,
            unlockLevel: 8,
            icon: '💨',
            slot: 'fan',
            growthBonus: 15,
            yieldBonus: 15
        },

        // ================================
        // GARDEN CENTRE - CONTAINERS
        // ================================
        basic_pot: {
            id: 'basic_pot',
            name: 'Plastic Pot',
            description: 'Simple plastic pot. Gets the job done.',
            section: 'containers',
            store: 'garden_centre',
            cost: 10,
            unlockLevel: 1,
            icon: '🪴',
            slot: 'pot',
            growthBonus: 0,
            yieldBonus: 0
        },
        fabric_pot: {
            id: 'fabric_pot',
            name: 'Fabric Pot',
            description: 'Better drainage and root aeration.',
            section: 'containers',
            store: 'garden_centre',
            cost: 25,
            unlockLevel: 3,
            icon: '🪴',
            slot: 'pot',
            growthBonus: 10,
            yieldBonus: 10
        },
        airpot: {
            id: 'airpot',
            name: 'Air Pot',
            description: 'Premium container for maximum root health.',
            section: 'containers',
            store: 'garden_centre',
            cost: 50,
            unlockLevel: 7,
            icon: '🪴',
            slot: 'pot',
            growthBonus: 15,
            yieldBonus: 20
        },

        // ================================
        // GARDEN CENTRE - SOIL
        // ================================
        basic_soil: {
            id: 'basic_soil',
            name: 'Potting Soil',
            description: 'Standard potting mix. Nothing special.',
            section: 'soil',
            store: 'garden_centre',
            cost: 5,
            unlockLevel: 1,
            icon: '🟫',
            slot: 'soil',
            consumable: true,
            uses: 1,
            growthBonus: 0,
            yieldBonus: 0
        },
        premium_soil: {
            id: 'premium_soil',
            name: 'Premium Mix',
            description: 'Enriched soil with perlite and nutrients. Lasts 3 cycles.',
            section: 'soil',
            store: 'garden_centre',
            cost: 22,
            unlockLevel: 4,
            icon: '🟫',
            slot: 'soil',
            consumable: true,
            uses: 3,
            growthBonus: 10,
            yieldBonus: 14
        },
        super_soil: {
            id: 'super_soil',
            name: 'Super Soil',
            description: 'Living organic soil. Maximum quality. Lasts 4 cycles.',
            section: 'soil',
            store: 'garden_centre',
            cost: 55,
            unlockLevel: 9,
            icon: '🟫',
            slot: 'soil',
            consumable: true,
            uses: 4,
            growthBonus: 18,
            yieldBonus: 22,
            qualityBonus: 18
        },
        coco_coir: {
            id: 'coco_coir',
            name: 'Coco Coir',
            description: 'Clean, airy medium. Great for fast root growth. Lasts 3 cycles.',
            section: 'soil',
            store: 'garden_centre',
            cost: 32,
            unlockLevel: 6,
            icon: '🥥',
            slot: 'soil',
            consumable: true,
            uses: 3,
            growthBonus: 14,
            yieldBonus: 10,
            qualityBonus: 5
        },
        perlite_mix: {
            id: 'perlite_mix',
            name: 'Perlite Mix',
            description: 'Extra aeration and drainage. Reduces overwatering risk. Lasts 2 cycles.',
            section: 'soil',
            store: 'garden_centre',
            cost: 25,
            unlockLevel: 6,
            icon: '⚪',
            slot: 'soil',
            consumable: true,
            uses: 2,
            growthBonus: 12,
            yieldBonus: 12,
            qualityBonus: 3
        },
        rockwool_cubes: {
            id: 'rockwool_cubes',
            name: 'Rockwool Cubes',
            description: 'Hydro-friendly starter medium. Consistent moisture.',
            section: 'soil',
            store: 'garden_centre',
            cost: 35,
            unlockLevel: 8,
            icon: '🧱',
            slot: 'soil',
            consumable: true,
            uses: 1,
            growthBonus: 18,
            yieldBonus: 15,
            qualityBonus: 10
        },
        worm_castings_soil: {
            id: 'worm_castings_soil',
            name: 'Worm Castings Soil',
            description: 'Worm-castings amended mix. Boosts quality and vigor. Lasts 4 cycles.',
            section: 'soil',
            store: 'garden_centre',
            cost: 85,
            unlockLevel: 12,
            icon: '🪱',
            slot: 'soil',
            consumable: true,
            uses: 4,
            growthBonus: 22,
            yieldBonus: 22,
            qualityBonus: 28
        },
        aerated_supermix: {
            id: 'aerated_supermix',
            name: 'Aerated Supermix',
            description: 'Ultra-aerated, pre-amended mix. Great yields with strong quality. Lasts 5 cycles.',
            section: 'soil',
            store: 'garden_centre',
            cost: 195,
            unlockLevel: 21,
            icon: '🫧',
            slot: 'soil',
            consumable: true,
            uses: 5,
            growthBonus: 32,
            yieldBonus: 32,
            qualityBonus: 24
        },

        // ================================
        // GARDEN CENTRE - FERTILIZERS
        // ================================
        basic_fertilizer: {
            id: 'basic_fertilizer',
            name: 'Basic Fertilizer',
            description: 'Simple NPK mix. Slight growth boost.',
            section: 'fertilizers',
            store: 'garden_centre',
            cost: 15,
            unlockLevel: 1,
            icon: '🧪',
            slot: 'fertilizer',
            consumable: true,
            uses: 1,
            growthBonus: 10,
            yieldBonus: 5
        },
        bloom_booster: {
            id: 'bloom_booster',
            name: 'Bloom Booster',
            description: 'High phosphorus for bigger yields.',
            section: 'fertilizers',
            store: 'garden_centre',
            cost: 30,
            unlockLevel: 4,
            icon: '🌸',
            slot: 'fertilizer',
            consumable: true,
            uses: 1,
            growthBonus: 5,
            yieldBonus: 25
        },
        organic_nutrients: {
            id: 'organic_nutrients',
            name: 'Organic Nutrients',
            description: 'Full organic nutrient line. Quality boost. Lasts 3 cycles.',
            section: 'fertilizers',
            store: 'garden_centre',
            cost: 65,
            unlockLevel: 7,
            icon: '🌿',
            slot: 'fertilizer',
            consumable: true,
            uses: 3,
            growthBonus: 14,
            yieldBonus: 14,
            qualityBonus: 14
        },
        premium_nutrients: {
            id: 'premium_nutrients',
            name: 'Premium Nutrients',
            description: 'Professional grade. Maximum performance. Lasts 4 cycles.',
            section: 'fertilizers',
            store: 'garden_centre',
            cost: 108,
            unlockLevel: 11,
            icon: '⚗️',
            slot: 'fertilizer',
            consumable: true,
            uses: 4,
            growthBonus: 22,
            yieldBonus: 28,
            qualityBonus: 22
        },
        calmag_supplement: {
            id: 'calmag_supplement',
            name: 'Cal-Mag Supplement',
            description: 'Prevents deficiencies. Stabilizes growth and yield. Lasts 3 cycles.',
            section: 'fertilizers',
            store: 'garden_centre',
            cost: 28,
            unlockLevel: 3,
            icon: '🦴',
            slot: 'fertilizer',
            consumable: true,
            uses: 3,
            growthBonus: 7,
            yieldBonus: 7,
            qualityBonus: 5
        },
        silica_boost: {
            id: 'silica_boost',
            name: 'Silica Boost',
            description: 'Stronger stems and better stress resistance. Quality up. Lasts 3 cycles.',
            section: 'fertilizers',
            store: 'garden_centre',
            cost: 48,
            unlockLevel: 8,
            icon: '🛡️',
            slot: 'fertilizer',
            consumable: true,
            uses: 3,
            growthBonus: 9,
            yieldBonus: 14,
            qualityBonus: 14
        },
        terpene_booster: {
            id: 'terpene_booster',
            name: 'Terpene Booster',
            description: 'Focuses on flavor and aroma. Massive quality boost. Lasts 3 cycles.',
            section: 'fertilizers',
            store: 'garden_centre',
            cost: 80,
            unlockLevel: 10,
            icon: '🍋',
            slot: 'fertilizer',
            consumable: true,
            uses: 3,
            growthBonus: 5,
            yieldBonus: 9,
            qualityBonus: 32
        },
        monster_bloom: {
            id: 'monster_bloom',
            name: 'Monster Bloom',
            description: 'Aggressive flowering nutrients. Big yields, big buds. Lasts 3 cycles.',
            section: 'fertilizers',
            store: 'garden_centre',
            cost: 125,
            unlockLevel: 16,
            icon: '🧨',
            slot: 'fertilizer',
            consumable: true,
            uses: 3,
            growthBonus: 5,
            yieldBonus: 42,
            qualityBonus: 18
        },
        lab_grade_nutrients: {
            id: 'lab_grade_nutrients',
            name: 'Lab-Grade Nutrients',
            description: 'Precision nutrients for maximum output. Endgame. Lasts 5 cycles.',
            section: 'fertilizers',
            store: 'garden_centre',
            cost: 480,
            unlockLevel: 24,
            icon: '🧬',
            slot: 'fertilizer',
            consumable: true,
            uses: 5,
            growthBonus: 18,
            yieldBonus: 50,
            qualityBonus: 42
        },

        // ================================
        // GARDEN CENTRE - MIXING (blend markup upgrade)
        // ================================
        blend_booster: {
            id: 'blend_booster',
            name: 'Blend Booster',
            description: 'Permanent lab upgrade. All blends sell for 20% more on the market.',
            section: 'mixing',
            store: 'garden_centre',
            cost: 250,
            unlockLevel: 6,
            icon: '📈',
            slot: null  // Not installed on plots; owned = bonus applies
        },

        // ================================
        // ADVANCED LIGHTING
        // ================================
        quantum_board: {
            id: 'quantum_board',
            name: 'Quantum Board LED',
            description: 'Full spectrum LED. Maximum efficiency and yield.',
            section: 'lighting',
            store: 'hardware_store',
            cost: 500,
            unlockLevel: 14,
            icon: '💎',
            slot: 'light',
            growthBonus: 35,
            yieldBonus: 50,
            qualityBonus: 15
        },
        cmh_light: {
            id: 'cmh_light',
            name: 'CMH Light',
            description: 'Ceramic Metal Halide. Professional spectrum.',
            section: 'lighting',
            store: 'hardware_store',
            cost: 600,
            unlockLevel: 17,
            icon: '💡',
            slot: 'light',
            growthBonus: 40,
            yieldBonus: 55,
            qualityBonus: 20
        },
        full_spectrum_led: {
            id: 'full_spectrum_led',
            name: 'Full Spectrum LED',
            description: 'Advanced LED system. Perfect for all growth stages.',
            section: 'lighting',
            store: 'hardware_store',
            cost: 800,
            unlockLevel: 20,
            icon: '🌈',
            slot: 'light',
            growthBonus: 45,
            yieldBonus: 60,
            qualityBonus: 25
        },
        laser_led_array: {
            id: 'laser_led_array',
            name: 'Laser LED Array',
            description: 'Extreme lighting for elite grows. Brutal yields and quality.',
            section: 'lighting',
            store: 'hardware_store',
            cost: 3500,
            unlockLevel: 24,
            icon: '🔺',
            slot: 'light',
            growthBonus: 70,
            yieldBonus: 90,
            qualityBonus: 40
        },

        // ================================
        // ADVANCED WATERING/AUTOMATION
        // ================================
        auto_watering_system: {
            id: 'auto_watering_system',
            name: 'Auto Watering System',
            description: 'Fully automated. Never worry about watering again.',
            section: 'watering',
            store: 'hardware_store',
            cost: 600,
            unlockLevel: 15,
            icon: '🤖',
            slot: 'watering_can',
            waterAmount: 300,
            uses: 10,
            autoWater: true
        },
        hydroponic_system: {
            id: 'hydroponic_system',
            name: 'Hydroponic System',
            description: 'Soilless growing. Faster growth, higher yields.',
            section: 'watering',
            store: 'hardware_store',
            cost: 1000,
            unlockLevel: 18,
            icon: '🌊',
            slot: 'watering_can',
            waterAmount: 240,
            uses: 12,
            autoWater: true,
            growthBonus: 30,
            yieldBonus: 40
        },
        smart_irrigation: {
            id: 'smart_irrigation',
            name: 'Smart Irrigation',
            description: 'AI-controlled watering. Optimal moisture levels.',
            section: 'watering',
            store: 'hardware_store',
            cost: 1200,
            unlockLevel: 22,
            icon: '🧠',
            slot: 'watering_can',
            waterAmount: 360,
            uses: 15,
            autoWater: true,
            growthBonus: 20,
            yieldBonus: 30,
            qualityBonus: 15
        },
        closed_loop_irrigation: {
            id: 'closed_loop_irrigation',
            name: 'Closed-Loop Irrigation',
            description: 'Recycles and optimizes watering. Designed for massive rooms.',
            section: 'watering',
            store: 'hardware_store',
            cost: 4500,
            unlockLevel: 24,
            icon: '♻️',
            slot: 'watering_can',
            waterAmount: 600,
            uses: 30,
            autoWater: true,
            growthBonus: 45,
            yieldBonus: 50,
            qualityBonus: 25
        },

        // ================================
        // ADVANCED VENTILATION
        // ================================
        carbon_filter_system: {
            id: 'carbon_filter_system',
            name: 'Carbon Filter System',
            description: 'Odor control and air purification. Reduces heat.',
            section: 'ventilation',
            store: 'hardware_store',
            cost: 400,
            unlockLevel: 12,
            icon: '🌬️',
            slot: 'fan',
            growthBonus: 20,
            yieldBonus: 20,
            qualityBonus: 10
        },
        climate_control: {
            id: 'climate_control',
            name: 'Climate Control Unit',
            description: 'Temperature and humidity control. Perfect environment.',
            section: 'ventilation',
            store: 'hardware_store',
            cost: 800,
            unlockLevel: 18,
            icon: '🌡️',
            slot: 'fan',
            growthBonus: 30,
            yieldBonus: 35,
            qualityBonus: 20
        },
        co2_enrichment: {
            id: 'co2_enrichment',
            name: 'CO2 Enrichment System',
            description: 'CO2 supplementation. Accelerates growth significantly.',
            section: 'ventilation',
            store: 'hardware_store',
            cost: 1500,
            unlockLevel: 23,
            icon: '💨',
            slot: 'fan',
            growthBonus: 50,
            yieldBonus: 40,
            qualityBonus: 10
        },

        // ================================
        // PREMIUM CONTAINERS
        // ================================
        smart_pot: {
            id: 'smart_pot',
            name: 'Smart Pot XL',
            description: 'Self-watering container. Advanced root system.',
            section: 'containers',
            store: 'garden_centre',
            cost: 100,
            unlockLevel: 12,
            icon: '🧠',
            slot: 'pot',
            growthBonus: 20,
            yieldBonus: 25,
            qualityBonus: 10
        },
        dwc_bucket: {
            id: 'dwc_bucket',
            name: 'DWC Bucket',
            description: 'Deep Water Culture. Maximum root development.',
            section: 'containers',
            store: 'garden_centre',
            cost: 150,
            unlockLevel: 16,
            icon: '🪣',
            slot: 'pot',
            growthBonus: 25,
            yieldBonus: 30,
            qualityBonus: 15
        },
        aeroponic_tower: {
            id: 'aeroponic_tower',
            name: 'Aeroponic Tower',
            description: 'Mist-based root system. Endgame speed and yields.',
            section: 'containers',
            store: 'garden_centre',
            cost: 1500,
            unlockLevel: 21,
            icon: '🗼',
            slot: 'pot',
            growthBonus: 45,
            yieldBonus: 55,
            qualityBonus: 30
        },

        // ================================
        // PREMIUM SOIL/NUTRIENTS
        // ================================
        living_soil: {
            id: 'living_soil',
            name: 'Living Soil',
            description: 'Microbe-rich organic soil. Self-sustaining ecosystem.',
            section: 'soil',
            store: 'garden_centre',
            cost: 100,
            unlockLevel: 14,
            icon: '🦠',
            slot: 'soil',
            consumable: true,
            uses: 4,
            growthBonus: 25,
            yieldBonus: 30,
            qualityBonus: 25
        },
        mycorrhizal_inoculant: {
            id: 'mycorrhizal_inoculant',
            name: 'Mycorrhizal Inoculant',
            description: 'Beneficial fungi. Enhances nutrient uptake.',
            section: 'fertilizers',
            store: 'garden_centre',
            cost: 150,
            unlockLevel: 15,
            icon: '🍄',
            slot: 'fertilizer',
            consumable: true,
            uses: 3,
            growthBonus: 30,
            yieldBonus: 35,
            qualityBonus: 30
        },
        organic_compost_tea: {
            id: 'organic_compost_tea',
            name: 'Compost Tea',
            description: 'Beneficial microbes. Boosts plant health and quality.',
            section: 'fertilizers',
            store: 'garden_centre',
            cost: 120,
            unlockLevel: 13,
            icon: '🍵',
            slot: 'fertilizer',
            consumable: true,
            uses: 2,
            growthBonus: 20,
            yieldBonus: 20,
            qualityBonus: 35
        }
    };

    // Required equipment slots to start growing
    var requiredSlots = ['pot', 'soil', 'light'];

    return {
        getAll: function() { return definitions; },
        get: function(id) { return definitions[id] || null; },
        getIds: function() { return Object.keys(definitions); },
        getRequiredSlots: function() { return requiredSlots.slice(); },
        
        getStoreSections: function(storeId) {
            return storeSections[storeId] || [];
        },

        getByStore: function(storeId) {
            var items = [];
            for (var id in definitions) {
                if (definitions[id].store === storeId) {
                    items.push(definitions[id]);
                }
            }
            return items;
        },

        getBySection: function(storeId, sectionId) {
            var items = [];
            for (var id in definitions) {
                if (definitions[id].store === storeId && definitions[id].section === sectionId) {
                    items.push(definitions[id]);
                }
            }
            return items;
        },

        getWateringCans: function() {
            var cans = [];
            for (var id in definitions) {
                if (definitions[id].slot === 'watering_can') {
                    cans.push(definitions[id]);
                }
            }
            return cans;
        },

        getUnlocked: function(playerLevel) {
            var unlocked = [];
            for (var id in definitions) {
                if (definitions[id].unlockLevel <= playerLevel) {
                    unlocked.push(definitions[id]);
                }
            }
            return unlocked;
        }
    };
})();
