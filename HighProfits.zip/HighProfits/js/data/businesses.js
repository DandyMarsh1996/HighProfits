/**
 * HighProfits - Business Definitions
 * Businesses reduce laundering fee when owned. Bought at Real Estate.
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Businesses = (function() {
    'use strict';

    var definitions = {
        car_wash: {
            id: 'car_wash',
            name: 'Car Wash',
            description: 'Classic cash business. Run money through it daily; limited capacity.',
            cost: 5000,
            unlockLevel: 3,
            launderFeeReduction: 3,
            dailyLaunderCapacity: 3000,
            icon: '🚗'
        },
        nail_salon: {
            id: 'nail_salon',
            name: 'Nail Salon',
            description: 'Low-profile cash flow. Daily capacity for laundering.',
            cost: 12000,
            unlockLevel: 5,
            launderFeeReduction: 5,
            dailyLaunderCapacity: 6000,
            icon: '💅'
        },
        laundromat: {
            id: 'laundromat',
            name: 'Laundromat',
            description: 'Fitting choice. Higher daily throughput.',
            cost: 25000,
            unlockLevel: 7,
            launderFeeReduction: 8,
            dailyLaunderCapacity: 12000,
            icon: '🧺'
        },
        restaurant: {
            id: 'restaurant',
            name: 'Restaurant',
            description: 'High-volume cash business. Good daily capacity.',
            cost: 50000,
            unlockLevel: 10,
            launderFeeReduction: 12,
            dailyLaunderCapacity: 25000,
            icon: '🍽️'
        },
        nightclub: {
            id: 'nightclub',
            name: 'Nightclub',
            description: 'Premium cash flow. Large daily capacity.',
            cost: 100000,
            unlockLevel: 14,
            launderFeeReduction: 15,
            dailyLaunderCapacity: 50000,
            icon: '🎭'
        },
        construction: {
            id: 'construction',
            name: 'Construction Co',
            description: 'Large-scale operations. Highest daily capacity.',
            cost: 250000,
            unlockLevel: 18,
            launderFeeReduction: 20,
            dailyLaunderCapacity: 100000,
            icon: '🏗️'
        }
    };

    function get(id) {
        return definitions[id] || null;
    }

    function getAll() {
        var list = [];
        for (var key in definitions) {
            if (definitions.hasOwnProperty(key)) list.push(definitions[key]);
        }
        return list;
    }

    function getUnlocked(playerLevel) {
        var unlocked = [];
        for (var key in definitions) {
            if (definitions[key].unlockLevel <= playerLevel) {
                unlocked.push(definitions[key]);
            }
        }
        return unlocked;
    }

    return { get: get, getAll: getAll, getUnlocked: getUnlocked };
})();
