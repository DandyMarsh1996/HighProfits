/**
 * HighProfits - Stock Market Definitions
 * Companies and items relevant to the game (bulbs, hydroponics, seeds, etc.). Cookie Clicker-style: buy low, sell high; prices drift and mean-revert.
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Stocks = (function() {
    'use strict';

    var definitions = {
        growbright: {
            id: 'growbright',
            name: 'GrowBright LEDs',
            ticker: 'GBL',
            description: 'Grow light and bulb manufacturer. Popular with indoor growers.',
            basePrice: 12,
            icon: '💡'
        },
        hydroflow: {
            id: 'hydroflow',
            name: 'HydroFlow Systems',
            ticker: 'HFS',
            description: 'Hydroponics equipment and nutrient systems.',
            basePrice: 18,
            icon: '🌊'
        },
        seedlab: {
            id: 'seedlab',
            name: 'SeedLab Genetics',
            ticker: 'SLG',
            description: 'Agricultural and horticultural seed research.',
            basePrice: 22,
            icon: '🧬'
        },
        soilworks: {
            id: 'soilworks',
            name: 'SoilWorks Organics',
            ticker: 'SWO',
            description: 'Soil, compost, and growing medium supplier.',
            basePrice: 8,
            icon: '🪴'
        },
        ventmax: {
            id: 'ventmax',
            name: 'VentMax Industries',
            ticker: 'VMX',
            description: 'Ventilation and climate control for indoor agriculture.',
            basePrice: 15,
            icon: '💨'
        },
        safetynet: {
            id: 'safetynet',
            name: 'SafetyNet Security',
            ticker: 'SNS',
            description: 'Security systems and surveillance. Demand from growers.',
            basePrice: 25,
            icon: '🔒'
        },
        greenbank: {
            id: 'greenbank',
            name: 'GreenBank Holdings',
            ticker: 'GBH',
            description: 'Financial services with ties to the horticulture sector.',
            basePrice: 35,
            icon: '🏦'
        },
        cannatech: {
            id: 'cannatech',
            name: 'CannaTech Solutions',
            ticker: 'CTS',
            description: 'Specialist tech and automation for cultivation.',
            basePrice: 42,
            icon: '📡'
        }
    };

    function get(id) {
        return definitions[id] || null;
    }

    function getAll() {
        var list = [];
        for (var key in definitions) {
            if (definitions.hasOwnProperty(key)) list.push(definitions[key]);
        }
        return list;
    }

    return { get: get, getAll: getAll };
})();
