/**
 * HighProfits - Customers/Dealers
 * Different buyers with varying prices and requirements
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Customers = (function() {
    'use strict';

    var definitions = {
        // === STREET LEVEL (Low quality buyers - keep this tier profitable!) ===
        street_buyer: {
            id: 'street_buyer',
            name: 'Street Buyer',
            description: 'Random people looking for small amounts.',
            icon: '🚶',
            unlockLevel: 1,
            // Price multipliers per quality (base prices: low=8, med=12, good=18, prem=30)
            priceMultiplier: {
                low: 1.3,      // +30% for low quality (street markup)
                medium: 1.15,
                good: 1.0,
                premium: 0.9   // Don't appreciate premium
            },
            minAmount: 1,
            maxAmount: 5,
            preferredQuality: ['low', 'medium'],
            bulkDiscount: 0,  // No bulk buying
            availability: 'always'
        },

        college_kid: {
            id: 'college_kid',
            name: 'College Student',
            description: 'Buys medium amounts for parties.',
            icon: '🎓',
            unlockLevel: 1,
            priceMultiplier: {
                low: 1.1,      // Better price for low
                medium: 1.25,  // Best price for medium
                good: 1.1,
                premium: 0.8
            },
            minAmount: 5,
            maxAmount: 20,
            preferredQuality: ['medium', 'good'],
            bulkDiscount: 0.05,  // 5% discount on bulk
            availability: 'always'
        },

        // === NEW: Budget-focused buyers ===
        party_host: {
            id: 'party_host',
            name: 'Party Host',
            description: 'Needs quantity over quality for events. Pays well for cheap bulk strains.',
            icon: '🎈',
            unlockLevel: 2,
            priceMultiplier: {
                low: 1.4,
                medium: 1.3,
                good: 1.0,
                premium: 0.7
            },
            strainMultipliers: { ditch_weed_seed: 1.15, schwag_seed: 1.1, brick_weed_seed: 1.1 },
            minAmount: 10,
            maxAmount: 40,
            preferredQuality: ['low', 'medium'],
            bulkDiscount: 0.1,
            availability: 'always'
        },

        budget_dealer: {
            id: 'budget_dealer',
            name: 'Budget Dealer',
            description: 'Resells cheap product to budget customers.',
            icon: '💵',
            unlockLevel: 4,
            priceMultiplier: {
                low: 1.35,     // Excellent low quality price
                medium: 1.2,
                good: 0.9,
                premium: 0.6
            },
            minAmount: 20,
            maxAmount: 80,
            preferredQuality: ['low', 'medium'],
            bulkDiscount: 0.15,
            availability: 'always'
        },

        // === MID-TIER (Medium quality sweet spot) ===
        regular_customer: {
            id: 'regular_customer',
            name: 'Regular Customer',
            description: 'Loyal buyer who pays fair prices.',
            icon: '😎',
            unlockLevel: 3,
            priceMultiplier: {
                low: 1.15,     // Still buys low
                medium: 1.3,   // Best for medium
                good: 1.2,
                premium: 1.1
            },
            minAmount: 5,
            maxAmount: 30,
            preferredQuality: ['medium', 'good'],
            bulkDiscount: 0.1,
            availability: 'always'
        },

        medical_patient: {
            id: 'medical_patient',
            name: 'Medical Patient',
            description: 'Consistent buyer of medium-quality medicine.',
            icon: '🩺',
            unlockLevel: 5,
            priceMultiplier: {
                low: 0.9,
                medium: 1.4,   // Excellent medium price
                good: 1.35,
                premium: 1.2
            },
            minAmount: 10,
            maxAmount: 40,
            preferredQuality: ['medium', 'good'],
            bulkDiscount: 0.08,
            availability: 'always'
        },

        dispensary_owner: {
            id: 'dispensary_owner',
            name: 'Dispensary Owner',
            description: 'Bulk buyer. Good prices for quality. Wants popular strains.',
            icon: '🏥',
            unlockLevel: 6,
            priceMultiplier: {
                low: 0.8,
                medium: 1.15,
                good: 1.3,
                premium: 1.4
            },
            strainMultipliers: { blue_dream_seed: 1.15, white_widow_seed: 1.1, sour_diesel_seed: 1.1 },
            minAmount: 20,
            maxAmount: 100,
            preferredQuality: ['medium', 'good', 'premium'],
            bulkDiscount: 0.15,
            availability: 'always'
        },

        // === HIGH-TIER ===
        club_promoter: {
            id: 'club_promoter',
            name: 'Club Promoter',
            description: 'Pays premium for premium product. Loves hype strains.',
            icon: '🎉',
            unlockLevel: 8,
            priceMultiplier: {
                low: 0.5,
                medium: 0.8,
                good: 1.2,
                premium: 1.5
            },
            strainMultipliers: { purple_haze_seed: 1.25, gelato_seed: 1.2, girl_scout_cookies_seed: 1.15 },
            minAmount: 10,
            maxAmount: 50,
            preferredQuality: ['premium'],
            bulkDiscount: 0.1,
            availability: 'always'
        },

        private_collector: {
            id: 'private_collector',
            name: 'Private Collector',
            description: 'Connoisseur who only buys the best. Pays top dollar for legendary strains.',
            icon: '🎩',
            unlockLevel: 10,
            priceMultiplier: {
                low: 0.0,
                medium: 0.5,
                good: 1.3,
                premium: 1.8
            },
            strainMultipliers: { premium_seed: 1.2, granddaddy_purple_seed: 1.35, jack_herer_seed: 1.25, wedding_cake_seed: 1.2 },
            minAmount: 5,
            maxAmount: 25,
            preferredQuality: ['premium'],
            bulkDiscount: 0,
            availability: 'always'
        },

        // === SPECIAL (Bulk operations - all tiers viable) ===
        bulk_buyer: {
            id: 'bulk_buyer',
            name: 'Wholesale Buyer',
            description: 'Buys large quantities at discount.',
            icon: '📦',
            unlockLevel: 7,
            priceMultiplier: {
                low: 1.0,      // Fair bulk price for low
                medium: 1.05,  // Slight premium for medium bulk
                good: 1.1,
                premium: 1.15
            },
            minAmount: 50,
            maxAmount: 500,
            preferredQuality: ['low', 'medium', 'good', 'premium'],
            bulkDiscount: 0.2,  // Discount but still profitable
            availability: 'always'
        },

        extract_artist: {
            id: 'extract_artist',
            name: 'Extract Artist',
            description: 'Makes concentrates. Buys any quality in bulk.',
            icon: '🧪',
            unlockLevel: 9,
            priceMultiplier: {
                low: 1.2,      // Good price for low (extracts don't care)
                medium: 1.25,
                good: 1.3,
                premium: 1.35
            },
            minAmount: 30,
            maxAmount: 150,
            preferredQuality: ['low', 'medium', 'good'],
            bulkDiscount: 0.12,
            availability: 'always'
        },

        // === DEALERS ===
        street_dealer: {
            id: 'street_dealer',
            name: 'Street Dealer',
            description: 'Resells on the street. Buys medium quantities.',
            icon: '💼',
            unlockLevel: 5,
            priceMultiplier: {
                low: 0.9,
                medium: 1.0,
                good: 1.1,
                premium: 1.0
            },
            minAmount: 10,
            maxAmount: 50,
            preferredQuality: ['low', 'medium', 'good'],
            bulkDiscount: 0.1,
            availability: 'always'
        },
        mid_level_dealer: {
            id: 'mid_level_dealer',
            name: 'Mid-Level Dealer',
            description: 'Established dealer network. Good prices for quality.',
            icon: '👔',
            unlockLevel: 10,
            priceMultiplier: {
                low: 0.7,
                medium: 0.95,
                good: 1.15,
                premium: 1.25
            },
            minAmount: 25,
            maxAmount: 100,
            preferredQuality: ['good', 'premium'],
            bulkDiscount: 0.12,
            availability: 'always'
        },
        cartel_contact: {
            id: 'cartel_contact',
            name: 'Cartel Contact',
            description: 'Organized crime connection. Premium prices, large orders.',
            icon: '🕴️',
            unlockLevel: 14,
            priceMultiplier: {
                low: 0.5,
                medium: 0.8,
                good: 1.2,
                premium: 1.6
            },
            minAmount: 50,
            maxAmount: 200,
            preferredQuality: ['premium'],
            bulkDiscount: 0.15,
            availability: 'always'
        },

        // === INTERNATIONAL ===
        canadian_buyer: {
            id: 'canadian_buyer',
            name: 'Canadian Buyer',
            description: 'Cross-border buyer. Pays well for premium.',
            icon: '🍁',
            unlockLevel: 12,
            priceMultiplier: {
                low: 0.6,
                medium: 0.9,
                good: 1.3,
                premium: 1.7
            },
            minAmount: 30,
            maxAmount: 150,
            preferredQuality: ['good', 'premium'],
            bulkDiscount: 0.1,
            availability: 'always'
        },
        european_distributor: {
            id: 'european_distributor',
            name: 'European Distributor',
            description: 'International distributor. High prices for top quality. Loves classic strains.',
            icon: '🇪🇺',
            unlockLevel: 16,
            priceMultiplier: {
                low: 0.4,
                medium: 0.7,
                good: 1.4,
                premium: 2.0
            },
            strainMultipliers: { white_widow_seed: 1.2, amnesia_seed: 1.15, jack_herer_seed: 1.25, durban_poison_seed: 1.1 },
            minAmount: 40,
            maxAmount: 200,
            preferredQuality: ['premium'],
            bulkDiscount: 0.05,
            availability: 'always'
        },

        // === SPECIALTY ===
        medical_marijuana_clinic: {
            id: 'medical_marijuana_clinic',
            name: 'Medical Clinic',
            description: 'Medical marijuana clinic. Premium prices for quality.',
            icon: '🏥',
            unlockLevel: 18,
            priceMultiplier: {
                low: 0.0,  // Won't buy low
                medium: 0.8,
                good: 1.4,
                premium: 1.8
            },
            minAmount: 20,
            maxAmount: 100,
            preferredQuality: ['good', 'premium'],
            bulkDiscount: 0.12,
            availability: 'always'
        },
        celebrity_client: {
            id: 'celebrity_client',
            name: 'Celebrity Client',
            description: 'High-profile buyer. Pays top dollar for premium only. Wants name-brand strains.',
            icon: '⭐',
            unlockLevel: 20,
            priceMultiplier: {
                low: 0.0,
                medium: 0.0,
                good: 1.0,
                premium: 2.5
            },
            strainMultipliers: { gelato_seed: 1.3, girl_scout_cookies_seed: 1.35, wedding_cake_seed: 1.25, gorilla_glue_seed: 1.2 },
            minAmount: 5,
            maxAmount: 30,
            preferredQuality: ['premium'],
            bulkDiscount: 0,
            availability: 'always'
        },

        // === ENDGAME / GLOBAL ===
        dispensary_chain: {
            id: 'dispensary_chain',
            name: 'Dispensary Chain',
            description: 'Corporate chain buyer. Huge volume, reliable payments.',
            icon: '🏬',
            unlockLevel: 21,
            priceMultiplier: {
                low: 0.6,
                medium: 0.9,
                good: 1.2,
                premium: 1.35
            },
            minAmount: 100,
            maxAmount: 1000,
            preferredQuality: ['good', 'premium'],
            bulkDiscount: 0.18,
            availability: 'always'
        },
        luxury_connoisseur: {
            id: 'luxury_connoisseur',
            name: 'Luxury Connoisseur',
            description: 'Ultra-high-end buyer. Only wants the best, pays absurdly well.',
            icon: '💎',
            unlockLevel: 23,
            priceMultiplier: {
                low: 0.0,
                medium: 0.0,
                good: 1.2,
                premium: 3.0
            },
            minAmount: 10,
            maxAmount: 80,
            preferredQuality: ['premium'],
            bulkDiscount: 0,
            availability: 'always'
        },
        global_wholesaler: {
            id: 'global_wholesaler',
            name: 'Global Wholesaler',
            description: 'Moves product internationally. Massive orders at a discount.',
            icon: '🌍',
            unlockLevel: 24,
            priceMultiplier: {
                low: 0.75,
                medium: 0.8,
                good: 0.9,
                premium: 1.0
            },
            minAmount: 500,
            maxAmount: 5000,
            preferredQuality: ['medium', 'good', 'premium'],
            bulkDiscount: 0.28,
            availability: 'always'
        },
        cartel_export_boss: {
            id: 'cartel_export_boss',
            name: 'Cartel Export Boss',
            description: 'Endgame contact. Biggest premium orders and best payouts.',
            icon: '🏆',
            unlockLevel: 25,
            priceMultiplier: {
                low: 0.0,
                medium: 0.5,
                good: 1.4,
                premium: 2.7
            },
            minAmount: 250,
            maxAmount: 2500,
            preferredQuality: ['premium'],
            bulkDiscount: 0.08,
            availability: 'always'
        }
    };

    return {
        getAll: function() { return definitions; },
        get: function(id) { return definitions[id] || null; },
        getIds: function() { return Object.keys(definitions); },
        
        getUnlocked: function(playerLevel) {
            var unlocked = [];
            for (var id in definitions) {
                if (definitions[id].unlockLevel <= playerLevel) {
                    unlocked.push(definitions[id]);
                }
            }
            return unlocked;
        },

        /**
         * Get price multiplier from reputation with this customer (reputation thresholds award bonus %)
         */
        getReputationBonus: function(customerId) {
            var rep = (HP.State && HP.State.getCustomerReputation) ? HP.State.getCustomerReputation(customerId) : 0;
            var thresholds = (HP.Data.Constants && HP.Data.Constants.REP_THRESHOLDS) ? HP.Data.Constants.REP_THRESHOLDS : [10, 25, 50, 100, 200];
            var bonusPerTier = (HP.Data.Constants && HP.Data.Constants.REP_BONUS_PER_THRESHOLD != null) ? HP.Data.Constants.REP_BONUS_PER_THRESHOLD : 0.03;
            var tiers = 0;
            for (var i = 0; i < thresholds.length; i++) {
                if (rep >= thresholds[i]) tiers++;
            }
            return 1 + tiers * bonusPerTier;
        },

        /**
         * Calculate sale price for a customer by strain (includes reputation + per-dealer strain preference)
         * @param {string} customerId - Customer ID
         * @param {string} seedId - Strain/seed ID (product type)
         * @param {number} amount - Amount in grams
         * @returns {Object} {pricePerGram, total, multiplier, bulkDiscount, isPreferred, reputationBonus, quality}
         */
        calculatePrice: function(customerId, seedId, amount) {
            var customer = definitions[customerId];
            if (!customer) return null;

            var seed = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedId) : null;
            var quality = seed ? seed.quality : 'low';
            if (['low', 'medium', 'good', 'premium'].indexOf(quality) === -1) quality = 'low';

            // Base prices: good/premium slightly higher for late-game income pacing
            var basePrices = { low: 8, medium: 12, good: 20, premium: 35 };
            var basePrice = basePrices[quality] || 8;
            var qualityMult = customer.priceMultiplier[quality] || 1.0;
            var strainMult = (customer.strainMultipliers && customer.strainMultipliers[seedId]) ? customer.strainMultipliers[seedId] : 1.0;
            var multiplier = qualityMult * strainMult;

            // Apply bulk discount if buying more than minimum
            var bulkBonus = 0;
            if (amount >= customer.minAmount * 2) {
                bulkBonus = customer.bulkDiscount;
            }

            // Late-game money pacing:
            var level = (HP.State && HP.State.getLevel) ? HP.State.getLevel() : 1;
            var levelPriceMult = (HP.Progression && HP.Progression.getLevelBonus) ? HP.Progression.getLevelBonus('price', level) : 1.0;

            var pricePerGram = basePrice * multiplier * (1 - bulkBonus) * levelPriceMult;
            var repBonus = this.getReputationBonus(customerId);
            pricePerGram *= repBonus;

            // Event modifiers (buyer frenzy, market crash, quality demand for premium)
            var eventMult = HP.Events && HP.Events.Manager ? HP.Events.Manager.getModifier('salePrice') : 1;
            pricePerGram *= eventMult;
            if (quality === 'premium' && HP.Events && HP.Events.Manager) {
                var premiumMult = HP.Events.Manager.getModifier('premiumBonus');
                pricePerGram *= premiumMult;
            }
            var strainSaleMult = (HP.Data.StrainEffects && HP.Data.StrainEffects.getSalePriceMultiplier && seed) ? HP.Data.StrainEffects.getSalePriceMultiplier(seed) : 1;
            pricePerGram *= strainSaleMult;
            var smokeSaleMult = (HP.State && HP.State.getSaleMultiplier) ? HP.State.getSaleMultiplier() : 1;
            pricePerGram *= smokeSaleMult;

            var total = Math.floor(pricePerGram * amount);

            return {
                pricePerGram: Math.floor(pricePerGram * 100) / 100,
                total: total,
                multiplier: multiplier,
                bulkDiscount: bulkBonus,
                isPreferred: customer.preferredQuality.indexOf(quality) !== -1,
                reputationBonus: repBonus,
                quality: quality
            };
        }
    };
})();
