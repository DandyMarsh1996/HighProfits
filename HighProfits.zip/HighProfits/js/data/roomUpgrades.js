/**
 * HighProfits - Room Upgrades
 * Upgrades that apply to an entire property/room
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.RoomUpgrades = (function() {
    'use strict';

    var categories = [
        { id: 'insulation', name: '🔲 Insulation', description: 'Light reflection and temperature control' },
        { id: 'ventilation', name: '💨 Ventilation', description: 'Air quality and circulation' },
        { id: 'climate', name: '🌡️ Climate', description: 'Temperature and humidity control' },
        { id: 'security', name: '🔒 Security', description: 'Protection and peace of mind' },
        { id: 'automation', name: '🤖 Automation', description: 'Sensors and smart control' },
        { id: 'pest', name: '🪲 Pest Control', description: 'Cleanliness and prevention' }
    ];

    var definitions = {
        // === INSULATION ===
        basic_foil: {
            id: 'basic_foil',
            name: 'Reflective Foil',
            description: 'Basic mylar sheets to reflect light back to plants.',
            category: 'insulation',
            cost: 50,
            unlockLevel: 1,
            icon: '🔲',
            growthBonus: 5,
            yieldBonus: 5,
            qualityBonus: 0
        },
        panda_film: {
            id: 'panda_film',
            name: 'Panda Film',
            description: 'Black/white poly film. Better light reflection.',
            category: 'insulation',
            cost: 120,
            unlockLevel: 4,
            icon: '⬜',
            growthBonus: 10,
            yieldBonus: 10,
            qualityBonus: 5
        },
        diamond_mylar: {
            id: 'diamond_mylar',
            name: 'Diamond Mylar',
            description: 'Premium reflective material. Maximum light efficiency.',
            category: 'insulation',
            cost: 300,
            unlockLevel: 10,
            icon: '💎',
            growthBonus: 15,
            yieldBonus: 15,
            qualityBonus: 10
        },
        soundproofing_panels: {
            id: 'soundproofing_panels',
            name: 'Soundproofing Panels',
            description: 'Reduces noise and helps maintain a stable environment.',
            category: 'insulation',
            cost: 220,
            unlockLevel: 6,
            icon: '🔇',
            growthBonus: 5,
            yieldBonus: 10,
            qualityBonus: 5
        },
        thermal_blankets: {
            id: 'thermal_blankets',
            name: 'Thermal Blankets',
            description: 'Improved insulation for colder climates. Consistent growth.',
            category: 'insulation',
            cost: 450,
            unlockLevel: 16,
            icon: '🧣',
            growthBonus: 15,
            yieldBonus: 10,
            qualityBonus: 10
        },

        // === VENTILATION ===
        basic_exhaust: {
            id: 'basic_exhaust',
            name: 'Exhaust Fan',
            description: 'Basic exhaust to remove hot air.',
            category: 'ventilation',
            cost: 75,
            unlockLevel: 1,
            icon: '🌀',
            growthBonus: 5,
            yieldBonus: 5,
            qualityBonus: 0
        },
        inline_fan: {
            id: 'inline_fan',
            name: 'Inline Fan System',
            description: 'Powerful inline fan with ducting.',
            category: 'ventilation',
            cost: 200,
            unlockLevel: 7,
            icon: '💨',
            growthBonus: 10,
            yieldBonus: 10,
            qualityBonus: 5
        },
        carbon_filter: {
            id: 'carbon_filter',
            name: 'Carbon Filter System',
            description: 'Activated carbon filter. Eliminates odors.',
            category: 'ventilation',
            cost: 350,
            unlockLevel: 10,
            icon: '🔘',
            growthBonus: 10,
            yieldBonus: 15,
            qualityBonus: 10
        },
        intake_system: {
            id: 'intake_system',
            name: 'Fresh Air Intake',
            description: 'Brings in fresh air for faster, healthier growth.',
            category: 'ventilation',
            cost: 180,
            unlockLevel: 4,
            icon: '🌬️',
            growthBonus: 8,
            yieldBonus: 10,
            qualityBonus: 0
        },
        hepa_filter: {
            id: 'hepa_filter',
            name: 'HEPA Filter',
            description: 'Cleaner air means fewer issues and better quality.',
            category: 'ventilation',
            cost: 500,
            unlockLevel: 16,
            icon: '🧼',
            growthBonus: 5,
            yieldBonus: 10,
            qualityBonus: 15
        },

        // === CLIMATE ===
        thermometer: {
            id: 'thermometer',
            name: 'Thermometer',
            description: 'Monitor temperature. Small growth bonus.',
            category: 'climate',
            cost: 25,
            unlockLevel: 1,
            icon: '🌡️',
            growthBonus: 3,
            yieldBonus: 0,
            qualityBonus: 0
        },
        humidifier: {
            id: 'humidifier',
            name: 'Humidifier',
            description: 'Maintain optimal humidity levels.',
            category: 'climate',
            cost: 150,
            unlockLevel: 6,
            icon: '💧',
            growthBonus: 8,
            yieldBonus: 8,
            qualityBonus: 5
        },
        ac_unit: {
            id: 'ac_unit',
            name: 'AC Unit',
            description: 'Keep temperatures perfect even in summer.',
            category: 'climate',
            cost: 400,
            unlockLevel: 10,
            icon: '❄️',
            growthBonus: 12,
            yieldBonus: 12,
            qualityBonus: 8
        },
        climate_controller: {
            id: 'climate_controller',
            name: 'Climate Controller',
            description: 'Automated temp and humidity. Professional grade.',
            category: 'climate',
            cost: 800,
            unlockLevel: 16,
            icon: '🎛️',
            growthBonus: 20,
            yieldBonus: 20,
            qualityBonus: 15
        },
        dehumidifier_upgrade: {
            id: 'dehumidifier_upgrade',
            name: 'Dehumidifier',
            description: 'Prevents mold and keeps buds dense. Big quality gain.',
            category: 'climate',
            cost: 350,
            unlockLevel: 8,
            icon: '🧽',
            growthBonus: 5,
            yieldBonus: 10,
            qualityBonus: 12
        },
        heater_unit: {
            id: 'heater_unit',
            name: 'Space Heater',
            description: 'Stable temps during winter. Faster growth.',
            category: 'climate',
            cost: 200,
            unlockLevel: 4,
            icon: '🔥',
            growthBonus: 10,
            yieldBonus: 5,
            qualityBonus: 0
        },

        // === SECURITY ===
        door_lock: {
            id: 'door_lock',
            name: 'Heavy Door Lock',
            description: 'Secure lock prevents theft. Protects your harvest.',
            category: 'security',
            cost: 50,
            unlockLevel: 1,
            icon: '🔐',
            growthBonus: 0,
            yieldBonus: 10,
            qualityBonus: 0
        },
        timer_system: {
            id: 'timer_system',
            name: 'Light Timer',
            description: 'Automate light schedules. Consistent growth.',
            category: 'security',
            cost: 100,
            unlockLevel: 4,
            icon: '⏰',
            growthBonus: 10,
            yieldBonus: 5,
            qualityBonus: 5
        },
        security_camera: {
            id: 'security_camera',
            name: 'Security Camera',
            description: 'Monitor your grow remotely. Deters thieves.',
            category: 'security',
            cost: 250,
            unlockLevel: 8,
            icon: '📹',
            growthBonus: 0,
            yieldBonus: 15,
            qualityBonus: 0
        },
        motion_sensors: {
            id: 'motion_sensors',
            name: 'Motion Sensors',
            description: 'Early warning and deterrence. Protects your yields.',
            category: 'security',
            cost: 180,
            unlockLevel: 6,
            icon: '🚨',
            growthBonus: 0,
            yieldBonus: 12,
            qualityBonus: 5
        },
        reinforced_safe: {
            id: 'reinforced_safe',
            name: 'Reinforced Safe',
            description: 'Secure storage for your best harvest. Peace of mind.',
            category: 'security',
            cost: 600,
            unlockLevel: 16,
            icon: '🧰',
            growthBonus: 0,
            yieldBonus: 25,
            qualityBonus: 0
        },

        // === AUTOMATION ===
        smart_sensors: {
            id: 'smart_sensors',
            name: 'Smart Sensors',
            description: 'Monitors temp/humidity/CO2 for consistent results.',
            category: 'automation',
            cost: 300,
            unlockLevel: 10,
            icon: '📡',
            growthBonus: 10,
            yieldBonus: 10,
            qualityBonus: 10
        },
        auto_ph_controller: {
            id: 'auto_ph_controller',
            name: 'Auto pH Controller',
            description: 'Perfect root-zone conditions. Boosts everything.',
            category: 'automation',
            cost: 900,
            unlockLevel: 20,
            icon: '🧪',
            growthBonus: 18,
            yieldBonus: 18,
            qualityBonus: 12
        },
        backup_generator: {
            id: 'backup_generator',
            name: 'Backup Generator',
            description: 'Power stability for critical systems. Fewer setbacks.',
            category: 'automation',
            cost: 1200,
            unlockLevel: 22,
            icon: '🔋',
            growthBonus: 10,
            yieldBonus: 10,
            qualityBonus: 5
        },
        full_automation_suite: {
            id: 'full_automation_suite',
            name: 'Full Automation Suite',
            description: 'Endgame sensors + automation. Maximum consistency.',
            category: 'automation',
            cost: 3000,
            unlockLevel: 24,
            icon: '🤖',
            growthBonus: 25,
            yieldBonus: 25,
            qualityBonus: 20
        },

        // === PEST CONTROL ===
        sticky_traps: {
            id: 'sticky_traps',
            name: 'Sticky Traps',
            description: 'Cheap prevention. Helps keep pests under control.',
            category: 'pest',
            cost: 60,
            unlockLevel: 1,
            icon: '🕸️',
            growthBonus: 0,
            yieldBonus: 0,
            qualityBonus: 5
        },
        ipm_kit: {
            id: 'ipm_kit',
            name: 'IPM Kit',
            description: 'Integrated pest management. Keeps plants healthy.',
            category: 'pest',
            cost: 260,
            unlockLevel: 10,
            icon: '🧴',
            growthBonus: 5,
            yieldBonus: 10,
            qualityBonus: 15
        },
        uv_sanitizer: {
            id: 'uv_sanitizer',
            name: 'UV Sanitizer',
            description: 'Sterilizes the space and prevents outbreaks.',
            category: 'pest',
            cost: 750,
            unlockLevel: 18,
            icon: '🟣',
            growthBonus: 5,
            yieldBonus: 10,
            qualityBonus: 25
        },
        clean_room_protocol: {
            id: 'clean_room_protocol',
            name: 'Clean Room Protocol',
            description: 'Endgame cleanliness and prevention. Elite quality protection.',
            category: 'pest',
            cost: 2500,
            unlockLevel: 21,
            icon: '🧫',
            growthBonus: 5,
            yieldBonus: 10,
            qualityBonus: 35
        }
    };

    return {
        getAll: function() { return definitions; },
        get: function(id) { return definitions[id] || null; },
        getIds: function() { return Object.keys(definitions); },
        getCategories: function() { return categories; },
        
        getByCategory: function(categoryId) {
            var items = [];
            for (var id in definitions) {
                if (definitions[id].category === categoryId) {
                    items.push(definitions[id]);
                }
            }
            return items;
        },

        getUnlocked: function(playerLevel) {
            var unlocked = [];
            for (var id in definitions) {
                if (definitions[id].unlockLevel <= playerLevel) {
                    unlocked.push(definitions[id]);
                }
            }
            return unlocked;
        },

        /**
         * Calculate total bonuses from installed room upgrades
         */
        calculateBonuses: function(installedUpgrades) {
            var bonuses = {
                growth: 0,
                yield: 0,
                quality: 0
            };

            if (!installedUpgrades) return bonuses;

            for (var i = 0; i < installedUpgrades.length; i++) {
                var upgrade = definitions[installedUpgrades[i]];
                if (upgrade) {
                    bonuses.growth += upgrade.growthBonus || 0;
                    bonuses.yield += upgrade.yieldBonus || 0;
                    bonuses.quality += upgrade.qualityBonus || 0;
                }
            }

            return bonuses;
        }
    };
})();
