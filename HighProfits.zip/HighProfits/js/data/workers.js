/**
 * HighProfits - Worker Definitions
 * Worker types, costs, and production rates
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Workers = (function() {
    'use strict';

    var definitions = {
        producer: {
            id: 'producer',
            name: 'Producer',
            namePlural: 'Producers',
            description: 'Generates raw materials over time',
            baseCost: 200,
            costMultiplier: 1.15,
            productionRate: 1,    // Raw materials per second
            icon: '👨‍🔬'
        },
        packer: {
            id: 'packer',
            name: 'Packer',
            namePlural: 'Packers',
            description: 'Converts raw materials into sellable bags',
            baseCost: 200,
            costMultiplier: 1.15,
            productionRate: 1,    // Bags per second (consumes raw materials)
            icon: '📦'
        },
        dealer: {
            id: 'dealer',
            name: 'Dealer',
            namePlural: 'Dealers',
            description: 'Automatically sells bags for money',
            baseCost: 1000,
            costMultiplier: 1.15,
            salesRate: 1,         // Bags sold per second
            icon: '🤝'
        }
    };

    // Order for display
    var displayOrder = ['producer', 'packer', 'dealer'];

    return {
        /**
         * Get all worker definitions
         */
        getAll: function() {
            return definitions;
        },

        /**
         * Get a specific worker type by ID
         */
        get: function(id) {
            return definitions[id] || null;
        },

        /**
         * Get all worker type IDs
         */
        getIds: function() {
            return Object.keys(definitions);
        },

        /**
         * Get worker types in display order
         */
        getDisplayOrder: function() {
            return displayOrder.slice();
        }
    };
})();
