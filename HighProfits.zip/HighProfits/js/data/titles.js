/**
 * HighProfits - Unlockable Titles
 * Titles displayed with character name; unlocked via journal and progress.
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Titles = (function() {
    'use strict';

    var titles = {
        street_hustler: { id: 'street_hustler', name: 'Street Hustler', description: 'Starting title', default: true },
        first_timer: { id: 'first_timer', name: 'First Timer', description: 'Bought your first seeds' },
        green_thumb: { id: 'green_thumb', name: 'Green Thumb', description: 'Harvested your first plant' },
        big_spender: { id: 'big_spender', name: 'Big Spender', description: 'Spent $1,000 at once' },
        dealer: { id: 'dealer', name: 'Dealer', description: 'Made your first sale' },
        grower: { id: 'grower', name: 'Grower', description: 'Harvested 10 plants' },
        supplier: { id: 'supplier', name: 'Supplier', description: 'Sold 50g total' },
        landscaper: { id: 'landscaper', name: 'Landscaper', description: 'Own 2 properties' },
        equipped: { id: 'equipped', name: 'Equipped', description: 'Bought 5 different equipment items' },
        collector: { id: 'collector', name: 'Collector', description: 'Own 5 different seed types' },
        breeder: { id: 'breeder', name: 'Breeder', description: 'Created your first hybrid' },
        hustler: { id: 'hustler', name: 'Hustler', description: 'Earned $10,000 total' },
        boss: { id: 'boss', name: 'Boss', description: 'Hired your first worker' },
        kingpin: { id: 'kingpin', name: 'Kingpin', description: 'Reach level 20' },
        legend: { id: 'legend', name: 'Legend', description: 'Complete 50 journal entries' },
        harvest_master: { id: 'harvest_master', name: 'Harvest Master', description: 'Harvest 100 plants (challenge)' },
        money_maker: { id: 'money_maker', name: 'Money Maker', description: 'Earn $10k total (challenge)' },
        property_mogul: { id: 'property_mogul', name: 'Property Mogul', description: 'Own 3 properties (challenge)' },
        real_estate_king: { id: 'real_estate_king', name: 'Real Estate King', description: 'Own 5 properties (challenge)' },
        veteran: { id: 'veteran', name: 'Veteran', description: 'Reach level 20 (challenge)' }
    };

    function get(id) {
        return titles[id] || null;
    }

    function getAll() {
        var list = [];
        for (var key in titles) {
            if (titles.hasOwnProperty(key)) list.push(titles[key]);
        }
        return list;
    }

    function getDefaultId() {
        for (var key in titles) {
            if (titles.hasOwnProperty(key) && titles[key].default) return titles[key].id;
        }
        return 'street_hustler';
    }

    return { get: get, getAll: getAll, getDefaultId: getDefaultId };
})();
