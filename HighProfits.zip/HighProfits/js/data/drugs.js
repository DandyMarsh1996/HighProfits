/**
 * HighProfits - Drug Definitions
 * Currently focused on weed only - other drugs will be added as game expands
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Drugs = (function() {
    'use strict';

    // Currently only weed is available
    // Future drugs will be added here as the game expands
    var definitions = {
        weed: {
            id: 'weed',
            name: 'Weed',
            emoji: '🌿',
            basePrice: 10,
            priceVariance: 0.2,
            rawName: 'grams',
            bagSize: 10,
            icon: 'weedicon.png',
            bagImage: 'weed.png',
            productionVerb: 'Grown',
            unlockLevel: 1,
            unlockDescription: 'Starting product'
        }
    };

    // Ordered list for progression (currently just weed)
    var unlockOrder = ['weed'];

    return {
        /**
         * Get all drug definitions
         */
        getAll: function() {
            return definitions;
        },

        /**
         * Get a specific drug by ID
         */
        get: function(id) {
            return definitions[id] || null;
        },

        /**
         * Get all drug IDs
         */
        getIds: function() {
            return Object.keys(definitions);
        },

        /**
         * Get drug IDs in unlock order
         */
        getUnlockOrder: function() {
            return unlockOrder.slice();
        },

        /**
         * Create empty inventory object for all drugs
         */
        createEmptyInventory: function() {
            var inventory = {};
            for (var id in definitions) {
                inventory[id] = { raw: 0, bagged: 0, produced: 0, packaged: 0, sold: 0 };
            }
            return inventory;
        },

        /**
         * Create empty workers object for all drugs
         */
        createEmptyWorkers: function() {
            var workers = {};
            for (var id in definitions) {
                workers[id] = { producers: 0, packers: 0, dealers: 0 };
            }
            return workers;
        }
    };
})();
