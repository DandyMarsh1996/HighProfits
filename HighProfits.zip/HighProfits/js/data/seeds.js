/**
 * HighProfits - Seed Definitions
 * Seeds that can be planted and grown
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Seeds = (function() {
    'use strict';

    // Seed definitions (strains)
    var definitions = {
        basic_seed: {
            id: 'basic_seed',
            name: 'Bag Seed',
            strainName: 'Unknown',
            description: 'Low quality bag seeds. Unreliable but cheap.',
            store: 'dealer',
            cost: 10,
            unlockLevel: 1,
            icon: '🌱',
            // Growing properties
            growthTime: 60,        // Total seconds to grow (when watered)
            baseYield: 5,          // Base grams per harvest
            yieldVariance: 0.3,    // +/- 30% yield variance
            quality: 'low',
            failureChance: 0.1,    // 10% chance plant dies if neglected
            waterConsumption: 1.0,  // Water usage multiplier (1.0 = normal)
            qualityBias: 0         // Chance to upgrade quality (0-100)
        },
        regular_seed: {
            id: 'regular_seed',
            name: 'Skunk #1',
            strainName: 'Skunk #1',
            description: 'Classic strain. Decent genetics from a local grower.',
            store: 'dealer',
            cost: 35,
            unlockLevel: 3,
            icon: '🌱',
            growthTime: 90,
            baseYield: 10,
            yieldVariance: 0.2,
            quality: 'medium',
            failureChance: 0.05,
            waterConsumption: 1.0,
            qualityBias: 5
        },
        feminized_seed: {
            id: 'feminized_seed',
            name: 'Northern Lights',
            strainName: 'Northern Lights',
            description: 'Feminized. Guaranteed female plants. Higher quality.',
            store: 'dealer',
            cost: 75,
            unlockLevel: 5,
            icon: '🌿',
            growthTime: 120,
            baseYield: 15,
            yieldVariance: 0.15,
            quality: 'good',
            failureChance: 0.02,
            waterConsumption: 0.9,  // Uses less water
            qualityBias: 15
        },
        autoflower_seed: {
            id: 'autoflower_seed',
            name: 'Quick Haze',
            strainName: 'Quick Haze',
            description: 'Autoflower variety. Fast growing, lower yield but quick.',
            store: 'dealer',
            cost: 60,
            unlockLevel: 6,
            icon: '⚡',
            growthTime: 45,        // Much faster
            baseYield: 7,
            yieldVariance: 0.1,
            quality: 'medium',
            failureChance: 0.02,
            waterConsumption: 1.2,  // Uses more water (fast growth)
            qualityBias: 5
        },
        // === LOW QUALITY SEEDS (Budget-friendly, fast turnover) ===
        ditch_weed_seed: {
            id: 'ditch_weed_seed',
            name: 'Ditch Weed',
            strainName: 'Roadside',
            description: 'Wild genetics. Very cheap, very fast, very low quality.',
            store: 'dealer',
            cost: 5,
            unlockLevel: 1,
            icon: '🌾',
            growthTime: 35,        // Super fast
            baseYield: 3,
            yieldVariance: 0.4,
            quality: 'low',
            failureChance: 0.15,
            waterConsumption: 1.3,
            qualityBias: 0
        },
        brick_weed_seed: {
            id: 'brick_weed_seed',
            name: 'Brick Weed',
            strainName: 'Compressed',
            description: 'Imported bulk seeds. Cheap and plentiful but harsh.',
            store: 'dealer',
            cost: 8,
            unlockLevel: 2,
            icon: '🧱',
            growthTime: 50,
            baseYield: 6,
            yieldVariance: 0.35,
            quality: 'low',
            failureChance: 0.12,
            waterConsumption: 1.2,
            qualityBias: 2
        },
        schwag_seed: {
            id: 'schwag_seed',
            name: 'Schwag',
            strainName: 'Budget Mix',
            description: 'Mixed bag seeds. Inconsistent but affordable.',
            store: 'dealer',
            cost: 12,
            unlockLevel: 2,
            icon: '📦',
            growthTime: 55,
            baseYield: 7,
            yieldVariance: 0.3,
            quality: 'low',
            failureChance: 0.1,
            waterConsumption: 1.15,
            qualityBias: 3
        },
        outdoor_seed: {
            id: 'outdoor_seed',
            name: 'Outdoor Mix',
            strainName: 'Outdoor',
            description: 'Hardy outdoor genetics. Low quality but reliable.',
            store: 'dealer',
            cost: 15,
            unlockLevel: 3,
            icon: '🌳',
            growthTime: 70,
            baseYield: 9,
            yieldVariance: 0.25,
            quality: 'low',
            failureChance: 0.08,
            waterConsumption: 1.0,
            qualityBias: 5
        },
        mexi_brick_seed: {
            id: 'mexi_brick_seed',
            name: 'Mexican Brick',
            strainName: 'Acapulco Low',
            description: 'Classic import. Fast and cheap for bulk operations.',
            store: 'dealer',
            cost: 18,
            unlockLevel: 4,
            icon: '🌮',
            growthTime: 65,
            baseYield: 10,
            yieldVariance: 0.28,
            quality: 'low',
            failureChance: 0.09,
            waterConsumption: 1.1,
            qualityBias: 4
        },
        // === MEDIUM QUALITY SEEDS (Balanced, consistent) ===
        ak47_seed: {
            id: 'ak47_seed',
            name: 'AK-47',
            strainName: 'AK-47',
            description: 'Reliable hybrid. Good balance of speed and quality.',
            store: 'dealer',
            cost: 45,
            unlockLevel: 5,
            icon: '🔫',
            growthTime: 85,
            baseYield: 12,
            yieldVariance: 0.18,
            quality: 'medium',
            failureChance: 0.04,
            waterConsumption: 1.0,
            qualityBias: 8
        },
        cheese_seed: {
            id: 'cheese_seed',
            name: 'UK Cheese',
            strainName: 'Cheese',
            description: 'Pungent indica. Consistent medium quality yields.',
            store: 'dealer',
            cost: 50,
            unlockLevel: 6,
            icon: '🧀',
            growthTime: 95,
            baseYield: 13,
            yieldVariance: 0.16,
            quality: 'medium',
            failureChance: 0.04,
            waterConsumption: 0.95,
            qualityBias: 10
        },
        trainwreck_seed: {
            id: 'trainwreck_seed',
            name: 'Trainwreck',
            strainName: 'Trainwreck',
            description: 'Fast-acting sativa. Quick growth, solid yields.',
            store: 'dealer',
            cost: 55,
            unlockLevel: 7,
            icon: '🚂',
            growthTime: 80,
            baseYield: 11,
            yieldVariance: 0.2,
            quality: 'medium',
            failureChance: 0.05,
            waterConsumption: 1.05,
            qualityBias: 7
        },
        bubba_kush_seed: {
            id: 'bubba_kush_seed',
            name: 'Bubba Kush',
            strainName: 'Bubba Kush',
            description: 'Heavy indica. Slower but reliable medium quality.',
            store: 'dealer',
            cost: 65,
            unlockLevel: 8,
            icon: '😴',
            growthTime: 110,
            baseYield: 16,
            yieldVariance: 0.14,
            quality: 'medium',
            failureChance: 0.03,
            waterConsumption: 0.92,
            qualityBias: 12
        },
        super_skunk_seed: {
            id: 'super_skunk_seed',
            name: 'Super Skunk',
            strainName: 'Super Skunk',
            description: 'Enhanced skunk genetics. Better than basic but affordable.',
            store: 'dealer',
            cost: 58,
            unlockLevel: 7,
            icon: '🦨',
            growthTime: 100,
            baseYield: 14,
            yieldVariance: 0.17,
            quality: 'medium',
            failureChance: 0.04,
            waterConsumption: 1.0,
            qualityBias: 9
        },
        critical_mass_seed: {
            id: 'critical_mass_seed',
            name: 'Critical Mass',
            strainName: 'Critical Mass',
            description: 'High yield indica. Medium quality but huge harvests.',
            store: 'dealer',
            cost: 70,
            unlockLevel: 9,
            icon: '⚖️',
            growthTime: 105,
            baseYield: 18,
            yieldVariance: 0.15,
            quality: 'medium',
            failureChance: 0.03,
            waterConsumption: 0.98,
            qualityBias: 11
        },
        amnesia_seed: {
            id: 'amnesia_seed',
            name: 'Amnesia Haze',
            strainName: 'Amnesia',
            description: 'Classic haze. Balanced medium quality with good yield.',
            store: 'dealer',
            cost: 68,
            unlockLevel: 9,
            icon: '🌫️',
            growthTime: 98,
            baseYield: 15,
            yieldVariance: 0.16,
            quality: 'medium',
            failureChance: 0.04,
            waterConsumption: 1.02,
            qualityBias: 10
        },
        premium_seed: {
            id: 'premium_seed',
            name: 'OG Kush',
            strainName: 'OG Kush',
            description: 'Premium genetics. Top shelf quality and yield.',
            store: 'dealer',
            cost: 150,
            unlockLevel: 12,
            icon: '💎',
            growthTime: 180,       // Takes longer
            baseYield: 25,
            yieldVariance: 0.1,
            quality: 'premium',
            failureChance: 0.01,
            waterConsumption: 0.8,  // Efficient water usage
            qualityBias: 30         // High chance to stay premium
        },
        // New strains for variety
        blue_dream_seed: {
            id: 'blue_dream_seed',
            name: 'Blue Dream',
            strainName: 'Blue Dream',
            description: 'Balanced hybrid. Good yield and quality.',
            store: 'dealer',
            cost: 100,
            unlockLevel: 8,
            icon: '💙',
            growthTime: 100,
            baseYield: 18,
            yieldVariance: 0.12,
            quality: 'good',
            failureChance: 0.02,
            waterConsumption: 1.0,
            qualityBias: 20
        },
        white_widow_seed: {
            id: 'white_widow_seed',
            name: 'White Widow',
            strainName: 'White Widow',
            description: 'High yield indica. Great for bulk growing.',
            store: 'dealer',
            cost: 120,
            unlockLevel: 10,
            icon: '❄️',
            growthTime: 140,
            baseYield: 22,
            yieldVariance: 0.1,
            quality: 'good',
            failureChance: 0.015,
            waterConsumption: 0.95,
            qualityBias: 18
        },
        // Exotic and rare strains
        purple_haze_seed: {
            id: 'purple_haze_seed',
            name: 'Purple Haze',
            strainName: 'Purple Haze',
            description: 'Rare sativa. Premium quality with unique effects.',
            store: 'dealer',
            cost: 200,
            unlockLevel: 14,
            icon: '💜',
            growthTime: 150,
            baseYield: 20,
            yieldVariance: 0.08,
            quality: 'premium',
            failureChance: 0.01,
            waterConsumption: 0.85,
            qualityBias: 40
        },
        gelato_seed: {
            id: 'gelato_seed',
            name: 'Gelato',
            strainName: 'Gelato',
            description: 'Exotic hybrid. High quality, balanced effects.',
            store: 'dealer',
            cost: 180,
            unlockLevel: 15,
            icon: '🍧',
            growthTime: 130,
            baseYield: 18,
            yieldVariance: 0.1,
            quality: 'premium',
            failureChance: 0.01,
            waterConsumption: 0.9,
            qualityBias: 35
        },
        gorilla_glue_seed: {
            id: 'gorilla_glue_seed',
            name: 'Gorilla Glue',
            strainName: 'Gorilla Glue #4',
            description: 'High THC indica. Powerful effects, premium quality.',
            store: 'dealer',
            cost: 220,
            unlockLevel: 17,
            icon: '🦍',
            growthTime: 160,
            baseYield: 24,
            yieldVariance: 0.08,
            quality: 'premium',
            failureChance: 0.008,
            waterConsumption: 0.88,
            qualityBias: 45
        },
        sour_diesel_seed: {
            id: 'sour_diesel_seed',
            name: 'Sour Diesel',
            strainName: 'Sour Diesel',
            description: 'Energizing sativa. Fast growth, good yields.',
            store: 'dealer',
            cost: 160,
            unlockLevel: 9,
            icon: '⛽',
            growthTime: 95,
            baseYield: 19,
            yieldVariance: 0.12,
            quality: 'good',
            failureChance: 0.02,
            waterConsumption: 1.1,
            qualityBias: 22
        },
        granddaddy_purple_seed: {
            id: 'granddaddy_purple_seed',
            name: 'Granddaddy Purple',
            strainName: 'GDP',
            description: 'Legendary indica. Maximum quality and potency.',
            store: 'dealer',
            cost: 300,
            unlockLevel: 20,
            icon: '👑',
            growthTime: 180,
            baseYield: 28,
            yieldVariance: 0.05,
            quality: 'premium',
            failureChance: 0.005,
            waterConsumption: 0.8,
            qualityBias: 50
        },
        jack_herer_seed: {
            id: 'jack_herer_seed',
            name: 'Jack Herer',
            strainName: 'Jack Herer',
            description: 'Award-winning sativa. Excellent quality and yield.',
            store: 'dealer',
            cost: 250,
            unlockLevel: 18,
            icon: '🎯',
            growthTime: 145,
            baseYield: 23,
            yieldVariance: 0.09,
            quality: 'premium',
            failureChance: 0.01,
            waterConsumption: 0.92,
            qualityBias: 38
        },
        durban_poison_seed: {
            id: 'durban_poison_seed',
            name: 'Durban Poison',
            strainName: 'Durban Poison',
            description: 'Classic landrace sativa. Fast and consistent.',
            store: 'dealer',
            cost: 210,
            unlockLevel: 13,
            icon: '🌍',
            growthTime: 110,
            baseYield: 20,
            yieldVariance: 0.1,
            quality: 'good',
            failureChance: 0.015,
            waterConsumption: 1.05,
            qualityBias: 25
        },
        girl_scout_cookies_seed: {
            id: 'girl_scout_cookies_seed',
            name: 'Girl Scout Cookies',
            strainName: 'GSC',
            description: 'Top-shelf hybrid. Huge quality potential.',
            store: 'dealer',
            cost: 340,
            unlockLevel: 22,
            icon: '🍪',
            growthTime: 170,
            baseYield: 30,
            yieldVariance: 0.07,
            quality: 'premium',
            failureChance: 0.006,
            waterConsumption: 0.85,
            qualityBias: 55
        },
        wedding_cake_seed: {
            id: 'wedding_cake_seed',
            name: 'Wedding Cake',
            strainName: 'Wedding Cake',
            description: 'Elite genetics. Dense buds and strong yields.',
            store: 'dealer',
            cost: 380,
            unlockLevel: 23,
            icon: '🎂',
            growthTime: 190,
            baseYield: 34,
            yieldVariance: 0.06,
            quality: 'premium',
            failureChance: 0.005,
            waterConsumption: 0.82,
            qualityBias: 60
        },
        platinum_kush_seed: {
            id: 'platinum_kush_seed',
            name: 'Platinum Kush',
            strainName: 'Platinum Kush',
            description: 'Endgame indica. Slow, heavy, premium harvests.',
            store: 'dealer',
            cost: 500,
            unlockLevel: 25,
            icon: '🏆',
            growthTime: 220,
            baseYield: 40,
            yieldVariance: 0.05,
            quality: 'premium',
            failureChance: 0.004,
            waterConsumption: 0.78,
            qualityBias: 70
        }
    };

    function get(seedId) {
        // Check regular definitions first
        if (definitions[seedId]) return definitions[seedId];
        
        // Check custom strains from state
        if (HP.State && HP.State.getCustomStrains) {
            var customStrains = HP.State.getCustomStrains();
            if (customStrains[seedId]) return customStrains[seedId];
        }
        
        return null;
    }

    function getAll() {
        var all = {};
        for (var id in definitions) {
            all[id] = definitions[id];
        }
        
        // Add custom strains
        if (HP.State && HP.State.getCustomStrains) {
            var customStrains = HP.State.getCustomStrains();
            for (var customId in customStrains) {
                all[customId] = customStrains[customId];
            }
        }
        
        return all;
    }

    return {
        getAll: getAll,
        get: get,
        getIds: function() {
            var all = getAll();
            return Object.keys(all);
        },
        
        getUnlocked: function(playerLevel) {
            var unlocked = [];
            var all = getAll();
            for (var id in all) {
                if (all[id].unlockLevel <= playerLevel) {
                    unlocked.push(all[id]);
                }
            }
            return unlocked;
        },

        // Kept for compatibility
        getStages: function() {
            return {
                empty: { id: 'empty', name: 'Empty' },
                growing: { id: 'growing', name: 'Growing' },
                harvest: { id: 'harvest', name: 'Ready' }
            };
        }
    };
})();
