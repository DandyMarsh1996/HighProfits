/**
 * HighProfits - Worker Skill / Level Progression Data
 * Single level + global bonus (efficiency & watering speed). Workers gain XP from actions.
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.WorkerSkills = (function() {
    'use strict';

    var MAX_LEVEL = 10;
    var XP_PER_PLANT = 8;
    var XP_PER_WATER = 4;
    var XP_PER_HARVEST = 12;
    var XP_PER_CLEAR = 6;
    /** Bonus per level: +2% efficiency and watering speed (capped at 20% at max level) */
    var BONUS_PER_LEVEL = 0.02;

    /**
     * XP required to reach level N (from level N-1).
     * Level 1→2: 100, 2→3: 120, 3→4: 144, etc. (20% increase per level)
     */
    function getXPForLevel(level) {
        if (level < 1 || level >= MAX_LEVEL) return 0;
        return Math.floor(100 * Math.pow(1.2, level - 1));
    }

    /**
     * Multiplier from level (1 + level * BONUS_PER_LEVEL, capped at MAX_LEVEL)
     */
    function getLevelBonus(level) {
        var lvl = Math.min(MAX_LEVEL, Math.max(1, level || 1));
        return 1 + (lvl - 1) * BONUS_PER_LEVEL;
    }

    return {
        MAX_LEVEL: MAX_LEVEL,
        XP_PER_PLANT: XP_PER_PLANT,
        XP_PER_WATER: XP_PER_WATER,
        XP_PER_HARVEST: XP_PER_HARVEST,
        XP_PER_CLEAR: XP_PER_CLEAR,
        getXPForLevel: getXPForLevel,
        getLevelBonus: getLevelBonus
    };
})();
