/**
 * HighProfits - Property Definitions
 * Properties the player can purchase to set up grow operations
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Properties = (function() {
    'use strict';

    var definitions = {
        closet: {
            id: 'closet',
            name: 'Spare Closet',
            description: 'A small closet in your apartment. Perfect for starting out.',
            plotCapacity: 2,
            cost: 0,
            unlockLevel: 1,
            icon: '🚪',
            cashCapBonus: 2500,
            bankCapBonus: 5000
        },
        spare_room: {
            id: 'spare_room',
            name: 'Spare Room',
            description: 'Convert a spare bedroom into a grow room.',
            plotCapacity: 4,
            cost: 500,
            unlockLevel: 3,
            icon: '🛏️',
            cashCapBonus: 4000,
            bankCapBonus: 8000
        },
        garage: {
            id: 'garage',
            name: 'Garage',
            description: 'A detached garage with more space and privacy.',
            plotCapacity: 8,
            cost: 2000,
            unlockLevel: 5,
            icon: '🏠',
            cashCapBonus: 6000,
            bankCapBonus: 12000
        },
        warehouse: {
            id: 'warehouse',
            name: 'Warehouse',
            description: 'An industrial warehouse for serious operations.',
            plotCapacity: 20,
            cost: 10000,
            unlockLevel: 8,
            icon: '🏭',
            cashCapBonus: 10000,
            bankCapBonus: 20000
        },
        farm: {
            id: 'farm',
            name: 'Rural Farm',
            description: 'A remote farm property. Maximum growing space.',
            plotCapacity: 50,
            cost: 50000,
            unlockLevel: 12,
            icon: '🌾',
            cashCapBonus: 15000,
            bankCapBonus: 35000
        },
        underground_bunker: {
            id: 'underground_bunker',
            name: 'Underground Bunker',
            description: 'Hidden underground facility. Maximum security and privacy.',
            plotCapacity: 30,
            cost: 75000,
            unlockLevel: 18,
            icon: '🕳️',
            cashCapBonus: 18000,
            bankCapBonus: 45000
        },
        rooftop_garden: {
            id: 'rooftop_garden',
            name: 'Rooftop Garden',
            description: 'Urban rooftop operation. Natural sunlight advantage.',
            plotCapacity: 25,
            cost: 60000,
            unlockLevel: 14,
            icon: '🏙️',
            cashCapBonus: 12000,
            bankCapBonus: 30000
        },
        industrial_complex: {
            id: 'industrial_complex',
            name: 'Industrial Complex',
            description: 'Massive industrial facility. Maximum capacity.',
            plotCapacity: 100,
            cost: 200000,
            unlockLevel: 22,
            icon: '🏗️',
            cashCapBonus: 25000,
            bankCapBonus: 60000
        },
        shipping_container: {
            id: 'shipping_container',
            name: 'Shipping Container',
            description: 'Portable grow unit. Easy to relocate.',
            plotCapacity: 12,
            cost: 30000,
            unlockLevel: 10,
            icon: '📦',
            cashCapBonus: 8000,
            bankCapBonus: 18000
        },
        greenhouse: {
            id: 'greenhouse',
            name: 'Commercial Greenhouse',
            description: 'Professional greenhouse. Natural and artificial light.',
            plotCapacity: 40,
            cost: 90000,
            unlockLevel: 16,
            icon: '🌿',
            cashCapBonus: 14000,
            bankCapBonus: 40000
        },
        highrise_penthouse: {
            id: 'highrise_penthouse',
            name: 'High-Rise Penthouse',
            description: 'Luxury rooftop grow with discretion and resources.',
            plotCapacity: 60,
            cost: 180000,
            unlockLevel: 20,
            icon: '🏙️',
            cashCapBonus: 20000,
            bankCapBonus: 55000
        },
        remote_compound: {
            id: 'remote_compound',
            name: 'Remote Compound',
            description: 'Off-grid compound. Massive space and low interference.',
            plotCapacity: 150,
            cost: 650000,
            unlockLevel: 24,
            icon: '🛰️',
            cashCapBonus: 35000,
            bankCapBonus: 90000
        },
        mega_facility: {
            id: 'mega_facility',
            name: 'Mega Facility',
            description: 'A sprawling endgame operation. Unlimited ambition, unlimited scale.',
            plotCapacity: 300,
            cost: 2500000,
            unlockLevel: 25,
            icon: '🏭',
            cashCapBonus: 60000,
            bankCapBonus: 150000
        }
    };

    var unlockOrder = ['closet', 'spare_room', 'garage', 'warehouse', 'farm', 'shipping_container', 'rooftop_garden', 'greenhouse', 'underground_bunker', 'highrise_penthouse', 'industrial_complex', 'remote_compound', 'mega_facility'];

    return {
        getAll: function() { return definitions; },
        get: function(id) { return definitions[id] || null; },
        getIds: function() { return Object.keys(definitions); },
        getUnlockOrder: function() { return unlockOrder.slice(); },
        getUnlockedProperties: function(playerLevel) {
            var unlocked = [];
            for (var i = 0; i < unlockOrder.length; i++) {
                var id = unlockOrder[i];
                if (definitions[id].unlockLevel <= playerLevel) {
                    unlocked.push(id);
                }
            }
            return unlocked;
        }
    };
})();
