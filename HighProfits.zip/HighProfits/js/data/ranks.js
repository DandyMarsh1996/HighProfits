/**
 * HighProfits - Rank Definitions
 * Player progression ranks and XP requirements
 * Note: Drug unlocks removed for now - focusing on weed only
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Ranks = (function() {
    'use strict';

    // Rank definitions in order
    // 25 total levels; steeper early curve so progression feels slower and rewards stay meaningful
    var definitions = [
        { level: 1,  name: 'Street Hustler',        xpRequired: 0,            icon: '🚶', bonus: null },
        { level: 2,  name: 'Corner Dealer',         xpRequired: 320,         icon: '🧍', bonus: 'Unlock Producers' },
        { level: 3,  name: 'Block Captain',         xpRequired: 900,        icon: '🏃', bonus: 'Unlock Packers' },
        { level: 4,  name: 'Distribution Lead',     xpRequired: 2000,        icon: '🚗', bonus: 'Unlock Dealers' },
        { level: 5,  name: 'Supplier',              xpRequired: 4200,        icon: '🚐', bonus: '+10% Production' },
        { level: 6,  name: 'Cartel Associate',     xpRequired: 9000,        icon: '🏎️', bonus: '+10% Sale Price' },
        { level: 7,  name: 'Cartel Lieutenant',    xpRequired: 20000,       icon: '✈️', bonus: '+25% Storage' },
        { level: 8,  name: 'Cartel Boss',           xpRequired: 42000,       icon: '🚁', bonus: '-10% Heat Gain' },
        { level: 9,  name: 'Kingpin',               xpRequired: 90000,      icon: '🏰', bonus: '+20% All Stats' },
        { level: 10, name: 'Drug Lord',             xpRequired: 190000,      icon: '👑', bonus: 'High Roller Status' },

        { level: 11, name: 'Underboss',             xpRequired: 400000,      icon: '🕴️', bonus: '+5% Growth Speed' },
        { level: 12, name: 'Syndicate Captain',     xpRequired: 820000,      icon: '🧳', bonus: '+10% Yield' },
        { level: 13, name: 'Syndicate Boss',        xpRequired: 1700000,     icon: '🧠', bonus: '+10% Quality Chance' },
        { level: 14, name: 'Operation Chief',       xpRequired: 3500000,     icon: '📋', bonus: '-5% Supply Costs' },
        { level: 15, name: 'Territory Controller',  xpRequired: 7200000,     icon: '🗺️', bonus: '+15% Sale Price' },

        { level: 16, name: 'Network Architect',     xpRequired: 14800000,   icon: '🕸️', bonus: '+15% Production' },
        { level: 17, name: 'Smuggling Director',   xpRequired: 30000000,    icon: '🚛', bonus: '-15% Heat Gain' },
        { level: 18, name: 'City Boss',             xpRequired: 61000000,    icon: '🏙️', bonus: '+25% Storage' },
        { level: 19, name: 'Regional Kingpin',      xpRequired: 124000000,   icon: '🌆', bonus: '+5% All Stats' },
        { level: 20, name: 'Empire Builder',        xpRequired: 250000000,   icon: '🏗️', bonus: '+10% All Stats' },

        { level: 21, name: 'Shadow Mogul',          xpRequired: 505000000,   icon: '🕶️', bonus: '+15% All Stats' },
        { level: 22, name: 'Global Operator',       xpRequired: 700000000,   icon: '🌍', bonus: '+20% All Stats' },
        { level: 23, name: 'Untouchable',           xpRequired: 970000000,   icon: '🧱', bonus: '-25% Heat Gain' },
        { level: 24, name: 'Legend',                xpRequired: 1350000000,  icon: '⭐', bonus: '+30% All Stats' },
        { level: 25, name: 'Mythic Drug Lord',      xpRequired: 1850000000,  icon: '🏆', bonus: 'Max Level' }
    ];

    return {
        /**
         * Get all rank definitions
         */
        getAll: function() {
            return definitions.slice();
        },

        /**
         * Get rank by level number
         */
        getByLevel: function(level) {
            for (var i = 0; i < definitions.length; i++) {
                if (definitions[i].level === level) {
                    return definitions[i];
                }
            }
            return null;
        },

        /**
         * Get the rank for a given XP amount
         */
        getForXP: function(xp) {
            var currentRank = definitions[0];
            for (var i = 0; i < definitions.length; i++) {
                if (xp >= definitions[i].xpRequired) {
                    currentRank = definitions[i];
                } else {
                    break;
                }
            }
            return currentRank;
        },

        /**
         * Get the next rank after the given level
         */
        getNext: function(currentLevel) {
            for (var i = 0; i < definitions.length; i++) {
                if (definitions[i].level > currentLevel) {
                    return definitions[i];
                }
            }
            return null; // Max level reached
        },

        /**
         * Get the maximum level
         */
        getMaxLevel: function() {
            return definitions[definitions.length - 1].level;
        },

        /**
         * Get XP required for a specific level
         */
        getXPRequired: function(level) {
            var rank = this.getByLevel(level);
            return rank ? rank.xpRequired : 0;
        }
    };
})();
