/**
 * HighProfits - Rank Definitions
 * Player progression ranks and XP requirements
 * Note: Drug unlocks removed for now - focusing on weed only
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Ranks = (function() {
    'use strict';

    // Rank definitions in order
    // 25 total levels with a steep XP curve (each level requires far more XP than the previous)
    var definitions = [
        { level: 1,  name: 'Street Hustler',        xpRequired: 0,            icon: '🚶', bonus: null },
        { level: 2,  name: 'Corner Dealer',         xpRequired: 150,          icon: '🧍', bonus: 'Unlock Producers' },
        { level: 3,  name: 'Block Captain',         xpRequired: 450,          icon: '🏃', bonus: 'Unlock Packers' },
        { level: 4,  name: 'Distribution Lead',     xpRequired: 1000,         icon: '🚗', bonus: 'Unlock Dealers' },
        { level: 5,  name: 'Supplier',              xpRequired: 2200,         icon: '🚐', bonus: '+10% Production' },
        { level: 6,  name: 'Cartel Associate',      xpRequired: 5000,         icon: '🏎️', bonus: '+10% Sale Price' },
        { level: 7,  name: 'Cartel Lieutenant',     xpRequired: 11000,        icon: '✈️', bonus: '+25% Storage' },
        { level: 8,  name: 'Cartel Boss',           xpRequired: 24000,        icon: '🚁', bonus: '-10% Heat Gain' },
        { level: 9,  name: 'Kingpin',               xpRequired: 52000,        icon: '🏰', bonus: '+20% All Stats' },
        { level: 10, name: 'Drug Lord',             xpRequired: 110000,       icon: '👑', bonus: 'High Roller Status' },

        { level: 11, name: 'Underboss',             xpRequired: 230000,       icon: '🕴️', bonus: '+5% Growth Speed' },
        { level: 12, name: 'Syndicate Captain',     xpRequired: 480000,       icon: '🧳', bonus: '+10% Yield' },
        { level: 13, name: 'Syndicate Boss',        xpRequired: 1000000,      icon: '🧠', bonus: '+10% Quality Chance' },
        { level: 14, name: 'Operation Chief',       xpRequired: 2100000,      icon: '📋', bonus: '-5% Supply Costs' },
        { level: 15, name: 'Territory Controller',  xpRequired: 4400000,      icon: '🗺️', bonus: '+15% Sale Price' },

        { level: 16, name: 'Network Architect',     xpRequired: 9200000,      icon: '🕸️', bonus: '+15% Production' },
        { level: 17, name: 'Smuggling Director',    xpRequired: 19000000,     icon: '🚛', bonus: '-15% Heat Gain' },
        { level: 18, name: 'City Boss',             xpRequired: 39000000,     icon: '🏙️', bonus: '+25% Storage' },
        { level: 19, name: 'Regional Kingpin',      xpRequired: 80000000,     icon: '🌆', bonus: '+5% All Stats' },
        { level: 20, name: 'Empire Builder',        xpRequired: 165000000,    icon: '🏗️', bonus: '+10% All Stats' },

        // Smoothed late-game curve: no single level is a huge wall (deltas ~100–400M)
        { level: 21, name: 'Shadow Mogul',          xpRequired: 365000000,    icon: '🕶️', bonus: '+15% All Stats' },
        { level: 22, name: 'Global Operator',       xpRequired: 505000000,    icon: '🌍', bonus: '+20% All Stats' },
        { level: 23, name: 'Untouchable',           xpRequired: 705000000,   icon: '🧱', bonus: '-25% Heat Gain' },
        { level: 24, name: 'Legend',                xpRequired: 985000000,    icon: '⭐', bonus: '+30% All Stats' },
        { level: 25, name: 'Mythic Drug Lord',      xpRequired: 1385000000,   icon: '🏆', bonus: 'Max Level' }
    ];

    return {
        /**
         * Get all rank definitions
         */
        getAll: function() {
            return definitions.slice();
        },

        /**
         * Get rank by level number
         */
        getByLevel: function(level) {
            for (var i = 0; i < definitions.length; i++) {
                if (definitions[i].level === level) {
                    return definitions[i];
                }
            }
            return null;
        },

        /**
         * Get the rank for a given XP amount
         */
        getForXP: function(xp) {
            var currentRank = definitions[0];
            for (var i = 0; i < definitions.length; i++) {
                if (xp >= definitions[i].xpRequired) {
                    currentRank = definitions[i];
                } else {
                    break;
                }
            }
            return currentRank;
        },

        /**
         * Get the next rank after the given level
         */
        getNext: function(currentLevel) {
            for (var i = 0; i < definitions.length; i++) {
                if (definitions[i].level > currentLevel) {
                    return definitions[i];
                }
            }
            return null; // Max level reached
        },

        /**
         * Get the maximum level
         */
        getMaxLevel: function() {
            return definitions[definitions.length - 1].level;
        },

        /**
         * Get XP required for a specific level
         */
        getXPRequired: function(level) {
            var rank = this.getByLevel(level);
            return rank ? rank.xpRequired : 0;
        }
    };
})();
