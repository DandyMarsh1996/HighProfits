/**
 * HighProfits - Completion Journal
 * Entries for buying, unlocking, milestones. Rewards (e.g. titles) when completed.
 */
var HP = HP || {};
HP.Data = HP.Data || {};

HP.Data.Journal = (function() {
    'use strict';

    var categories = {
        buying: { id: 'buying', name: 'Buying', order: 1 },
        growing: { id: 'growing', name: 'Growing', order: 2 },
        selling: { id: 'selling', name: 'Selling', order: 3 },
        unlocking: { id: 'unlocking', name: 'Unlocking', order: 4 },
        milestones: { id: 'milestones', name: 'Milestones', order: 5 }
    };

    var entries = [
        { id: 'first_seeds', name: 'First seeds', description: 'Buy your first seeds', category: 'buying', rewardTitleId: 'first_timer' },
        { id: 'first_equipment', name: 'First equipment', description: 'Buy any equipment (pot, soil, light, etc.)', category: 'buying', rewardTitleId: null },
        { id: 'five_equipment_types', name: 'Five equipment types', description: 'Own 5 different equipment items', category: 'buying', rewardTitleId: 'equipped' },
        { id: 'first_harvest', name: 'First harvest', description: 'Harvest your first plant', category: 'growing', rewardTitleId: 'green_thumb' },
        { id: 'harvest_10', name: 'Harvest 10', description: 'Harvest 10 plants', category: 'growing', rewardTitleId: 'grower' },
        { id: 'harvest_50', name: 'Harvest 50', description: 'Harvest 50 plants', category: 'growing', rewardTitleId: null },
        { id: 'first_sale', name: 'First sale', description: 'Sell product to a customer', category: 'selling', rewardTitleId: 'dealer' },
        { id: 'sell_50g', name: 'Sell 50g', description: 'Sell 50g of product total', category: 'selling', rewardTitleId: 'supplier' },
        { id: 'spend_1000', name: 'Big spender', description: 'Spend $1,000 in one go', category: 'buying', rewardTitleId: 'big_spender' },
        { id: 'own_2_properties', name: 'Two properties', description: 'Own 2 properties', category: 'unlocking', rewardTitleId: 'landscaper' },
        { id: 'own_3_properties', name: 'Three properties', description: 'Own 3 properties', category: 'unlocking', rewardTitleId: null },
        { id: 'own_5_properties', name: 'Five properties', description: 'Own 5 properties', category: 'unlocking', rewardTitleId: null },
        { id: 'own_5_seed_types', name: 'Seed collector', description: 'Own 5 different seed types', category: 'unlocking', rewardTitleId: 'collector' },
        { id: 'first_hybrid', name: 'First hybrid', description: 'Breed your first hybrid strain', category: 'unlocking', rewardTitleId: 'breeder' },
        { id: 'earn_10000', name: 'Earn $10k', description: 'Earn $10,000 total', category: 'milestones', rewardTitleId: 'hustler' },
        { id: 'first_worker', name: 'First worker', description: 'Hire your first worker', category: 'unlocking', rewardTitleId: 'boss' },
        { id: 'level_20', name: 'Level 20', description: 'Reach level 20', category: 'milestones', rewardTitleId: 'kingpin' },
        { id: 'first_launder', name: 'Clean money', description: 'Launder cash into the bank for the first time', category: 'unlocking', rewardTitleId: null },
        { id: 'first_water_upgrade', name: 'Water works', description: 'Buy your first water reservoir upgrade', category: 'unlocking', rewardTitleId: null },
        { id: 'first_heat_payoff', name: 'Under the radar', description: 'Pay off heat for the first time', category: 'unlocking', rewardTitleId: null },
        { id: 'contracts_10', name: 'Contract runner', description: 'Complete 10 delivery contracts', category: 'milestones', rewardTitleId: null },
        { id: 'harvest_all', name: 'Bulk harvest', description: 'Use Harvest all on a property', category: 'growing', rewardTitleId: null },
        { id: 'worker_upgrade', name: 'Promoted', description: 'Upgrade a worker to a higher tier', category: 'unlocking', rewardTitleId: null },
        { id: 'premium_mix', name: 'Premium blend', description: 'Create a 3-strain premium mix', category: 'unlocking', rewardTitleId: null },
        { id: 'worker_level_5', name: 'Skilled worker', description: 'Have a worker reach level 5', category: 'milestones', rewardTitleId: null },
        { id: 'worker_max_level', name: 'Veteran worker', description: 'Have a worker reach max level', category: 'milestones', rewardTitleId: null },
        { id: 'all_workers_level_3', name: 'Trained crew', description: 'Have all workers at level 3 or higher', category: 'milestones', rewardTitleId: null }
    ];

    function get(id) {
        for (var i = 0; i < entries.length; i++) {
            if (entries[i].id === id) return entries[i];
        }
        return null;
    }

    function getAll() {
        return entries.slice();
    }

    function getCategories() {
        return categories;
    }

    function getByCategory(categoryId) {
        return entries.filter(function(e) { return e.category === categoryId; });
    }

    return { get: get, getAll: getAll, getCategories: getCategories, getByCategory: getByCategory };
})();
