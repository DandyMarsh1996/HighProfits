/**
 * State domain: customer reputation, global reputation, relationship tier, special requests
 */
var HP = HP || {};

HP.StateReputation = {
    create: function(state, notify) {
        function getTier(rep) {
            if (rep >= 50) return 'Trusted';
            if (rep >= 25) return 'Regular';
            if (rep >= 10) return 'Acquaintance';
            return 'New';
        }

        return {
            getCustomerReputation: function(customerId) {
                if (!state.customerReputation) state.customerReputation = {};
                return state.customerReputation[customerId] || 0;
            },
            getRelationshipTier: function(customerId) {
                return getTier(this.getCustomerReputation(customerId));
            },
            addCustomerReputation: function(customerId, delta) {
                if (!state.customerReputation) state.customerReputation = {};
                var current = state.customerReputation[customerId] || 0;
                state.customerReputation[customerId] = current + delta;
                var newRep = state.customerReputation[customerId];
                if (newRep >= 50 && !(state.specialRequests && state.specialRequests[customerId])) {
                    if (!state.specialRequests) state.specialRequests = {};
                    var seeds = HP.Data.Seeds && HP.Data.Seeds.getAll ? HP.Data.Seeds.getAll() : {};
                    var seedIds = Object.keys(seeds);
                    if (seedIds.length > 0) {
                        var seedId = seedIds[Math.floor(Math.random() * seedIds.length)];
                        state.specialRequests[customerId] = {
                            seedId: seedId,
                            amount: 15 + Math.floor(Math.random() * 20),
                            payout: 250 + Math.floor(Math.random() * 350)
                        };
                        notify('specialRequests', state.specialRequests);
                    }
                }
                notify('customerReputation', state.customerReputation);
                return newRep;
            },
            getSpecialRequest: function(customerId) {
                return (state.specialRequests && state.specialRequests[customerId]) || null;
            },
            clearSpecialRequest: function(customerId) {
                if (state.specialRequests && state.specialRequests[customerId]) {
                    delete state.specialRequests[customerId];
                    notify('specialRequests', state.specialRequests);
                }
            },
            getReputation: function() { return state.reputation; },
            setReputation: function(value) {
                state.reputation = Math.max(0, Math.min(100, value));
                notify('reputation', state.reputation);
            }
        };
    }
};
