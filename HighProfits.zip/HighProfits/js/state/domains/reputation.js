/**
 * State domain: customer reputation, global reputation
 */
var HP = HP || {};

HP.StateReputation = {
    create: function(state, notify) {
        return {
            getCustomerReputation: function(customerId) {
                if (!state.customerReputation) state.customerReputation = {};
                return state.customerReputation[customerId] || 0;
            },
            addCustomerReputation: function(customerId, delta) {
                if (!state.customerReputation) state.customerReputation = {};
                var current = state.customerReputation[customerId] || 0;
                state.customerReputation[customerId] = current + delta;
                notify('customerReputation', state.customerReputation);
                return state.customerReputation[customerId];
            },
            getReputation: function() { return state.reputation; },
            setReputation: function(value) {
                state.reputation = Math.max(0, Math.min(100, value));
                notify('reputation', state.reputation);
            }
        };
    }
};
