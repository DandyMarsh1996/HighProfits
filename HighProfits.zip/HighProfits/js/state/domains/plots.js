/**
 * State domain: properties, plots, room upgrades
 */
var HP = HP || {};

HP.StatePlots = {
    create: function(state, notify, api) {
        return {
            getProperties: function() {
                var owned = (state.properties.owned || []).slice();
                return {
                    owned: owned.map(function(propId) {
                        return {
                            id: propId,
                            plots: (state.properties.plots[propId] || []).slice(),
                            upgrades: (state.properties.upgrades[propId] || []).slice()
                        };
                    })
                };
            },
            getOwnedProperties: function() { return state.properties.owned.slice(); },
            ownsProperty: function(propertyId) { return state.properties.owned.indexOf(propertyId) !== -1; },
            buyProperty: function(propertyId) {
                if (api.ownsProperty(propertyId)) return { success: false, message: 'Already owned' };
                var property = HP.Data.Properties.get(propertyId);
                if (!property) return { success: false, message: 'Invalid property' };
                if (!api.spendBank(property.cost)) return { success: false, message: 'Not enough bank funds. Real Estate requires clean money.' };
                state.properties.owned.push(propertyId);
                state.properties.plots[propertyId] = [];
                state.properties.upgrades[propertyId] = [];
                for (var i = 0; i < property.plotCapacity; i++) {
                    state.properties.plots[propertyId].push(HP.Growing.createEmptyPlot());
                }
                notify('properties', state.properties);
                return { success: true, message: 'Purchased ' + property.name };
            },
            getPlots: function(propertyId) {
                if (propertyId) return state.properties.plots[propertyId] || [];
                return state.properties.plots;
            },
            getPlot: function(propertyId, plotIndex) {
                var plots = state.properties.plots[propertyId];
                if (plots && plots[plotIndex]) return plots[plotIndex];
                return null;
            },
            getAllPlots: function() {
                var allPlots = [];
                for (var propId in state.properties.plots) {
                    var plots = state.properties.plots[propId];
                    for (var i = 0; i < plots.length; i++) {
                        allPlots.push({ propertyId: propId, plotIndex: i, plot: plots[i] });
                    }
                }
                return allPlots;
            },
            updatePlot: function(propertyId, plotIndex, updates) {
                var plot = api.getPlot(propertyId, plotIndex);
                if (!plot) return false;
                for (var key in updates) plot[key] = updates[key];
                notify('plots', state.properties.plots);
                return true;
            },
            getRoomUpgrades: function(propertyId) {
                if (!state.properties.upgrades[propertyId]) state.properties.upgrades[propertyId] = [];
                return state.properties.upgrades[propertyId].slice();
            },
            hasRoomUpgrade: function(propertyId, upgradeId) {
                var upgrades = api.getRoomUpgrades(propertyId);
                return upgrades.indexOf(upgradeId) !== -1;
            },
            addRoomUpgrade: function(propertyId, upgradeId) {
                if (!state.properties.upgrades[propertyId]) state.properties.upgrades[propertyId] = [];
                var upgrade = HP.Data.RoomUpgrades.get(upgradeId);
                if (!upgrade) return false;
                var existing = api.getRoomUpgrades(propertyId);
                for (var i = 0; i < existing.length; i++) {
                    var existingUpgrade = HP.Data.RoomUpgrades.get(existing[i]);
                    if (existingUpgrade && existingUpgrade.category === upgrade.category) {
                        api.removeRoomUpgrade(propertyId, existing[i]);
                        break;
                    }
                }
                if (existing.indexOf(upgradeId) === -1) {
                    state.properties.upgrades[propertyId].push(upgradeId);
                    notify('roomUpgrades', state.properties.upgrades);
                    return true;
                }
                return false;
            },
            removeRoomUpgrade: function(propertyId, upgradeId) {
                if (!state.properties.upgrades[propertyId]) return false;
                var index = state.properties.upgrades[propertyId].indexOf(upgradeId);
                if (index !== -1) {
                    state.properties.upgrades[propertyId].splice(index, 1);
                    notify('roomUpgrades', state.properties.upgrades);
                    return true;
                }
                return false;
            },
            getRoomBonuses: function(propertyId) {
                var upgrades = api.getRoomUpgrades(propertyId);
                return HP.Data.RoomUpgrades.calculateBonuses(upgrades);
            }
        };
    }
};
