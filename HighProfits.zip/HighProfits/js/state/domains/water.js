/**
 * State domain: water reservoir, water upgrades, heat reduction owned
 */
var HP = HP || {};

HP.StateWater = {
    create: function(state, notify, api) {
        return {
            getWaterCapacity: function() {
                var base = (HP.Data.Constants && HP.Data.Constants.WATER_RESERVOIR_BASE_CAPACITY != null) ? HP.Data.Constants.WATER_RESERVOIR_BASE_CAPACITY : 50;
                var owned = state.waterUpgradesOwned || [];
                var bonus = 0;
                if (HP.Data.WaterUpgrades) {
                    for (var i = 0; i < owned.length; i++) {
                        var up = HP.Data.WaterUpgrades.get(owned[i]);
                        if (up && up.capacityBonus) bonus += up.capacityBonus;
                    }
                }
                return base + bonus;
            },
            getWaterReservoir: function() {
                var w = state.waterReservoir;
                var capacity = api.getWaterCapacity();
                var current = Math.min(w.current || 0, capacity);
                if (current !== (w.current || 0)) state.waterReservoir.current = current;
                return { capacity: capacity, current: current, refillAccumulator: w.refillAccumulator || 0 };
            },
            useWater: function(amount) {
                amount = amount || (HP.Data.Constants && HP.Data.Constants.WATER_COST_PER_USE != null ? HP.Data.Constants.WATER_COST_PER_USE : 1);
                var current = state.waterReservoir.current || 0;
                if (current < amount) return false;
                state.waterReservoir.current = current - amount;
                notify('waterReservoir', state.waterReservoir);
                return true;
            },
            tickWaterRefill: function(deltaTime) {
                var interval = (HP.Data.Constants && HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS != null) ? HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS : 8;
                var cap = api.getWaterCapacity();
                var w = state.waterReservoir;
                var current = w.current || 0;
                if (current >= cap) return;
                w.refillAccumulator = (w.refillAccumulator || 0) + deltaTime;
                while (w.refillAccumulator >= interval && (w.current || 0) < cap) {
                    w.refillAccumulator -= interval;
                    w.current = Math.min((w.current || 0) + 1, cap);
                }
                if (w.refillAccumulator >= interval) w.refillAccumulator = w.refillAccumulator % interval;
                notify('waterReservoir', state.waterReservoir);
            },
            getWaterUpgradesOwned: function() { return (state.waterUpgradesOwned || []).slice(); },
            buyWaterUpgrade: function(upgradeId) {
                if (!HP.Data.WaterUpgrades) return false;
                var up = HP.Data.WaterUpgrades.get(upgradeId);
                if (!up || !state.waterUpgradesOwned) return false;
                if (state.waterUpgradesOwned.indexOf(upgradeId) !== -1) return false;
                if ((state.bank || 0) < up.cost) return false;
                state.bank -= up.cost;
                state.waterUpgradesOwned.push(upgradeId);
                var cap = api.getWaterCapacity();
                if ((state.waterReservoir.current || 0) > cap) state.waterReservoir.current = cap;
                notify('waterReservoir', state.waterReservoir);
                state.money = (state.cash || 0) + state.bank;
                notify('money', state.money);
                notify('bank', state.bank);
                return true;
            },
            getHeatReductionOwned: function() { return (state.heatReductionOwned || []).slice(); },
            buyHeatReduction: function(itemId) {
                if (!HP.Data.HeatReduction) return false;
                var item = HP.Data.HeatReduction.get(itemId);
                if (!item || !state.heatReductionOwned) return false;
                if (state.heatReductionOwned.indexOf(itemId) !== -1) return false;
                if ((state.bank || 0) < item.cost) return false;
                state.bank -= item.cost;
                state.heatReductionOwned.push(itemId);
                state.money = (state.cash || 0) + state.bank;
                notify('money', state.money);
                notify('bank', state.bank);
                return true;
            }
        };
    }
};
