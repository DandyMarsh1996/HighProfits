/**
 * State domain: challenges
 */
var HP = HP || {};

HP.StateChallenges = {
    create: function(state, notify) {
        return {
            getChallenges: function() {
                return {
                    active: state.challenges.active.slice(),
                    completed: state.challenges.completed.slice()
                };
            },
            addChallenge: function(challenge) {
                state.challenges.active.push(challenge);
                notify('challenge', state.challenges);
            },
            completeChallenge: function(challengeId) {
                if (state.challenges.completed.indexOf(challengeId) !== -1) return false;
                var index = state.challenges.active.findIndex(function(c) { return c.id === challengeId; });
                var challenge = null;
                if (index !== -1) {
                    challenge = state.challenges.active[index];
                    state.challenges.active.splice(index, 1);
                }
                state.challenges.completed.push(challengeId);
                notify('challengeCompleted', challenge || { id: challengeId });
                return true;
            }
        };
    }
};
