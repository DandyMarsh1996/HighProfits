/**
 * State domain: delivery contracts (supply Xg to customer by deadline for bonus)
 */
var HP = HP || {};

HP.StateContracts = {
    create: function(state, notify) {
        return {
            getActiveContracts: function() {
                if (!state.contracts) state.contracts = [];
                var now = Date.now();
                return state.contracts.filter(function(c) { return c.expiresAt > now && (c.amountFulfilled || 0) < c.amountRequired; });
            },
            addContract: function(customerId, seedId, amountRequired, payout, durationMs) {
                if (!state.contracts) state.contracts = [];
                var id = 'c_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
                state.contracts.push({
                    id: id,
                    customerId: customerId,
                    seedId: seedId,
                    amountRequired: amountRequired,
                    amountFulfilled: 0,
                    payout: payout,
                    expiresAt: Date.now() + (durationMs || 600000)
                });
                notify('contracts', state.contracts);
                return id;
            },
            fulfillContract: function(customerId, seedId, amount) {
                if (!state.contracts) return null;
                for (var i = 0; i < state.contracts.length; i++) {
                    var c = state.contracts[i];
                    if (c.customerId !== customerId || c.seedId !== seedId || c.expiresAt <= Date.now()) continue;
                    c.amountFulfilled = (c.amountFulfilled || 0) + amount;
                    if (c.amountFulfilled >= c.amountRequired) {
                        state.cash = (state.cash || 0) + c.payout;
                        state.money = (state.cash || 0) + (state.bank || 0);
                        state.contracts.splice(i, 1);
                        notify('money', state.money);
                        notify('cash', state.cash);
                        notify('contracts', state.contracts);
                        return { completed: true, payout: c.payout };
                    }
                    notify('contracts', state.contracts);
                    return { completed: false };
                }
                return null;
            }
        };
    }
};
