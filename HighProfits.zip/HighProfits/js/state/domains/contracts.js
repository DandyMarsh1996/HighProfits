/**
 * State domain: delivery contracts (supply Xg to customer by deadline for bonus)
 * Supports: strain, blend (seedId 'mixed'), and requiredQuality (minimum quality tier).
 */
var HP = HP || {};

var QUALITY_ORDER = ['low', 'medium', 'good', 'premium'];

HP.StateContracts = {
    create: function(state, notify) {
        function qualityMeets(minQuality, actualQuality) {
            if (!minQuality) return true;
            var mi = QUALITY_ORDER.indexOf(minQuality);
            var ai = QUALITY_ORDER.indexOf(actualQuality);
            if (mi === -1 || ai === -1) return true;
            return ai >= mi;
        }
        function seedIdMatches(contractSeedId, deliverySeedId) {
            if (contractSeedId === deliverySeedId) return true;
            if ((contractSeedId === 'mixed' || contractSeedId === 'mixed:any') && deliverySeedId && deliverySeedId.indexOf('mixed:') === 0) return true;
            return false;
        }
        return {
            getActiveContracts: function() {
                if (!state.contracts) state.contracts = [];
                var now = Date.now();
                return state.contracts.filter(function(c) { return c.expiresAt > now && (c.amountFulfilled || 0) < c.amountRequired; });
            },
            addContract: function(customerId, seedId, amountRequired, payout, durationMs, options) {
                if (!state.contracts) state.contracts = [];
                options = options || {};
                var id = 'c_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
                var contract = {
                    id: id,
                    customerId: customerId,
                    seedId: seedId,
                    amountRequired: amountRequired,
                    amountFulfilled: 0,
                    payout: payout,
                    expiresAt: Date.now() + (durationMs || 600000)
                };
                if (options.requiredQuality) contract.requiredQuality = options.requiredQuality;
                state.contracts.push(contract);
                notify('contracts', state.contracts);
                return id;
            },
            fulfillContract: function(customerId, seedId, amount, quality) {
                if (!state.contracts) return null;
                for (var i = 0; i < state.contracts.length; i++) {
                    var c = state.contracts[i];
                    if (c.customerId !== customerId || c.expiresAt <= Date.now()) continue;
                    if (!seedIdMatches(c.seedId, seedId)) continue;
                    if (!qualityMeets(c.requiredQuality, quality)) continue;
                    c.amountFulfilled = (c.amountFulfilled || 0) + amount;
                    if (c.amountFulfilled >= c.amountRequired) {
                        state.cash = (state.cash || 0) + c.payout;
                        state.money = (state.cash || 0) + (state.bank || 0);
                        state.contracts.splice(i, 1);
                        notify('money', state.money);
                        notify('cash', state.cash);
                        notify('contracts', state.contracts);
                        return { completed: true, payout: c.payout };
                    }
                    notify('contracts', state.contracts);
                    return { completed: false };
                }
                return null;
            }
        };
    }
};
