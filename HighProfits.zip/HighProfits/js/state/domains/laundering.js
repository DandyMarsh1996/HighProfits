/**
 * State domain: daily laundering usage per business (capacity resets each calendar day).
 */
var HP = HP || {};

HP.StateLaundering = {
    create: function(state, notify) {
        function todayString() {
            return new Date().toDateString();
        }

        function ensureDay() {
            if (!state.launderDaily) state.launderDaily = { date: '', byBusiness: {} };
            var today = todayString();
            if (state.launderDaily.date !== today) {
                state.launderDaily.date = today;
                state.launderDaily.byBusiness = {};
                notify('launderDaily', state.launderDaily);
            }
        }

        return {
            /** Returns $ already laundered through this business today. */
            getLaunderUsedToday: function(businessId) {
                ensureDay();
                return (state.launderDaily.byBusiness && state.launderDaily.byBusiness[businessId]) || 0;
            },
            /** Returns remaining $ capacity for this business today (0 if not owned or no capacity). */
            getLaunderCapacityRemaining: function(businessId) {
                ensureDay();
                var owned = (state.businessesOwned || []).indexOf(businessId) !== -1;
                if (!owned) return 0;
                var biz = HP.Data.Businesses && HP.Data.Businesses.get ? HP.Data.Businesses.get(businessId) : null;
                if (!biz || biz.dailyLaunderCapacity == null) return 0;
                var used = (state.launderDaily.byBusiness && state.launderDaily.byBusiness[businessId]) || 0;
                return Math.max(0, biz.dailyLaunderCapacity - used);
            },
            /** Record amount laundered through this business today. */
            recordLaunder: function(businessId, amount) {
                ensureDay();
                state.launderDaily.byBusiness[businessId] = (state.launderDaily.byBusiness[businessId] || 0) + amount;
                notify('launderDaily', state.launderDaily);
            }
        };
    }
};
