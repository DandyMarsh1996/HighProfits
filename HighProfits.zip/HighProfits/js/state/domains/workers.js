/**
 * State domain: grower workers + wage fund (pay per game day = 12 min)
 */
var HP = HP || {};

/** Parodies / thematic names (drug-TV vibes, stereotypical) – one picked at random when hired */
var WORKER_NAMES = [
    'Walt', 'Jesse', 'Saul', 'Mike', 'Gus', 'Tuco', 'Skinny Pete', 'Badger', 'Combo', 'Krazy-8',
    'Nancy', 'Silas', 'Shane', 'Doug', 'Andy', 'Conrad', 'Heylia', 'Guillermo', 'U-Turn', 'Ignacio',
    'Cheech', 'Chong', 'Dave', 'Ricky', 'Bubbles', 'Julian', 'Randy', 'Mr. Lahey', 'J-Roc', 'Trinity',
    'Tony', 'Vinnie', 'Sal', 'Lou', 'Frankie', 'Joey', 'Paulie', 'Bobby', 'Silvio', 'Christopher',
    'Smoky', 'Dank', 'Bud', 'Slim', 'Scooter', 'Skip', 'Rocco', 'Vinny', 'Gino', 'Marco',
    'Pablo', 'Hector', 'Nacho', 'Lalo', 'Tio', 'Gale', 'Todd', 'Lydia', 'Kuby', 'Huell',
    'Felix', 'Omar', 'Stringer', 'Avon', 'Bodie', 'Poot', 'Wee-Bey', 'Snoop', 'Marlo', 'Prop Joe',
    'Jimmy', 'Kim', 'Howard', 'Chuck', 'Nacho', 'Krazy', 'Spooge', 'Tortuga', 'Domingo', 'Gaff'
];

HP.StateWorkers = {
    create: function(state, notify) {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        var daySec = (c.WORKER_DAY_SECONDS != null) ? c.WORKER_DAY_SECONDS : 720;

        function pickWorkerName() {
            return WORKER_NAMES[Math.floor(Math.random() * WORKER_NAMES.length)];
        }

        return {
            getWorkerWageFund: function() { return state.workerWageFund != null ? state.workerWageFund : 0; },
            setWorkerWageFund: function(v) {
                state.workerWageFund = Math.max(0, Math.floor(v));
                notify('workerWageFund', state.workerWageFund);
            },
            /** Transfer amount from bank to wage fund. Returns true if successful. */
            addToWorkerWageFund: function(amount) {
                amount = Math.floor(amount);
                if (amount <= 0) return false;
                if (!HP.State.canAffordBank || !HP.State.canAffordBank(amount)) return false;
                HP.State.spendBank(amount);
                state.workerWageFund = (state.workerWageFund != null ? state.workerWageFund : 0) + amount;
                notify('workerWageFund', state.workerWageFund);
                return true;
            },
            getWorkerDayAccumulator: function() { return state.workerDayAccumulator != null ? state.workerDayAccumulator : 0; },
            setWorkerDayAccumulator: function(v) {
                state.workerDayAccumulator = v;
                notify('workerDayAccumulator', state.workerDayAccumulator);
            },
            getWorkerDaySeconds: function() { return daySec; },
            getGrowerWorkers: function() {
                var instances = state.growerWorkers.instances;
                var changed = false;
                var didMigrate = false;
                for (var i = 0; i < instances.length; i++) {
                    var w = instances[i];
                    if (!w.name) {
                        w.name = pickWorkerName();
                        changed = true;
                    }
                    if (w.assignedPlot && w.assignedPropertyId == null) {
                        w.assignedPropertyId = w.assignedPlot.propertyId;
                        changed = true;
                        didMigrate = true;
                    }
                }
                if (didMigrate) {
                    if (!state.progressTriggers) state.progressTriggers = {};
                    state.progressTriggers.workersMigratedToProperty = true;
                    notify('progressTriggers', state.progressTriggers);
                }
                if (changed) notify('growerWorkers', state.growerWorkers);
                return instances.slice();
            },
            addGrowerWorker: function(workerTypeId, assignedPropertyId, config) {
                var worker = {
                    id: 'worker_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
                    name: pickWorkerName(),
                    workerTypeId: workerTypeId,
                    assignedPropertyId: assignedPropertyId,
                    config: config || { seedId: null, soilId: null, fertilizerId: null },
                    status: 'active',
                    lastNotification: null,
                    lastActionAt: 0,
                    lastWaterAt: 0,
                    xp: 0,
                    level: 1
                };
                state.growerWorkers.instances.push(worker);
                notify('growerWorkers', state.growerWorkers);
                return worker;
            },
            removeGrowerWorker: function(workerId) {
                var index = state.growerWorkers.instances.findIndex(function(w) { return w.id === workerId; });
                if (index > -1) {
                    state.growerWorkers.instances.splice(index, 1);
                    notify('growerWorkers', state.growerWorkers);
                    return true;
                }
                return false;
            },
            getWorkersForProperty: function(propertyId) {
                return state.growerWorkers.instances.filter(function(w) {
                    var pid = w.assignedPropertyId != null ? w.assignedPropertyId : (w.assignedPlot && w.assignedPlot.propertyId);
                    return pid === propertyId;
                });
            },
            getWorkerByPlot: function(propertyId, plotIndex) {
                var atProp = state.growerWorkers.instances.filter(function(w) {
                    var pid = w.assignedPropertyId != null ? w.assignedPropertyId : (w.assignedPlot && w.assignedPlot.propertyId);
                    return pid === propertyId;
                });
                return atProp.length > 0 ? atProp[0] : null;
            },
            updateWorkerConfig: function(workerId, config) {
                var worker = state.growerWorkers.instances.find(function(w) { return w.id === workerId; });
                if (worker) {
                    worker.config = config;
                    notify('growerWorkers', state.growerWorkers);
                    return true;
                }
                return false;
            },
            setWorkerProperty: function(workerId, propertyId) {
                var worker = state.growerWorkers.instances.find(function(w) { return w.id === workerId; });
                if (!worker) return false;
                worker.assignedPropertyId = propertyId;
                if (worker.assignedPlot) delete worker.assignedPlot;
                notify('growerWorkers', state.growerWorkers);
                return true;
            },
            updateWorkerStatus: function(workerId, status, pauseReason) {
                var worker = state.growerWorkers.instances.find(function(w) { return w.id === workerId; });
                if (worker) {
                    worker.status = status;
                    if (pauseReason !== undefined) worker.pauseReason = pauseReason;
                    if (status === 'active') worker.pauseReason = null;
                    notify('growerWorkers', state.growerWorkers);
                    return true;
                }
                return false;
            },
            /** Change a worker's type (for upgrades). Keeps name, plot, config. */
            setWorkerTypeId: function(workerId, workerTypeId) {
                var worker = state.growerWorkers.instances.find(function(w) { return w.id === workerId; });
                if (!worker) return false;
                worker.workerTypeId = workerTypeId;
                notify('growerWorkers', state.growerWorkers);
                return true;
            },
            setWorkerNotification: function(workerId, timestamp) {
                var worker = state.growerWorkers.instances.find(function(w) { return w.id === workerId; });
                if (worker) {
                    worker.lastNotification = timestamp;
                    return true;
                }
                return false;
            },
            /** Add XP to a worker. Level up when XP threshold reached. Returns true if level changed. */
            addWorkerXP: function(workerId, amount) {
                var worker = state.growerWorkers.instances.find(function(w) { return w.id === workerId; });
                if (!worker || amount <= 0) return false;
                if (worker.level == null) worker.level = 1;
                if (worker.xp == null) worker.xp = 0;
                var maxLevel = HP.Data.WorkerSkills ? HP.Data.WorkerSkills.MAX_LEVEL : 10;
                if (worker.level >= maxLevel) return false;
                worker.xp += amount;
                var xpForNext = HP.Data.WorkerSkills && HP.Data.WorkerSkills.getXPForLevel
                    ? HP.Data.WorkerSkills.getXPForLevel(worker.level) : 100;
                var leveled = false;
                while (worker.level < maxLevel && worker.xp >= xpForNext) {
                    worker.xp -= xpForNext;
                    worker.level++;
                    leveled = true;
                    xpForNext = HP.Data.WorkerSkills && HP.Data.WorkerSkills.getXPForLevel
                        ? HP.Data.WorkerSkills.getXPForLevel(worker.level) : 100;
                }
                notify('growerWorkers', state.growerWorkers);
                return leveled;
            }
        };
    }
};
