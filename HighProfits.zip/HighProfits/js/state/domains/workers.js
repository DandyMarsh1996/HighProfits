/**
 * State domain: grower workers
 */
var HP = HP || {};

HP.StateWorkers = {
    create: function(state, notify) {
        return {
            getGrowerWorkers: function() { return state.growerWorkers.instances.slice(); },
            addGrowerWorker: function(workerTypeId, assignedPlot, config) {
                var worker = {
                    id: 'worker_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
                    workerTypeId: workerTypeId,
                    assignedPlot: assignedPlot,
                    config: config || { seedId: null, soilId: null, fertilizerId: null },
                    status: 'active',
                    lastNotification: null
                };
                state.growerWorkers.instances.push(worker);
                notify('growerWorkers', state.growerWorkers);
                return worker;
            },
            removeGrowerWorker: function(workerId) {
                var index = state.growerWorkers.instances.findIndex(function(w) { return w.id === workerId; });
                if (index > -1) {
                    state.growerWorkers.instances.splice(index, 1);
                    notify('growerWorkers', state.growerWorkers);
                    return true;
                }
                return false;
            },
            getWorkerByPlot: function(propertyId, plotIndex) {
                return state.growerWorkers.instances.find(function(w) {
                    return w.assignedPlot && w.assignedPlot.propertyId === propertyId && w.assignedPlot.plotIndex === plotIndex;
                });
            },
            updateWorkerConfig: function(workerId, config) {
                var worker = state.growerWorkers.instances.find(function(w) { return w.id === workerId; });
                if (worker) {
                    worker.config = config;
                    notify('growerWorkers', state.growerWorkers);
                    return true;
                }
                return false;
            },
            updateWorkerStatus: function(workerId, status) {
                var worker = state.growerWorkers.instances.find(function(w) { return w.id === workerId; });
                if (worker) {
                    worker.status = status;
                    notify('growerWorkers', state.growerWorkers);
                    return true;
                }
                return false;
            },
            setWorkerNotification: function(workerId, timestamp) {
                var worker = state.growerWorkers.instances.find(function(w) { return w.id === workerId; });
                if (worker) {
                    worker.lastNotification = timestamp;
                    return true;
                }
                return false;
            }
        };
    }
};
