/**
 * State domain: statistics
 */
var HP = HP || {};

HP.StateStats = {
    create: function(state, notify) {
        function deepClone(obj) { return JSON.parse(JSON.stringify(obj)); }
        return {
            getStats: function() { return deepClone(state.stats); },
            getStat: function(statName) {
                if (state.stats.hasOwnProperty(statName)) return state.stats[statName];
                return undefined;
            },
            setStat: function(statName, value) {
                if (state.stats.hasOwnProperty(statName)) {
                    state.stats[statName] = value;
                    notify('stats', state.stats);
                }
            },
            incrementStat: function(statName, amount) {
                if (!state.stats.hasOwnProperty(statName)) state.stats[statName] = 0;
                state.stats[statName] += amount;
                notify('stats', state.stats);
            }
        };
    }
};
