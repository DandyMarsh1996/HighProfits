/**
 * State domain: businesses (launder fee reduction)
 */
var HP = HP || {};

HP.StateBusinesses = {
    create: function(state, notify, api) {
        return {
            getBusinessesOwned: function() {
                return (state.businessesOwned || []).slice();
            },
            ownsBusiness: function(businessId) {
                return (state.businessesOwned || []).indexOf(businessId) !== -1;
            },
            buyBusiness: function(businessId) {
                if (api.ownsBusiness(businessId)) return { success: false, message: 'Already owned' };
                var business = HP.Data.Businesses && HP.Data.Businesses.get(businessId);
                if (!business) return { success: false, message: 'Invalid business' };
                if (!api.spendBank(business.cost)) return { success: false, message: 'Not enough bank funds.' };
                state.businessesOwned = state.businessesOwned || [];
                state.businessesOwned.push(businessId);
                notify('businesses', state.businessesOwned);
                return { success: true, message: 'Purchased ' + business.name };
            }
        };
    }
};
