/**
 * State domain: achievements
 */
var HP = HP || {};

HP.StateAchievements = {
    create: function(state, notify, api) {
        return {
            getAchievements: function() {
                return {
                    unlocked: state.achievements.unlocked.slice(),
                    notifications: state.achievements.notifications.slice()
                };
            },
            isAchievementUnlocked: function(achievementId) {
                return state.achievements.unlocked.indexOf(achievementId) !== -1;
            },
            unlockAchievement: function(achievementId) {
                if (api.isAchievementUnlocked(achievementId)) return false;
                var achievement = HP.Data.Achievements.get(achievementId);
                if (!achievement) return false;
                state.achievements.unlocked.push(achievementId);
                state.achievements.notifications.push(achievementId);
                if (achievement.xpReward) api.addXP(achievement.xpReward);
                notify('achievement', { id: achievementId, achievement: achievement });
                return true;
            },
            checkAchievements: function() {
                var currentUnlocked = state.achievements.unlocked.slice();
                var newlyUnlocked = HP.Data.Achievements.checkAchievements(state, currentUnlocked);
                for (var i = 0; i < newlyUnlocked.length; i++) {
                    api.unlockAchievement(newlyUnlocked[i]);
                }
                return newlyUnlocked.length;
            },
            clearAchievementNotifications: function() {
                state.achievements.notifications = [];
            }
        };
    }
};
