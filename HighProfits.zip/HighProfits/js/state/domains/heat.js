/**
 * State domain: heat, heat pay-off, raid
 */
var HP = HP || {};

HP.StateHeat = {
    create: function(state, notify, api) {
        return {
            getHeat: function() { return state.heat.level; },
            addHeat: function(amount) {
                state.heat.level = Math.min(state.heat.level + amount, state.heat.maxLevel);
                notify('heat', state.heat);
            },
            reduceHeat: function(amount) {
                state.heat.level = Math.max(state.heat.level - amount, 0);
                notify('heat', state.heat);
            },
            getHeatPayOffCount: function() { return state.heatPayOffCount || 0; },
            applyHeatReduction: function(actionId) {
                var result = HP.Heat && HP.Heat.getReductionCost ? HP.Heat.getReductionCost(actionId, state.heatPayOffCount || 0) : null;
                if (!result || result.cost === undefined) return { success: false, reason: 'unknown_action' };
                if ((state.cash || 0) < result.cost) return { success: false, reason: 'cant_afford', cost: result.cost };
                state.cash -= result.cost;
                state.heatPayOffCount = (state.heatPayOffCount || 0) + 1;
                if (state.stats.heatPayOffsTotal != null) state.stats.heatPayOffsTotal++;
                state.heat.level = Math.max(state.heat.level - result.reduction, 0);
                state.money = (state.cash || 0) + (state.bank || 0);
                notify('money', state.money);
                notify('cash', state.cash);
                notify('heat', state.heat);
                return { success: true, cost: result.cost, reduction: result.reduction };
            },
            triggerRaid: function() {
                var constants = HP.Data.Constants;
                var moneyPercent = (constants && constants.RAID_MONEY_LOSS_PERCENT != null) ? constants.RAID_MONEY_LOSS_PERCENT : 25;
                var productPercent = (constants && constants.RAID_PRODUCT_LOSS_PERCENT != null) ? constants.RAID_PRODUCT_LOSS_PERCENT : 30;
                var cash = state.cash || 0;
                var bank = state.bank || 0;
                var total = cash + bank;
                var moneyLost = Math.floor(total * (moneyPercent / 100));
                var cashRatio = total > 0 ? cash / total : 0.5;
                var cashLost = Math.min(cash, Math.floor(moneyLost * cashRatio));
                var bankLost = Math.min(bank, moneyLost - cashLost);
                state.cash = Math.max(0, cash - cashLost);
                state.bank = Math.max(0, bank - bankLost);
                state.money = state.cash + state.bank;
                var weed = state.inventory.weed || {};
                var qualities = ['low', 'medium', 'good', 'premium'];
                var productLost = { low: 0, medium: 0, good: 0, premium: 0 };
                for (var q = 0; q < qualities.length; q++) {
                    var qual = qualities[q];
                    var amt = weed[qual] || 0;
                    productLost[qual] = Math.floor(amt * (productPercent / 100));
                    state.inventory.weed[qual] = Math.max(0, amt - productLost[qual]);
                }
                state.heat.level = 0;
                state.heatPayOffCount = 0;
                if (state.stats.raidsTotal != null) state.stats.raidsTotal++;
                notify('money', state.money);
                notify('cash', state.cash);
                notify('bank', state.bank);
                notify('inventory', state.inventory);
                notify('heat', state.heat);
                return { moneyLost: moneyLost, productLost: productLost, newHeat: 0 };
            }
        };
    }
};
