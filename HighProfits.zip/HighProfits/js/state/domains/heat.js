/**
 * State domain: heat, heat pay-off, raid
 */
var HP = HP || {};

HP.StateHeat = {
    create: function(state, notify, api) {
        return {
            getHeat: function() { return state.heat.level; },
            addHeat: function(amount) {
                state.heat.level = Math.min(state.heat.level + amount, state.heat.maxLevel);
                notify('heat', state.heat);
            },
            reduceHeat: function(amount) {
                state.heat.level = Math.max(state.heat.level - amount, 0);
                notify('heat', state.heat);
            },
            getHeatPayOffCount: function() { return state.heatPayOffCount || 0; },
            applyHeatReduction: function(actionId) {
                var result = HP.Heat && HP.Heat.getReductionCost ? HP.Heat.getReductionCost(actionId, state.heatPayOffCount || 0) : null;
                if (!result || result.cost === undefined) return { success: false, reason: 'unknown_action' };
                if ((state.cash || 0) < result.cost) return { success: false, reason: 'cant_afford', cost: result.cost };
                state.cash -= result.cost;
                state.heatPayOffCount = (state.heatPayOffCount || 0) + 1;
                if (state.stats.heatPayOffsTotal != null) state.stats.heatPayOffsTotal++;
                state.heat.level = Math.max(state.heat.level - result.reduction, 0);
                state.money = (state.cash || 0) + (state.bank || 0);
                notify('money', state.money);
                notify('cash', state.cash);
                notify('heat', state.heat);
                return { success: true, cost: result.cost, reduction: result.reduction };
            },
            getPropertyLockedUntil: function(propertyId) {
                if (!state.propertyLockedUntil) state.propertyLockedUntil = {};
                return state.propertyLockedUntil[propertyId] || 0;
            },
            isPropertyLocked: function(propertyId) {
                var until = this.getPropertyLockedUntil(propertyId);
                return until > Date.now();
            },
            triggerRaid: function() {
                var constants = HP.Data.Constants;
                var moneyPercent = (constants && constants.RAID_MONEY_LOSS_PERCENT != null) ? constants.RAID_MONEY_LOSS_PERCENT : 25;
                var productPercent = (constants && constants.RAID_PRODUCT_LOSS_PERCENT != null) ? constants.RAID_PRODUCT_LOSS_PERCENT : 30;
                var bailPercent = (constants && constants.RAID_BAIL_PERCENT != null) ? constants.RAID_BAIL_PERCENT : 12;
                var lockMinutes = (constants && constants.RAID_PROPERTY_LOCK_MINUTES != null) ? constants.RAID_PROPERTY_LOCK_MINUTES : 3;
                var heatAfter = (constants && constants.RAID_HEAT_AFTER != null) ? constants.RAID_HEAT_AFTER : 15;
                var minMoneyAfter = (constants && constants.RAID_MIN_MONEY_AFTER != null) ? constants.RAID_MIN_MONEY_AFTER : 100;
                var minProductLeft = (constants && constants.RAID_MIN_PRODUCT_LEFT != null) ? constants.RAID_MIN_PRODUCT_LEFT : 1;
                var cash = state.cash || 0;
                var bank = state.bank || 0;
                var total = cash + bank;
                var moneyLost = Math.floor(total * (moneyPercent / 100));
                var bailPaid = Math.min(cash, Math.floor(total * (bailPercent / 100)));
                var totalDeduction = moneyLost + bailPaid;
                var totalAfter = total - totalDeduction;
                if (totalAfter < minMoneyAfter && total > minMoneyAfter) {
                    totalDeduction = total - minMoneyAfter;
                    var bailRatio = (moneyLost + bailPaid) > 0 ? bailPaid / (moneyLost + bailPaid) : 0.5;
                    bailPaid = Math.min(cash, Math.floor(totalDeduction * bailRatio));
                    moneyLost = totalDeduction - bailPaid;
                } else if (total <= minMoneyAfter) {
                    moneyLost = 0;
                    bailPaid = 0;
                }
                var cashRatio = total > 0 ? cash / total : 0.5;
                var cashLost = Math.min(cash, Math.floor(moneyLost * cashRatio));
                var bankLost = Math.min(bank, moneyLost - cashLost);
                state.cash = Math.max(0, cash - cashLost - bailPaid);
                state.bank = Math.max(0, bank - bankLost);
                state.money = state.cash + state.bank;
                if (state.money < minMoneyAfter && (cash + bank) >= minMoneyAfter) {
                    state.cash = Math.max(state.cash, minMoneyAfter - state.bank);
                    state.bank = Math.max(state.bank, minMoneyAfter - state.cash);
                    state.money = state.cash + state.bank;
                }
                var weed = state.inventory.weed || {};
                var productLost = {};
                var totalLost = 0;
                var hadProduct = false;
                var firstStrainId = null;
                for (var seedId in weed) {
                    var amt = weed[seedId] || 0;
                    if (amt > 0) { hadProduct = true; if (!firstStrainId) firstStrainId = seedId; }
                    var lost = Math.floor(amt * (productPercent / 100));
                    productLost[seedId] = lost;
                    totalLost += lost;
                    state.inventory.weed[seedId] = Math.max(0, amt - lost);
                    if (state.inventory.weed[seedId] <= 0) delete state.inventory.weed[seedId];
                }
                var remainingProduct = 0;
                for (var s in state.inventory.weed) remainingProduct += state.inventory.weed[s] || 0;
                if (hadProduct && remainingProduct === 0 && firstStrainId && minProductLeft > 0) {
                    state.inventory.weed[firstStrainId] = minProductLeft;
                    totalLost = Math.max(0, totalLost - minProductLeft);
                    if (productLost[firstStrainId] != null) productLost[firstStrainId] = Math.max(0, (productLost[firstStrainId] || 0) - minProductLeft);
                }
                state.heat.level = heatAfter;
                state.heatPayOffCount = 0;
                if (!state.propertyLockedUntil) state.propertyLockedUntil = {};
                var owned = (state.properties && state.properties.owned) || [];
                var lockedPropertyId = null;
                var lockedUntil = 0;
                if (owned.length > 1) {
                    var idx = Math.floor(Math.random() * owned.length);
                    lockedPropertyId = owned[idx];
                    lockedUntil = Date.now() + lockMinutes * 60 * 1000;
                    state.propertyLockedUntil[lockedPropertyId] = lockedUntil;
                }
                if (state.stats.raidsTotal != null) state.stats.raidsTotal++;
                notify('money', state.money);
                notify('cash', state.cash);
                notify('bank', state.bank);
                notify('inventory', state.inventory);
                notify('heat', state.heat);
                return { moneyLost: moneyLost, bailPaid: bailPaid, productLost: productLost, productLostTotal: totalLost, newHeat: heatAfter, lockedPropertyId: lockedPropertyId, lockedUntil: lockedUntil };
            }
        };
    }
};
