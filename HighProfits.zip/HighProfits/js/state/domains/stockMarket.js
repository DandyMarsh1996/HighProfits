/**
 * State domain: Stock market portfolio and prices. Cookie Clicker-style drift and mean reversion.
 * Prices persist; missing prices are seeded from Data.Stocks basePrice.
 */
var HP = HP || {};

HP.StateStockMarket = {
    create: function(state, notify) {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        var intervalSec = (c.STOCK_TICK_INTERVAL_SEC != null) ? c.STOCK_TICK_INTERVAL_SEC : 60;
        var accumKey = '_stockTickAccum';

        function ensurePrice(stockId) {
            if (state.stockPrices[stockId] != null) return state.stockPrices[stockId];
            var stock = HP.Data.Stocks && HP.Data.Stocks.get ? HP.Data.Stocks.get(stockId) : null;
            var base = stock && stock.basePrice != null ? stock.basePrice : 10;
            state.stockPrices[stockId] = base;
            return base;
        }

        return {
            getPortfolio: function() {
                return state.stockPortfolio ? Object.assign({}, state.stockPortfolio) : {};
            },
            getShares: function(stockId) {
                return (state.stockPortfolio && state.stockPortfolio[stockId]) || 0;
            },
            getPrice: function(stockId) {
                return ensurePrice(stockId);
            },
            getRestingPrice: function(stockId) {
                var stock = HP.Data.Stocks && HP.Data.Stocks.get ? HP.Data.Stocks.get(stockId) : null;
                return (stock && stock.basePrice != null) ? stock.basePrice : 10;
            },
            /** Seconds until next price tick (for countdown UI). */
            getStockTickSecondsRemaining: function() {
                var acc = state[accumKey] || 0;
                return Math.max(0, Math.ceil(intervalSec - acc));
            },
            getStockTickIntervalSec: function() { return intervalSec; },
            /** Total portfolio value (shares × current price) across all stocks. */
            getPortfolioValue: function() {
                var total = 0;
                var portfolio = state.stockPortfolio || {};
                for (var id in portfolio) {
                    if (portfolio[id] > 0) total += ensurePrice(id) * portfolio[id];
                }
                return total;
            },
            buy: function(stockId, shares) {
                if (!shares || shares < 1) return { success: false, message: 'Invalid amount' };
                var stock = HP.Data.Stocks && HP.Data.Stocks.get ? HP.Data.Stocks.get(stockId) : null;
                if (!stock) return { success: false, message: 'Unknown stock' };
                var price = ensurePrice(stockId);
                var feePct = (c.STOCK_BROKER_FEE_PERCENT != null) ? c.STOCK_BROKER_FEE_PERCENT : 2;
                var cost = Math.ceil(price * shares * (1 + feePct / 100));
                if (!HP.State.spendBank(cost)) return { success: false, message: 'Not enough bank funds. Need $' + (HP.Helpers && HP.Helpers.formatNumber ? HP.Helpers.formatNumber(cost) : cost) + '.' };
                state.stockPortfolio[stockId] = (state.stockPortfolio[stockId] || 0) + shares;
                var buyImpact = (c.STOCK_BUY_IMPACT != null) ? c.STOCK_BUY_IMPACT : 0.0003;
                state.stockPrices[stockId] = Math.max(c.STOCK_PRICE_MIN || 1, price * (1 + shares * buyImpact));
                notify('stockPortfolio', state.stockPortfolio);
                notify('stockPrices', state.stockPrices);
                return { success: true, cost: cost, newPrice: state.stockPrices[stockId] };
            },
            sell: function(stockId, shares) {
                if (!shares || shares < 1) return { success: false, message: 'Invalid amount' };
                var held = (state.stockPortfolio && state.stockPortfolio[stockId]) || 0;
                if (held < shares) return { success: false, message: 'You only have ' + held + ' share(s).' };
                var price = ensurePrice(stockId);
                var proceeds = Math.floor(price * shares);
                state.stockPortfolio[stockId] = held - shares;
                if (state.stockPortfolio[stockId] <= 0) delete state.stockPortfolio[stockId];
                var sellImpact = (c.STOCK_SELL_IMPACT != null) ? c.STOCK_SELL_IMPACT : 0.00015;
                state.stockPrices[stockId] = Math.max(c.STOCK_PRICE_MIN || 1, price * (1 - shares * sellImpact));
                HP.State.addBank(proceeds);
                notify('stockPortfolio', state.stockPortfolio);
                notify('stockPrices', state.stockPrices);
                return { success: true, proceeds: proceeds, newPrice: state.stockPrices[stockId] };
            },
            /** Called by game loop every deltaTime seconds. Accumulates and runs price tick every STOCK_TICK_INTERVAL_SEC. */
            tickStockMarket: function(deltaTime) {
                state[accumKey] = (state[accumKey] || 0) + deltaTime;
                if (state[accumKey] < intervalSec) return;
                state[accumKey] -= intervalSec;

                state.stockDeltas = state.stockDeltas || {};
                var minP = (c.STOCK_PRICE_MIN != null) ? c.STOCK_PRICE_MIN : 1;
                var floorBump = (c.STOCK_PRICE_FLOOR_BUMP != null) ? c.STOCK_PRICE_FLOOR_BUMP : 5;
                var meanRate = (c.STOCK_MEAN_REVERT_RATE != null) ? c.STOCK_MEAN_REVERT_RATE : 0.01;
                var randomRange = (c.STOCK_RANDOM_RANGE != null) ? c.STOCK_RANDOM_RANGE : 2;
                var all = HP.Data.Stocks && HP.Data.Stocks.getAll ? HP.Data.Stocks.getAll() : [];
                for (var i = 0; i < all.length; i++) {
                    var id = all[i].id;
                    var resting = all[i].basePrice != null ? all[i].basePrice : 10;
                    var price = ensurePrice(id);
                    var delta = (state.stockDeltas && state.stockDeltas[id]) || 0;
                    delta *= 0.97;
                    delta += (Math.random() * 2 - 1) * 0.05;
                    price += (resting - price) * meanRate;
                    price += (Math.random() * 2 - 1) * (Math.random() * Math.random()) * randomRange * 3;
                    price += delta;
                    if (price < floorBump) price += (floorBump - price) * 0.5;
                    if (price < minP) price = minP;
                    if (delta > 0 && price > resting * 2.5) delta *= 0.9;
                    var maxP = resting * 4;
                    if (price > maxP) price = maxP;
                    state.stockPrices[id] = Math.round(price * 100) / 100;
                    state.stockDeltas[id] = delta;
                }
                notify('stockPrices', state.stockPrices);
            }
        };
    }
};
