/**
 * State domain: tutorial
 */
var HP = HP || {};

HP.StateTutorial = {
    create: function(state, notify) {
        return {
            getTutorialStep: function() { return state.tutorialStep || 0; },
            setTutorialStep: function(step) {
                state.tutorialStep = step;
                notify('tutorial', state.tutorialStep);
            },
            isTutorialCompleted: function() { return state.tutorialCompleted || false; },
            completeTutorial: function() {
                state.tutorialCompleted = true;
                notify('tutorial', state.tutorialCompleted);
            },
            isTourCompleted: function() { return state.tourCompleted === true; },
            setTourCompleted: function(completed) {
                state.tourCompleted = !!completed;
                notify('tour', state.tourCompleted);
            }
        };
    }
};
