/**
 * State domain: strain mastery (track harvests per strain, unlock bonuses)
 */
var HP = HP || {};

HP.StateStrainMastery = {
    create: function(state, notify) {
        return {
            getStrainMastery: function(seedId) {
                if (!state.strainMastery) state.strainMastery = {};
                if (!state.strainMastery[seedId]) {
                    state.strainMastery[seedId] = { harvests: 0, level: 0 };
                }
                return state.strainMastery[seedId];
            },
            
            incrementStrainHarvests: function(seedId) {
                if (!state.strainMastery) state.strainMastery = {};
                if (!state.strainMastery[seedId]) {
                    state.strainMastery[seedId] = { harvests: 0, level: 0 };
                }
                state.strainMastery[seedId].harvests++;
                
                // Check for level up (every 10 harvests = 1 level, max 5)
                var newLevel = Math.min(5, Math.floor(state.strainMastery[seedId].harvests / 10));
                if (newLevel > state.strainMastery[seedId].level) {
                    state.strainMastery[seedId].level = newLevel;
                    notify('strainMastery', { seedId: seedId, level: newLevel });
                    return { leveledUp: true, newLevel: newLevel };
                }
                
                notify('strainMastery', state.strainMastery);
                return { leveledUp: false };
            },
            
            getStrainBonus: function(seedId) {
                var mastery = this.getStrainMastery(seedId);
                var level = mastery.level;
                // Each level: +5% yield, +3% quality chance, -2% growth time
                return {
                    yieldBonus: level * 5,
                    qualityBonus: level * 3,
                    growthSpeedBonus: level * 2
                };
            },
            
            getAllMasteries: function() {
                if (!state.strainMastery) state.strainMastery = {};
                return Object.assign({}, state.strainMastery);
            }
        };
    }
};
