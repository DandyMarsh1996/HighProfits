/**
 * State domain: character (name, titles, journal)
 */
var HP = HP || {};

HP.StateCharacter = {
    create: function(state, notify, api) {
        return {
            getCharacterId: function() { return state.characterId || null; },
            setCharacterId: function(id) {
                state.characterId = id || null;
                notify('character', state.characterId);
            },
            getCharacterName: function() { return state.characterName || ''; },
            setCharacterName: function(name) {
                state.characterName = String(name || '').trim() || 'Player';
                notify('character', state.characterName);
            },
            getUnlockedTitles: function() { return (state.unlockedTitles || []).slice(); },
            unlockTitle: function(titleId) {
                if (!state.unlockedTitles) state.unlockedTitles = [];
                if (state.unlockedTitles.indexOf(titleId) === -1) {
                    state.unlockedTitles.push(titleId);
                    notify('titles', state.unlockedTitles);
                }
            },
            getSelectedTitleId: function() { return state.selectedTitleId || 'street_hustler'; },
            setSelectedTitleId: function(titleId) {
                state.selectedTitleId = titleId || 'street_hustler';
                notify('titles', state.selectedTitleId);
            },
            setUnlockedTitles: function(arr) {
                state.unlockedTitles = Array.isArray(arr) ? arr.slice() : [];
                notify('titles', state.unlockedTitles);
            },
            getJournalCompleted: function() { return state.journalCompleted ? Object.assign({}, state.journalCompleted) : {}; },
            isJournalEntryComplete: function(entryId) { return !!(state.journalCompleted && state.journalCompleted[entryId]); },
            completeJournalEntry: function(entryId) {
                if (!state.journalCompleted) state.journalCompleted = {};
                if (state.journalCompleted[entryId]) return false;
                state.journalCompleted[entryId] = true;
                var entry = HP.Data.Journal && HP.Data.Journal.get(entryId);
                if (entry && entry.rewardTitleId) {
                    api.unlockTitle(entry.rewardTitleId);
                }
                notify('journal', state.journalCompleted);
                return true;
            }
        };
    }
};
