/**
 * State domain: genetics, custom strains, strain library
 */
var HP = HP || {};

HP.StateGenetics = {
    create: function(state, notify) {
        return {
            getCustomStrains: function() { return state.customStrains || {}; },
            addCustomStrain: function(strainDef) {
                if (!state.customStrains) state.customStrains = {};
                state.customStrains[strainDef.id] = strainDef;
                if (!state.strainLibrary) state.strainLibrary = [];
                if (state.strainLibrary.indexOf(strainDef.id) === -1) {
                    state.strainLibrary.push(strainDef.id);
                }
                notify('customStrains', state.customStrains);
                return true;
            },
            getStrainLibrary: function() { return (state.strainLibrary || []).slice(); },
            hasStrain: function(strainId) {
                if (HP.Data.Seeds.get(strainId)) return true;
                if (state.customStrains && state.customStrains[strainId]) return true;
                return false;
            }
        };
    }
};
