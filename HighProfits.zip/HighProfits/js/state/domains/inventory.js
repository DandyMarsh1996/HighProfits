/**
 * State domain: inventory (weed by strain, seeds, equipment)
 */
var HP = HP || {};

HP.StateInventory = {
    create: function(state, notify) {
        function deepClone(obj) { return JSON.parse(JSON.stringify(obj)); }

        /** Migrate legacy quality-based weed to strain-based (one seed per quality tier). */
        function migrateWeedIfLegacy() {
            var w = state.inventory.weed;
            if (!w || typeof w !== 'object') return;
            var hasLegacy = w.low != null || w.medium != null || w.good != null || w.premium != null;
            if (!hasLegacy) return;
            var defaults = { low: 'basic_seed', medium: 'regular_seed', good: 'feminized_seed', premium: 'premium_seed' };
            for (var q in defaults) {
                var amt = w[q];
                if (amt && amt > 0) {
                    var seedId = defaults[q];
                    if (!state.inventory.weed[seedId]) state.inventory.weed[seedId] = 0;
                    state.inventory.weed[seedId] += amt;
                }
                delete w[q];
            }
            notify('inventory', state.inventory);
        }

        return {
            getInventory: function() {
                migrateWeedIfLegacy();
                return deepClone(state.inventory);
            },
            getWeed: function(seedId) {
                migrateWeedIfLegacy();
                if (seedId) return state.inventory.weed[seedId] || 0;
                return deepClone(state.inventory.weed || {});
            },
            addWeed: function(seedId, amount) {
                migrateWeedIfLegacy();
                if (!state.inventory.weed[seedId]) state.inventory.weed[seedId] = 0;
                state.inventory.weed[seedId] += amount;
                state.stats.totalHarvested += amount;
                notify('inventory', state.inventory);
            },
            removeWeed: function(seedId, amount) {
                migrateWeedIfLegacy();
                var current = state.inventory.weed[seedId] || 0;
                var removed = Math.min(current, amount);
                state.inventory.weed[seedId] = current - removed;
                if (state.inventory.weed[seedId] <= 0) delete state.inventory.weed[seedId];
                notify('inventory', state.inventory);
                return removed;
            },
            getTotalWeed: function() {
                migrateWeedIfLegacy();
                var total = 0;
                var w = state.inventory.weed || {};
                for (var id in w) total += w[id];
                return total;
            },
            getSeeds: function(seedId) {
                if (seedId) return state.inventory.seeds[seedId] || 0;
                return deepClone(state.inventory.seeds);
            },
            addSeeds: function(seedId, amount) {
                if (!state.inventory.seeds[seedId]) state.inventory.seeds[seedId] = 0;
                state.inventory.seeds[seedId] += amount;
                notify('inventory', state.inventory);
            },
            removeSeeds: function(seedId, amount) {
                var current = state.inventory.seeds[seedId] || 0;
                var removed = Math.min(current, amount);
                state.inventory.seeds[seedId] = current - removed;
                notify('inventory', state.inventory);
                return removed;
            },
            getEquipment: function(equipmentId) {
                if (equipmentId) return state.inventory.equipment[equipmentId] || 0;
                return deepClone(state.inventory.equipment);
            },
            addEquipment: function(equipmentId, amount) {
                if (!state.inventory.equipment[equipmentId]) state.inventory.equipment[equipmentId] = 0;
                state.inventory.equipment[equipmentId] += amount;
                notify('inventory', state.inventory);
            },
            removeEquipment: function(equipmentId, amount) {
                var current = state.inventory.equipment[equipmentId] || 0;
                var removed = Math.min(current, amount);
                state.inventory.equipment[equipmentId] = current - removed;
                notify('inventory', state.inventory);
                return removed;
            }
        };
    }
};
