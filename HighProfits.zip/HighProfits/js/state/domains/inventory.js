/**
 * State domain: inventory (weed, seeds, equipment)
 */
var HP = HP || {};

HP.StateInventory = {
    create: function(state, notify) {
        function deepClone(obj) { return JSON.parse(JSON.stringify(obj)); }
        return {
            getInventory: function() { return deepClone(state.inventory); },
            getWeed: function(quality) {
                if (quality) return state.inventory.weed[quality] || 0;
                return deepClone(state.inventory.weed);
            },
            addWeed: function(quality, amount) {
                if (!state.inventory.weed[quality]) state.inventory.weed[quality] = 0;
                state.inventory.weed[quality] += amount;
                state.stats.totalHarvested += amount;
                notify('inventory', state.inventory);
            },
            removeWeed: function(quality, amount) {
                var current = state.inventory.weed[quality] || 0;
                var removed = Math.min(current, amount);
                state.inventory.weed[quality] = current - removed;
                notify('inventory', state.inventory);
                return removed;
            },
            getTotalWeed: function() {
                var total = 0;
                for (var q in state.inventory.weed) total += state.inventory.weed[q];
                return total;
            },
            getSeeds: function(seedId) {
                if (seedId) return state.inventory.seeds[seedId] || 0;
                return deepClone(state.inventory.seeds);
            },
            addSeeds: function(seedId, amount) {
                if (!state.inventory.seeds[seedId]) state.inventory.seeds[seedId] = 0;
                state.inventory.seeds[seedId] += amount;
                notify('inventory', state.inventory);
            },
            removeSeeds: function(seedId, amount) {
                var current = state.inventory.seeds[seedId] || 0;
                var removed = Math.min(current, amount);
                state.inventory.seeds[seedId] = current - removed;
                notify('inventory', state.inventory);
                return removed;
            },
            getEquipment: function(equipmentId) {
                if (equipmentId) return state.inventory.equipment[equipmentId] || 0;
                return deepClone(state.inventory.equipment);
            },
            addEquipment: function(equipmentId, amount) {
                if (!state.inventory.equipment[equipmentId]) state.inventory.equipment[equipmentId] = 0;
                state.inventory.equipment[equipmentId] += amount;
                notify('inventory', state.inventory);
            },
            removeEquipment: function(equipmentId, amount) {
                var current = state.inventory.equipment[equipmentId] || 0;
                var removed = Math.min(current, amount);
                state.inventory.equipment[equipmentId] = current - removed;
                notify('inventory', state.inventory);
                return removed;
            }
        };
    }
};
