/**
 * State domain: progress triggers (one-off flags so tutorials/triggers don't repeat)
 */
var HP = HP || {};

HP.StateProgress = {
    create: function(state, notify) {
        return {
            getProgressTriggers: function() { return state.progressTriggers && typeof state.progressTriggers === 'object' ? Object.assign({}, state.progressTriggers) : {}; },
            setProgressTrigger: function(id, value) {
                if (!state.progressTriggers) state.progressTriggers = {};
                state.progressTriggers[id] = !!value;
                notify('progressTriggers', state.progressTriggers);
            },
            hasProgressTrigger: function(id) { return !!(state.progressTriggers && state.progressTriggers[id]); },
            getLastSeenChangelogVersion: function() { return state.lastSeenChangelogVersion != null ? state.lastSeenChangelogVersion : null; },
            setLastSeenChangelogVersion: function(version) {
                state.lastSeenChangelogVersion = version != null ? String(version) : null;
                notify('lastSeenChangelogVersion', state.lastSeenChangelogVersion);
            }
        };
    }
};
