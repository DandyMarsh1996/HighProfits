/**
 * State domain: active smoke buff (one at a time, expires after duration).
 * Buff type is derived from strain effects when smoking.
 */
var HP = HP || {};

HP.StateSmokeBuff = {
    create: function(state, notify) {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        var durationMs = (c.SMOKE_BUFF_DURATION_MS != null) ? c.SMOKE_BUFF_DURATION_MS : 120000;
        var growthMult = (c.SMOKE_BUFF_GROWTH_MULT != null) ? c.SMOKE_BUFF_GROWTH_MULT : 0.9;
        var yieldMult = (c.SMOKE_BUFF_YIELD_MULT != null) ? c.SMOKE_BUFF_YIELD_MULT : 1.1;
        var heatMult = (c.SMOKE_BUFF_HEAT_MULT != null) ? c.SMOKE_BUFF_HEAT_MULT : 0.85;
        var saleMult = (c.SMOKE_BUFF_SALE_MULT != null) ? c.SMOKE_BUFF_SALE_MULT : 1.1;
        var repBonus = (c.SMOKE_BUFF_REP_BONUS != null) ? c.SMOKE_BUFF_REP_BONUS : 1;

        /** Effect id -> buff type for smoking */
        var effectToBuffType = {
            fast_growth: 'growth',
            high_yield: 'yield',
            heat_low: 'heat',
            sale_premium: 'sale',
            rep_boost: 'rep',
            water_efficient: 'growth',  // map to growth as generic "focus"
            hardy: 'yield',
            premium_genes: 'sale'
        };

        function checkExpiry() {
            if (!state.activeSmokeBuff || !state.activeSmokeBuff.expiresAt) return;
            if (Date.now() >= state.activeSmokeBuff.expiresAt) {
                state.activeSmokeBuff = null;
                notify('activeSmokeBuff', null);
            }
        }

        return {
            getActiveSmokeBuff: function() {
                checkExpiry();
                return state.activeSmokeBuff ? {
                    seedId: state.activeSmokeBuff.seedId,
                    strainName: state.activeSmokeBuff.strainName,
                    expiresAt: state.activeSmokeBuff.expiresAt,
                    buffType: state.activeSmokeBuff.buffType
                } : null;
            },
            setActiveSmokeBuff: function(seedId, strainName, buffType) {
                state.activeSmokeBuff = {
                    seedId: seedId,
                    strainName: strainName,
                    expiresAt: Date.now() + durationMs,
                    buffType: buffType
                };
                notify('activeSmokeBuff', state.activeSmokeBuff);
            },
            clearSmokeBuff: function() {
                state.activeSmokeBuff = null;
                notify('activeSmokeBuff', null);
            },
            getSmokeBuffDurationMs: function() { return durationMs; },
            /** Returns multiplier for growth (1 = normal, <1 = faster). Null if no active buff or wrong type. */
            getGrowthMultiplier: function() {
                checkExpiry();
                if (!state.activeSmokeBuff || state.activeSmokeBuff.buffType !== 'growth') return 1;
                return growthMult;
            },
            /** Returns multiplier for yield (1 = normal, >1 = more). */
            getYieldMultiplier: function() {
                checkExpiry();
                if (!state.activeSmokeBuff || state.activeSmokeBuff.buffType !== 'yield') return 1;
                return yieldMult;
            },
            /** Returns multiplier for heat contribution (1 = normal, <1 = less heat). */
            getHeatMultiplier: function() {
                checkExpiry();
                if (!state.activeSmokeBuff || state.activeSmokeBuff.buffType !== 'heat') return 1;
                return heatMult;
            },
            /** Returns multiplier for sale price (1 = normal, >1 = higher). */
            getSaleMultiplier: function() {
                checkExpiry();
                if (!state.activeSmokeBuff || state.activeSmokeBuff.buffType !== 'sale') return 1;
                return saleMult;
            },
            /** Returns extra rep when selling (0 or bonus). */
            getRepBonus: function() {
                checkExpiry();
                if (!state.activeSmokeBuff || state.activeSmokeBuff.buffType !== 'rep') return 0;
                return repBonus;
            },
            /** Pick buff type from strain (first effect that maps, or 'sale' by default for quality). */
            getBuffTypeForStrain: function(seed) {
                if (!seed) return 'sale';
                var effects = HP.Data.StrainEffects && HP.Data.StrainEffects.getEffects ? HP.Data.StrainEffects.getEffects(seed) : [];
                for (var i = 0; i < effects.length; i++) {
                    var buffType = effectToBuffType[effects[i]];
                    if (buffType) return buffType;
                }
                var q = seed.quality;
                if (q === 'premium') return 'sale';
                if (q === 'good') return 'yield';
                if (q === 'medium') return 'growth';
                return 'heat';
            },
            getBuffTypeLabel: function(buffType) {
                var labels = { growth: 'Faster growth', yield: 'Higher yield', heat: 'Less heat', sale: 'Better prices', rep: 'Dealer friendly' };
                return labels[buffType] || buffType;
            }
        };
    }
};
