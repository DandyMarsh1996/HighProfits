/**
 * State domain: property-specific upgrades (security, ventilation, auto-water)
 */
var HP = HP || {};

HP.StatePropertyUpgrades = {
    create: function(state, notify, api) {
        return {
            getPropertyUpgrades: function(propertyId) {
                if (!state.propertyUpgrades) state.propertyUpgrades = {};
                if (!state.propertyUpgrades[propertyId]) {
                    state.propertyUpgrades[propertyId] = {
                        security: 0,      // Level 0-3 (reduces heat gain)
                        ventilation: 0,   // Level 0-3 (increases growth speed)
                        autoWater: false  // Boolean (auto-waters plants)
                    };
                }
                return state.propertyUpgrades[propertyId];
            },
            
            upgradePropertySecurity: function(propertyId) {
                var upgrades = this.getPropertyUpgrades(propertyId);
                if (upgrades.security >= 3) return { success: false, message: 'Security already at max level' };
                
                var cost = this.getSecurityUpgradeCost(propertyId);
                if (!api.spendBank(cost)) return { success: false, message: 'Not enough bank funds' };
                
                upgrades.security++;
                notify('propertyUpgrades', state.propertyUpgrades);
                return { success: true, message: 'Security upgraded to level ' + upgrades.security, level: upgrades.security };
            },
            
            upgradePropertyVentilation: function(propertyId) {
                var upgrades = this.getPropertyUpgrades(propertyId);
                if (upgrades.ventilation >= 3) return { success: false, message: 'Ventilation already at max level' };
                
                var cost = this.getVentilationUpgradeCost(propertyId);
                if (!api.spendBank(cost)) return { success: false, message: 'Not enough bank funds' };
                
                upgrades.ventilation++;
                notify('propertyUpgrades', state.propertyUpgrades);
                return { success: true, message: 'Ventilation upgraded to level ' + upgrades.ventilation, level: upgrades.ventilation };
            },
            
            installAutoWater: function(propertyId) {
                var upgrades = this.getPropertyUpgrades(propertyId);
                if (upgrades.autoWater) return { success: false, message: 'Auto-watering already installed' };
                
                var cost = this.getAutoWaterCost(propertyId);
                if (!api.spendBank(cost)) return { success: false, message: 'Not enough bank funds' };
                
                upgrades.autoWater = true;
                notify('propertyUpgrades', state.propertyUpgrades);
                return { success: true, message: 'Auto-watering system installed!' };
            },
            
            getSecurityUpgradeCost: function(propertyId) {
                var upgrades = this.getPropertyUpgrades(propertyId);
                var baseCost = 5000;
                return baseCost * Math.pow(2, upgrades.security); // 5k, 10k, 20k
            },
            
            getVentilationUpgradeCost: function(propertyId) {
                var upgrades = this.getPropertyUpgrades(propertyId);
                var baseCost = 3000;
                return baseCost * Math.pow(2, upgrades.ventilation); // 3k, 6k, 12k
            },
            
            getAutoWaterCost: function(propertyId) {
                return 15000; // Flat cost
            },
            
            getSecurityHeatReduction: function(propertyId) {
                var upgrades = this.getPropertyUpgrades(propertyId);
                // Each level: -10% heat gain for this property
                return upgrades.security * 0.10;
            },
            
            getVentilationGrowthBonus: function(propertyId) {
                var upgrades = this.getPropertyUpgrades(propertyId);
                // Each level: +8% growth speed for this property
                return upgrades.ventilation * 0.08;
            },
            
            hasAutoWater: function(propertyId) {
                var upgrades = this.getPropertyUpgrades(propertyId);
                return upgrades.autoWater === true;
            }
        };
    }
};
