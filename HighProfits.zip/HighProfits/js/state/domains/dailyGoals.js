/**
 * State domain: daily goals (sell Xg, harvest N, earn $Y) with rewards
 */
var HP = HP || {};

HP.StateDailyGoals = {
    create: function(state, notify) {
        var GOAL_TYPES = [
            { id: 'sell_100g', type: 'sell_grams', target: 100, rewardCash: 80 },
            { id: 'sell_50g', type: 'sell_grams', target: 50, rewardCash: 45 },
            { id: 'harvest_5', type: 'harvest_count', target: 5, rewardCash: 55 },
            { id: 'harvest_3', type: 'harvest_count', target: 3, rewardCash: 30 },
            { id: 'earn_500', type: 'earn_cash', target: 500, rewardCash: 30 },
            { id: 'earn_1000', type: 'earn_cash', target: 1000, rewardCash: 70 }
        ];

        function getTodayKey() {
            var d = new Date();
            return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
        }

        function ensureGoals() {
            if (!state.dailyGoals) state.dailyGoals = { date: '', goals: [], completed: [] };
            var today = getTodayKey();
            if (state.dailyGoals.date !== today) {
                state.dailyGoals.date = today;
                state.dailyGoals.completed = [];
                var pick = [];
                for (var i = 0; i < GOAL_TYPES.length; i++) pick.push(GOAL_TYPES[i]);
                for (var j = pick.length - 1; j > 0; j--) {
                    var k = Math.floor(Math.random() * (j + 1));
                    var t = pick[j]; pick[j] = pick[k]; pick[k] = t;
                }
                state.dailyGoals.goals = pick.slice(0, 3).map(function(g) {
                    return { id: g.id, type: g.type, target: g.target, rewardCash: g.rewardCash, current: 0 };
                });
                notify('dailyGoals', state.dailyGoals);
            }
        }

        return {
            getDailyGoals: function() {
                ensureGoals();
                return state.dailyGoals;
            },
            addProgress: function(type, amount) {
                ensureGoals();
                var goals = state.dailyGoals.goals || [];
                for (var i = 0; i < goals.length; i++) {
                    var g = goals[i];
                    if (g.type !== type || (state.dailyGoals.completed || []).indexOf(g.id) !== -1) continue;
                    g.current = (g.current || 0) + amount;
                    if (g.current >= g.target) {
                        state.dailyGoals.completed = state.dailyGoals.completed || [];
                        state.dailyGoals.completed.push(g.id);
                        state.cash = (state.cash || 0) + (g.rewardCash || 0);
                        state.money = (state.cash || 0) + (state.bank || 0);
                        notify('money', state.money);
                        notify('cash', state.cash);
                        notify('dailyGoals', state.dailyGoals);
                        return { completed: true, goal: g, reward: g.rewardCash };
                    }
                }
                notify('dailyGoals', state.dailyGoals);
                return { completed: false };
            }
        };
    }
};
