/**
 * HighProfits - State Core
 * Single state object, init, money, XP/level, listeners, save/load. See state.js facade.
 */
var HP = HP || {};

HP.StateCore = (function() {
    'use strict';

    function getInitialState() {
        var constants = HP.Data.Constants;
        var startCash = (constants.STARTING_CASH != null) ? constants.STARTING_CASH : 100;
        var startBank = (constants.STARTING_BANK != null) ? constants.STARTING_BANK : 100;
        return {
            money: startCash + startBank,
            moneyCap: constants.STARTING_MONEY_CAP,
            cash: startCash,
            bank: startBank,
            stats: {
                totalMoneyEarned: 0,
                totalHarvested: 0,
                totalSold: 0,
                totalSales: 0,
                plantsGrown: 0,
                plantsWatered: 0,
                plantsPlanted: 0,
                plantsDied: 0,
                playTime: 0,
                bestHarvest: 0,
                biggestSale: 0,
                raidsTotal: 0,
                heatPayOffsTotal: 0,
                laundersTotal: 0,
                harvestedByQuality: { low: 0, medium: 0, good: 0, premium: 0 }
            },
            inventory: {
                weed: { low: 0, medium: 0, good: 0, premium: 0 },
                seeds: {},
                equipment: {}
            },
            customStrains: {},
            strainLibrary: [],
            strainMastery: {}, // { seedId: { harvests: 0, level: 0 } }
            propertyUpgrades: {}, // { propertyId: { security: 0, ventilation: 0, autoWater: false } }
            tutorialCompleted: false,
            tutorialStep: 0,
            tourCompleted: false,
            waterReservoir: {
                current: (constants && constants.WATER_RESERVOIR_BASE_CAPACITY != null) ? constants.WATER_RESERVOIR_BASE_CAPACITY : 50,
                refillAccumulator: 0
            },
            waterUpgradesOwned: [],
            heatReductionOwned: [],
            businessesOwned: [],
            properties: { owned: ['closet'], plots: {}, upgrades: {} },
            xp: 0,
            level: 1,
            rank: 'Street Hustler',
            heat: { level: constants.STARTING_HEAT, maxLevel: constants.MAX_HEAT },
            heatPayOffCount: 0,
            reputation: constants.STARTING_REPUTATION,
            customerReputation: {},
            achievements: { unlocked: [], notifications: [] },
            challenges: { active: [], completed: [] },
            growerWorkers: { instances: [] },
            lastSave: null,
            lastTick: null,
            characterId: null,
            characterName: '',
            unlockedTitles: [],
            selectedTitleId: 'street_hustler',
            journalCompleted: {}
        };
    }

    var state = null;
    var listeners = [];

    function initializeState() {
        state = getInitialState();
        var closet = HP.Data.Properties.get('closet');
        if (closet) {
            state.properties.plots['closet'] = [];
            state.properties.upgrades['closet'] = [];
            for (var i = 0; i < closet.plotCapacity; i++) {
                state.properties.plots['closet'].push(HP.Growing.createEmptyPlot());
            }
        }
    }

    function notifyListeners(key, value) {
        for (var i = 0; i < listeners.length; i++) {
            listeners[i](key, value, state);
        }
    }

    function deepClone(obj) {
        return JSON.parse(JSON.stringify(obj));
    }

    function migrateMoneyToCashBank() {
        if (state.hasOwnProperty('cash') && state.hasOwnProperty('bank')) return;
        var m = state.money || 0;
        state.cash = state.cash != null ? state.cash : 0;
        state.bank = state.bank != null ? state.bank : m;
        state.money = state.cash + state.bank;
    }

    function getEffectiveCashCap() {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        var base = (c.CASH_CAP_BASE != null) ? c.CASH_CAP_BASE : 5000;
        var owned = (state.properties && state.properties.owned) || [];
        var props = HP.Data && HP.Data.Properties ? HP.Data.Properties : null;
        var total = base;
        for (var i = 0; i < owned.length; i++) {
            var p = props && props.get ? props.get(owned[i]) : null;
            total += (p && p.cashCapBonus != null) ? p.cashCapBonus : 5000;
        }
        return total;
    }

    function getEffectiveBankCap() {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        var base = (c.BANK_CAP_BASE != null) ? c.BANK_CAP_BASE : 10000;
        var owned = (state.properties && state.properties.owned) || [];
        var props = HP.Data && HP.Data.Properties ? HP.Data.Properties : null;
        var total = base;
        for (var i = 0; i < owned.length; i++) {
            var p = props && props.get ? props.get(owned[i]) : null;
            total += (p && p.bankCapBonus != null) ? p.bankCapBonus : 10000;
        }
        return total;
    }

    return {
        init: function() {
            if (!state) initializeState();
        },
        getState: function() { return deepClone(state); },
        get: function(key) {
            if (state.hasOwnProperty(key)) {
                var value = state[key];
                return (typeof value === 'object') ? deepClone(value) : value;
            }
            return undefined;
        },
        set: function(key, value) {
            if (state.hasOwnProperty(key)) {
                state[key] = value;
                notifyListeners(key, value);
            }
        },
        getMoney: function() { return (state.cash || 0) + (state.bank || 0); },
        getCash: function() { return state.cash != null ? state.cash : state.money || 0; },
        getBank: function() { return state.bank != null ? state.bank : 0; },
        setMoney: function(amount) {
            state.cash = state.cash != null ? state.cash : 0;
            state.bank = state.bank != null ? state.bank : 0;
            state.bank = Math.min(Math.floor(amount / 2), getEffectiveBankCap());
            state.cash = Math.min(amount - state.bank, getEffectiveCashCap());
            state.money = state.cash + state.bank;
            notifyListeners('money', state.money);
        },
        addMoney: function(amount) { return addCash(amount); },
        addCash: function(amount) {
            if (!state.hasOwnProperty('cash')) migrateMoneyToCashBank();
            var cap = getEffectiveCashCap();
            var newAmount = Math.min((state.cash || 0) + amount, cap);
            var actualAdded = newAmount - (state.cash || 0);
            state.cash = newAmount;
            state.money = (state.cash || 0) + (state.bank || 0);
            if (actualAdded > 0 && state.stats) state.stats.totalMoneyEarned = (state.stats.totalMoneyEarned || 0) + actualAdded;
            notifyListeners('money', state.money);
            notifyListeners('cash', state.cash);
            return actualAdded;
        },
        addBank: function(amount) {
            if (!state.hasOwnProperty('bank')) migrateMoneyToCashBank();
            var cap = getEffectiveBankCap();
            var newAmount = Math.min((state.bank || 0) + amount, cap);
            var actualAdded = newAmount - (state.bank || 0);
            state.bank = newAmount;
            state.money = (state.cash || 0) + (state.bank || 0);
            if (actualAdded > 0 && state.stats) state.stats.totalMoneyEarned = (state.stats.totalMoneyEarned || 0) + actualAdded;
            notifyListeners('money', state.money);
            notifyListeners('bank', state.bank);
            return actualAdded;
        },
        spendMoney: function(amount) {
            if (!state.hasOwnProperty('cash')) migrateMoneyToCashBank();
            var total = (state.cash || 0) + (state.bank || 0);
            if (total < amount) return false;
            var c = state.cash || 0;
            if (c >= amount) {
                state.cash = c - amount;
            } else {
                state.cash = 0;
                state.bank = (state.bank || 0) - (amount - c);
            }
            state.money = state.cash + state.bank;
            notifyListeners('money', state.money);
            notifyListeners('cash', state.cash);
            notifyListeners('bank', state.bank);
            return true;
        },
        spendCash: function(amount) {
            if (!state.hasOwnProperty('cash')) migrateMoneyToCashBank();
            var c = state.cash || 0;
            if (c >= amount) {
                state.cash = c - amount;
                state.money = state.cash + (state.bank || 0);
                notifyListeners('money', state.money);
                notifyListeners('cash', state.cash);
                return true;
            }
            return false;
        },
        spendBank: function(amount) {
            if (!state.hasOwnProperty('bank')) migrateMoneyToCashBank();
            var b = state.bank || 0;
            if (b >= amount) {
                state.bank = b - amount;
                state.money = (state.cash || 0) + state.bank;
                notifyListeners('money', state.money);
                notifyListeners('bank', state.bank);
                return true;
            }
            return false;
        },
        canAfford: function(amount) { return (state.cash || 0) + (state.bank || 0) >= amount; },
        canAffordCash: function(amount) {
            if (!state.hasOwnProperty('cash')) migrateMoneyToCashBank();
            return (state.cash || 0) >= amount;
        },
        canAffordBank: function(amount) {
            if (!state.hasOwnProperty('bank')) migrateMoneyToCashBank();
            return (state.bank || 0) >= amount;
        },
        getMoneyCap: function() { return state.moneyCap; },
        getCashCap: function() { return getEffectiveCashCap(); },
        getBankCap: function() { return getEffectiveBankCap(); },
        setMoneyCap: function(cap) {
            state.moneyCap = cap;
            notifyListeners('moneyCap', state.moneyCap);
        },
        getXP: function() { return state.xp; },
        addXP: function(amount) {
            state.xp += amount;
            var newRank = HP.Data.Ranks.getForXP(state.xp);
            if (newRank.level > state.level) {
                state.level = newRank.level;
                state.rank = newRank.name;
                notifyListeners('levelUp', { level: state.level, rank: state.rank });
            }
            notifyListeners('xp', state.xp);
        },
        getLevel: function() { return state.level; },
        getRank: function() { return state.rank; },
        setLastTick: function(timestamp) { state.lastTick = timestamp; },
        getLastTick: function() { return state.lastTick; },
        addListener: function(callback) { listeners.push(callback); },
        removeListener: function(callback) {
            var index = listeners.indexOf(callback);
            if (index > -1) listeners.splice(index, 1);
        },
        exportState: function() {
            state.lastSave = Date.now();
            return deepClone(state);
        },
        importState: function(newState) {
            var keys = Object.keys(state);
            for (var i = 0; i < keys.length; i++) {
                var key = keys[i];
                if (newState.hasOwnProperty(key)) state[key] = newState[key];
            }
            if (!newState.hasOwnProperty('cash') || !newState.hasOwnProperty('bank')) {
                var m = state.money || 0;
                state.cash = state.cash != null ? state.cash : 0;
                state.bank = state.bank != null ? state.bank : m;
                state.money = state.cash + state.bank;
            }
            if (!newState.hasOwnProperty('businessesOwned')) {
                state.businessesOwned = state.businessesOwned || [];
            }
            // Ensure tutorial fields are properly migrated for old saves
            if (!newState.hasOwnProperty('tutorialStep')) {
                state.tutorialStep = state.tutorialStep || 0;
            }
            if (!newState.hasOwnProperty('tutorialCompleted')) {
                state.tutorialCompleted = state.tutorialCompleted || false;
            }
            if (!newState.hasOwnProperty('tourCompleted')) {
                state.tourCompleted = state.tourCompleted || false;
            }
            // Ensure characterName is preserved
            if (!state.characterName && newState.characterName) {
                state.characterName = newState.characterName;
            }
            notifyListeners('stateLoaded', state);
        },
        reset: function() {
            initializeState();
            notifyListeners('reset', state);
        },
        _stateRef: function() { return state; },
        _notifyListeners: function() { return notifyListeners; }
    };
})();
