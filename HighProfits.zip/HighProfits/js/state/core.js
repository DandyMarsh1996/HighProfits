/**
 * HighProfits - State Core
 * Single state object, init, money, XP/level, listeners, save/load. See state.js facade.
 */
var HP = HP || {};

HP.StateCore = (function() {
    'use strict';

    function getInitialState() {
        var constants = HP.Data.Constants;
        var startCash = (constants.STARTING_CASH != null) ? constants.STARTING_CASH : 100;
        var startBank = (constants.STARTING_BANK != null) ? constants.STARTING_BANK : 100;
        return {
            money: startCash + startBank,
            moneyCap: constants.STARTING_MONEY_CAP,
            cash: startCash,
            bank: startBank,
            stats: {
                totalMoneyEarned: 0,
                totalHarvested: 0,
                totalSold: 0,
                totalSales: 0,
                plantsGrown: 0,
                plantsWatered: 0,
                plantsPlanted: 0,
                plantsDied: 0,
                playTime: 0,
                bestHarvest: 0,
                biggestSale: 0,
                raidsTotal: 0,
                heatPayOffsTotal: 0,
                laundersTotal: 0,
                contractsCompleted: 0,
                harvestAllCount: 0,
                workerUpgradesCount: 0,
                premiumMixCount: 0,
                harvestedByQuality: { low: 0, medium: 0, good: 0, premium: 0 }
            },
            inventory: {
                weed: {},   // strain-based: { [seedId]: amount }
                seeds: {},
                equipment: {},
                mixed: {}   // blends: { [blendKey]: { seedId1, seedId2, amount, quality } }
            },
            customStrains: {},
            strainLibrary: [],
            strainMastery: {}, // { seedId: { harvests: 0, level: 0 } }
            propertyUpgrades: {}, // { propertyId: { security: 0, ventilation: 0, autoWater: false } }
            tutorialCompleted: false,
            tutorialStep: 0,
            tourCompleted: false,
            progressTriggers: {}, // One-off flags so tutorials/triggers don't repeat (e.g. firstSaleSeen, welcomeTourSeen)
            waterReservoir: {
                current: (constants && constants.WATER_RESERVOIR_BASE_CAPACITY != null) ? constants.WATER_RESERVOIR_BASE_CAPACITY : 50,
                refillAccumulator: 0
            },
            waterUpgradesOwned: [],
            heatReductionOwned: [],
            businessesOwned: [],
            properties: { owned: ['closet'], plots: {}, upgrades: {} },
            xp: 0,
            level: 1,
            rank: 'Street Hustler',
            heat: { level: constants.STARTING_HEAT, maxLevel: constants.MAX_HEAT },
            heatPayOffCount: 0,
            propertyLockedUntil: {},
            reputation: constants.STARTING_REPUTATION,
            customerReputation: {},
            achievements: { unlocked: [], notifications: [] },
            challenges: { active: [], completed: [] },
            growerWorkers: { instances: [] },
            workerWageFund: 0,           // Money deposited to pay workers (deducted each day)
            workerDayAccumulator: 0,     // Seconds elapsed in current game day (0..WORKER_DAY_SECONDS)
            lastSave: null,
            lastTick: null,
            lastFallbackHustleAt: 0,  // Timestamp of last "quick hustle" (emergency cash when broke)
            characterId: null,
            characterName: '',
            unlockedTitles: [],
            selectedTitleId: 'street_hustler',
            journalCompleted: {},
            dailyGoals: { date: '', goals: [], completed: [] },
            contracts: [],
            specialRequests: {},
            activeSmokeBuff: null,   // { seedId, strainName, expiresAt, buffType } or null
            launderDaily: { date: '', byBusiness: {} },  // Resets each calendar day; byBusiness[bizId] = $ used today
            stockPortfolio: {},   // { stockId: number of shares }
            stockPrices: {},      // { stockId: current price } (persisted; seeded from basePrice if missing)
            stockDeltas: {},     // { stockId: velocity } for Cookie Clicker-style drift (optional)
            lastSeenChangelogVersion: null  // One-time "What's new" modal: show when saved version < current
        };
    }

    var state = null;
    var listeners = [];

    function initializeState() {
        state = getInitialState();
        var closet = HP.Data.Properties.get('closet');
        if (closet) {
            state.properties.plots['closet'] = [];
            state.properties.upgrades['closet'] = [];
            for (var i = 0; i < closet.plotCapacity; i++) {
                state.properties.plots['closet'].push(HP.Growing.createEmptyPlot());
            }
        }
    }

    function notifyListeners(key, value) {
        for (var i = 0; i < listeners.length; i++) {
            listeners[i](key, value, state);
        }
    }

    function deepClone(obj) {
        return JSON.parse(JSON.stringify(obj));
    }

    function migrateMoneyToCashBank() {
        if (state.hasOwnProperty('cash') && state.hasOwnProperty('bank')) return;
        var m = state.money || 0;
        state.cash = state.cash != null ? state.cash : 0;
        state.bank = state.bank != null ? state.bank : m;
        state.money = state.cash + state.bank;
    }

    function getEffectiveCashCap() {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        var base = (c.CASH_CAP_BASE != null) ? c.CASH_CAP_BASE : 5000;
        var owned = (state.properties && state.properties.owned) || [];
        var props = HP.Data && HP.Data.Properties ? HP.Data.Properties : null;
        var total = base;
        for (var i = 0; i < owned.length; i++) {
            var p = props && props.get ? props.get(owned[i]) : null;
            total += (p && p.cashCapBonus != null) ? p.cashCapBonus : 5000;
        }
        return total;
    }

    function getEffectiveBankCap() {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        var base = (c.BANK_CAP_BASE != null) ? c.BANK_CAP_BASE : 10000;
        var owned = (state.properties && state.properties.owned) || [];
        var props = HP.Data && HP.Data.Properties ? HP.Data.Properties : null;
        var total = base;
        for (var i = 0; i < owned.length; i++) {
            var p = props && props.get ? props.get(owned[i]) : null;
            total += (p && p.bankCapBonus != null) ? p.bankCapBonus : 10000;
        }
        return total;
    }

    return {
        init: function() {
            if (!state) initializeState();
        },
        getState: function() { return deepClone(state); },
        get: function(key) {
            if (state.hasOwnProperty(key)) {
                var value = state[key];
                return (typeof value === 'object') ? deepClone(value) : value;
            }
            return undefined;
        },
        set: function(key, value) {
            if (state.hasOwnProperty(key)) {
                state[key] = value;
                notifyListeners(key, value);
            }
        },
        getMoney: function() { return (state.cash || 0) + (state.bank || 0); },
        getCash: function() { return state.cash != null ? state.cash : state.money || 0; },
        getBank: function() { return state.bank != null ? state.bank : 0; },
        setMoney: function(amount) {
            state.cash = state.cash != null ? state.cash : 0;
            state.bank = state.bank != null ? state.bank : 0;
            state.bank = Math.min(Math.floor(amount / 2), getEffectiveBankCap());
            state.cash = Math.min(amount - state.bank, getEffectiveCashCap());
            state.money = state.cash + state.bank;
            notifyListeners('money', state.money);
        },
        addMoney: function(amount) { return addCash(amount); },
        addCash: function(amount) {
            if (!state.hasOwnProperty('cash')) migrateMoneyToCashBank();
            var cap = getEffectiveCashCap();
            var newAmount = Math.min((state.cash || 0) + amount, cap);
            var actualAdded = newAmount - (state.cash || 0);
            state.cash = newAmount;
            state.money = (state.cash || 0) + (state.bank || 0);
            if (actualAdded > 0 && state.stats) state.stats.totalMoneyEarned = (state.stats.totalMoneyEarned || 0) + actualAdded;
            notifyListeners('money', state.money);
            notifyListeners('cash', state.cash);
            return actualAdded;
        },
        addBank: function(amount) {
            if (!state.hasOwnProperty('bank')) migrateMoneyToCashBank();
            var cap = getEffectiveBankCap();
            var newAmount = Math.min((state.bank || 0) + amount, cap);
            var actualAdded = newAmount - (state.bank || 0);
            state.bank = newAmount;
            state.money = (state.cash || 0) + (state.bank || 0);
            if (actualAdded > 0 && state.stats) state.stats.totalMoneyEarned = (state.stats.totalMoneyEarned || 0) + actualAdded;
            notifyListeners('money', state.money);
            notifyListeners('bank', state.bank);
            return actualAdded;
        },
        spendMoney: function(amount) {
            if (!state.hasOwnProperty('cash')) migrateMoneyToCashBank();
            var total = (state.cash || 0) + (state.bank || 0);
            if (total < amount) return false;
            var c = state.cash || 0;
            if (c >= amount) {
                state.cash = c - amount;
            } else {
                state.cash = 0;
                state.bank = (state.bank || 0) - (amount - c);
            }
            state.money = state.cash + state.bank;
            notifyListeners('money', state.money);
            notifyListeners('cash', state.cash);
            notifyListeners('bank', state.bank);
            return true;
        },
        spendCash: function(amount) {
            if (!state.hasOwnProperty('cash')) migrateMoneyToCashBank();
            var c = state.cash || 0;
            if (c >= amount) {
                state.cash = c - amount;
                state.money = state.cash + (state.bank || 0);
                notifyListeners('money', state.money);
                notifyListeners('cash', state.cash);
                return true;
            }
            return false;
        },
        spendBank: function(amount) {
            if (!state.hasOwnProperty('bank')) migrateMoneyToCashBank();
            var b = state.bank || 0;
            if (b >= amount) {
                state.bank = b - amount;
                state.money = (state.cash || 0) + state.bank;
                notifyListeners('money', state.money);
                notifyListeners('bank', state.bank);
                return true;
            }
            return false;
        },
        canAfford: function(amount) { return (state.cash || 0) + (state.bank || 0) >= amount; },
        canAffordCash: function(amount) {
            if (!state.hasOwnProperty('cash')) migrateMoneyToCashBank();
            return (state.cash || 0) >= amount;
        },
        canAffordBank: function(amount) {
            if (!state.hasOwnProperty('bank')) migrateMoneyToCashBank();
            return (state.bank || 0) >= amount;
        },
        getMoneyCap: function() { return state.moneyCap; },
        getCashCap: function() { return getEffectiveCashCap(); },
        getBankCap: function() { return getEffectiveBankCap(); },
        setMoneyCap: function(cap) {
            state.moneyCap = cap;
            notifyListeners('moneyCap', state.moneyCap);
        },
        getXP: function() { return state.xp; },
        addXP: function(amount) {
            state.xp += amount;
            var newRank = HP.Data.Ranks.getForXP(state.xp);
            if (newRank.level > state.level) {
                state.level = newRank.level;
                state.rank = newRank.name;
                notifyListeners('levelUp', { level: state.level, rank: state.rank });
            }
            notifyListeners('xp', state.xp);
        },
        getLevel: function() { return state.level; },
        getRank: function() { return state.rank; },
        setLastTick: function(timestamp) { state.lastTick = timestamp; },
        getLastTick: function() { return state.lastTick; },
        getLastFallbackHustleAt: function() { return state.lastFallbackHustleAt || 0; },
        setLastFallbackHustleAt: function(ts) { state.lastFallbackHustleAt = ts; },
        addListener: function(callback) { listeners.push(callback); },
        removeListener: function(callback) {
            var index = listeners.indexOf(callback);
            if (index > -1) listeners.splice(index, 1);
        },
        exportState: function() {
            state.lastSave = Date.now();
            return deepClone(state);
        },
        importState: function(newState) {
            if (!newState || typeof newState !== 'object') return;
            // Copy every key from saved state so tutorial, character, and all persisted data are restored
            for (var key in newState) {
                if (newState.hasOwnProperty(key)) {
                    state[key] = newState[key];
                }
            }
            if (!newState.hasOwnProperty('cash') || !newState.hasOwnProperty('bank')) {
                var m = state.money || 0;
                state.cash = state.cash != null ? state.cash : 0;
                state.bank = state.bank != null ? state.bank : m;
                state.money = state.cash + state.bank;
            }
            if (!newState.hasOwnProperty('businessesOwned')) {
                state.businessesOwned = state.businessesOwned || [];
            }
            // Ensure tutorial and progress fields are restored (fallbacks for very old saves)
            if (state.tutorialStep == null) state.tutorialStep = 0;
            if (state.tutorialCompleted == null) state.tutorialCompleted = false;
            if (state.tourCompleted == null) state.tourCompleted = false;
            if (!state.progressTriggers || typeof state.progressTriggers !== 'object') state.progressTriggers = newState.progressTriggers && typeof newState.progressTriggers === 'object' ? newState.progressTriggers : {};
            // Ensure character data is restored
            if (state.characterName == null || state.characterName === '') {
                state.characterName = (newState.characterName && String(newState.characterName).trim()) ? String(newState.characterName).trim() : 'Player';
            }
            if (state.characterId == null && newState.characterId) state.characterId = newState.characterId;
            if (!state.unlockedTitles || !Array.isArray(state.unlockedTitles)) state.unlockedTitles = newState.unlockedTitles || ['street_hustler'];
            if (state.workerWageFund == null) state.workerWageFund = 0;
            if (state.workerDayAccumulator == null) state.workerDayAccumulator = 0;
            if (state.selectedTitleId == null || state.selectedTitleId === '') state.selectedTitleId = newState.selectedTitleId || 'street_hustler';
            if (!state.journalCompleted || typeof state.journalCompleted !== 'object') state.journalCompleted = newState.journalCompleted || {};
            if (state.lastFallbackHustleAt == null) state.lastFallbackHustleAt = newState.lastFallbackHustleAt != null ? newState.lastFallbackHustleAt : 0;
            if (state.activeSmokeBuff == null) state.activeSmokeBuff = newState.activeSmokeBuff != null ? newState.activeSmokeBuff : null;
            if (!state.launderDaily || typeof state.launderDaily !== 'object') state.launderDaily = { date: '', byBusiness: {} };
            if (state.lastSeenChangelogVersion === undefined) state.lastSeenChangelogVersion = newState.lastSeenChangelogVersion != null ? newState.lastSeenChangelogVersion : null;
            if (!state.stockPortfolio || typeof state.stockPortfolio !== 'object') state.stockPortfolio = {};
            if (!state.stockPrices || typeof state.stockPrices !== 'object') state.stockPrices = {};
            if (!state.stockDeltas || typeof state.stockDeltas !== 'object') state.stockDeltas = {};
            if (state.growerWorkers && state.growerWorkers.instances && Array.isArray(state.growerWorkers.instances)) {
                for (var wi = 0; wi < state.growerWorkers.instances.length; wi++) {
                    var w = state.growerWorkers.instances[wi];
                    if (w.xp == null) w.xp = 0;
                    if (w.level == null) w.level = 1;
                }
            }
            if (state.inventory && typeof state.inventory === 'object' && !state.inventory.hasOwnProperty('mixed')) state.inventory.mixed = {};
            notifyListeners('stateLoaded', state);
        },
        reset: function() {
            initializeState();
            notifyListeners('reset', state);
        },
        _stateRef: function() { return state; },
        _notifyListeners: function() { return notifyListeners; }
    };
})();
