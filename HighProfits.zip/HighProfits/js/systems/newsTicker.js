/**
 * HighProfits - News Ticker System
 * Scrolls random headlines in the top bar (Cookie-clicker style flavor).
 */
var HP = HP || {};

HP.NewsTicker = (function() {
    'use strict';

    var elContainer = null;
    var elViewport = null;
    var elTrack = null;
    var elText = null;

    var currentAnimation = null;
    var lastHeadlineId = null;
    var currentRenderedText = '';

    // Tuning
    var PX_PER_SECOND = 95;     // scroll speed
    var MIN_DURATION_MS = 9000; // minimum time on screen
    var GAP_MS = 300;           // pause between headlines

    function getContext() {
        // Keep this lightweight: only what we can safely read from the public State API.
        var level = 1;
        var rank = '';
        var money = 0;

        try { level = HP.State.getLevel(); } catch (e) {}
        try { rank = HP.State.getRank(); } catch (e) {}
        try { money = Math.floor(HP.State.getMoney()); } catch (e) {}

        return { level: level, rank: rank, money: money };
    }

    function renderText(raw, ctx) {
        // Simple templating support for future use.
        // Example tokens: {level}, {rank}, {money}
        if (!raw) return '';
        var out = String(raw);
        out = out.replace(/\{level\}/g, String(ctx.level || 1));
        out = out.replace(/\{rank\}/g, String(ctx.rank || ''));
        out = out.replace(/\{money\}/g, HP.Helpers && HP.Helpers.formatNumber ? HP.Helpers.formatNumber(ctx.money || 0) : String(ctx.money || 0));
        return out;
    }

    function stopAnimation() {
        if (currentAnimation) {
            try { currentAnimation.cancel(); } catch (e) {}
            currentAnimation = null;
        }
    }

    function measureWidths() {
        if (!elViewport || !elTrack || !elText) return { viewportW: 0, textW: 0 };
        var viewportW = elViewport.getBoundingClientRect().width;
        // Ensure the text is measured at its natural width.
        var textW = elText.getBoundingClientRect().width;
        return { viewportW: viewportW, textW: textW };
    }

    function startScroll() {
        if (!elViewport || !elTrack || !elText) return;

        stopAnimation();

        var dims = measureWidths();
        var viewportW = dims.viewportW;
        var textW = dims.textW;

        if (!viewportW || !textW) return;

        // Start just outside the right edge, end just outside the left edge.
        var startX = viewportW;
        var endX = -textW;
        var distance = startX - endX;

        var durationMs = Math.max(MIN_DURATION_MS, Math.floor((distance / PX_PER_SECOND) * 1000));

        // Reset position immediately so the animation starts cleanly.
        elTrack.style.transform = 'translateX(' + startX + 'px)';

        currentAnimation = elTrack.animate(
            [
                { transform: 'translateX(' + startX + 'px)' },
                { transform: 'translateX(' + endX + 'px)' }
            ],
            {
                duration: durationMs,
                iterations: 1,
                easing: 'linear',
                fill: 'forwards'
            }
        );

        currentAnimation.onfinish = function() {
            setTimeout(function() {
                showNextHeadline();
            }, GAP_MS);
        };
    }

    function showNextHeadline() {
        if (!elText || !HP.Data || !HP.Data.News || !HP.Data.News.getRandom) return;

        var ctx = getContext();
        var entry = HP.Data.News.getRandom(ctx, lastHeadlineId);
        if (!entry) return;

        lastHeadlineId = entry.id || null;
        currentRenderedText = renderText(entry.text, ctx);

        elText.textContent = currentRenderedText;

        // Trigger event if headline has triggersEvent flag (small chance)
        if (entry.triggersEvent && entry.eventId && HP.Events && HP.Events.Manager) {
            var chance = 0.08; // 8% chance to trigger event when event headline appears
            if (Math.random() < chance) {
                HP.Events.Manager.startEvent(entry.eventId);
            }
        }

        // Wait a frame so layout updates before measuring/animating.
        requestAnimationFrame(function() {
            startScroll();
        });
    }

    function init() {
        elContainer = document.getElementById('news-ticker');
        elViewport = document.querySelector('#news-ticker .news-ticker-viewport');
        elTrack = document.getElementById('news-ticker-track');
        elText = document.getElementById('news-ticker-text');

        if (!elContainer || !elViewport || !elTrack || !elText) {
            console.warn('[NewsTicker] Missing DOM elements; ticker disabled.');
            return;
        }

        // Click to skip
        elContainer.addEventListener('click', function() {
            showNextHeadline();
        });

        // Restart scrolling when resizing (keeps movement smooth on window size changes).
        window.addEventListener('resize', function() {
            if (!elText) return;
            // Keep current text; just restart animation.
            requestAnimationFrame(function() {
                startScroll();
            });
        });

        showNextHeadline();
        console.log('[NewsTicker] Initialized');
    }

    return {
        init: init
    };
})();

