/**
 * HighProfits - Heat System
 * Manages police heat/wanted level mechanics
 */
var HP = HP || {};

HP.Heat = (function() {
    'use strict';

    /**
     * Get heat level category
     * @param {number} heat - Heat value 0-100
     * @returns {Object} Heat category info
     */
    function getHeatCategory(heat) {
        if (heat < 20) {
            return {
                level: 'low',
                label: 'Low',
                color: '#00ff88',
                description: 'Your operations are currently under the radar.',
                riskMultiplier: 1.0
            };
        }
        if (heat < 40) {
            return {
                level: 'moderate',
                label: 'Moderate',
                color: '#88ff00',
                description: 'Police are starting to take notice of unusual activity.',
                riskMultiplier: 1.2
            };
        }
        if (heat < 60) {
            return {
                level: 'high',
                label: 'High',
                color: '#ffaa00',
                description: 'Investigations are underway. Be careful.',
                riskMultiplier: 1.5
            };
        }
        if (heat < 80) {
            return {
                level: 'veryhigh',
                label: 'Very High',
                color: '#ff6600',
                description: 'You\'re being watched closely. Consider laying low.',
                riskMultiplier: 2.0
            };
        }
        return {
            level: 'critical',
            label: 'Critical',
            color: '#ff0000',
            description: 'DANGER! Authorities are closing in. Take immediate action!',
            riskMultiplier: 3.0
        };
    }

    /**
     * Calculate heat decay for a time period
     * @param {number} currentHeat - Current heat level
     * @param {number} deltaTime - Time in seconds
     * @returns {number} New heat level after decay
     */
    function calculateDecay(currentHeat, deltaTime) {
        if (currentHeat <= 0) return 0;
        
        var decayRate = HP.Data.Constants.HEAT_DECAY_RATE;
        var decay = currentHeat * decayRate * deltaTime;
        return Math.max(0, currentHeat - decay);
    }

    /**
     * Calculate heat gain from an action
     * @param {string} action - Action type ('sale', 'manual_sale', etc.)
     * @param {number} quantity - Quantity involved
     * @returns {number} Heat to add
     */
    function calculateHeatGain(action, quantity) {
        var constants = HP.Data.Constants;
        quantity = quantity || 1;
        
        switch (action) {
            case 'sale':
                return constants.HEAT_PER_SALE * quantity;
            case 'manual_sale':
                return constants.HEAT_PER_MANUAL_SALE * quantity;
            default:
                return 0;
        }
    }

    /**
     * Get cost for a pay-off action (exponential: each use since last raid costs more)
     * @param {number} baseCost - Base cost from constants
     * @param {number} payOffCount - Number of times player has paid off since last raid
     * @returns {number} Scaled cost
     */
    function getScaledPayOffCost(baseCost, payOffCount) {
        var mult = (HP.Data.Constants && HP.Data.Constants.HEAT_PAYOFF_COST_MULTIPLIER != null)
            ? HP.Data.Constants.HEAT_PAYOFF_COST_MULTIPLIER : 1.5;
        payOffCount = payOffCount || 0;
        return Math.floor(baseCost * Math.pow(mult, payOffCount));
    }

    /**
     * Get available heat reduction options (costs scale exponentially with pay-off count)
     * @param {number} currentMoney - Player's current money
     * @param {number} payOffCount - Number of pay-offs since last raid
     * @returns {Array} Available options with affordability and scaled cost
     */
    function getReductionOptions(currentMoney, payOffCount) {
        var constants = HP.Data.Constants;
        payOffCount = payOffCount || 0;

        var bribeCost = getScaledPayOffCost(constants.HEAT_BRIBE_COST, payOffCount);
        var hideCost = getScaledPayOffCost(constants.HEAT_HIDE_COST, payOffCount);
        var cleanersCost = getScaledPayOffCost(constants.HEAT_CLEANERS_COST, payOffCount);

        return [
            {
                id: 'bribe',
                name: 'Bribe Authorities',
                description: 'Pay off local police to look the other way (cost increases each time until raid)',
                cost: bribeCost,
                reduction: constants.HEAT_BRIBE_REDUCTION,
                canAfford: currentMoney >= bribeCost
            },
            {
                id: 'hide',
                name: 'Lay Low',
                description: 'Temporarily cease operations to reduce attention',
                cost: hideCost,
                reduction: constants.HEAT_HIDE_REDUCTION,
                canAfford: currentMoney >= hideCost
            },
            {
                id: 'cleaners',
                name: 'Use Cleaners',
                description: 'Hire professionals to erase evidence',
                cost: cleanersCost,
                reduction: constants.HEAT_CLEANERS_REDUCTION,
                canAfford: currentMoney >= cleanersCost
            }
        ];
    }

    /**
     * Get cost and reduction for a pay-off action (exponential cost)
     * @param {string} actionId - Reduction action ID
     * @param {number} payOffCount - Number of pay-offs since last raid
     * @returns {Object} { cost, reduction }
     */
    function getReductionCost(actionId, payOffCount) {
        var constants = HP.Data.Constants;
        payOffCount = payOffCount || 0;

        switch (actionId) {
            case 'bribe':
                return { cost: getScaledPayOffCost(constants.HEAT_BRIBE_COST, payOffCount), reduction: constants.HEAT_BRIBE_REDUCTION };
            case 'hide':
                return { cost: getScaledPayOffCost(constants.HEAT_HIDE_COST, payOffCount), reduction: constants.HEAT_HIDE_REDUCTION };
            case 'cleaners':
                return { cost: getScaledPayOffCost(constants.HEAT_CLEANERS_COST, payOffCount), reduction: constants.HEAT_CLEANERS_REDUCTION };
            default:
                return { cost: 0, reduction: 0 };
        }
    }

    /**
     * Get heat gain multiplier from security room upgrades and hardware heat-reduction items
     * @returns {number} Multiplier (1 = normal, 0.5 = min, e.g. 0.8 = 20% less heat)
     */
    function getHeatGainMultiplier() {
        if (!HP.State) return 1;
        var constants = HP.Data.Constants;
        var reductionPerUpgrade = (constants && constants.HEAT_SECURITY_REDUCTION_PER_UPGRADE != null)
            ? constants.HEAT_SECURITY_REDUCTION_PER_UPGRADE : 0.04;
        var minMult = 0.5;
        var totalReduction = 0;

        // Security room upgrades (per property)
        if (HP.State.getProperties) {
            var owned = HP.State.getProperties().owned || [];
            var securityCount = 0;
            for (var i = 0; i < owned.length; i++) {
                var upgrades = HP.State.getRoomUpgrades(owned[i]) || [];
                for (var u = 0; u < upgrades.length; u++) {
                    var up = HP.Data.RoomUpgrades && HP.Data.RoomUpgrades.get(upgrades[u]);
                    if (up && up.category === 'security') securityCount++;
                }
            }
            totalReduction += securityCount * reductionPerUpgrade;
        }

        // Hardware store heat-reduction items (one-time purchases)
        if (HP.State.getHeatReductionOwned && HP.Data.HeatReduction) {
            var heatOwned = HP.State.getHeatReductionOwned();
            for (var h = 0; h < heatOwned.length; h++) {
                var item = HP.Data.HeatReduction.get(heatOwned[h]);
                if (item && item.heatReduction) totalReduction += item.heatReduction;
            }
        }

        var mult = 1 - totalReduction;
        return Math.max(minMult, Math.min(1, mult));
    }

    // Public API
    return {
        getHeatCategory: getHeatCategory,
        calculateDecay: calculateDecay,
        calculateHeatGain: calculateHeatGain,
        getReductionOptions: getReductionOptions,
        getReductionCost: getReductionCost,
        getHeatGainMultiplier: getHeatGainMultiplier
    };
})();
