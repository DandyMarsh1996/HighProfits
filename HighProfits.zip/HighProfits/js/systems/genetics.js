/**
 * HighProfits - Genetics & Breeding System
 * Cross-breed plants to create custom strains with inherited traits
 */
var HP = HP || {};

HP.Genetics = (function() {
    'use strict';

    var MUTATION_CHANCE = 0.05; // 5% chance for bonus trait

    /** Words used to auto-generate hybrid strain names (2 words picked per hybrid) */
    var STRAIN_NAME_WORDS = [
        'Purple', 'Haze', 'Kush', 'Skunk', 'Dream', 'Northern', 'Southern', 'Blue', 'Green', 'Orange',
        'Lemon', 'Pine', 'Diesel', 'Cheese', 'Berry', 'Cherry', 'Gelato', 'Cookie', 'Cake', 'Candy',
        'Fire', 'Ice', 'Storm', 'Thunder', 'Royal', 'Grand', 'Super', 'Mega', 'Ultra', 'Golden',
        'Silver', 'Crystal', 'Diamond', 'OG', 'Sour', 'Sweet', 'Tropical', 'Arctic', 'Sunset', 'Dawn',
        'Ghost', 'Phantom', 'Cosmic', 'Lunar', 'Stellar', 'Nova', 'Frost', 'Blaze', 'Shadow', 'Mystic',
        'Wild', 'Urban', 'Alpine', 'Jungle', 'Desert', 'Ocean', 'River', 'Peak', 'Valley', 'Canyon',
        'Elite', 'Prime', 'Alpha', 'Omega', 'Zen', 'Karma', 'Sage', 'Spirit', 'Soul', 'Mind',
        'Mint', 'Vanilla', 'Mango', 'Peach', 'Grape', 'Apple', 'Pineapple', 'Kiwi', 'Banana', 'Melon',
        'Lavender', 'Rose', 'Eucalyptus', 'Clove', 'Basil', 'Citrus', 'Honey', 'Maple', 'Caramel', 'Toffee',
        'Midnight', 'Twilight', 'Aurora', 'Comet', 'Nebula', 'Void', 'Ember', 'Ash', 'Coal', 'Obsidian',
        'Jade', 'Onyx', 'Ruby', 'Amber', 'Ivory', 'Pearl', 'Coral', 'Sapphire', 'Topaz', 'Garnet',
        'Rogue', 'Viper', 'Wolf', 'Bear', 'Eagle', 'Hawk', 'Raven', 'Phoenix', 'Dragon', 'Tiger',
        'Bold', 'Silent', 'Swift', 'Heavy', 'Smooth', 'Rough', 'Deep', 'High', 'Low', 'Bright',
        'Ancient', 'Modern', 'Classic', 'Rare', 'Common', 'Secret', 'Hidden', 'Lost', 'Found', 'First',
        'Last', 'True', 'Pure', 'Raw', 'Clean', 'Dirty', 'Fresh', 'Stale', 'Hot', 'Cold',
        'East', 'West', 'North', 'South', 'Central', 'Outer', 'Inner', 'Upper', 'Lower', 'Middle'
    ];

    /**
     * Generate a strain name by picking 2 words from STRAIN_NAME_WORDS, seeded by parent IDs
     * so the same parent pair always produces the same name.
     */
    function generateStrainName(parent1Id, parent2Id) {
        var sorted = [parent1Id, parent2Id].slice().sort();
        var seed = (sorted[0] + '_' + sorted[1]).split('').reduce(function(acc, c) { return ((acc << 5) - acc) + c.charCodeAt(0); }, 0);
        var len = STRAIN_NAME_WORDS.length;
        var i = Math.abs(seed) % len;
        var j = Math.abs(seed * 31 + 1) % len;
        if (i === j) j = (j + 1) % len;
        return STRAIN_NAME_WORDS[i] + ' ' + STRAIN_NAME_WORDS[j];
    }

    /**
     * Breed two parent strains to create a new hybrid
     * @param {string} parent1Id - First parent seed ID
     * @param {string} parent2Id - Second parent seed ID
     * @returns {Object} New strain definition
     */
    function breedStrains(parent1Id, parent2Id) {
        var parent1 = HP.Data.Seeds.get(parent1Id);
        var parent2 = HP.Data.Seeds.get(parent2Id);

        if (!parent1 || !parent2) {
            return { success: false, error: 'Invalid parent strains' };
        }

        var generatedName = generateStrainName(parent1Id, parent2Id);

        // Generate unique ID for the hybrid
        var hybridId = 'hybrid_' + Date.now() + '_' + Math.floor(Math.random() * 10000);

        // Inherit traits (average with variance)
        var traits = inheritTraits(parent1, parent2);

        // Check for mutations
        var mutations = checkMutations();
        applyMutations(traits, mutations);

        // Inherit strain effects from parents (union) and add mutations as effects
        var effects = [];
        var seen = {};
        function addEffect(id) {
            if (id && !seen[id]) { seen[id] = true; effects.push(id); }
        }
        var p1Effects = (parent1.effects && Array.isArray(parent1.effects)) ? parent1.effects : [];
        var p2Effects = (parent2.effects && Array.isArray(parent2.effects)) ? parent2.effects : [];
        for (var e = 0; e < p1Effects.length; e++) addEffect(p1Effects[e]);
        for (var e2 = 0; e2 < p2Effects.length; e2++) addEffect(p2Effects[e2]);
        for (var m = 0; m < mutations.length; m++) addEffect(mutations[m]);

        // Create hybrid definition
        var hybrid = {
            id: hybridId,
            name: generatedName,
            strainName: generatedName,
            description: 'Custom hybrid bred from ' + parent1.strainName + ' and ' + parent2.strainName + '.',
            store: null, // Not purchasable, only from breeding
            cost: 0,
            unlockLevel: 1,
            icon: '🧬',
            isHybrid: true,
            parentIds: [parent1Id, parent2Id],
            mutations: mutations,
            effects: effects,
            // Inherited traits
            growthTime: traits.growthTime,
            baseYield: traits.baseYield,
            yieldVariance: traits.yieldVariance,
            quality: traits.quality,
            failureChance: traits.failureChance,
            waterConsumption: traits.waterConsumption,
            qualityBias: traits.qualityBias,
            // Breeding metadata
            generation: Math.max(parent1.generation || 1, parent2.generation || 1) + 1,
            bredAt: Date.now()
        };

        return { success: true, hybrid: hybrid, mutations: mutations };
    }

    /**
     * Inherit traits from parents (average with some variance)
     */
    function inheritTraits(parent1, parent2) {
        var traits = {};

        // Growth time: average ± 10%
        var avgGrowth = (parent1.growthTime + parent2.growthTime) / 2;
        traits.growthTime = Math.round(avgGrowth * (0.9 + Math.random() * 0.2));

        // Base yield: average ± 15%
        var avgYield = (parent1.baseYield + parent2.baseYield) / 2;
        traits.baseYield = Math.round(avgYield * (0.85 + Math.random() * 0.3));

        // Yield variance: average (lower is better)
        traits.yieldVariance = (parent1.yieldVariance + parent2.yieldVariance) / 2;

        // Quality: take the better parent's quality (with small chance to upgrade)
        var qualities = ['low', 'medium', 'good', 'premium'];
        var p1QualityIdx = qualities.indexOf(parent1.quality);
        var p2QualityIdx = qualities.indexOf(parent2.quality);
        var bestQualityIdx = Math.max(p1QualityIdx, p2QualityIdx);
        if (Math.random() < 0.1 && bestQualityIdx < qualities.length - 1) {
            bestQualityIdx++; // 10% chance to upgrade quality
        }
        traits.quality = qualities[bestQualityIdx];

        // Failure chance: average (lower is better)
        traits.failureChance = (parent1.failureChance + parent2.failureChance) / 2;

        // Water consumption: average ± 10%
        var avgWater = (parent1.waterConsumption + parent2.waterConsumption) / 2;
        traits.waterConsumption = Math.round((avgWater * (0.9 + Math.random() * 0.2)) * 100) / 100;

        // Quality bias: average + small bonus
        var avgBias = (parent1.qualityBias + parent2.qualityBias) / 2;
        traits.qualityBias = Math.round(avgBias * (1 + Math.random() * 0.2));

        return traits;
    }

    /**
     * Check for random mutations (5% chance each)
     */
    function checkMutations() {
        var mutations = [];
        
        if (Math.random() < MUTATION_CHANCE) {
            mutations.push('fast_growth'); // -20% growth time
        }
        if (Math.random() < MUTATION_CHANCE) {
            mutations.push('high_yield'); // +25% yield
        }
        if (Math.random() < MUTATION_CHANCE) {
            mutations.push('water_efficient'); // -20% water consumption
        }
        if (Math.random() < MUTATION_CHANCE) {
            mutations.push('hardy'); // -50% failure chance
        }
        if (Math.random() < MUTATION_CHANCE) {
            mutations.push('premium_genes'); // +15 quality bias
        }

        return mutations;
    }

    /**
     * Apply mutation bonuses to traits
     */
    function applyMutations(traits, mutations) {
        for (var i = 0; i < mutations.length; i++) {
            var mut = mutations[i];
            if (mut === 'fast_growth') {
                traits.growthTime = Math.round(traits.growthTime * 0.8);
            } else if (mut === 'high_yield') {
                traits.baseYield = Math.round(traits.baseYield * 1.25);
            } else if (mut === 'water_efficient') {
                traits.waterConsumption = Math.round(traits.waterConsumption * 0.8 * 100) / 100;
            } else if (mut === 'hardy') {
                traits.failureChance = Math.round(traits.failureChance * 0.5 * 100) / 100;
            } else if (mut === 'premium_genes') {
                traits.qualityBias += 15;
            }
        }
    }

    /**
     * Get mutation display info
     */
    function getMutationInfo(mutationId) {
        var info = {
            fast_growth: { name: '⚡ Fast Growth', description: '-20% growth time' },
            high_yield: { name: '🌿 High Yield', description: '+25% base yield' },
            water_efficient: { name: '💧 Water Efficient', description: '-20% water consumption' },
            hardy: { name: '💪 Hardy', description: '-50% failure chance' },
            premium_genes: { name: '💎 Premium Genes', description: '+15 quality bias' }
        };
        return info[mutationId] || { name: mutationId, description: 'Unknown mutation' };
    }

    return {
        breedStrains: breedStrains,
        getMutationInfo: getMutationInfo,
        MUTATION_CHANCE: MUTATION_CHANCE
    };
})();
