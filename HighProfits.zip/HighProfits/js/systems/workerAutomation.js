/**
 * HighProfits - Worker Automation System
 * Handles automated plot management by workers
 */
var HP = HP || {};

HP.WorkerAutomation = (function() {
    'use strict';

    var NOTIFICATION_COOLDOWN = 30000; // 30 seconds between notifications

    /**
     * Process all worker automation
     * Called from game loop
     */
    function processWorkers(deltaTime) {
        var workers = HP.State.getGrowerWorkers();
        
        for (var i = 0; i < workers.length; i++) {
            var worker = workers[i];
            if (worker.status !== 'active') continue;

            var plot = HP.State.getPlot(worker.assignedPlot.propertyId, worker.assignedPlot.plotIndex);
            if (!plot) {
                // Plot doesn't exist, pause worker
                HP.State.updateWorkerStatus(worker.id, 'paused');
                continue;
            }

            processWorker(worker, plot, deltaTime);
        }
    }

    /**
     * Process a single worker's automation
     */
    function processWorker(worker, plot, deltaTime) {
        var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
        if (!workerType) return;

        // Check plot status and act accordingly
        if (plot.status === 'empty' || plot.status === 'setup') {
            // Try to plant
            tryPlant(worker, plot);
        } else if (plot.status === 'growing' && plot.plant) {
            // Check if needs watering
            if (!plot.plant.isHydrated || plot.plant.waterLevel < plot.plant.maxWater * 0.3) {
                tryWater(worker, plot);
            }
        } else if (plot.status === 'harvest') {
            // Harvest the plant
            tryHarvest(worker, plot);
        } else if (plot.status === 'dead') {
            // Clear dead plant
            tryClearDead(worker, plot);
        }
    }

    /**
     * Try to plant a seed in the plot
     */
    function tryPlant(worker, plot) {
        var config = worker.config;
        var inventory = HP.State.getInventory();

        // Check if plot is ready (has required equipment)
        var requiredSlots = HP.Data.Equipment.getRequiredSlots();
        var hasRequired = true;
        for (var i = 0; i < requiredSlots.length; i++) {
            if (!plot.equipment[requiredSlots[i]]) {
                hasRequired = false;
                break;
            }
        }

        if (!hasRequired) {
            notifyResourceDepleted(worker, 'Plot needs equipment (pot, soil, light)');
            return;
        }

        // Check for seed (auto-select best available if not configured)
        var seedIdToUse = config.seedId;
        if (!seedIdToUse) {
            // Auto-select: find best available seed
            var allSeeds = HP.Data.Seeds.getAll();
            var bestSeed = null;
            for (var seedId in allSeeds) {
                var seedCount = inventory.seeds[seedId] || 0;
                if (seedCount > 0) {
                    var seed = allSeeds[seedId];
                    if (!bestSeed || seed.cost > bestSeed.cost) {
                        bestSeed = seed;
                        seedIdToUse = seedId;
                    }
                }
            }
            if (!seedIdToUse) {
                notifyResourceDepleted(worker, 'No seeds available');
                return;
            }
        } else {
            var seedCount = inventory.seeds[seedIdToUse] || 0;
            if (seedCount < 1) {
                var seed = HP.Data.Seeds.get(seedIdToUse);
                var seedName = seed ? seed.name : 'seeds';
                notifyResourceDepleted(worker, 'Out of ' + seedName);
                return;
            }
        }

        // Check for soil if configured
        if (config.soilId) {
            var soilCount = inventory.equipment[config.soilId] || 0;
            if (soilCount < 1) {
                var soil = HP.Data.Equipment.get(config.soilId);
                var soilName = soil ? soil.name : 'soil';
                notifyResourceDepleted(worker, 'Out of ' + soilName);
                return;
            }
        }

        // Check for fertilizer if configured
        if (config.fertilizerId) {
            var fertCount = inventory.equipment[config.fertilizerId] || 0;
            if (fertCount < 1) {
                var fert = HP.Data.Equipment.get(config.fertilizerId);
                var fertName = fert ? fert.name : 'fertilizer';
                notifyResourceDepleted(worker, 'Out of ' + fertName);
                return;
            }
        }

        // Install soil if needed and configured (only if plot doesn't have soil)
        if (config.soilId && !plot.equipment.soil) {
            var soilCount = inventory.equipment[config.soilId] || 0;
            if (soilCount > 0) {
                var result = HP.Growing.installEquipment(plot, config.soilId);
                if (result.success) {
                    HP.State.removeEquipment(config.soilId, 1);
                }
            }
        }

        // Install fertilizer if needed and configured (only if plot doesn't have fertilizer)
        if (config.fertilizerId && !plot.equipment.fertilizer) {
            var fertCount = inventory.equipment[config.fertilizerId] || 0;
            if (fertCount > 0) {
                var result = HP.Growing.installEquipment(plot, config.fertilizerId);
                if (result.success) {
                    HP.State.removeEquipment(config.fertilizerId, 1);
                }
            }
        }

        // Plant the seed
        var propertyId = worker.assignedPlot.propertyId;
        var roomBonuses = HP.State.getRoomBonuses(propertyId);
        var result = HP.Growing.plantSeed(plot, seedIdToUse, roomBonuses);

        if (result.success) {
            HP.State.removeSeeds(seedIdToUse, 1);
            if (HP.Progression && HP.Progression.calculateXPForPlanting) {
                HP.State.addXP(HP.Progression.calculateXPForPlanting(seedIdToUse));
            }
            
            // Clear any previous notifications since we succeeded
            HP.State.setWorkerNotification(worker.id, null);
        }
    }

    /**
     * Try to water the plant
     */
    function tryWater(worker, plot) {
        if (!plot.plant) return;

        var inventory = HP.State.getInventory();
        var wateringCans = HP.Data.Equipment.getWateringCans();
        
        // Find best available watering can
        var bestCan = null;
        for (var i = 0; i < wateringCans.length; i++) {
            var can = wateringCans[i];
            if (inventory.equipment[can.id] > 0) {
                if (!bestCan || can.waterAmount > bestCan.waterAmount) {
                    bestCan = can;
                }
            }
        }

        if (!bestCan) {
            notifyResourceDepleted(worker, 'No watering can available');
            return;
        }

        var waterCost = HP.Data.Constants && HP.Data.Constants.WATER_COST_PER_USE != null ? HP.Data.Constants.WATER_COST_PER_USE : 1;
        var reservoir = HP.State.getWaterReservoir ? HP.State.getWaterReservoir() : { current: 0 };
        if (reservoir.current < waterCost) {
            notifyResourceDepleted(worker, 'Out of water - refill at tap');
            return;
        }

        var result = HP.Growing.waterPlant(plot, bestCan.waterAmount);
        if (result && result.success) {
            if (HP.State.useWater) HP.State.useWater(waterCost);
            HP.State.setWorkerNotification(worker.id, null);
        } else {
            notifyResourceDepleted(worker, 'Failed to water plant');
        }
    }

    /**
     * Try to harvest the plant
     */
    function tryHarvest(worker, plot) {
        var result = HP.Growing.harvestPlant(plot);
        if (result.success) {
            HP.State.addWeed(result.quality, result.yield);
            if (HP.Progression && HP.Progression.calculateXPForHarvest) {
                HP.State.addXP(HP.Progression.calculateXPForHarvest(plot, result));
            } else {
                HP.State.addXP(HP.Data.Constants.XP_PER_HARVEST);
            }
            HP.State.incrementStat('plantsGrown', 1);
            HP.State.setWorkerNotification(worker.id, null);
                        
            if (HP.SoundManager) HP.SoundManager.play('harvest');
        }
    }

    /**
     * Try to clear dead plant
     */
    function tryClearDead(worker, plot) {
        HP.Growing.clearDeadPlant(plot);
        HP.State.setWorkerNotification(worker.id, null);
    }

    /**
     * Notify player about resource depletion (with cooldown)
     */
    function notifyResourceDepleted(worker, message) {
        var now = Date.now();
        var lastNotif = worker.lastNotification || 0;

        // Only notify if cooldown has passed
        if (now - lastNotif < NOTIFICATION_COOLDOWN) {
            return;
        }

        HP.State.setWorkerNotification(worker.id, now);
        var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
        var workerName = workerType ? workerType.name : 'Worker';
        
        HP.Notifications.warning(workerName + ' paused: ' + message);
    }

    /**
     * Check if resources are available for a worker
     */
    function checkResourcesAvailable(worker) {
        var config = worker.config;
        var inventory = HP.State.getInventory();

        // Check seed
        if (config.seedId) {
            var seedCount = inventory.seeds[config.seedId] || 0;
            if (seedCount < 1) return false;
        }

        // Check soil if configured
        if (config.soilId) {
            var soilCount = inventory.equipment[config.soilId] || 0;
            if (soilCount < 1) return false;
        }

        // Check fertilizer if configured
        if (config.fertilizerId) {
            var fertCount = inventory.equipment[config.fertilizerId] || 0;
            if (fertCount < 1) return false;
        }

        // Check for watering can
        var wateringCans = HP.Data.Equipment.getWateringCans();
        var hasCan = false;
        for (var i = 0; i < wateringCans.length; i++) {
            if (inventory.equipment[wateringCans[i].id] > 0) {
                hasCan = true;
                break;
            }
        }

        return hasCan;
    }

    /**
     * Resume workers when resources become available
     */
    function checkAndResumeWorkers() {
        var workers = HP.State.getGrowerWorkers();
        
        for (var i = 0; i < workers.length; i++) {
            var worker = workers[i];
            if (worker.status === 'paused' && checkResourcesAvailable(worker)) {
                HP.State.updateWorkerStatus(worker.id, 'active');
                var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
                var workerName = workerType ? workerType.name : 'Worker';
                HP.Notifications.info(workerName + ' resumed work - resources available');
            }
        }
    }

    return {
        processWorkers: processWorkers,
        checkResourcesAvailable: checkResourcesAvailable,
        checkAndResumeWorkers: checkAndResumeWorkers
    };
})();
