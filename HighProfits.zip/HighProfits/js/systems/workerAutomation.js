/**
 * HighProfits - Worker Automation System
 * Handles automated plot management by workers
 */
var HP = HP || {};

HP.WorkerAutomation = (function() {
    'use strict';

    var NOTIFICATION_COOLDOWN = 30000; // 30 seconds between notifications
    var ACTION_COOLDOWN_MS = 2500;     // Base cooldown for plant/harvest/clear (reduced by efficiency)
    var WATER_COOLDOWN_MS = 2000;      // Base cooldown for watering (reduced by wateringSpeed)

    /**
     * Get effective efficiency and wateringSpeed for a worker (base from type + level bonus)
     */
    function getEffectiveStats(worker) {
        var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
        if (!workerType) return { efficiency: 1, wateringSpeed: 1 };
        var efficiency = Math.max(0.5, workerType.efficiency || 1);
        var wateringSpeed = Math.max(0.5, workerType.wateringSpeed || 1);
        var hasSpeedFocus = HP.Data.GrowerWorkers.hasTrait && HP.Data.GrowerWorkers.hasTrait(workerType, 'speedFocus');
        if (hasSpeedFocus) {
            efficiency *= 1.2;
            wateringSpeed *= 1.2;
        }
        var levelBonus = HP.Data.WorkerSkills && HP.Data.WorkerSkills.getLevelBonus
            ? HP.Data.WorkerSkills.getLevelBonus(worker.level || 1) : 1;
        return {
            efficiency: efficiency * levelBonus,
            wateringSpeed: wateringSpeed * levelBonus
        };
    }

    /**
     * Process all worker automation
     * Called from game loop
     */
    function processWorkers(deltaTime) {
        var workers = HP.State.getGrowerWorkers();
        var now = Date.now();

        for (var i = 0; i < workers.length; i++) {
            var worker = workers[i];
            if (worker.status !== 'active') continue;

            var propertyId = worker.assignedPropertyId != null ? worker.assignedPropertyId : (worker.assignedPlot && worker.assignedPlot.propertyId);
            if (!propertyId) {
                HP.State.updateWorkerStatus(worker.id, 'paused', 'no_plot');
                continue;
            }

            var plots = HP.State.getPlots(propertyId);
            if (!plots || plots.length === 0) {
                HP.State.updateWorkerStatus(worker.id, 'paused', 'no_plot');
                continue;
            }

            var target = pickPlotNeedingWork(worker, plots, propertyId, now);
            if (!target) continue;

            worker.lastActionAt = worker.lastActionAt || 0;
            worker.lastWaterAt = worker.lastWaterAt || 0;
            processWorker(worker, target.plot, deltaTime, now);
        }
    }

    /** Pick one plot at this property that needs work (priority: harvest > water > plant > clear dead) */
    function pickPlotNeedingWork(worker, plots, propertyId, now) {
        var stats = getEffectiveStats(worker);
        var efficiency = stats.efficiency;
        var wateringSpeed = stats.wateringSpeed;
        var actionCooldown = ACTION_COOLDOWN_MS / efficiency;
        var waterCooldown = WATER_COOLDOWN_MS / wateringSpeed;

        for (var i = 0; i < plots.length; i++) {
            var plot = plots[i];
            if (plot.status === 'harvest') {
                if (now - (worker.lastActionAt || 0) >= actionCooldown) return { plot: plot, plotIndex: i };
            }
        }
        for (var j = 0; j < plots.length; j++) {
            var p = plots[j];
            if (p.status === 'growing' && p.plant && (!p.plant.isHydrated || p.plant.waterLevel < p.plant.maxWater * 0.3)) {
                if (now - (worker.lastWaterAt || 0) >= waterCooldown) return { plot: p, plotIndex: j };
            }
        }
        for (var k = 0; k < plots.length; k++) {
            var pl = plots[k];
            if ((pl.status === 'empty' || pl.status === 'setup') && (now - (worker.lastActionAt || 0) >= actionCooldown)) return { plot: pl, plotIndex: k };
        }
        for (var m = 0; m < plots.length; m++) {
            var deadPlot = plots[m];
            if (deadPlot.status === 'dead' && (now - (worker.lastActionAt || 0) >= actionCooldown)) return { plot: deadPlot, plotIndex: m };
        }
        return null;
    }

    /**
     * Process a single worker's automation (efficiency & wateringSpeed apply to cooldowns and outcomes)
     */
    function processWorker(worker, plot, deltaTime, now) {
        var stats = getEffectiveStats(worker);
        var efficiency = stats.efficiency;
        var wateringSpeed = stats.wateringSpeed;

        if (plot.status === 'empty' || plot.status === 'setup') {
            var actionCooldown = ACTION_COOLDOWN_MS / efficiency;
            if (now - worker.lastActionAt < actionCooldown) return;
            tryPlant(worker, plot, efficiency, now);
        } else if (plot.status === 'growing' && plot.plant) {
            if (!plot.plant.isHydrated || plot.plant.waterLevel < plot.plant.maxWater * 0.3) {
                var waterCooldown = WATER_COOLDOWN_MS / wateringSpeed;
                if (now - worker.lastWaterAt < waterCooldown) return;
                tryWater(worker, plot, wateringSpeed, now);
            }
        } else if (plot.status === 'harvest') {
            var harvestCooldown = ACTION_COOLDOWN_MS / efficiency;
            if (now - worker.lastActionAt < harvestCooldown) return;
            tryHarvest(worker, plot, efficiency, now);
        } else if (plot.status === 'dead') {
            var clearCooldown = ACTION_COOLDOWN_MS / efficiency;
            if (now - worker.lastActionAt < clearCooldown) return;
            tryClearDead(worker, plot, now);
        }
    }

    /**
     * Try to plant a seed in the plot
     */
    function tryPlant(worker, plot, efficiency, now) {
        var config = worker.config;
        var inventory = HP.State.getInventory();

        // Check if plot is ready (has required equipment)
        var requiredSlots = HP.Data.Equipment.getRequiredSlots();
        var hasRequired = true;
        for (var i = 0; i < requiredSlots.length; i++) {
            if (!plot.equipment[requiredSlots[i]]) {
                hasRequired = false;
                break;
            }
        }

        if (!hasRequired) {
            notifyResourceDepleted(worker, 'Plot needs equipment (pot, soil, light)');
            return;
        }

        // Seed is required (no auto best-seed)
        var seedIdToUse = config.seedId;
        if (!seedIdToUse) {
            notifyResourceDepleted(worker, 'No seed configured – set one in Configure');
            return;
        }
        var seedCount = inventory.seeds[seedIdToUse] || 0;
        if (seedCount < 1) {
            var seed = HP.Data.Seeds.get(seedIdToUse);
            var seedName = seed ? seed.name : 'seeds';
            notifyResourceDepleted(worker, 'Out of ' + seedName);
            return;
        }

        // Soil is required
        if (!config.soilId) {
            notifyResourceDepleted(worker, 'No soil configured – set one in Configure');
            return;
        }
        var soilCount = inventory.equipment[config.soilId] || 0;
        if (soilCount < 1) {
            var soil = HP.Data.Equipment.get(config.soilId);
            var soilName = soil ? soil.name : 'soil';
            notifyResourceDepleted(worker, 'Out of ' + soilName);
            return;
        }

        // Fertilizer is required
        if (!config.fertilizerId) {
            notifyResourceDepleted(worker, 'No fertilizer configured – set one in Configure');
            return;
        }
        var fertCount = inventory.equipment[config.fertilizerId] || 0;
        if (fertCount < 1) {
            var fert = HP.Data.Equipment.get(config.fertilizerId);
            var fertName = fert ? fert.name : 'fertilizer';
            notifyResourceDepleted(worker, 'Out of ' + fertName);
            return;
        }

        // Install soil if needed (plot doesn't have soil yet)
        if (!plot.equipment.soil) {
            var soilCount = inventory.equipment[config.soilId] || 0;
            if (soilCount > 0) {
                var result = HP.Growing.installEquipment(plot, config.soilId);
                if (result.success) {
                    HP.State.removeEquipment(config.soilId, 1);
                }
            }
        }

        // Install fertilizer if needed (plot doesn't have fertilizer yet)
        if (!plot.equipment.fertilizer) {
            var fertCount = inventory.equipment[config.fertilizerId] || 0;
            if (fertCount > 0) {
                var result = HP.Growing.installEquipment(plot, config.fertilizerId);
                if (result.success) {
                    HP.State.removeEquipment(config.fertilizerId, 1);
                }
            }
        }

        // Plant the seed
        var propertyId = worker.assignedPropertyId != null ? worker.assignedPropertyId : (worker.assignedPlot && worker.assignedPlot.propertyId);
        var roomBonuses = HP.State.getRoomBonuses(propertyId);
        var result = HP.Growing.plantSeed(plot, seedIdToUse, roomBonuses, propertyId);

        if (result.success) {
            HP.State.removeSeeds(seedIdToUse, 1);
            if (HP.Progression && HP.Progression.calculateXPForPlanting) {
                HP.State.addXP(HP.Progression.calculateXPForPlanting(seedIdToUse));
            }
            worker.lastActionAt = now;
            HP.State.setWorkerNotification(worker.id, null);
            var xpAmount = HP.Data.WorkerSkills ? HP.Data.WorkerSkills.XP_PER_PLANT : 8;
            var leveled = HP.State.addWorkerXP && HP.State.addWorkerXP(worker.id, xpAmount);
            if (leveled) notifyWorkerLevelUp(worker);
        }
    }

    /**
     * Try to water the plant (wateringSpeed scales amount applied)
     */
    function tryWater(worker, plot, wateringSpeed, now) {
        if (!plot.plant) return;

        var inventory = HP.State.getInventory();
        var wateringCans = HP.Data.Equipment.getWateringCans();
        
        // Find best available watering can
        var bestCan = null;
        for (var i = 0; i < wateringCans.length; i++) {
            var can = wateringCans[i];
            if (inventory.equipment[can.id] > 0) {
                if (!bestCan || can.waterAmount > bestCan.waterAmount) {
                    bestCan = can;
                }
            }
        }

        if (!bestCan) {
            notifyResourceDepleted(worker, 'No watering can available');
            return;
        }

        var waterCost = HP.Data.Constants && HP.Data.Constants.WATER_COST_PER_USE != null ? HP.Data.Constants.WATER_COST_PER_USE : 1;
        var hasWaterSaver = HP.Data.GrowerWorkers.hasTrait && HP.Data.GrowerWorkers.hasTrait(HP.Data.GrowerWorkers.get(worker.workerTypeId), 'waterSaver');
        if (hasWaterSaver) waterCost = Math.max(1, Math.floor(waterCost * 0.5));
        var reservoir = HP.State.getWaterReservoir ? HP.State.getWaterReservoir() : { current: 0 };
        if (reservoir.current < waterCost) {
            notifyResourceDepleted(worker, 'Out of water - refill at tap');
            return;
        }

        var waterAmount = Math.min(plot.plant.maxWater - plot.plant.waterLevel, bestCan.waterAmount * Math.min(wateringSpeed, 2));
        if (waterAmount < 0.5) waterAmount = bestCan.waterAmount;
        var result = HP.Growing.waterPlant(plot, waterAmount);
        if (result && result.success) {
            if (HP.State.useWater) HP.State.useWater(waterCost);
            worker.lastWaterAt = now;
            HP.State.setWorkerNotification(worker.id, null);
            var xpAmount = HP.Data.WorkerSkills ? HP.Data.WorkerSkills.XP_PER_WATER : 4;
            var leveled = HP.State.addWorkerXP && HP.State.addWorkerXP(worker.id, xpAmount);
            if (leveled) notifyWorkerLevelUp(worker);
        } else {
            notifyResourceDepleted(worker, 'Failed to water plant');
        }
    }

    /**
     * Try to harvest the plant (efficiency scales yield up to 1.5x)
     */
    function tryHarvest(worker, plot, efficiency, now) {
        var result = HP.Growing.harvestPlant(plot);
        if (result.success) {
            var yieldMult = Math.min(1.5, 0.7 + (efficiency * 0.2));
            var bonusYield = Math.max(0, Math.floor(result.yield * yieldMult) - result.yield);
            var totalYield = result.yield + bonusYield;
            var workerTypeForTrait = HP.Data.GrowerWorkers.get(worker.workerTypeId);
            if (HP.Data.GrowerWorkers.hasTrait && HP.Data.GrowerWorkers.hasTrait(workerTypeForTrait, 'qualityFocus')) {
                totalYield += Math.max(0, Math.floor(totalYield * 0.05));
            }
            HP.State.addWeed(result.seedId, totalYield);
            if (HP.Progression && HP.Progression.calculateXPForHarvest) {
                var harvestResult = { yield: totalYield, quality: result.quality, seedId: result.seedId };
                HP.State.addXP(HP.Progression.calculateXPForHarvest(plot, harvestResult));
            } else {
                HP.State.addXP(HP.Data.Constants.XP_PER_HARVEST);
            }
            HP.State.incrementStat('plantsGrown', 1);
            worker.lastActionAt = now;
            HP.State.setWorkerNotification(worker.id, null);
            var xpAmount = HP.Data.WorkerSkills ? HP.Data.WorkerSkills.XP_PER_HARVEST : 12;
            var leveled = HP.State.addWorkerXP && HP.State.addWorkerXP(worker.id, xpAmount);
            if (leveled) notifyWorkerLevelUp(worker);
            if (HP.SoundManager) HP.SoundManager.play('harvest');
        }
    }

    /**
     * Try to clear dead plant
     */
    function tryClearDead(worker, plot, now) {
        HP.Growing.clearDeadPlant(plot);
        worker.lastActionAt = now;
        HP.State.setWorkerNotification(worker.id, null);
        var xpAmount = HP.Data.WorkerSkills ? HP.Data.WorkerSkills.XP_PER_CLEAR : 6;
        var leveled = HP.State.addWorkerXP && HP.State.addWorkerXP(worker.id, xpAmount);
        if (leveled) notifyWorkerLevelUp(worker);
    }

    /**
     * Show notification and play sound when a worker levels up; trigger achievement/journal checks.
     */
    function notifyWorkerLevelUp(worker) {
        var name = worker.name || (HP.Data.GrowerWorkers.get(worker.workerTypeId) || {}).name || 'Worker';
        if (HP.Notifications && HP.Notifications.success) {
            HP.Notifications.success(name + ' reached Level ' + (worker.level || 1) + '!');
        }
        if (HP.SoundManager && HP.SoundManager.play) HP.SoundManager.play('levelup');
        if (HP.State.checkAchievements) HP.State.checkAchievements();
        if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
    }

    /**
     * Notify player about resource depletion (with cooldown)
     */
    function notifyResourceDepleted(worker, message) {
        var now = Date.now();
        var lastNotif = worker.lastNotification || 0;

        // Only notify if cooldown has passed
        if (now - lastNotif < NOTIFICATION_COOLDOWN) {
            return;
        }

        HP.State.setWorkerNotification(worker.id, now);
        var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
        var workerName = workerType ? workerType.name : 'Worker';
        
        HP.Notifications.warning(workerName + ' paused: ' + message);
    }

    var daySec = 720;
    function getWorkerDaySeconds() {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        return (c.WORKER_DAY_SECONDS != null) ? c.WORKER_DAY_SECONDS : 720;
    }

    /**
     * Total wage cost per game day for all active workers
     */
    function getTotalWagePerDay() {
        var workers = HP.State.getGrowerWorkers();
        var total = 0;
        for (var i = 0; i < workers.length; i++) {
            if (workers[i].status !== 'active') continue;
            var t = HP.Data.GrowerWorkers.get(workers[i].workerTypeId);
            var wage = (t && (t.wagePerDay != null)) ? t.wagePerDay : 0;
            if (wage > 0) total += wage;
        }
        return total;
    }

    /**
     * Total wage per day for all workers (active + paused), for resume check
     */
    function getTotalWagePerDayAll() {
        var workers = HP.State.getGrowerWorkers();
        var total = 0;
        for (var i = 0; i < workers.length; i++) {
            var t = HP.Data.GrowerWorkers.get(workers[i].workerTypeId);
            var wage = (t && (t.wagePerDay != null)) ? t.wagePerDay : 0;
            if (wage > 0) total += wage;
        }
        return total;
    }

    /**
     * Whether the wage fund can cover one day's wages (so workers can resume)
     */
    function canAffordWages() {
        var fund = HP.State.getWorkerWageFund ? HP.State.getWorkerWageFund() : 0;
        var need = getTotalWagePerDayAll();
        return need <= 0 || fund >= need;
    }

    /**
     * Process wage payments (called from game loop). Each game day (12 min) deduct from wage fund; pause workers if fund insufficient.
     */
    function processWages(deltaTimeSeconds) {
        daySec = getWorkerDaySeconds();
        if (!HP.State.getWorkerDayAccumulator || !HP.State.setWorkerDayAccumulator) return;
        var acc = HP.State.getWorkerDayAccumulator() + deltaTimeSeconds;
        while (acc >= daySec) {
            acc -= daySec;
            var workers = HP.State.getGrowerWorkers();
            var totalWage = 0;
            for (var i = 0; i < workers.length; i++) {
                if (workers[i].status !== 'active') continue;
                var t = HP.Data.GrowerWorkers.get(workers[i].workerTypeId);
                var wage = (t && (t.wagePerDay != null)) ? t.wagePerDay : 0;
                if (wage > 0) totalWage += wage;
            }
            if (totalWage > 0 && HP.State.getWorkerWageFund && HP.State.setWorkerWageFund) {
                var fund = HP.State.getWorkerWageFund();
                if (fund < totalWage) {
                    var paused = 0;
                    for (var j = 0; j < workers.length; j++) {
                        if (workers[j].status === 'active') {
                            HP.State.updateWorkerStatus(workers[j].id, 'paused', 'unpaid');
                            paused++;
                        }
                    }
                    if (paused > 0 && HP.Notifications) {
                        HP.Notifications.warning('Wage fund too low – ' + paused + ' worker(s) paused. Deposit money to the wage fund to resume.');
                    }
                } else {
                    HP.State.setWorkerWageFund(fund - totalWage);
                }
            }
        }
        HP.State.setWorkerDayAccumulator(acc);
    }

    /**
     * Check if resources are available for a worker (seed, soil, fertilizer required)
     */
    function checkResourcesAvailable(worker) {
        var config = worker.config;
        var inventory = HP.State.getInventory();

        if (!config.seedId) return false;
        var seedCount = inventory.seeds[config.seedId] || 0;
        if (seedCount < 1) return false;

        if (!config.soilId) return false;
        var soilCount = inventory.equipment[config.soilId] || 0;
        if (soilCount < 1) return false;

        if (!config.fertilizerId) return false;
        var fertCount = inventory.equipment[config.fertilizerId] || 0;
        if (fertCount < 1) return false;

        // Check for watering can
        var wateringCans = HP.Data.Equipment.getWateringCans();
        var hasCan = false;
        for (var i = 0; i < wateringCans.length; i++) {
            if (inventory.equipment[wateringCans[i].id] > 0) {
                hasCan = true;
                break;
            }
        }

        return hasCan;
    }

    /**
     * Resume workers when resources become available
     */
    function checkAndResumeWorkers() {
        var workers = HP.State.getGrowerWorkers();
        
        for (var i = 0; i < workers.length; i++) {
            var worker = workers[i];
            var canResume = worker.pauseReason === 'unpaid' ? canAffordWages()
                : (worker.pauseReason !== 'no_plot' && checkResourcesAvailable(worker));
            if (worker.status === 'paused' && canResume) {
                HP.State.updateWorkerStatus(worker.id, 'active');
                var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
                var workerName = workerType ? workerType.name : 'Worker';
                HP.Notifications.info(workerName + ' resumed work - resources available');
            }
        }
    }

    return {
        processWorkers: processWorkers,
        processWages: processWages,
        getTotalWagePerDay: getTotalWagePerDay,
        getTotalWagePerDayAll: getTotalWagePerDayAll,
        getWorkerDaySeconds: getWorkerDaySeconds,
        checkResourcesAvailable: checkResourcesAvailable,
        checkAndResumeWorkers: checkAndResumeWorkers,
        getEffectiveStats: getEffectiveStats
    };
})();
