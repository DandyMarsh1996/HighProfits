/**
 * HighProfits - Tutorial & Onboarding System
 * Guides new players through their first 5 minutes
 */
var HP = HP || {};

HP.Tutorial = (function() {
    'use strict';

    // Tutorial steps for first-time players
    var tutorialSteps = [
        {
            id: 0,
            title: 'Wagwan Fam! 🌿',
            message: 'Yo, wagwan! I\'m Rais, yeah? Man\'s gonna show you how we do tings round here, trust. First ting - you need some seeds, bruv. Can\'t grow nuttin without dem.',
            actionHint: '👉 Link up with the Seed Dealer (🌱) in the menu and cop some seeds, fam!',
            action: 'buy_seeds',
            highlight: 'dealer',
            requirement: function() {
                var inv = HP.State.getInventory();
                return inv.seeds && Object.keys(inv.seeds).length > 0;
            }
        },
        {
            id: 1,
            title: 'Plant Dem Seeds 🌱',
            message: 'Safe! You got the tings now, yeah? Time to get dem in the ground. Big man ting, this is where it starts innit.',
            actionHint: '👉 Go Grow (🌿), click a empty plot and bang "Plant" - select your seed, dun know!',
            action: 'plant_seed',
            highlight: 'grow',
            requirement: function() {
                var properties = HP.State.getProperties();
                for (var i = 0; i < properties.owned.length; i++) {
                    var plots = properties.owned[i].plots || [];
                    for (var j = 0; j < plots.length; j++) {
                        if (plots[j].status === 'growing') return true;
                    }
                }
                return false;
            }
        },
        {
            id: 2,
            title: 'Water Dem Crops 💧',
            message: 'Aight listen yeah, plants need water still. See that water meter at the top? It refills over time, so don\'t be stressing. Just keep your crops hydrated, fam.',
            actionHint: '👉 Click your plant ting, then bang "Water" to sort it out!',
            action: 'water_plant',
            highlight: 'water-reservoir-display',
            requirement: function() {
                var stats = HP.State.getStats();
                return stats.plantsWatered > 0;
            }
        },
        {
            id: 3,
            title: 'Wait It Out ⏱️',
            message: 'Now we chill, bruv. The ting is growing, yeah? Just keep watering and watch for when it says "Ready". Patience is key in this game, trust.',
            actionHint: '👉 Wait for your plant to finish (or use Skip Time if you\'re moving mad impatient)',
            action: 'wait_harvest',
            highlight: null,
            requirement: function() {
                var properties = HP.State.getProperties();
                for (var i = 0; i < properties.owned.length; i++) {
                    var plots = properties.owned[i].plots || [];
                    for (var j = 0; j < plots.length; j++) {
                        if (plots[j].status === 'harvest') return true;
                    }
                }
                return false;
            }
        },
        {
            id: 4,
            title: 'Harvest Time Bruv! ✂️',
            message: 'YOOO the ting is ready fam! Bare peng looking plant right there. Time to collect your food, yeah? Quality depends on how you looked after it still.',
            actionHint: '👉 Click the ready plant and bang "Harvest" to get your product!',
            action: 'harvest',
            highlight: 'grow',
            requirement: function() {
                var inv = HP.State.getInventory();
                return inv.weed && Object.keys(inv.weed).length > 0;
            }
        },
        {
            id: 5,
            title: 'Time to Get Paid 💰',
            message: 'Aight now we\'re talking! You got product, time to make some Ps init. Different mans pay different prices, so choose your buyer wisely, yeah?',
            actionHint: '👉 Go Market (💰), pick a customer, select your bits and click "Sell"!',
            action: 'sell',
            highlight: 'market',
            requirement: function() {
                var stats = HP.State.getStats();
                return stats.totalSales > 0;
            }
        },
        {
            id: 6,
            title: 'You\'re Patterned! 🎉',
            message: 'Madting! You\'ve got the basics down, fam. Now go build your empire innit - cop better seeds, upgrade your yard, keep the feds off your back, and breed some mad genetics. Man\'s always watching, I\'ll link you with tips when you level up. Stay dangerous, bruv!',
            actionHint: null,
            action: 'complete',
            highlight: null,
            requirement: function() { return true; }
        }
    ];

    // Level-based hints (shown when player reaches certain levels)
    var levelHints = {
        2: {
            title: 'Rais: Equipment Unlocked! 🔧',
            message: 'Yo fam, sick progress! You can cop equipment from Hardware now innit. Grow lights, fertilizers - all dat. Trust me bruv, they\'re bare worth it for the yields.'
        },
        3: {
            title: 'Rais: Watch the Heat Fam! 🔥',
            message: 'Oi listen yeah, you\'re starting to look bait now. See that heat meter? Feds are watching still. Cop some security tings to stay lowkey, don\'t let it fill up or it\'s peak!'
        },
        5: {
            title: 'Rais: Market Orders! 📋',
            message: 'Wagwan bruv, got some contacts looking for specific bits yeah? Check the Orders panel in Market - bare bonus Ps if you got the right food. Easy money, dun know!'
        },
        7: {
            title: 'Rais: Time to Expand Your Yard! 🏠',
            message: 'You\'re moving mad now fam, outgrowing this place innit! Check Real Estate for new yards. More plots means more product, more Ps. Think bigger, bruv!'
        },
        10: {
            title: 'Rais: Get Yourself a Team! 👷',
            message: 'Oi you looking tired still! Hire some mandem from the Workers tab yeah? They\'ll water and harvest automatic like. Sit back, count your Ps, easy life fam.'
        },
        12: {
            title: 'Rais: Premium Tings! 🌿',
            message: 'BRUV the peng stuff is unlocked now! Premium strains take longer to grow but the quality is mad. Check Seed Dealer, this is where the real money\'s at!'
        },
        15: {
            title: 'Rais: Breeding Lab Open! 🧬',
            message: 'Aight now we\'re talking proper business! Cross-breed your strains to make custom hybrids fam. Some even mutate with special bonuses, it\'s a madting. Get experimenting!'
        },
        20: {
            title: 'Rais: You\'re a Don Now! 👑',
            message: 'LOOK AT YOU FAM! Proper kingpin energy right there! Focus on breeding elite genetics, run your empire, chase them achievements. Man always knew you had it in you, stay blessed bruv!'
        }
    };

    var currentStep = 0;
    var hintsShown = {};

    /**
     * Initialize tutorial system
     */
    function init() {
        currentStep = HP.State.getTutorialStep();
        
        // Show tutorial if not completed
        if (!HP.State.isTutorialCompleted()) {
            showTutorialStep(currentStep);
        }
    }

    /**
     * Check if tutorial is active
     */
    function isActive() {
        return !HP.State.isTutorialCompleted();
    }

    /**
     * Show current tutorial step
     */
    function showTutorialStep(stepIndex) {
        if (stepIndex >= tutorialSteps.length) {
            completeTutorial();
            return;
        }

        var step = tutorialSteps[stepIndex];
        if (!step) return;

        // Show advisor message with action hint
        showAdvisorMessage(step.title, step.message, step.highlight, null, step.actionHint);
    }

    /**
     * Check if current step is complete and advance
     */
    function checkProgress() {
        if (HP.State.isTutorialCompleted()) return;

        var step = tutorialSteps[currentStep];
        if (!step) return;

        // Check if requirement is met
        if (step.requirement && step.requirement()) {
            advanceStep();
        }
    }

    /**
     * Advance to next tutorial step
     */
    function advanceStep() {
        currentStep++;
        HP.State.setTutorialStep(currentStep);

        if (currentStep >= tutorialSteps.length) {
            completeTutorial();
        } else {
            // Small delay before showing next step
            setTimeout(function() {
                showTutorialStep(currentStep);
            }, 1000);
        }
    }

    /**
     * Complete tutorial
     */
    function completeTutorial() {
        HP.State.completeTutorial();
        showAdvisorMessage(
            '🎉 You\'re Patterned Fam!',
            'Yo that\'s what I\'m talking about bruv! You\'re ready to run tings now, trust. Remember yeah - keep the heat low, upgrade your yard, and experiment with breeding some mad strains. Man\'s always watching, I\'ll link you when you level up. Stay dangerous out there fam, bless!',
            null
        );
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            hideAdvisor();
        }, 5000);
    }

    /**
     * Check and show level-based hints
     */
    function checkLevelHint(level) {
        if (hintsShown[level]) return;
        
        var hint = levelHints[level];
        if (hint) {
            hintsShown[level] = true;
            showAdvisorMessage(hint.title, hint.message, null, 'hint');
            
            // Auto-hide hints after 8 seconds
            setTimeout(function() {
                hideAdvisor();
            }, 8000);
        }
    }

    /**
     * Show advisor message
     */
    function showAdvisorMessage(title, message, highlightElement, type, actionHint) {
        var advisor = document.getElementById('tutorial-advisor');
        if (!advisor) return;

        var titleEl = advisor.querySelector('.advisor-title');
        var messageEl = advisor.querySelector('.advisor-message');
        var actionEl = document.getElementById('advisor-action');
        var dismissBtn = advisor.querySelector('.advisor-dismiss');
        var gotItBtn = document.getElementById('advisor-gotit');
        var skipBtn = document.getElementById('advisor-skip');

        if (titleEl) titleEl.textContent = title;
        if (messageEl) messageEl.textContent = message;

        // Show action hint if provided
        if (actionEl) {
            if (actionHint) {
                actionEl.textContent = actionHint;
                actionEl.classList.add('visible');
            } else {
                actionEl.textContent = '';
                actionEl.classList.remove('visible');
            }
        }

        // Show advisor
        advisor.classList.remove('hidden');
        advisor.classList.add('visible');

        // Add type class
        advisor.className = 'tutorial-advisor visible';
        if (type) advisor.classList.add('advisor-' + type);

        // Highlight element if specified
        clearHighlights();
        if (highlightElement) {
            var el = document.getElementById(highlightElement);
            if (!el) el = document.querySelector('[data-view="' + highlightElement + '"]');
            if (el) {
                el.classList.add('tutorial-highlight');
            }
        }

        // Bind dismiss button (X)
        if (dismissBtn) {
            dismissBtn.onclick = function() {
                hideAdvisor();
            };
        }

        // Bind "Got it!" button - acknowledges message, hides advisor but keeps tutorial active
        if (gotItBtn) {
            if (!HP.State.isTutorialCompleted() || type === 'hint') {
                gotItBtn.style.display = 'inline-block';
                gotItBtn.onclick = function() {
                    hideAdvisor();
                    // Tutorial continues checking progress in background
                };
            } else {
                gotItBtn.style.display = 'none';
            }
        }

        // Bind skip button
        if (skipBtn) {
            if (!HP.State.isTutorialCompleted()) {
                skipBtn.style.display = 'inline-block';
                skipBtn.onclick = function() {
                    skipTutorial();
                };
            } else {
                skipBtn.style.display = 'none';
            }
        }
    }

    /**
     * Hide advisor
     */
    function hideAdvisor() {
        var advisor = document.getElementById('tutorial-advisor');
        if (advisor) {
            advisor.classList.remove('visible');
            advisor.classList.add('hidden');
        }
        clearHighlights();
    }

    /**
     * Clear all tutorial highlights
     */
    function clearHighlights() {
        var highlighted = document.querySelectorAll('.tutorial-highlight');
        highlighted.forEach(function(el) {
            el.classList.remove('tutorial-highlight');
        });
    }

    /**
     * Skip tutorial (for experienced players)
     */
    function skipTutorial() {
        HP.State.completeTutorial();
        hideAdvisor();
        HP.Notifications.info('Tutorial skipped');
    }

    /**
     * Reset tutorial (for testing)
     */
    function resetTutorial() {
        currentStep = 0;
        hintsShown = {};
        HP.State.setTutorialStep(0);
        HP.State.tutorialCompleted = false;
        init();
    }

    return {
        init: init,
        isActive: isActive,
        checkProgress: checkProgress,
        checkLevelHint: checkLevelHint,
        showAdvisorMessage: showAdvisorMessage,
        hideAdvisor: hideAdvisor,
        skipTutorial: skipTutorial,
        resetTutorial: resetTutorial
    };
})();
