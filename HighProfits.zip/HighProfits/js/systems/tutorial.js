/**
 * HighProfits - Tutorial & Onboarding System
 * Guides new players through their first 5 minutes
 */
var HP = HP || {};

HP.Tutorial = (function() {
    'use strict';

    // Tutorial steps for first-time players (Rais – slang-heavy, varied)
    var tutorialSteps = [
        {
            id: 0,
            title: 'Wagwan, my guy! 🌿',
            message: 'Yo, wagwan! Rais, dat’s me – man’s gonna show you how we run tings round here, trust. First up you need seeds, blud. Can’t grow nuttin without dem, simple.',
            actionHint: '👉 Link up with the Seed Dealer (🌱) in the menu and cop some seeds, yeah?',
            action: 'buy_seeds',
            highlight: 'dealer',
            requirement: function() {
                var inv = HP.State.getInventory();
                return inv.seeds && Object.keys(inv.seeds).length > 0;
            }
        },
        {
            id: 1,
            title: 'Set up your plot, g 🌱',
            message: 'Safe, you got the seeds – big. Before you can plant you need to set the yard up still. Every plot needs a pot, soil, and a grow light. Cop dat from Hardware (🔧), add it to a plot in Grow, then bang your seed in there, dun know.',
            actionHint: '👉 Go Hardware (🔧), buy a pot, soil and a light. Then Grow (🌿), click a plot, equip them, then "Plant" and pick your seed!',
            action: 'setup_plot_then_plant',
            highlight: 'grow',
            requirement: function() {
                var properties = HP.State.getProperties();
                for (var i = 0; i < properties.owned.length; i++) {
                    var plots = properties.owned[i].plots || [];
                    for (var j = 0; j < plots.length; j++) {
                        if (plots[j].status === 'growing') return true;
                    }
                }
                return false;
            }
        },
        {
            id: 2,
            title: 'Water dem crops, blud 💧',
            message: 'Aight listen – plants need water still, no cap. That water meter at the top? Dat’s your reservoir, it refills from the tap over time. If you don’t keep your crops hydrated they can get dry and die, peak dat. Use your watering can on the plant – reservoir goes down when you water so keep an eye and refill when it’s low, yeah?',
            actionHint: '👉 Click your plant, then hit "Water" to sort it, innit.',
            action: 'water_plant',
            highlight: 'water-reservoir-display',
            requirement: function() {
                var stats = HP.State.getStats();
                return stats.plantsWatered > 0;
            }
        },
        {
            id: 3,
            title: 'Just wait it out ⏱️',
            message: 'Now we chill, my guy. The ting’s growing – just keep it watered and watch for when it says "Ready". Patience is key round here, trust me.',
            actionHint: '👉 Wait for your plant to finish, or use Skip Time if you’re moving impatient.',
            action: 'wait_harvest',
            highlight: null,
            requirement: function() {
                var properties = HP.State.getProperties();
                for (var i = 0; i < properties.owned.length; i++) {
                    var plots = properties.owned[i].plots || [];
                    for (var j = 0; j < plots.length; j++) {
                        if (plots[j].status === 'harvest') return true;
                    }
                }
                return false;
            }
        },
        {
            id: 4,
            title: 'Harvest time – leng! ✂️',
            message: 'YOOO the ting’s ready, bruv! Bare peng plant right there. Time to collect your food – quality depends on how you looked after it, still.',
            actionHint: '👉 Click the ready plant and bang "Harvest" to get your product!',
            action: 'harvest',
            highlight: 'grow',
            requirement: function() {
                var inv = HP.State.getInventory();
                return inv.weed && Object.keys(inv.weed).length > 0;
            }
        },
        {
            id: 5,
            title: 'Time to get your bread 💰',
            message: 'Aight now we’re talking! You got product – time to make some Ps, init. Different mans pay different prices so choose your buyer wisely, yeah?',
            actionHint: '👉 Go Market (💰), pick a customer, select your bits and click "Sell"!',
            action: 'sell',
            highlight: 'market',
            requirement: function() {
                var stats = HP.State.getStats();
                return stats.totalSales > 0;
            }
        },
        {
            id: 6,
            title: 'You’re patterned, fam! 🎉',
            message: 'Madting! You’ve got the basics down, blud. Now go build your empire – cop better seeds, upgrade your yard, keep the feds off your back, and breed some mad genetics. Man’s always watching; I’ll link you with tips when you level up. Stay dangerous out there, yeah?',
            actionHint: null,
            action: 'complete',
            highlight: null,
            requirement: function() { return true; }
        }
    ];

    // Level-based hints (Rais – slang variation)
    var levelHints = {
        2: {
            title: 'Rais: Equipment unlocked, g! 🔧',
            message: 'Yo my guy, sick progress! You can cop equipment from Hardware now – grow lights, fertilizers, all dat. Trust me blud, they’re bare worth it for the yields, innit.'
        },
        3: {
            title: 'Rais: Watch the heat, blud! 🔥',
            message: 'Oi listen – you’re starting to look bait now, still. See that heat meter? Feds are watching. Cop some security tings to stay lowkey. Use Reduce heat to bribe or lay low – don’t let it fill up or it’s peak, yeah?'
        },
        4: {
            title: 'Rais: Water works, fam 💧',
            message: 'Yo that reservoir running low? Check Hardware – you can buy water upgrades to hold more. Bigger tank = less refilling, more time for your crops. Trust.'
        },
        5: {
            title: 'Rais: Market orders, fam 📋',
            message: 'Wagwan! Got some contacts looking for specific bits – check the Orders panel in Market. Bare bonus Ps if you got the right food. Easy bread, dun know.'
        },
        6: {
            title: 'Rais: Cash vs bank – laundry time 🧺',
            message: 'Street sales give cash. Legit stores need bank. Hit Inventory – Money Management – launder cash into bank (lose a bit in fees) or withdraw bank to cash. Own businesses at Real Estate to reduce fees. Keep both sides sorted, yeah?'
        },
        7: {
            title: 'Rais: Expand your ends! 🏠',
            message: 'You’re moving mad now, outgrowing this yard! Check Real Estate for new spots. More plots = more product, more Ps. Think bigger, my guy.'
        },
        10: {
            title: 'Rais: Get your mandem in! 👷',
            message: 'Oi you’re looking tired still! Hire some mandem from the Workers tab – they’ll water and harvest on auto. Sit back, count your paper, easy life, yeah?'
        },
        12: {
            title: 'Rais: Premium tings unlocked! 🌿',
            message: 'BRUV – the peng stuff is unlocked now! Premium strains take longer but the quality is mad. Check Seed Dealer – dat’s where the real bread’s at, trust.'
        },
        15: {
            title: 'Rais: Breeding lab’s open! 🧬',
            message: 'Aight now we’re talking proper business! Cross-breed your strains and make custom hybrids – some even mutate with special bonuses, madting. Get experimenting, blud!'
        },
        20: {
            title: 'Rais: You’re a don now! 👑',
            message: 'LOOK AT YOU! Proper kingpin energy – focus on breeding elite genetics, run your empire, chase them achievements. Man always knew you had it. Stay blessed out there, yeah?'
        }
    };

    var currentStep = 0;
    var hintsShown = {};

    /**
     * Initialize tutorial system
     */
    function init() {
        currentStep = HP.State.getTutorialStep();
        
        // Show tutorial if not completed
        if (!HP.State.isTutorialCompleted()) {
            showTutorialStep(currentStep);
        }
    }

    /**
     * Check if tutorial is active
     */
    function isActive() {
        return !HP.State.isTutorialCompleted();
    }

    /**
     * Show current tutorial step
     */
    function showTutorialStep(stepIndex) {
        if (stepIndex >= tutorialSteps.length) {
            completeTutorial();
            return;
        }

        var step = tutorialSteps[stepIndex];
        if (!step) return;

        // Show advisor message with action hint
        showAdvisorMessage(step.title, step.message, step.highlight, null, step.actionHint);
    }

    /**
     * Check if current step is complete and advance
     */
    function checkProgress() {
        if (HP.State.isTutorialCompleted()) return;

        var step = tutorialSteps[currentStep];
        if (!step) return;

        // Check if requirement is met
        if (step.requirement && step.requirement()) {
            advanceStep();
        }
    }

    /**
     * Advance to next tutorial step
     */
    function advanceStep() {
        currentStep++;
        HP.State.setTutorialStep(currentStep);
        if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();

        if (currentStep >= tutorialSteps.length) {
            completeTutorial();
        } else {
            // Small delay before showing next step
            setTimeout(function() {
                showTutorialStep(currentStep);
            }, 1000);
        }
    }

    /**
     * Complete tutorial
     */
    function completeTutorial() {
        HP.State.completeTutorial();
        if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
        showAdvisorMessage(
            '🎉 You\'re patterned, blud!',
            'Yo that\'s what I\'m talking about! You\'re ready to run tings now – keep the heat low, upgrade your yard, and experiment with breeding some mad genetics. Man\'s always watching; I\'ll link you when you level up. Stay dangerous out there, yeah? Bless.',
            null
        );
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            hideAdvisor();
        }, 5000);
    }

    /**
     * Check and show level-based hints
     */
    function checkLevelHint(level) {
        if (localStorage.getItem('highprofits_tutorial_hints') === 'false') return;
        if (hintsShown[level]) return;

        var hint = levelHints[level];
        if (hint) {
            hintsShown[level] = true;
            showAdvisorMessage(hint.title, hint.message, null, 'hint');
            
            // Auto-hide hints after 8 seconds
            setTimeout(function() {
                hideAdvisor();
            }, 8000);
        }
    }

    /**
     * Show advisor message
     */
    function showAdvisorMessage(title, message, highlightElement, type, actionHint) {
        var advisor = document.getElementById('tutorial-advisor');
        if (!advisor) return;

        var titleEl = advisor.querySelector('.advisor-title');
        var messageEl = advisor.querySelector('.advisor-message');
        var actionEl = document.getElementById('advisor-action');
        var dismissBtn = advisor.querySelector('.advisor-dismiss');
        var gotItBtn = document.getElementById('advisor-gotit');
        var skipBtn = document.getElementById('advisor-skip');

        if (titleEl) titleEl.textContent = title;
        if (messageEl) messageEl.textContent = message;

        // Show action hint if provided
        if (actionEl) {
            if (actionHint) {
                actionEl.textContent = actionHint;
                actionEl.classList.add('visible');
            } else {
                actionEl.textContent = '';
                actionEl.classList.remove('visible');
            }
        }

        // Show advisor
        advisor.classList.remove('hidden');
        advisor.classList.add('visible');

        // Add type class
        advisor.className = 'tutorial-advisor visible';
        if (type) advisor.classList.add('advisor-' + type);

        // Highlight element if specified
        clearHighlights();
        if (highlightElement) {
            var el = document.getElementById(highlightElement);
            if (!el) el = document.querySelector('[data-view="' + highlightElement + '"]');
            if (el) {
                el.classList.add('tutorial-highlight');
            }
        }

        // Bind dismiss button (X)
        if (dismissBtn) {
            dismissBtn.onclick = function() {
                hideAdvisor();
            };
        }

        // Bind "Got it!" button - acknowledges message, hides advisor but keeps tutorial active
        if (gotItBtn) {
            if (!HP.State.isTutorialCompleted() || type === 'hint') {
                gotItBtn.style.display = 'inline-block';
                gotItBtn.onclick = function() {
                    hideAdvisor();
                    // Tutorial continues checking progress in background
                };
            } else {
                gotItBtn.style.display = 'none';
            }
        }

        // Bind skip button
        if (skipBtn) {
            if (!HP.State.isTutorialCompleted()) {
                skipBtn.style.display = 'inline-block';
                skipBtn.onclick = function() {
                    skipTutorial();
                };
            } else {
                skipBtn.style.display = 'none';
            }
        }
    }

    /**
     * Hide advisor
     */
    function hideAdvisor() {
        var advisor = document.getElementById('tutorial-advisor');
        if (advisor) {
            advisor.classList.remove('visible');
            advisor.classList.add('hidden');
        }
        clearHighlights();
    }

    /**
     * Clear all tutorial highlights
     */
    function clearHighlights() {
        var highlighted = document.querySelectorAll('.tutorial-highlight');
        highlighted.forEach(function(el) {
            el.classList.remove('tutorial-highlight');
        });
    }

    /**
     * Skip tutorial (for experienced players)
     */
    function skipTutorial() {
        HP.State.completeTutorial();
        if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
        hideAdvisor();
        HP.Notifications.info('Tutorial skipped');
    }

    /**
     * Reset tutorial (for testing)
     */
    function resetTutorial() {
        currentStep = 0;
        hintsShown = {};
        HP.State.setTutorialStep(0);
        HP.State.tutorialCompleted = false;
        init();
    }

    return {
        init: init,
        isActive: isActive,
        checkProgress: checkProgress,
        checkLevelHint: checkLevelHint,
        showAdvisorMessage: showAdvisorMessage,
        hideAdvisor: hideAdvisor,
        skipTutorial: skipTutorial,
        resetTutorial: resetTutorial
    };
})();
