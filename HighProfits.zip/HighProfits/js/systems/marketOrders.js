/**
 * HighProfits - Market Orders System
 * Generates and manages buyer orders with bonus pricing
 */
var HP = HP || {};

HP.MarketOrders = (function() {
    'use strict';

    var activeOrders = {};  // customerId: order object
    var orderCooldown = 300000; // 5 minutes between new orders

    /**
     * Generate a new order for a customer
     * @param {string} customerId - Customer ID
     * @returns {Object} Order object
     */
    function generateOrder(customerId) {
        var customer = HP.Data.Customers.get(customerId);
        if (!customer) return null;

        // Determine order quality (better distribution across preferred qualities)
        var quality = customer.preferredQuality[0];
        var rand = Math.random();
        
        if (customer.preferredQuality.length > 1) {
            if (rand < 0.45) {
                quality = customer.preferredQuality[0];
            } else if (rand < 0.85 && customer.preferredQuality.length > 1) {
                quality = customer.preferredQuality[1];
            } else if (customer.preferredQuality.length > 2) {
                quality = customer.preferredQuality[2];
            }
        }

        // Determine order amount (within customer's range)
        var range = customer.maxAmount - customer.minAmount;
        var amount = customer.minAmount + Math.floor(Math.random() * (range + 1));
        
        // Round to nice numbers
        if (amount > 10) {
            amount = Math.floor(amount / 5) * 5; // Round to nearest 5
        }

        // Calculate bonus multiplier for fulfilling order exactly
        var basePrice = HP.Data.Customers.calculatePrice(customerId, quality, amount);
        
        // Quality-based bonus scaling (low quality orders give better % bonus)
        var bonusMultiplier = 1.20; // Base 20% bonus
        if (quality === 'low') bonusMultiplier = 1.30;      // 30% bonus for low
        if (quality === 'medium') bonusMultiplier = 1.25;   // 25% bonus for medium
        if (quality === 'good') bonusMultiplier = 1.20;     // 20% bonus for good
        if (quality === 'premium') bonusMultiplier = 1.15;  // 15% bonus for premium
        
        // Apply event modifier (bulk order rush)
        if (HP.Events && HP.Events.Manager) {
            var eventOrderMult = HP.Events.Manager.getModifier('orderBonus');
            bonusMultiplier *= eventOrderMult;
        }

        return {
            customerId: customerId,
            quality: quality,
            amount: amount,
            basePrice: basePrice.total,
            bonusPrice: Math.floor(basePrice.total * bonusMultiplier),
            expiresAt: Date.now() + (orderCooldown * 2), // Order lasts 10 minutes
            createdAt: Date.now()
        };
    }

    /**
     * Get active order for a customer (or generate new one)
     * @param {string} customerId - Customer ID
     * @returns {Object} Order object or null
     */
    function getOrder(customerId) {
        var order = activeOrders[customerId];
        
        // Check if order exists and is still valid
        if (order && order.expiresAt > Date.now()) {
            return order;
        }

        // Check cooldown before generating new order
        if (order && (Date.now() - order.createdAt) < orderCooldown) {
            return null; // Still on cooldown
        }

        // Generate new order
        var newOrder = generateOrder(customerId);
        if (newOrder) {
            activeOrders[customerId] = newOrder;
        }
        return newOrder;
    }

    /**
     * Get all active orders
     * @returns {Object} All active orders
     */
    function getAllOrders() {
        var valid = {};
        var now = Date.now();
        
        for (var customerId in activeOrders) {
            var order = activeOrders[customerId];
            if (order.expiresAt > now) {
                valid[customerId] = order;
            }
        }
        
        activeOrders = valid; // Clean up expired
        return valid;
    }

    /**
     * Check if an order matches a sale
     * @param {string} customerId - Customer ID
     * @param {string} quality - Quality sold
     * @param {number} amount - Amount sold
     * @returns {boolean} True if order matches
     */
    function matchesOrder(customerId, quality, amount) {
        var order = activeOrders[customerId];
        if (!order || order.expiresAt <= Date.now()) return false;
        
        return order.quality === quality && order.amount === amount;
    }

    /**
     * Get order bonus price if order matches
     * @param {string} customerId - Customer ID
     * @param {string} quality - Quality sold
     * @param {number} amount - Amount sold
     * @returns {number} Bonus price or 0
     */
    function getOrderBonus(customerId, quality, amount) {
        if (matchesOrder(customerId, quality, amount)) {
            var order = activeOrders[customerId];
            return order.bonusPrice - order.basePrice; // Extra money from bonus
        }
        return 0;
    }

    /**
     * Fulfill an order (remove it after sale)
     * @param {string} customerId - Customer ID
     */
    function fulfillOrder(customerId) {
        delete activeOrders[customerId];
    }

    /**
     * Initialize orders for all unlocked customers
     */
    function initialize() {
        var playerLevel = HP.State.getLevel();
        var customers = HP.Data.Customers.getUnlocked(playerLevel);
        
        // Generate initial orders for some customers
        for (var i = 0; i < customers.length; i++) {
            if (Math.random() < 0.4) { // 40% chance to have an order
                getOrder(customers[i].id);
            }
        }
    }

    return {
        getOrder: getOrder,
        getAllOrders: getAllOrders,
        matchesOrder: matchesOrder,
        getOrderBonus: getOrderBonus,
        fulfillOrder: fulfillOrder,
        initialize: initialize
    };
})();
