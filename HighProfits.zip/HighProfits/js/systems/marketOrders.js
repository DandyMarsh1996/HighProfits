/**
 * HighProfits - Market Orders System
 * Generates and manages buyer orders with bonus pricing
 */
var HP = HP || {};

HP.MarketOrders = (function() {
    'use strict';

    var activeOrders = {};  // customerId: order object
    var orderCooldown = 300000; // 5 minutes between new orders

    /**
     * Get seed IDs that match a quality tier (for order generation)
     */
    function getSeedIdsByQuality(quality) {
        var seeds = HP.Data.Seeds && HP.Data.Seeds.getAll ? HP.Data.Seeds.getAll() : {};
        var ids = [];
        for (var id in seeds) {
            if (seeds[id].quality === quality) ids.push(id);
        }
        return ids;
    }

    /**
     * Generate a new order for a customer (strain-specific)
     * @param {string} customerId - Customer ID
     * @returns {Object} Order object { customerId, seedId, amount, basePrice, bonusPrice, expiresAt, createdAt }
     */
    function generateOrder(customerId) {
        var customer = HP.Data.Customers.get(customerId);
        if (!customer) return null;

        // Pick preferred quality (same distribution as before)
        var quality = customer.preferredQuality[0];
        var rand = Math.random();
        if (customer.preferredQuality.length > 1) {
            if (rand < 0.45) quality = customer.preferredQuality[0];
            else if (rand < 0.85) quality = customer.preferredQuality[1];
            else if (customer.preferredQuality.length > 2) quality = customer.preferredQuality[2];
        }

        var seedIds = getSeedIdsByQuality(quality);
        if (seedIds.length === 0) return null;
        var seedId = seedIds[Math.floor(Math.random() * seedIds.length)];

        var range = customer.maxAmount - customer.minAmount;
        var amount = customer.minAmount + Math.floor(Math.random() * (range + 1));
        if (amount > 10) amount = Math.floor(amount / 5) * 5;

        var basePrice = HP.Data.Customers.calculatePrice(customerId, seedId, amount);
        if (!basePrice) return null;

        var bonusMultiplier = 1.20;
        if (quality === 'low') bonusMultiplier = 1.30;
        if (quality === 'medium') bonusMultiplier = 1.25;
        if (quality === 'good') bonusMultiplier = 1.20;
        if (quality === 'premium') bonusMultiplier = 1.15;
        if (HP.Events && HP.Events.Manager) {
            var eventOrderMult = HP.Events.Manager.getModifier('orderBonus');
            bonusMultiplier *= eventOrderMult;
        }

        return {
            customerId: customerId,
            seedId: seedId,
            amount: amount,
            basePrice: basePrice.total,
            bonusPrice: Math.floor(basePrice.total * bonusMultiplier),
            expiresAt: Date.now() + (orderCooldown * 2),
            createdAt: Date.now()
        };
    }

    /**
     * Get active order for a customer (or generate new one)
     * @param {string} customerId - Customer ID
     * @returns {Object} Order object or null
     */
    function getOrder(customerId) {
        var order = activeOrders[customerId];
        
        // Check if order exists and is still valid
        if (order && order.expiresAt > Date.now()) {
            return order;
        }

        // Check cooldown before generating new order
        if (order && (Date.now() - order.createdAt) < orderCooldown) {
            return null; // Still on cooldown
        }

        // Generate new order
        var newOrder = generateOrder(customerId);
        if (newOrder) {
            activeOrders[customerId] = newOrder;
        }
        return newOrder;
    }

    /**
     * Get all active orders
     * @returns {Object} All active orders
     */
    function getAllOrders() {
        var valid = {};
        var now = Date.now();
        
        for (var customerId in activeOrders) {
            var order = activeOrders[customerId];
            if (order.expiresAt > now) {
                valid[customerId] = order;
            }
        }
        
        activeOrders = valid; // Clean up expired
        return valid;
    }

    /**
     * Check if an order matches a sale (by strain and amount)
     */
    function matchesOrder(customerId, seedId, amount) {
        var order = activeOrders[customerId];
        if (!order || order.expiresAt <= Date.now()) return false;
        return order.seedId === seedId && order.amount === amount;
    }

    /**
     * Get order bonus price if order matches
     */
    function getOrderBonus(customerId, seedId, amount) {
        if (matchesOrder(customerId, seedId, amount)) {
            var order = activeOrders[customerId];
            return order.bonusPrice - order.basePrice;
        }
        return 0;
    }

    /**
     * Fulfill an order (remove it after sale)
     * @param {string} customerId - Customer ID
     */
    function fulfillOrder(customerId) {
        delete activeOrders[customerId];
    }

    /**
     * Initialize orders for all unlocked customers
     */
    function initialize() {
        var playerLevel = HP.State.getLevel();
        var customers = HP.Data.Customers.getUnlocked(playerLevel);
        
        // Generate initial orders for some customers
        for (var i = 0; i < customers.length; i++) {
            if (Math.random() < 0.4) { // 40% chance to have an order
                getOrder(customers[i].id);
            }
        }
    }

    return {
        getOrder: getOrder,
        getAllOrders: getAllOrders,
        matchesOrder: matchesOrder,
        getOrderBonus: getOrderBonus,
        fulfillOrder: fulfillOrder,
        initialize: initialize
    };
})();
