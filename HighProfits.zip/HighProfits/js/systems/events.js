/**
 * HighProfits - Events System
 * Manages temporary gameplay events triggered by news headlines or random occurrences
 */
var HP = HP || {};

HP.Events = HP.Events || {};

HP.Events.Manager = (function() {
    'use strict';

    var activeEvent = null; // Currently active event (only one at a time)

    // Event definitions with modifiers
    var eventDefinitions = {
        buyer_frenzy: {
            id: 'buyer_frenzy',
            name: 'Buyer Frenzy',
            description: 'Buyers are desperate! Sale prices increased.',
            icon: '💸',
            duration: 120, // seconds
            modifiers: {
                salePrice: 1.20 // +20% sale price
            }
        },
        heat_wave: {
            id: 'heat_wave',
            name: 'Heat Wave',
            description: 'Unusual activity noticed. Heat builds faster.',
            icon: '🔥',
            duration: 120,
            modifiers: {
                heatGain: 1.5 // +50% heat gain
            }
        },
        supply_shortage: {
            id: 'supply_shortage',
            name: 'Supply Shortage',
            description: 'Equipment prices surge due to shortages.',
            icon: '📦',
            duration: 180,
            modifiers: {
                equipmentCost: 1.30 // +30% equipment cost
            }
        },
        inspection_day: {
            id: 'inspection_day',
            name: 'Inspection Day',
            description: 'Authorities are doing rounds. Heat builds rapidly!',
            icon: '🚨',
            duration: 90,
            modifiers: {
                heatGain: 2.0 // Double heat gain
            }
        },
        perfect_weather: {
            id: 'perfect_weather',
            name: 'Perfect Weather',
            description: 'Ideal growing conditions. Plants grow faster.',
            icon: '☀️',
            duration: 150,
            modifiers: {
                growthSpeed: 1.15 // +15% growth speed
            }
        },
        market_crash: {
            id: 'market_crash',
            name: 'Market Crash',
            description: 'Buyers are cautious. Prices drop temporarily.',
            icon: '📉',
            duration: 120,
            modifiers: {
                salePrice: 0.85 // -15% sale price
            }
        },
        bulk_order: {
            id: 'bulk_order',
            name: 'Bulk Order Rush',
            description: 'Market orders pay extra bonuses.',
            icon: '📋',
            duration: 180,
            modifiers: {
                orderBonus: 1.5 // 50% more bonus from orders (on top of base)
            }
        },
        quality_demand: {
            id: 'quality_demand',
            name: 'Quality Demand',
            description: 'Premium product fetches top dollar.',
            icon: '💎',
            duration: 150,
            modifiers: {
                premiumBonus: 1.25 // +25% for premium quality sales
            }
        }
    };

    /**
     * Start an event
     * @param {string} eventId - Event ID from definitions
     * @returns {boolean} True if started
     */
    function startEvent(eventId) {
        var def = eventDefinitions[eventId];
        if (!def) return false;
        if (activeEvent) return false; // Only one event at a time

        activeEvent = {
            id: eventId,
            definition: def,
            startTime: Date.now(),
            endTime: Date.now() + (def.duration * 1000)
        };

        if (HP.Notifications) {
            HP.Notifications.info('📰 Event: ' + def.name + ' — ' + def.description + ' (' + def.duration + 's)');
        }

        console.log('[Events] Started:', def.name);
        return true;
    }

    /**
     * Check if an event is active and update/end it
     * Called each game tick
     * @param {number} deltaTime - Time since last tick in seconds
     */
    function tick(deltaTime) {
        if (!activeEvent) return;

        var now = Date.now();
        if (now >= activeEvent.endTime) {
            endEvent();
        }
    }

    /**
     * End the active event
     */
    function endEvent() {
        if (!activeEvent) return;

        if (HP.Notifications) {
            HP.Notifications.info('Event ended: ' + activeEvent.definition.name);
        }

        console.log('[Events] Ended:', activeEvent.definition.name);
        activeEvent = null;
    }

    /**
     * Get the active event (or null)
     * @returns {Object|null} Active event
     */
    function getActiveEvent() {
        return activeEvent;
    }

    /**
     * Get modifier value for a stat type (1.0 = no modifier)
     * @param {string} modifierType - 'salePrice', 'heatGain', 'equipmentCost', etc.
     * @returns {number} Multiplier
     */
    function getModifier(modifierType) {
        if (!activeEvent || !activeEvent.definition || !activeEvent.definition.modifiers) return 1.0;
        return activeEvent.definition.modifiers[modifierType] || 1.0;
    }

    /**
     * Check if a specific event is active
     * @param {string} eventId - Event ID
     * @returns {boolean} True if active
     */
    function isEventActive(eventId) {
        return activeEvent && activeEvent.id === eventId;
    }

    /**
     * Get time remaining for active event (seconds)
     * @returns {number} Seconds remaining, or 0 if no event
     */
    function getTimeRemaining() {
        if (!activeEvent) return 0;
        var now = Date.now();
        return Math.max(0, Math.floor((activeEvent.endTime - now) / 1000));
    }

    return {
        startEvent: startEvent,
        tick: tick,
        endEvent: endEvent,
        getActiveEvent: getActiveEvent,
        getModifier: getModifier,
        isEventActive: isEventActive,
        getTimeRemaining: getTimeRemaining
    };
})();
