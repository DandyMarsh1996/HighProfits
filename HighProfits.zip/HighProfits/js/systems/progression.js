/**
 * HighProfits - Progression System
 * Handles leveling, rank bonuses, and XP calculations
 * Note: Drug unlocks removed - focusing on weed only for now
 */
var HP = HP || {};

HP.Progression = (function() {
    'use strict';

    /**
     * Check if a drug is unlocked at a given player level
     * Currently always returns true for weed
     * @param {string} drugId - Drug identifier
     * @param {number} playerLevel - Player's current level
     * @returns {boolean} True if unlocked
     */
    function isDrugUnlocked(drugId, playerLevel) {
        // For now, only weed exists and it's always unlocked
        return drugId === 'weed';
    }

    /**
     * Get all drugs unlocked at a given level
     * @param {number} playerLevel - Player's current level
     * @returns {Array} Array of drug IDs
     */
    function getUnlockedDrugs(playerLevel) {
        // Currently only weed
        return ['weed'];
    }

    /**
     * Get the next drug to unlock
     * @param {number} playerLevel - Player's current level
     * @returns {Object|null} Next drug or null if all unlocked
     */
    function getNextDrugToUnlock(playerLevel) {
        // No more drugs to unlock currently
        return null;
    }

    /**
     * Check which drugs would be unlocked by leveling up
     * @param {number} oldLevel - Previous level
     * @param {number} newLevel - New level
     * @returns {Array} Array of newly unlocked drug objects
     */
    function getNewlyUnlockedDrugs(oldLevel, newLevel) {
        // No drug unlocks currently
        return [];
    }

    /**
     * Calculate XP progress towards next level
     * @param {number} currentXP - Current XP total
     * @param {number} currentLevel - Current level
     * @returns {Object} Progress info {current, required, percentage}
     */
    function getXPProgress(currentXP, currentLevel) {
        var currentRank = HP.Data.Ranks.getByLevel(currentLevel);
        var nextRank = HP.Data.Ranks.getNext(currentLevel);
        
        if (!nextRank) {
            // Max level
            return {
                current: currentXP,
                required: currentXP,
                percentage: 100,
                isMaxLevel: true
            };
        }
        
        var xpForCurrent = currentRank.xpRequired;
        var xpForNext = nextRank.xpRequired;
        var xpProgress = currentXP - xpForCurrent;
        var xpNeeded = xpForNext - xpForCurrent;
        
        return {
            current: xpProgress,
            required: xpNeeded,
            percentage: (xpProgress / xpNeeded) * 100,
            isMaxLevel: false
        };
    }

    /**
     * Get bonus multiplier for a stat based on player level
     * @param {string} statType - Type of stat ('production', 'price', 'storage', 'heat')
     * @param {number} playerLevel - Player's level
     * @returns {number} Multiplier (1.0 = no bonus)
     */
    function getLevelBonus(statType, playerLevel) {
        var multiplier = 1.0;
        
        // Updated for 25-level progression:
        // - Early bonuses arrive gradually
        // - Late-game provides meaningful scaling without trivializing early progression
        if (statType === 'production') {
            if (playerLevel >= 5) multiplier *= 1.1;
            if (playerLevel >= 12) multiplier *= 1.15;
            if (playerLevel >= 20) multiplier *= 1.2;
            if (playerLevel >= 24) multiplier *= 1.15;
        }

        if (statType === 'price') {
            if (playerLevel >= 10) multiplier *= 1.1;
            if (playerLevel >= 15) multiplier *= 1.15;
            if (playerLevel >= 21) multiplier *= 1.15;
            if (playerLevel >= 24) multiplier *= 1.1;  // Late-game sale price boost
        }

        if (statType === 'storage') {
            if (playerLevel >= 15) multiplier *= 1.25;
            if (playerLevel >= 20) multiplier *= 1.25;
        }

        if (statType === 'heat') {
            if (playerLevel >= 12) multiplier *= 0.9;
            if (playerLevel >= 17) multiplier *= 0.85;
            if (playerLevel >= 23) multiplier *= 0.75;
        }
        
        return multiplier;
    }

    // ===========================
    // XP CALCULATIONS (SCALING)
    // ===========================

    function getQualityXPMultiplier(quality) {
        switch (quality) {
            case 'low': return 0.8;
            case 'medium': return 1.0;
            case 'good': return 1.3;
            case 'premium': return 1.6;
            default: return 1.0;
        }
    }

    /**
     * XP for a harvest scales with yield + quality, plus a small seed tier bonus.
     * @param {Object} plot - Plot object (may include plant.seedId)
     * @param {Object} harvestResult - {yield, quality}
     */
    function calculateXPForHarvest(plot, harvestResult) {
        if (!harvestResult) return 0;
        var grams = harvestResult.yield || 0;
        var quality = harvestResult.quality || 'medium';

        var seedTierBonus = 0;
        if (plot && plot.plant && plot.plant.seedId && HP.Data && HP.Data.Seeds) {
            var seed = HP.Data.Seeds.get(plot.plant.seedId);
            if (seed && seed.cost) {
                seedTierBonus = Math.floor(seed.cost / 25); // high-end genetics give a bit more XP
            }
        }

        var xp = Math.floor(grams * 3 * getQualityXPMultiplier(quality)) + seedTierBonus;
        return Math.max(1, xp);
    }

    /**
     * XP for sales scales primarily with money earned (operation size) and quality.
     */
    function calculateXPForSale(totalEarned, quality, amount, hasOrder) {
        var earned = totalEarned || 0;
        var q = quality || 'medium';
        var grams = amount || 0;

        // Main scaling: money earned -> XP (non-explosive)
        // Uses a sqrt curve so big sales matter, but don't skip huge chunks of the level curve.
        // $100 ≈ 20 XP, $10,000 ≈ 200 XP, $1,000,000 ≈ 2,000 XP
        var base = Math.floor(Math.sqrt(Math.max(0, earned)) * 2);

        // Slight gram-based contribution so very discounted bulk still progresses
        var gramBonus = Math.floor(grams * 0.5);

        var xp = Math.floor((base + gramBonus) * getQualityXPMultiplier(q));
        if (hasOrder) {
            xp += Math.floor(xp * 0.1); // 10% bonus for fulfilling an order
        }
        return Math.max(1, xp);
    }

    /**
     * XP for a plant becoming ready (passive) scales with seed tier.
     */
    function calculateXPForPlantReady(plot) {
        var seedTier = 0;
        if (plot && plot.plant && plot.plant.seedId && HP.Data && HP.Data.Seeds) {
            var seed = HP.Data.Seeds.get(plot.plant.seedId);
            if (seed && seed.cost) seedTier = Math.floor(seed.cost / 50);
        }
        return Math.max(1, 5 + seedTier);
    }

    function calculateXPForPlanting(seedId) {
        var seedTier = 0;
        if (seedId && HP.Data && HP.Data.Seeds) {
            var seed = HP.Data.Seeds.get(seedId);
            if (seed && seed.cost) seedTier = Math.floor(seed.cost / 25);
        }
        return Math.max(1, 2 + seedTier);
    }

    function calculateXPForEquipmentInstall(equipmentId) {
        var tier = 0;
        if (equipmentId && HP.Data && HP.Data.Equipment) {
            var equip = HP.Data.Equipment.get(equipmentId);
            if (equip && equip.cost) tier = Math.floor(equip.cost / 100);
        }
        return Math.max(1, 2 + tier);
    }

    function calculateXPForRoomUpgrade(upgradeId) {
        var tier = 0;
        if (upgradeId && HP.Data && HP.Data.RoomUpgrades) {
            var up = HP.Data.RoomUpgrades.get(upgradeId);
            if (up && up.cost) tier = Math.floor(up.cost / 50);
        }
        return Math.max(5, 10 + tier);
    }

    function calculateXPForPropertyPurchase(propertyId) {
        var tier = 0;
        if (propertyId && HP.Data && HP.Data.Properties) {
            var prop = HP.Data.Properties.get(propertyId);
            if (prop && prop.cost) tier = Math.floor(prop.cost / 100);
        }
        return Math.max(25, 50 + tier);
    }

    /**
     * Check if a feature is unlocked based on level
     * @param {string} feature - Feature name
     * @param {number} playerLevel - Player's level
     * @returns {boolean} True if unlocked
     */
    function isFeatureUnlocked(feature, playerLevel) {
        switch (feature) {
            case 'producers':
                return playerLevel >= 2;
            case 'packers':
                return playerLevel >= 3;
            case 'dealers':
                return playerLevel >= 4;
            default:
                return true;
        }
    }

    /**
     * Get description of next level bonus
     * @param {number} currentLevel - Player's current level
     * @returns {string|null} Description of next bonus
     */
    function getNextLevelBonus(currentLevel) {
        var nextRank = HP.Data.Ranks.getNext(currentLevel);
        if (nextRank && nextRank.bonus) {
            return nextRank.bonus;
        }
        return null;
    }

    // Public API
    return {
        isDrugUnlocked: isDrugUnlocked,
        getUnlockedDrugs: getUnlockedDrugs,
        getNextDrugToUnlock: getNextDrugToUnlock,
        getNewlyUnlockedDrugs: getNewlyUnlockedDrugs,
        getXPProgress: getXPProgress,
        getLevelBonus: getLevelBonus,
        isFeatureUnlocked: isFeatureUnlocked,
        getNextLevelBonus: getNextLevelBonus,

        // XP scaling helpers
        calculateXPForHarvest: calculateXPForHarvest,
        calculateXPForSale: calculateXPForSale,
        calculateXPForPlantReady: calculateXPForPlantReady,
        calculateXPForPlanting: calculateXPForPlanting,
        calculateXPForEquipmentInstall: calculateXPForEquipmentInstall,
        calculateXPForRoomUpgrade: calculateXPForRoomUpgrade,
        calculateXPForPropertyPurchase: calculateXPForPropertyPurchase
    };
})();
