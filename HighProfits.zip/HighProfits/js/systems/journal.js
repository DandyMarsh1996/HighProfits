/**
 * HighProfits - Journal completion checks
 * Call checkAll() after load and after key actions to complete journal entries and unlock titles.
 */
var HP = HP || {};

HP.Journal = (function() {
    'use strict';

    function complete(entryId) {
        if (!HP.State.completeJournalEntry) return;
        var completed = HP.State.completeJournalEntry(entryId);
        if (completed && HP.Notifications) {
            var entry = HP.Data.Journal && HP.Data.Journal.get(entryId);
            if (entry && entry.rewardTitleId) {
                var title = HP.Data.Titles && HP.Data.Titles.get(entry.rewardTitleId);
                if (title) HP.Notifications.success('Journal: ' + entry.name + ' ✓ – Unlocked title: ' + title.name);
                else HP.Notifications.success('Journal: ' + entry.name + ' ✓');
            } else HP.Notifications.success('Journal: ' + (entry ? entry.name : entryId) + ' ✓');
        }
    }

    function checkAll() {
        if (!HP.State || !HP.State.completeJournalEntry || !HP.Data.Journal) return;
        var state = HP.State.getState ? HP.State.getState() : {};
        var inv = state.inventory || {};
        var seeds = inv.seeds || {};
        var equipment = inv.equipment || {};
        var stats = state.stats || {};
        var money = HP.State.getMoney ? HP.State.getMoney() : 0;
        var level = HP.State.getLevel ? HP.State.getLevel() : 1;
        var properties = HP.State.getProperties ? HP.State.getProperties() : { owned: [] };
        var workers = state.growerWorkers && state.growerWorkers.instances ? state.growerWorkers.instances : [];
        var customStrains = state.customStrains || {};
        var seedCount = Object.keys(seeds).length;
        var equipCount = 0;
        for (var k in equipment) { if (equipment[k] && equipment[k] > 0) equipCount++; }
        for (var s in equipment) { if (typeof equipment[s] === 'object' && equipment[s] !== null) equipCount++; }
        var propOwned = (properties.owned || []).length;
        var totalEarned = (stats.totalMoneyEarned || 0);
        var totalSold = (stats.totalSold || 0);
        var plantsGrown = (stats.plantsGrown || 0);
        var totalHarvested = (stats.totalHarvested || 0);

        if (Object.keys(seeds).length > 0 && !HP.State.isJournalEntryComplete('first_seeds')) complete('first_seeds');
        if (equipCount > 0 && !HP.State.isJournalEntryComplete('first_equipment')) complete('first_equipment');
        if (plantsGrown >= 1 && !HP.State.isJournalEntryComplete('first_harvest')) complete('first_harvest');
        if (plantsGrown >= 10 && !HP.State.isJournalEntryComplete('harvest_10')) complete('harvest_10');
        if (plantsGrown >= 50 && !HP.State.isJournalEntryComplete('harvest_50')) complete('harvest_50');
        if (stats.totalSales > 0 && !HP.State.isJournalEntryComplete('first_sale')) complete('first_sale');
        if (totalSold >= 50 && !HP.State.isJournalEntryComplete('sell_50g')) complete('sell_50g');
        if (propOwned >= 2 && !HP.State.isJournalEntryComplete('own_2_properties')) complete('own_2_properties');
        if (propOwned >= 3 && !HP.State.isJournalEntryComplete('own_3_properties')) complete('own_3_properties');
        if (propOwned >= 5 && !HP.State.isJournalEntryComplete('own_5_properties')) complete('own_5_properties');
        if (seedCount >= 5 && !HP.State.isJournalEntryComplete('own_5_seed_types')) complete('own_5_seed_types');
        if (Object.keys(customStrains).length > 0 && !HP.State.isJournalEntryComplete('first_hybrid')) complete('first_hybrid');
        if (totalEarned >= 10000 && !HP.State.isJournalEntryComplete('earn_10000')) complete('earn_10000');
        if (workers.length > 0 && !HP.State.isJournalEntryComplete('first_worker')) complete('first_worker');
        if (level >= 20 && !HP.State.isJournalEntryComplete('level_20')) complete('level_20');

        var equipTypes = 0;
        if (state.inventory && state.inventory.equipment) {
            var eq = state.inventory.equipment;
            for (var key in eq) { if (eq[key]) equipTypes++; }
        }
        if (equipTypes >= 5 && !HP.State.isJournalEntryComplete('five_equipment_types')) complete('five_equipment_types');
        if ((stats.laundersTotal || 0) >= 1 && !HP.State.isJournalEntryComplete('first_launder')) complete('first_launder');
        var waterUpgrades = (state.waterUpgradesOwned || []).length;
        if (waterUpgrades >= 1 && !HP.State.isJournalEntryComplete('first_water_upgrade')) complete('first_water_upgrade');
        if ((stats.heatPayOffsTotal || 0) >= 1 && !HP.State.isJournalEntryComplete('first_heat_payoff')) complete('first_heat_payoff');
    }

    return { checkAll: checkAll, complete: complete };
})();
