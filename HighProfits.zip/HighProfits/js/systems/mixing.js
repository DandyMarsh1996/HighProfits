/**
 * HighProfits - Mixing System
 * Combine two grown strains into a blend that sells for a markup
 */
var HP = HP || {};

HP.Mixing = (function() {
    'use strict';

    var qualities = ['low', 'medium', 'good', 'premium'];

    /** Words for generated blend names (deterministic from blendKey) */
    var MIX_BLEND_WORDS = [
        'Purple', 'Blue', 'Green', 'Golden', 'Black', 'Red', 'Silver', 'Crystal', 'Northern', 'Southern',
        'Royal', 'Grand', 'Super', 'Mega', 'Elite', 'Prime', 'Alpha', 'Omega', 'Secret', 'Hidden',
        'Fire', 'Ice', 'Storm', 'Thunder', 'Cosmic', 'Lunar', 'Stellar', 'Nova', 'Frost', 'Blaze',
        'Shadow', 'Mystic', 'Ghost', 'Phantom', 'Wild', 'Urban', 'Alpine', 'Jungle', 'Desert', 'Ocean',
        'Midnight', 'Twilight', 'Aurora', 'Ember', 'Void', 'Rogue', 'Smooth', 'Heavy', 'Bold', 'Silent',
        'Dank', 'Sticky', 'Kush', 'Haze', 'Diesel', 'Skunk', 'Dream', 'Cherry', 'Berry', 'Gelato',
        'Fusion', 'Crush', 'Blend', 'Mix', 'Mash', 'Meld', 'Merge', 'Cross', 'Hybrid', 'Twist'
    ];

    /**
     * Canonical blend key (sorted seed ids) so A+B and B+A are the same blend
     */
    function blendKey(seedId1, seedId2) {
        if (!seedId1 || !seedId2) return '';
        return [seedId1, seedId2].sort().join('_');
    }

    /** Premium mix: 3-strain blend key (sorted) */
    function blendKey3(seedId1, seedId2, seedId3) {
        if (!seedId1 || !seedId2 || !seedId3) return '';
        return [seedId1, seedId2, seedId3].sort().join('_');
    }

    function isPremiumMixUnlocked() {
        var level = HP.State && HP.State.getLevel ? HP.State.getLevel() : 0;
        var req = HP.Data.Constants && HP.Data.Constants.PREMIUM_MIX_UNLOCK_LEVEL != null ? HP.Data.Constants.PREMIUM_MIX_UNLOCK_LEVEL : 8;
        return level >= req;
    }

    /**
     * Blend quality from two parent strains: best of the two, 15% chance to upgrade one tier
     */
    function getBlendQuality(seedId1, seedId2) {
        var s1 = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedId1) : null;
        var s2 = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedId2) : null;
        if (!s1 || !s2) return 'low';
        var i1 = qualities.indexOf(s1.quality);
        var i2 = qualities.indexOf(s2.quality);
        if (i1 === -1) i1 = 0;
        if (i2 === -1) i2 = 0;
        var best = Math.max(i1, i2);
        if (Math.random() < 0.15 && best < qualities.length - 1) best += 1;
        return qualities[best];
    }

    /** Blend quality from three strains: best of the three, 20% chance to upgrade one tier (premium mix) */
    function getBlendQuality3(seedId1, seedId2, seedId3) {
        var s1 = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedId1) : null;
        var s2 = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedId2) : null;
        var s3 = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedId3) : null;
        if (!s1 || !s2 || !s3) return 'low';
        var i1 = qualities.indexOf(s1.quality);
        var i2 = qualities.indexOf(s2.quality);
        var i3 = qualities.indexOf(s3.quality);
        if (i1 === -1) i1 = 0;
        if (i2 === -1) i2 = 0;
        if (i3 === -1) i3 = 0;
        var best = Math.max(i1, i2, i3);
        if (Math.random() < 0.2 && best < qualities.length - 1) best += 1;
        return qualities[best];
    }

    function getMinGrams() {
        var c = HP.Data.Constants || {};
        return (c.MIX_MIN_GRAMS != null && c.MIX_MIN_GRAMS >= 1) ? c.MIX_MIN_GRAMS : 1;
    }

    /**
     * Can we mix this much of each strain? (1:1 ratio → 2*amount blend)
     */
    function canMix(seedId1, seedId2, amount) {
        if (!seedId1 || !seedId2 || seedId1 === seedId2) return false;
        var minG = getMinGrams();
        if (amount < minG) return false;
        var have1 = HP.State && HP.State.getWeed ? HP.State.getWeed(seedId1) : 0;
        var have2 = HP.State && HP.State.getWeed ? HP.State.getWeed(seedId2) : 0;
        return have1 >= amount && have2 >= amount;
    }

    /**
     * Perform mix: remove amount from each strain, add 2*amount to blend (1:1 input → 2x output)
     */
    function doMix(seedId1, seedId2, amount) {
        if (!canMix(seedId1, seedId2, amount)) return { success: false, error: 'Not enough of one or both strains' };
        var key = blendKey(seedId1, seedId2);
        var quality = getBlendQuality(seedId1, seedId2);
        HP.State.removeWeed(seedId1, amount);
        HP.State.removeWeed(seedId2, amount);
        var outputAmount = amount * 2;
        HP.State.addMixed(key, seedId1, seedId2, outputAmount, quality);
        return { success: true, blendKey: key, amount: outputAmount, quality: quality };
    }

    /** Can we premium-mix this much of each of three strains? (1:1:1 → outputMult*amount) */
    function canMix3(seedId1, seedId2, seedId3, amount) {
        if (!isPremiumMixUnlocked()) return false;
        if (!seedId1 || !seedId2 || !seedId3) return false;
        var uniq = [seedId1, seedId2, seedId3].filter(function(id, i, arr) { return arr.indexOf(id) === i; });
        if (uniq.length !== 3) return false;
        var minG = getMinGrams();
        if (amount < minG) return false;
        var have1 = HP.State && HP.State.getWeed ? HP.State.getWeed(seedId1) : 0;
        var have2 = HP.State && HP.State.getWeed ? HP.State.getWeed(seedId2) : 0;
        var have3 = HP.State && HP.State.getWeed ? HP.State.getWeed(seedId3) : 0;
        return have1 >= amount && have2 >= amount && have3 >= amount;
    }

    /** Premium mix: remove amount from each of three strains, add outputMult*amount to blend */
    function doMix3(seedId1, seedId2, seedId3, amount) {
        if (!canMix3(seedId1, seedId2, seedId3, amount)) return { success: false, error: 'Premium mix unavailable or not enough of one or more strains' };
        var mult = (HP.Data.Constants && HP.Data.Constants.MIX_PREMIUM_OUTPUT_MULT != null) ? HP.Data.Constants.MIX_PREMIUM_OUTPUT_MULT : 3;
        var key = blendKey3(seedId1, seedId2, seedId3);
        var quality = getBlendQuality3(seedId1, seedId2, seedId3);
        HP.State.removeWeed(seedId1, amount);
        HP.State.removeWeed(seedId2, amount);
        HP.State.removeWeed(seedId3, amount);
        var outputAmount = amount * mult;
        HP.State.addMixed(key, seedId1, seedId2, outputAmount, quality, seedId3);
        if (HP.State.incrementStat) HP.State.incrementStat('premiumMixCount', 1);
        return { success: true, blendKey: key, amount: outputAmount, quality: quality };
    }

    /**
     * Generate a deterministic blend display name from blendKey (same blend = same name)
     */
    function generateBlendName(blendKey) {
        var seed = blendKey.split('').reduce(function(acc, c) { return ((acc << 5) - acc) + c.charCodeAt(0); }, 0);
        var len = MIX_BLEND_WORDS.length;
        var i = Math.abs(seed) % len;
        var j = Math.abs(seed * 31 + 17) % len;
        if (i === j) j = (j + 1) % len;
        return MIX_BLEND_WORDS[i] + ' ' + MIX_BLEND_WORDS[j];
    }

    /**
     * List all blends for UI (blendKey, seedId1, seedId2, amount, quality, display name; seedId3 for premium)
     */
    function getBlendsList() {
        var mixed = HP.State && HP.State.getMixed ? HP.State.getMixed() : {};
        var list = [];
        for (var key in mixed) {
            var m = mixed[key];
            if (!m || m.amount <= 0) continue;
            var s1 = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(m.seedId1) : null;
            var s2 = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(m.seedId2) : null;
            var name1 = s1 ? (s1.strainName || s1.name) : m.seedId1;
            var name2 = s2 ? (s2.strainName || s2.name) : m.seedId2;
            var recipeLabel = name1 + ' + ' + name2;
            if (m.seedId3) {
                var s3 = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(m.seedId3) : null;
                var name3 = s3 ? (s3.strainName || s3.name) : m.seedId3;
                recipeLabel += ' + ' + name3;
            }
            var blendName = generateBlendName(key);
            list.push({
                blendKey: key,
                seedId1: m.seedId1,
                seedId2: m.seedId2,
                seedId3: m.seedId3 || null,
                amount: m.amount,
                quality: m.quality || 'medium',
                name: blendName,
                recipeLabel: recipeLabel
            });
        }
        return list;
    }

    return {
        blendKey: blendKey,
        blendKey3: blendKey3,
        getBlendQuality: getBlendQuality,
        getBlendQuality3: getBlendQuality3,
        canMix: canMix,
        canMix3: canMix3,
        doMix: doMix,
        doMix3: doMix3,
        getBlendsList: getBlendsList,
        getMinGrams: getMinGrams,
        isPremiumMixUnlocked: isPremiumMixUnlocked
    };
})();
