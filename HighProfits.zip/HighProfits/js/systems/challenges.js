/**
 * HighProfits - Challenge System
 * Long-term goals and challenges for players
 */
var HP = HP || {};

HP.Challenges = (function() {
    'use strict';

    var CHALLENGE_TYPES = {
        HARVEST_TOTAL: 'harvest_total',
        EARN_TOTAL: 'earn_total',
        GROW_TOTAL: 'grow_total',
        SELL_TOTAL: 'sell_total',
        REACH_LEVEL: 'reach_level',
        OWN_PROPERTIES: 'own_properties',
        ROOM_UPGRADES_TOTAL: 'room_upgrades_total',
        GROWER_WORKERS_TOTAL: 'grower_workers_total',
        OWN_SEEDS_TOTAL: 'own_seeds_total',
        OWN_EQUIPMENT_TOTAL: 'own_equipment_total',
        PLAY_TIME_SECONDS: 'play_time_seconds'
    };

    // Challenge definitions
    var challengeDefinitions = [
        {
            id: 'harvest_100',
            type: CHALLENGE_TYPES.HARVEST_TOTAL,
            name: 'Harvest Master',
            description: 'Harvest 100 plants total',
            icon: '🌿',
            category: 'Harvesting',
            subCategory: 'Milestones',
            target: 100,
            reward: { money: 1000, xp: 100, titleId: 'harvest_master' },
            unlockLevel: 1
        },
        {
            id: 'harvest_500',
            type: CHALLENGE_TYPES.HARVEST_TOTAL,
            name: 'Harvest Expert',
            description: 'Harvest 500 plants total',
            icon: '🌿',
            category: 'Harvesting',
            subCategory: 'Milestones',
            target: 500,
            reward: { money: 5000, xp: 500 },
            unlockLevel: 5
        },
        {
            id: 'earn_10000',
            type: CHALLENGE_TYPES.EARN_TOTAL,
            name: 'Money Maker',
            description: 'Earn $10,000 total',
            icon: '💰',
            category: 'Money',
            subCategory: 'Milestones',
            target: 10000,
            reward: { money: 2000, xp: 200, titleId: 'money_maker' },
            unlockLevel: 3
        },
        {
            id: 'earn_100000',
            type: CHALLENGE_TYPES.EARN_TOTAL,
            name: 'Big Spender',
            description: 'Earn $100,000 total',
            icon: '💸',
            category: 'Money',
            subCategory: 'Milestones',
            target: 100000,
            reward: { money: 20000, xp: 2000 },
            unlockLevel: 7
        },
        {
            id: 'grow_50',
            type: CHALLENGE_TYPES.GROW_TOTAL,
            name: 'Green Thumb',
            description: 'Successfully grow 50 plants',
            icon: '🌱',
            category: 'Harvesting',
            subCategory: 'Milestones',
            target: 50,
            reward: { money: 500, xp: 50 },
            unlockLevel: 2
        },
        {
            id: 'sell_1000',
            type: CHALLENGE_TYPES.SELL_TOTAL,
            name: 'Sales Master',
            description: 'Sell 1,000 grams total',
            icon: '📦',
            category: 'Sales',
            subCategory: 'Milestones',
            target: 1000,
            reward: { money: 1500, xp: 150 },
            unlockLevel: 4
        },
        {
            id: 'level_10',
            type: CHALLENGE_TYPES.REACH_LEVEL,
            name: 'Rising Star',
            description: 'Reach level 10',
            icon: '⭐',
            category: 'Progression',
            subCategory: 'Milestones',
            target: 10,
            reward: { money: 1000, xp: 100 },
            unlockLevel: 1
        },
        {
            id: 'level_20',
            type: CHALLENGE_TYPES.REACH_LEVEL,
            name: 'Veteran',
            description: 'Reach level 20',
            icon: '🌟',
            category: 'Progression',
            subCategory: 'Milestones',
            target: 20,
            reward: { money: 5000, xp: 500, titleId: 'veteran' },
            unlockLevel: 5
        },
        {
            id: 'own_3_properties',
            type: CHALLENGE_TYPES.OWN_PROPERTIES,
            name: 'Property Mogul',
            description: 'Own 3 properties',
            icon: '🏠',
            category: 'Properties',
            subCategory: 'Milestones',
            target: 3,
            reward: { money: 2000, xp: 200, titleId: 'property_mogul' },
            unlockLevel: 3
        },
        {
            id: 'own_5_properties',
            type: CHALLENGE_TYPES.OWN_PROPERTIES,
            name: 'Real Estate King',
            description: 'Own 5 properties',
            icon: '👑',
            category: 'Properties',
            subCategory: 'Milestones',
            target: 5,
            reward: { money: 10000, xp: 1000, titleId: 'real_estate_king' },
            unlockLevel: 6
        }
    ];

    function countRoomUpgrades(state) {
        var upgradesByProp = state && state.properties ? state.properties.upgrades : null;
        if (!upgradesByProp) return 0;
        var total = 0;
        for (var propId in upgradesByProp) {
            var list = upgradesByProp[propId];
            if (Array.isArray(list)) total += list.length;
        }
        return total;
    }

    function countGrowerWorkers(state) {
        var workers = state && state.growerWorkers ? state.growerWorkers.instances : null;
        return Array.isArray(workers) ? workers.length : 0;
    }

    function addChallenge(ch) {
        if (!ch || !ch.id) return;
        for (var i = 0; i < challengeDefinitions.length; i++) {
            if (challengeDefinitions[i].id === ch.id) return;
        }
        challengeDefinitions.push(ch);
    }

    function addTiered(prefix, type, icon, category, subCategory, targets, unlockLevels, rewardFn, descFn, nameFn) {
        for (var i = 0; i < targets.length; i++) {
            var target = targets[i];
            var unlockLevel = unlockLevels && unlockLevels[i] ? unlockLevels[i] : 1;
            addChallenge({
                id: prefix + '_' + target,
                type: type,
                name: nameFn ? nameFn(target) : (prefix + ' ' + target),
                description: descFn ? descFn(target) : (prefix + ' ' + target),
                icon: icon,
                category: category,
                subCategory: subCategory,
                target: target,
                reward: rewardFn ? rewardFn(target, i) : { money: 0, xp: 0 },
                unlockLevel: unlockLevel
            });
        }
    }

    // Tiered challenges across the full progression
    addTiered(
        'harvest_plants',
        CHALLENGE_TYPES.HARVEST_TOTAL,
        '🌿',
        'Harvesting',
        'Milestones',
        [250, 500, 1000, 2500, 5000, 10000, 25000],
        [3, 5, 7, 10, 14, 18, 22],
        function(target) { return { money: Math.floor(target * 12), xp: Math.floor(target * 6) }; },
        function(target) { return 'Harvest ' + target + ' plants total'; },
        function(target) { return 'Harvest ' + target; }
    );

    addTiered(
        'earn_total',
        CHALLENGE_TYPES.EARN_TOTAL,
        '💰',
        'Money',
        'Milestones',
        [25000, 50000, 100000, 250000, 500000, 1000000, 2500000, 5000000],
        [5, 6, 7, 10, 12, 15, 20, 24],
        function(target) { return { money: Math.floor(target * 0.08), xp: Math.floor(target * 0.02) }; },
        function(target) { return 'Earn $' + HP.Helpers.formatNumber(target) + ' total'; },
        function(target) { return 'Earn $' + HP.Helpers.formatNumber(target); }
    );

    addTiered(
        'sell_grams',
        CHALLENGE_TYPES.SELL_TOTAL,
        '📦',
        'Sales',
        'Milestones',
        [5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000],
        [6, 7, 10, 12, 14, 18, 21, 24],
        function(target) { return { money: Math.floor(target * 2), xp: Math.floor(target * 0.8) }; },
        function(target) { return 'Sell ' + HP.Helpers.formatNumber(target) + ' grams total'; },
        function(target) { return 'Sell ' + HP.Helpers.formatNumber(target) + 'g'; }
    );

    addTiered(
        'reach_level',
        CHALLENGE_TYPES.REACH_LEVEL,
        '⭐',
        'Progression',
        'Milestones',
        [5, 10, 15, 20, 25],
        [1, 1, 8, 12, 20],
        function(target) { return { money: target * 2500, xp: target * 1000 }; },
        function(target) { return 'Reach level ' + target; },
        function(target) { return 'Level ' + target; }
    );

    addTiered(
        'own_properties',
        CHALLENGE_TYPES.OWN_PROPERTIES,
        '🏠',
        'Properties',
        'Milestones',
        [2, 3, 4, 5, 8, 10, 13],
        [2, 3, 5, 6, 12, 18, 24],
        function(target) { return { money: target * 8000, xp: target * 1500 }; },
        function(target) { return 'Own ' + target + ' properties'; },
        function(target) { return 'Own ' + target + ' Properties'; }
    );

    addTiered(
        'room_upgrades',
        CHALLENGE_TYPES.ROOM_UPGRADES_TOTAL,
        '⚙️',
        'Upgrades',
        'Milestones',
        [3, 6, 12, 24, 36],
        [4, 6, 10, 16, 22],
        function(target) { return { money: target * 5000, xp: target * 1200 }; },
        function(target) { return 'Install ' + target + ' room upgrades total'; },
        function(target) { return 'Upgrade Enthusiast (' + target + ')'; }
    );

    addTiered(
        'grower_workers',
        CHALLENGE_TYPES.GROWER_WORKERS_TOTAL,
        '👷',
        'Workers',
        'Milestones',
        [1, 2, 3, 5, 10],
        [3, 6, 8, 12, 20],
        function(target) { return { money: target * 25000, xp: target * 2500 }; },
        function(target) { return 'Hire ' + target + ' grower workers'; },
        function(target) { return 'Hire ' + target + ' Grower' + (target !== 1 ? 's' : ''); }
    );

    addTiered(
        'seed_stockpile',
        CHALLENGE_TYPES.OWN_SEEDS_TOTAL,
        '🌱',
        'Inventory',
        'Stockpiles',
        [50, 100, 250, 500, 1000],
        [2, 4, 8, 12, 20],
        function(target) { return { money: target * 50, xp: target * 15 }; },
        function(target) { return 'Hold ' + target + ' seeds in inventory at once'; },
        function(target) { return 'Seed Stockpile ' + target; }
    );

    addTiered(
        'gear_hoarder',
        CHALLENGE_TYPES.OWN_EQUIPMENT_TOTAL,
        '🧰',
        'Inventory',
        'Stockpiles',
        [25, 50, 100, 200, 400],
        [3, 6, 10, 16, 22],
        function(target) { return { money: target * 100, xp: target * 20 }; },
        function(target) { return 'Hold ' + target + ' equipment items in inventory at once'; },
        function(target) { return 'Gear Hoarder ' + target; }
    );

    addTiered(
        'play_time',
        CHALLENGE_TYPES.PLAY_TIME_SECONDS,
        '⏱️',
        'Time',
        'Milestones',
        [1800, 3600, 7200, 14400, 28800],
        [1, 3, 6, 10, 16],
        function(target) { return { money: Math.floor(target / 2), xp: Math.floor(target / 4) }; },
        function(target) { return 'Play for ' + Math.floor(target / 60) + ' minutes total'; },
        function(target) { return 'Time Played: ' + Math.floor(target / 60) + 'm'; }
    );

    /**
     * Get all available challenges
     */
    function getAllChallenges() {
        return challengeDefinitions;
    }

    /**
     * Get challenges available at current level
     */
    function getAvailableChallenges(playerLevel) {
        return challengeDefinitions.filter(function(challenge) {
            return challenge.unlockLevel <= playerLevel;
        });
    }

    /**
     * Check challenge progress
     */
    function checkChallengeProgress(challenge, state) {
        var progress = 0;
        var completed = false;

        switch (challenge.type) {
            case CHALLENGE_TYPES.HARVEST_TOTAL:
                // Plants harvested (count)
                progress = state.stats.plantsGrown || 0;
                break;
            case CHALLENGE_TYPES.EARN_TOTAL:
                progress = state.stats.totalMoneyEarned || 0;
                break;
            case CHALLENGE_TYPES.GROW_TOTAL:
                progress = state.stats.plantsGrown || 0;
                break;
            case CHALLENGE_TYPES.SELL_TOTAL:
                progress = state.stats.totalSold || 0;
                break;
            case CHALLENGE_TYPES.REACH_LEVEL:
                progress = state.level || 1;
                break;
            case CHALLENGE_TYPES.OWN_PROPERTIES:
                progress = (state.properties.owned || []).length;
                break;
            case CHALLENGE_TYPES.ROOM_UPGRADES_TOTAL:
                progress = countRoomUpgrades(state);
                break;
            case CHALLENGE_TYPES.GROWER_WORKERS_TOTAL:
                progress = countGrowerWorkers(state);
                break;
            case CHALLENGE_TYPES.OWN_SEEDS_TOTAL:
                progress = HP.Helpers && HP.Helpers.sumRecord ? HP.Helpers.sumRecord(state.inventory && state.inventory.seeds ? state.inventory.seeds : {}) : 0;
                break;
            case CHALLENGE_TYPES.OWN_EQUIPMENT_TOTAL:
                progress = HP.Helpers && HP.Helpers.sumRecord ? HP.Helpers.sumRecord(state.inventory && state.inventory.equipment ? state.inventory.equipment : {}) : 0;
                break;
            case CHALLENGE_TYPES.PLAY_TIME_SECONDS:
                // Stored as seconds and incremented in small deltas; display should never show decimals.
                progress = Math.floor(state.stats.playTime || 0);
                break;
        }

        completed = progress >= challenge.target;
        return {
            progress: Math.min(progress, challenge.target),
            target: challenge.target,
            completed: completed,
            percentage: Math.min((progress / challenge.target) * 100, 100)
        };
    }

    /**
     * Check all challenges and complete any that are done
     */
    function checkAllChallenges() {
        var state = HP.State.getState();
        var playerLevel = state.level;
        var availableChallenges = getAvailableChallenges(playerLevel);
        var completedChallenges = HP.State.getChallenges().completed;
        var newlyCompleted = [];

        for (var i = 0; i < availableChallenges.length; i++) {
            var challenge = availableChallenges[i];
            
            // Skip if already completed
            if (completedChallenges.indexOf(challenge.id) !== -1) {
                continue;
            }

            var progress = checkChallengeProgress(challenge, state);
            if (progress.completed) {
                completeChallenge(challenge);
                newlyCompleted.push(challenge);
            }
        }

        return newlyCompleted;
    }

    /**
     * Complete a challenge
     */
    function completeChallenge(challenge) {
        if (HP.State.completeChallenge(challenge.id)) {
            var parts = [];
            if (challenge.reward && challenge.reward.money) {
                HP.State.addBank(challenge.reward.money);
                parts.push('+$' + challenge.reward.money);
            }
            if (challenge.reward && challenge.reward.xp) {
                HP.State.addXP(challenge.reward.xp);
                parts.push('+' + challenge.reward.xp + ' XP');
            }
            if (challenge.reward && challenge.reward.titleId && HP.State.unlockTitle) {
                HP.State.unlockTitle(challenge.reward.titleId);
                var title = HP.Data.Titles && HP.Data.Titles.get(challenge.reward.titleId);
                if (title) parts.push('🏆 ' + title.name);
            }
            HP.Notifications.success(
                challenge.icon + ' Challenge Complete: ' + challenge.name + '! ' + parts.join(' '),
                { duration: 5000 }
            );
            return true;
        }
        return false;
    }

    /**
     * Get challenge by ID
     */
    function getChallenge(id) {
        for (var i = 0; i < challengeDefinitions.length; i++) {
            if (challengeDefinitions[i].id === id) {
                return challengeDefinitions[i];
            }
        }
        return null;
    }

    return {
        getAllChallenges: getAllChallenges,
        getAvailableChallenges: getAvailableChallenges,
        checkChallengeProgress: checkChallengeProgress,
        checkAllChallenges: checkAllChallenges,
        completeChallenge: completeChallenge,
        getChallenge: getChallenge,
        CHALLENGE_TYPES: CHALLENGE_TYPES
    };
})();
