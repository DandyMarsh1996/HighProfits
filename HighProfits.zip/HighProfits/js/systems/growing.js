/**
 * HighProfits - Growing System
 * Handles plant growth with water-based mechanics
 * Plants only grow when hydrated - water depletes over time
 */
var HP = HP || {};

HP.Growing = (function() {
    'use strict';

    function getEquipmentIdFromSlotValue(slotValue) {
        if (!slotValue) return null;
        if (typeof slotValue === 'string') return slotValue;
        if (typeof slotValue === 'object' && slotValue.id) return slotValue.id;
        return null;
    }

    function getEquipmentUsesLeftFromSlotValue(slotValue) {
        if (slotValue && typeof slotValue === 'object' && typeof slotValue.usesLeft === 'number') {
            return slotValue.usesLeft;
        }
        return null;
    }

    function consumePlotConsumable(plot, slot) {
        var slotValue = plot && plot.equipment ? plot.equipment[slot] : null;
        if (!slotValue) return;

        var equipId = getEquipmentIdFromSlotValue(slotValue);
        if (!equipId) {
            plot.equipment[slot] = null;
            return;
        }

        var equip = HP.Data.Equipment.get(equipId);
        if (!equip || !equip.consumable) return;

        // New format: { id, usesLeft }
        var usesLeft = getEquipmentUsesLeftFromSlotValue(slotValue);
        if (typeof usesLeft === 'number') {
            usesLeft -= 1;
            if (usesLeft <= 0) {
                plot.equipment[slot] = null;
            } else {
                plot.equipment[slot].usesLeft = usesLeft;
            }
            return;
        }

        // Legacy format: single-use consumable stored as string ID
        plot.equipment[slot] = null;
    }

    /**
     * Create a new empty plot
     */
    function createEmptyPlot() {
        return {
            id: generatePlotId(),
            status: 'empty',          // empty, setup, growing, harvest, dead
            equipment: {
                pot: null,
                soil: null,
                light: null,
                fan: null,
                fertilizer: null
            },
            plant: null
        };
    }

    var plotIdCounter = 0;
    function generatePlotId() {
        return 'plot_' + (++plotIdCounter) + '_' + Date.now();
    }

    /**
     * Create a new plant from a seed
     * @param {string} seedId - Seed type
     * @param {Object} plotEquipment - Equipment in the plot
     * @param {Object} roomBonuses - Bonuses from room upgrades (optional)
     */
    function createPlant(seedId, plotEquipment, roomBonuses) {
        var seed = HP.Data.Seeds.get(seedId);
        if (!seed) return null;

        var equipBonuses = calculateEquipmentBonuses(plotEquipment);
        roomBonuses = roomBonuses || { growth: 0, yield: 0, quality: 0 };

        // Apply diminishing returns to bonuses (logarithmic scaling)
        var effectiveBonuses = {
            growth: applyDiminishingReturns(equipBonuses.growth + roomBonuses.growth),
            yield: applyDiminishingReturns(equipBonuses.yield + roomBonuses.yield),
            quality: applyDiminishingReturns(equipBonuses.quality + roomBonuses.quality)
        };

        var growthReduction = 1 - (effectiveBonuses.growth / 100);
        var totalGrowthTime = Math.max(10, Math.floor(seed.growthTime * growthReduction));

        // Water consumption based on strain
        var waterConsumption = seed.waterConsumption || 1.0;
        var baseMaxWater = 120;
        var maxWater = Math.floor(baseMaxWater / waterConsumption);

        return {
            seedId: seedId,
            seedName: seed.name,
            strainName: seed.strainName || seed.name,
            plantedAt: Date.now(),
            // Growth tracking
            growthProgress: 0,        // Seconds of growth completed
            growthRequired: totalGrowthTime,
            // Water system
            waterLevel: 0,            // Current hydration (seconds remaining)
            maxWater: maxWater,       // Max water capacity (adjusted by strain)
            isHydrated: false,        // Currently has water?
            waterConsumption: waterConsumption,  // Strain water usage multiplier
            // Bonuses and quality
            bonuses: effectiveBonuses,
            quality: seed.quality,
            qualityBias: seed.qualityBias || 0,  // Chance to upgrade quality
            baseYield: seed.baseYield,
            yieldVariance: seed.yieldVariance,
            failureChance: seed.failureChance,
            timeSinceWater: 0         // Tracks time without water
        };
    }

    /**
     * Apply diminishing returns to bonuses
     * Formula: effective = base * (1 - e^(-base/100))
     * This caps bonuses around 70-80% effectiveness at high values
     */
    function applyDiminishingReturns(baseBonus) {
        if (baseBonus <= 0) return 0;
        // Simplified: effective = base * (100 / (100 + base * 0.5))
        var effective = baseBonus * (100 / (100 + baseBonus * 0.5));
        return Math.floor(effective * 100) / 100;
    }

    /**
     * Calculate equipment bonuses
     */
    function calculateEquipmentBonuses(equipment) {
        var bonuses = {
            growth: 0,      // % faster growth
            yield: 0,       // % more yield
            quality: 0      // % quality boost
        };

        for (var slot in equipment) {
            var itemId = getEquipmentIdFromSlotValue(equipment[slot]);
            if (!itemId) continue;

            var item = HP.Data.Equipment.get(itemId);
            if (!item) continue;

            bonuses.growth += item.growthBonus || 0;
            bonuses.yield += item.yieldBonus || 0;
            bonuses.quality += item.qualityBonus || 0;
        }

        return bonuses;
    }

    /**
     * Check if plot has required equipment
     */
    function canPlotGrow(plot) {
        var missing = [];

        if (!plot.equipment.pot) missing.push('pot');
        if (!plot.equipment.soil) missing.push('soil');
        if (!plot.equipment.light) missing.push('light');

        return {
            canGrow: missing.length === 0,
            missing: missing
        };
    }

    /**
     * Plant a seed
     * @param {Object} plot - Plot object
     * @param {string} seedId - Seed type
     * @param {Object} roomBonuses - Bonuses from room upgrades (optional)
     */
    function plantSeed(plot, seedId, roomBonuses) {
        var readyCheck = canPlotGrow(plot);
        if (!readyCheck.canGrow) {
            return {
                success: false,
                message: 'Missing: ' + readyCheck.missing.join(', ')
            };
        }

        if (plot.status !== 'empty' && plot.status !== 'setup') {
            return { success: false, message: 'Plot is not empty' };
        }

        var seed = HP.Data.Seeds.get(seedId);
        if (!seed) {
            return { success: false, message: 'Invalid seed' };
        }

        plot.plant = createPlant(seedId, plot.equipment, roomBonuses);
        plot.status = 'growing';

        return {
            success: true,
            message: 'Planted ' + seed.name + ' - Water it to start growing!'
        };
    }

    /**
     * Water a plant
     * @param {Object} plot - Plot with plant
     * @param {number} waterAmount - Seconds of hydration to add
     * @returns {Object} Result
     */
    function waterPlant(plot, waterAmount) {
        if (!plot.plant || plot.status !== 'growing') {
            return { success: false, message: 'Nothing to water' };
        }

        var plant = plot.plant;
        plant.waterLevel = Math.min(plant.maxWater, plant.waterLevel + waterAmount);
        plant.isHydrated = plant.waterLevel > 0;
        plant.timeSinceWater = 0;

        return {
            success: true,
            message: 'Watered plant! (' + Math.floor(plant.waterLevel) + 's of hydration)',
            waterLevel: plant.waterLevel
        };
    }

    /**
     * Update plant growth (called each tick)
     * Plants only grow when hydrated
     */
    function updatePlantGrowth(plot, deltaTime) {
        if (!plot.plant || plot.status !== 'growing') {
            return { changed: false };
        }

        var plant = plot.plant;

        // Decrease water level (adjusted by strain water consumption)
        if (plant.waterLevel > 0) {
            var waterDrainRate = deltaTime * plant.waterConsumption;
            plant.waterLevel = Math.max(0, plant.waterLevel - waterDrainRate);
            plant.isHydrated = plant.waterLevel > 0;
            plant.timeSinceWater = 0;

            // Grow while hydrated (apply event growth speed modifier)
            var eventSpeedMult = HP.Events && HP.Events.Manager ? HP.Events.Manager.getModifier('growthSpeed') : 1;
            plant.growthProgress += deltaTime * eventSpeedMult;

            // Check if growth complete
            if (plant.growthProgress >= plant.growthRequired) {
                plot.status = 'harvest';
                return {
                    changed: true,
                    event: 'ready',
                    message: 'Plant ready to harvest!'
                };
            }
        } else {
            // Not hydrated - track time without water
            plant.isHydrated = false;
            plant.timeSinceWater += deltaTime;

            // Plant dies if left too long without water (5+ minutes)
            var deathThreshold = 300; // 5 minutes
            if (plant.timeSinceWater > deathThreshold) {
                // Check failure chance
                var deathChance = plant.failureChance * (plant.timeSinceWater / deathThreshold);
                if (Math.random() < deathChance * deltaTime * 0.1) {
                    plot.status = 'dead';
                    return {
                        changed: true,
                        event: 'died',
                        message: 'Plant died from lack of water!'
                    };
                }
            }
        }

        return { changed: false };
    }

    /**
     * Harvest a plant
     */
    function harvestPlant(plot) {
        if (plot.status !== 'harvest' || !plot.plant) {
            return { success: false, message: 'Nothing to harvest' };
        }

        var plant = plot.plant;
        var seed = HP.Data.Seeds.get(plant.seedId);

        // Calculate yield with bonuses
        var baseYield = plant.baseYield;
        var yieldBonus = 1 + (plant.bonuses.yield / 100);
        var variance = 1 + (Math.random() * 2 - 1) * plant.yieldVariance;
        var finalYield = Math.max(1, Math.floor(baseYield * yieldBonus * variance));

        // Determine quality using threshold-based rolls:
        // Higher quality bonuses unlock better tiers and increase their roll chances.
        // Seed quality acts as a minimum (never downgrades below seed base quality).
        var quality = rollHarvestQuality(plant.quality, (plant.bonuses.quality || 0), (plant.qualityBias || 0));

        var result = {
            success: true,
            yield: finalYield,
            quality: quality,
            seedName: seed.name,
            message: 'Harvested ' + finalYield + 'g of ' + quality + ' quality!'
        };

        // Consume consumables (supports multi-use consumables via usesLeft)
        consumePlotConsumable(plot, 'soil');
        consumePlotConsumable(plot, 'fertilizer');

        // Reset plot
        plot.plant = null;
        plot.status = hasNonConsumableEquipment(plot) ? 'setup' : 'empty';

        return result;
    }

    /**
     * Roll harvest quality based on quality thresholds.
     * @param {string} baseQuality - Seed's base quality ('low'|'medium'|'good'|'premium')
     * @param {number} qualityBonus - Total quality bonus from gear/room (already has diminishing returns applied)
     * @param {number} qualityBias - Seed genetics bias (0-100-ish)
     * @returns {string} Final quality
     */
    function rollHarvestQuality(baseQuality, qualityBonus, qualityBias) {
        var qualities = ['low', 'medium', 'good', 'premium'];
        var baseIdx = qualities.indexOf(baseQuality);
        if (baseIdx < 0) baseIdx = 1; // default to medium if unknown

        // Total "quality points" driving threshold unlocks and chances.
        // This intentionally combines player bonuses + seed genetics.
        var points = (qualityBonus || 0) + (qualityBias || 0);

        // Thresholds (points needed before a tier can even be rolled)
        // Tune these to control when premium becomes realistically possible.
        // Raised thresholds so premium doesn't become trivial too early.
        var thresholds = {
            medium: 20,
            good: 60,
            premium: 110
        };

        // Helper: scale chance from min->max across a point window above the threshold.
        function scaledChance(threshold, minChance, maxChance, window) {
            if (points < threshold) return 0;
            window = window || 30;
            var progress = (points - threshold) / window;
            if (progress < 0) progress = 0;
            if (progress > 1) progress = 1;
            return minChance + (maxChance - minChance) * progress;
        }

        // Compute tier chances (roll highest tier first).
        // These represent "upgrade roll chances" from the base quality.
        var chancePremium = scaledChance(thresholds.premium, 0.03, 0.22, 80);
        var chanceGood = scaledChance(thresholds.good, 0.10, 0.45, 80);
        var chanceMedium = scaledChance(thresholds.medium, 0.18, 0.60, 80);

        // If base is already high, only roll for tiers above it.
        // Never downgrade below baseIdx.
        if (baseIdx < 3 && Math.random() < chancePremium) return 'premium';
        if (baseIdx < 2 && Math.random() < chanceGood) return 'good';
        if (baseIdx < 1 && Math.random() < chanceMedium) return 'medium';

        return qualities[baseIdx];
    }

    /**
     * Check if plot has non-consumable equipment
     */
    function hasNonConsumableEquipment(plot) {
        return plot.equipment.pot || plot.equipment.light || plot.equipment.fan;
    }

    /**
     * Clear a dead plant
     */
    function clearDeadPlant(plot) {
        if (plot.status !== 'dead') return;

        // Consume consumables even on failure (mirrors old behavior of clearing them)
        consumePlotConsumable(plot, 'soil');
        consumePlotConsumable(plot, 'fertilizer');
        plot.plant = null;
        plot.status = hasNonConsumableEquipment(plot) ? 'setup' : 'empty';
    }

    /**
     * Install equipment
     */
    function installEquipment(plot, equipmentId) {
        var equipment = HP.Data.Equipment.get(equipmentId);
        if (!equipment) {
            return { success: false, message: 'Invalid equipment' };
        }

        var slot = equipment.slot || getEquipmentSlot(equipment);
        if (!slot || slot === 'watering_can') {
            return { success: false, message: 'Cannot install this item' };
        }

        if (plot.status === 'growing' || plot.status === 'harvest') {
            return { success: false, message: 'Cannot change equipment while growing' };
        }

        if (equipment.consumable) {
            var uses = typeof equipment.uses === 'number' ? equipment.uses : 1;
            plot.equipment[slot] = { id: equipmentId, usesLeft: uses };
        } else {
            plot.equipment[slot] = equipmentId;
        }

        var readyCheck = canPlotGrow(plot);
        plot.status = readyCheck.canGrow ? 'setup' : 'empty';

        return {
            success: true,
            message: 'Installed ' + equipment.name
        };
    }

    /**
     * Uninstall equipment from a plot
     */
    function uninstallEquipment(plot, slot) {
        if (plot.status === 'growing' || plot.status === 'harvest') {
            return { success: false, message: 'Cannot remove equipment while growing' };
        }

        var equipmentId = getEquipmentIdFromSlotValue(plot.equipment[slot]);
        if (!equipmentId) {
            return { success: false, message: 'No equipment in that slot' };
        }

        var equipment = HP.Data.Equipment.get(equipmentId);
        plot.equipment[slot] = null;

        // Update plot status
        var readyCheck = canPlotGrow(plot);
        plot.status = readyCheck.canGrow ? 'setup' : 'empty';

        return {
            success: true,
            equipmentId: equipmentId,
            message: 'Removed ' + (equipment ? equipment.name : 'equipment')
        };
    }

    /**
     * Determine equipment slot from item
     */
    function getEquipmentSlot(equipment) {
        if (equipment.slot) return equipment.slot;
        
        var id = equipment.id;
        if (id.includes('pot')) return 'pot';
        if (id.includes('soil')) return 'soil';
        if (id.includes('bulb') || id.includes('light') || id.includes('hps')) return 'light';
        if (id.includes('fan') || id.includes('exhaust')) return 'fan';
        if (id.includes('fertilizer') || id.includes('nutrient') || id.includes('bloom')) return 'fertilizer';
        
        return null;
    }

    /**
     * Get growth progress percentage
     */
    function getGrowthProgress(plant) {
        if (!plant) return 0;
        if (plant.growthProgress >= plant.growthRequired) return 100;
        return Math.floor((plant.growthProgress / plant.growthRequired) * 100);
    }

    /**
     * Get time remaining for growth
     */
    function getTimeRemaining(plant) {
        if (!plant) return '';
        var remaining = Math.max(0, plant.growthRequired - plant.growthProgress);
        return formatTime(remaining);
    }

    /**
     * Get water level percentage
     */
    function getWaterLevel(plant) {
        if (!plant) return 0;
        return Math.floor((plant.waterLevel / plant.maxWater) * 100);
    }

    /**
     * Get water status text
     */
    function getWaterStatus(plant) {
        if (!plant) return '';
        if (plant.waterLevel <= 0) return 'Dry - Needs water!';
        if (plant.waterLevel < 30) return 'Low water';
        if (plant.waterLevel < 60) return 'Hydrated';
        return 'Well watered';
    }

    /**
     * Format seconds to readable time
     */
    function formatTime(seconds) {
        if (seconds < 60) {
            return Math.ceil(seconds) + 's';
        }
        var mins = Math.floor(seconds / 60);
        var secs = Math.floor(seconds % 60);
        return mins + 'm ' + secs + 's';
    }

    return {
        createEmptyPlot: createEmptyPlot,
        canPlotGrow: canPlotGrow,
        plantSeed: plantSeed,
        waterPlant: waterPlant,
        updatePlantGrowth: updatePlantGrowth,
        harvestPlant: harvestPlant,
        clearDeadPlant: clearDeadPlant,
        installEquipment: installEquipment,
        uninstallEquipment: uninstallEquipment,
        calculateEquipmentBonuses: calculateEquipmentBonuses,
        getGrowthProgress: getGrowthProgress,
        getTimeRemaining: getTimeRemaining,
        getWaterLevel: getWaterLevel,
        getWaterStatus: getWaterStatus,
        getEquipmentSlot: getEquipmentSlot
    };
})();
