/**
 * HighProfits - Configuration API
 * Provides a unified interface to all game data and configuration
 * Acts as a facade over the modular data files
 */
var HP = HP || {};

HP.Config = (function() {
    'use strict';

    // ===================
    // DRUG METHODS
    // ===================
    
    function getDrug(id) {
        return HP.Data.Drugs.get(id);
    }

    function getAllDrugs() {
        return HP.Data.Drugs.getAll();
    }

    function getDrugIds() {
        return HP.Data.Drugs.getIds();
    }

    function getDrugOrder() {
        return HP.Data.Drugs.getUnlockOrder();
    }

    function isDrugUnlocked(drugId, playerLevel) {
        return HP.Progression.isDrugUnlocked(drugId, playerLevel);
    }

    function getUnlockedDrugs(playerLevel) {
        return HP.Progression.getUnlockedDrugs(playerLevel);
    }

    function getNextDrugToUnlock(playerLevel) {
        return HP.Progression.getNextDrugToUnlock(playerLevel);
    }

    // ===================
    // WORKER METHODS
    // ===================

    function getWorker(id) {
        return HP.Data.Workers.get(id);
    }

    function getAllWorkers() {
        return HP.Data.Workers.getAll();
    }

    // ===================
    // STORAGE METHODS
    // ===================

    function getStorageConfig() {
        var constants = HP.Data.Constants;
        return {
            baseCost: constants.STORAGE_BASE_COST,
            costMultiplier: constants.STORAGE_COST_MULTIPLIER,
            baseCapacity: constants.STARTING_STORAGE_CAPACITY,
            capacityPerLevel: constants.STORAGE_CAPACITY_PER_LEVEL
        };
    }

    // ===================
    // BALANCE METHODS
    // ===================

    function getBalance() {
        var constants = HP.Data.Constants;
        return {
            tickRate: constants.TICK_RATE,
            autoSaveInterval: constants.AUTO_SAVE_INTERVAL,
            startingMoney: constants.STARTING_MONEY,
            moneyCap: constants.STARTING_MONEY_CAP
        };
    }

    function getTickRate() {
        return HP.Data.Constants.TICK_RATE;
    }

    function getConstants() {
        return HP.Data.Constants;
    }

    // ===================
    // RANK METHODS
    // ===================

    function getRanks() {
        return HP.Data.Ranks.getAll();
    }

    function getRankForXP(xp) {
        return HP.Data.Ranks.getForXP(xp);
    }

    function getNextRank(currentLevel) {
        return HP.Data.Ranks.getNext(currentLevel);
    }

    function getRankByLevel(level) {
        return HP.Data.Ranks.getByLevel(level);
    }

    // ===================
    // PUBLIC API
    // ===================

    return {
        // Drugs
        getDrug: getDrug,
        getAllDrugs: getAllDrugs,
        getDrugIds: getDrugIds,
        getDrugOrder: getDrugOrder,
        isDrugUnlocked: isDrugUnlocked,
        getUnlockedDrugs: getUnlockedDrugs,
        getNextDrugToUnlock: getNextDrugToUnlock,

        // Workers
        getWorker: getWorker,
        getAllWorkers: getAllWorkers,

        // Storage
        getStorageConfig: getStorageConfig,

        // Balance
        getBalance: getBalance,
        getTickRate: getTickRate,
        getConstants: getConstants,

        // Ranks
        getRanks: getRanks,
        getRankForXP: getRankForXP,
        getNextRank: getNextRank,
        getRankByLevel: getRankByLevel
    };
})();
