/**
 * HighProfits - Main Application Entry Point
 * Initializes all modules and starts the game
 */
var HP = HP || {};

HP.App = (function() {
    'use strict';

    var isInitialized = false;

    /**
     * Initialize the game
     */
    function init() {
        if (isInitialized) {
            console.warn('[App] Already initialized');
            return;
        }

        console.log('[App] Initializing High Profits...');
        console.log('[App] Version: 2.0.0 - Grow System');

        // Initialize state (creates initial plots)
        HP.State.init();

        // Initialize UI renderer
        HP.Renderer.init();

        // Initialize scrolling news ticker
        if (HP.NewsTicker) {
            HP.NewsTicker.init();
        }

        // Initialize tooltips
        if (HP.Tooltips) {
            HP.Tooltips.init();
        }

        // Initialize sound manager
        if (HP.SoundManager) {
            HP.SoundManager.init();
        }

        // Initialize event handlers
        HP.Events.init();

        // Apply accessibility settings from localStorage (font size, high contrast, reduced motion)
        if (HP.Accessibility && HP.Accessibility.apply) HP.Accessibility.apply();

        // Update loading status (splash hides when boot completes)
        var statusEl = document.getElementById('loading-status');
        if (statusEl) statusEl.textContent = 'Ready';

        // Always show character select on launch; never auto-load into game
        console.log('[App] Showing character select');
        if (HP.Events.CharacterSelect && HP.Events.CharacterSelect.showCharacterSelect) {
            HP.Events.CharacterSelect.showCharacterSelect();
        }

        isInitialized = true;
        console.log('[App] Initialization complete!');
    }

    /**
     * Start game (after character loaded or created)
     */
    function startGame() {
        if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();

        if (HP.State && HP.State.isTourCompleted && !HP.State.isTourCompleted()) {
            if (HP.Events.WelcomeTour && HP.Events.WelcomeTour.show) HP.Events.WelcomeTour.show();
        } else {
            if (HP.Tutorial) HP.Tutorial.init();
        }
        setupStateListeners();
        HP.Renderer.update();
        HP.GameLoop.start();
        if (HP.MarketOrders) HP.MarketOrders.initialize();
        HP.SaveManager.startAutoSave();

        window.addEventListener('beforeunload', function() {
            HP.SaveManager.save();
        });
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                HP.SaveManager.save();
            } else {
                if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
            }
        });

        var hasLoaded = HP.SaveManager.getCurrentCharacterId && HP.SaveManager.getCurrentCharacterId();
        if (!hasLoaded) {
            setTimeout(function() {
                if (HP.Notifications) HP.Notifications.info('Welcome to High Profits! Buy equipment and seeds to start growing.');
            }, 500);
        }
        if (HP.SoundManager && HP.SoundManager.isAmbientEnabled && HP.SoundManager.isAmbientEnabled() && HP.SoundManager.startAmbient) {
            HP.SoundManager.startAmbient();
        }
    }

    /**
     * Set up listeners for state changes
     */
    function setupStateListeners() {
        HP.State.addListener(function(key, value, state) {
            if (key === 'levelUp') {
                handleLevelUp(value);
            }
        });
    }

    /**
     * Handle level up event
     */
    function handleLevelUp(data) {
        HP.Notifications.levelUp(data.level, data.rank);
        HP.Renderer.update();
        
        // Check for level-based tutorial hints
        if (HP.Tutorial) {
            HP.Tutorial.checkLevelHint(data.level);
        }
    }

    /**
     * Get initialization status
     */
    function isReady() {
        return isInitialized;
    }

    /**
     * Return to main menu (character select). Saves current character first.
     */
    function returnToMainMenu() {
        if (HP.SaveManager && HP.SaveManager.save) {
            HP.SaveManager.save();
        }
        if (HP.GameLoop && HP.GameLoop.stop) {
            HP.GameLoop.stop();
        }
        if (HP.SaveManager && HP.SaveManager.stopAutoSave) {
            HP.SaveManager.stopAutoSave();
        }
        if (HP.SoundManager && HP.SoundManager.stopAmbient) {
            HP.SoundManager.stopAmbient();
        }
        if (HP.Events.CharacterSelect && HP.Events.CharacterSelect.showCharacterSelect) {
            HP.Events.CharacterSelect.showCharacterSelect();
        }
    }

    /**
     * Restart the game
     */
    function restart() {
        HP.GameLoop.stop();
        HP.SaveManager.stopAutoSave();
        isInitialized = false;
        init();
    }

    /**
     * Get game version info
     */
    function getVersion() {
        return {
            name: 'High Profits',
            version: '2.0.0',
            build: 'grow-system'
        };
    }

    // Public API
    return {
        init: init,
        startGame: startGame,
        isReady: isReady,
        restart: restart,
        returnToMainMenu: returnToMainMenu,
        getVersion: getVersion
    };
})();

// Auto-initialize when DOM is ready
(function() {
    'use strict';

    function boot() {
        if (HP.ErrorHandler && HP.ErrorHandler.init) HP.ErrorHandler.init();
        try {
            HP.App.init();
            hideLoadingSplash();
        } catch (err) {
            console.error('[App] Init failed:', err);
            hideLoadingSplash();
            if (HP.ErrorHandler && HP.ErrorHandler.show) {
                HP.ErrorHandler.show('Failed to load the game. Try refreshing the page.');
            }
        }
    }

    function hideLoadingSplash() {
        var splash = document.getElementById('loading-splash');
        if (splash) {
            splash.classList.add('hidden');
            splash.setAttribute('aria-busy', 'false');
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
