/**
 * HighProfits - Main Application Entry Point
 * Initializes all modules and starts the game
 */
var HP = HP || {};

HP.App = (function() {
    'use strict';

    var isInitialized = false;

    /**
     * Initialize the game
     */
    function init() {
        if (isInitialized) {
            console.warn('[App] Already initialized');
            return;
        }

        console.log('[App] Initializing High Profits...');
        console.log('[App] Version: 2.0.0 - Grow System');

        // Initialize state (creates initial plots)
        HP.State.init();

        // Initialize UI renderer
        HP.Renderer.init();

        // Initialize scrolling news ticker
        if (HP.NewsTicker) {
            HP.NewsTicker.init();
        }

        // Initialize tooltips
        if (HP.Tooltips) {
            HP.Tooltips.init();
        }

        // Initialize sound manager
        if (HP.SoundManager) {
            HP.SoundManager.init();
        }

        // Initialize event handlers
        HP.Events.init();

        // Apply accessibility settings from localStorage (font size, high contrast, reduced motion)
        if (HP.Accessibility && HP.Accessibility.apply) HP.Accessibility.apply();

        // Update loading status (splash hides when boot completes)
        var statusEl = document.getElementById('loading-status');
        if (statusEl) statusEl.textContent = 'Ready';

        if (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:') {
            console.warn('[App] Running from file:// – localStorage may be restricted in some browsers. Saves are written to primary + backup keys; for best persistence run from http(s) (e.g. npx serve or python -m http.server).');
        }

        // Try to load existing save; if we have one, resume game so tutorial and progress persist across refresh
        var loaded = HP.SaveManager && HP.SaveManager.load && HP.SaveManager.load();
        if (loaded) {
            console.log('[App] Save loaded – resuming game');
            if (HP.Events.CharacterSelect && HP.Events.CharacterSelect.hideCharacterSelect) {
                HP.Events.CharacterSelect.hideCharacterSelect();
            }
            startGame();
        } else {
            console.log('[App] No save found – showing character select');
            if (HP.Events.CharacterSelect && HP.Events.CharacterSelect.showCharacterSelect) {
                HP.Events.CharacterSelect.showCharacterSelect();
            }
        }

        isInitialized = true;
        console.log('[App] Initialization complete!');
    }

    /**
     * Start game (after character loaded or created)
     */
    function startGame() {
        if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();

        if (HP.State && HP.State.isTourCompleted && !HP.State.isTourCompleted()) {
            if (HP.Events.WelcomeTour && HP.Events.WelcomeTour.show) HP.Events.WelcomeTour.show();
        } else {
            if (HP.Tutorial) HP.Tutorial.init();
        }
        setupStateListeners();
        HP.Renderer.update();
        HP.GameLoop.start();
        if (HP.MarketOrders) HP.MarketOrders.initialize();
        HP.SaveManager.startAutoSave();

        // Persist immediately so refresh/cache loss doesn't lose state (overwrite save with current state)
        setTimeout(function() {
            if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
        }, 400);

        window.addEventListener('beforeunload', function() {
            HP.SaveManager.save();
        });
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                HP.SaveManager.save();
            } else {
                if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
            }
        });

        var hasLoaded = HP.SaveManager.getCurrentCharacterId && HP.SaveManager.getCurrentCharacterId();
        if (!hasLoaded) {
            setTimeout(function() {
                if (HP.Notifications) HP.Notifications.info('Welcome to High Profits! Buy equipment and seeds to start growing.');
            }, 500);
        }

        showWhatsNewIfNeeded();

        if (HP.SoundManager) {
            if (HP.SoundManager.stopMenuMusic) HP.SoundManager.stopMenuMusic();
            if (HP.SoundManager.startGameMusic) HP.SoundManager.startGameMusic();
            if (HP.SoundManager.isAmbientEnabled && HP.SoundManager.isAmbientEnabled() && HP.SoundManager.startAmbient) {
                HP.SoundManager.startAmbient();
            }
        }
    }

    function showWhatsNewIfNeeded() {
        if (!HP.Data.Changelog || !HP.Data.Changelog.getCurrentVersion) return;
        var current = HP.Data.Changelog.getCurrentVersion();
        var seen = HP.State.getLastSeenChangelogVersion && HP.State.getLastSeenChangelogVersion();
        if (!current || (seen != null && String(seen) >= String(current))) return;

        var entries = HP.Data.Changelog.getAll();
        var latest = entries.length > 0 ? entries[0] : null;
        if (!latest) return;

        var titleEl = document.getElementById('whats-new-title');
        var textEl = document.getElementById('whats-new-text');
        var modalEl = document.getElementById('whats-new-modal');
        var closeBtn = document.getElementById('btn-close-whats-new');
        if (!titleEl || !textEl || !modalEl) return;

        titleEl.textContent = "What's new in " + latest.version;
        var html = '<p><strong>' + latest.version + '</strong> (' + (latest.date || '') + ')</p><ul class="changelog-list">';
        var changes = latest.changes || [];
        for (var i = 0; i < changes.length; i++) {
            html += '<li>' + changes[i] + '</li>';
        }
        html += '</ul><p>Full changelog is on the main menu.</p>';
        textEl.innerHTML = html;

        modalEl.classList.remove('hidden');
        if (HP.ModalFocusTrap && HP.ModalFocusTrap.trap) HP.ModalFocusTrap.trap(modalEl);

        function closeAndMarkSeen() {
            if (HP.ModalFocusTrap && HP.ModalFocusTrap.release) HP.ModalFocusTrap.release(modalEl);
            modalEl.classList.add('hidden');
            if (HP.State.setLastSeenChangelogVersion) HP.State.setLastSeenChangelogVersion(current);
            if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
            if (closeBtn) closeBtn.removeEventListener('click', closeAndMarkSeen);
        }

        if (closeBtn) closeBtn.addEventListener('click', closeAndMarkSeen);
    }

    /**
     * Set up listeners for state changes
     */
    function setupStateListeners() {
        HP.State.addListener(function(key, value, state) {
            if (key === 'levelUp') {
                handleLevelUp(value);
            }
        });
    }

    /**
     * Handle level up event
     */
    function handleLevelUp(data) {
        HP.Notifications.levelUp(data.level, data.rank);
        HP.Renderer.update();
        
        // Check for level-based tutorial hints
        if (HP.Tutorial) {
            HP.Tutorial.checkLevelHint(data.level);
        }
    }

    /**
     * Get initialization status
     */
    function isReady() {
        return isInitialized;
    }

    /**
     * Return to main menu (character select). Saves current character first.
     */
    function returnToMainMenu() {
        if (HP.SaveManager && HP.SaveManager.save) {
            HP.SaveManager.save();
        }
        if (HP.GameLoop && HP.GameLoop.stop) {
            HP.GameLoop.stop();
        }
        if (HP.SaveManager && HP.SaveManager.stopAutoSave) {
            HP.SaveManager.stopAutoSave();
        }
        if (HP.SoundManager) {
            HP.SoundManager.stopAmbient && HP.SoundManager.stopAmbient();
            HP.SoundManager.stopGameMusic && HP.SoundManager.stopGameMusic();
        }
        if (HP.Events.CharacterSelect && HP.Events.CharacterSelect.showCharacterSelect) {
            HP.Events.CharacterSelect.showCharacterSelect();
        }
    }

    /**
     * Restart the game
     */
    function restart() {
        HP.GameLoop.stop();
        HP.SaveManager.stopAutoSave();
        isInitialized = false;
        init();
    }

    /**
     * Get game version info
     */
    function getVersion() {
        return {
            name: 'High Profits',
            version: '2.0.0',
            build: 'grow-system'
        };
    }

    // Public API
    return {
        init: init,
        startGame: startGame,
        isReady: isReady,
        restart: restart,
        returnToMainMenu: returnToMainMenu,
        getVersion: getVersion
    };
})();

// Auto-initialize when DOM is ready
(function() {
    'use strict';

    function boot() {
        if (HP.ErrorHandler && HP.ErrorHandler.init) HP.ErrorHandler.init();
        try {
            HP.App.init();
            hideLoadingSplash();
        } catch (err) {
            console.error('[App] Init failed:', err);
            hideLoadingSplash();
            if (HP.ErrorHandler && HP.ErrorHandler.show) {
                HP.ErrorHandler.show('Failed to load the game. Try refreshing the page.');
            }
        }
    }

    function hideLoadingSplash() {
        var splash = document.getElementById('loading-splash');
        if (splash) {
            splash.classList.add('hidden');
            splash.setAttribute('aria-busy', 'false');
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
