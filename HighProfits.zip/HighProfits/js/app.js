/**
 * HighProfits - Main Application Entry Point
 * Initializes all modules and starts the game
 */
var HP = HP || {};

HP.App = (function() {
    'use strict';

    var isInitialized = false;

    /**
     * Initialize the game
     */
    function init() {
        if (isInitialized) {
            console.warn('[App] Already initialized');
            return;
        }

        console.log('[App] Initializing High Profits...');
        console.log('[App] Version: 2.0.0 - Grow System');

        // Initialize state (creates initial plots)
        HP.State.init();

        // Initialize UI renderer
        HP.Renderer.init();

        // Initialize scrolling news ticker
        if (HP.NewsTicker) {
            HP.NewsTicker.init();
        }

        // Initialize tooltips
        if (HP.Tooltips) {
            HP.Tooltips.init();
        }

        // Initialize sound manager
        if (HP.SoundManager) {
            HP.SoundManager.init();
        }

        // Initialize event handlers
        HP.Events.init();

        // Initialize tutorial system
        if (HP.Tutorial) {
            HP.Tutorial.init();
        }

        // Try to load saved game
        var hasLoaded = false;
        if (HP.SaveManager.hasSave()) {
            hasLoaded = HP.SaveManager.load();
            if (hasLoaded) {
                var saveInfo = HP.SaveManager.getSaveInfo();
                console.log('[App] Loaded save from:', saveInfo.date);
            }
        }

        // If no save loaded, state is already initialized with defaults
        if (!hasLoaded) {
            console.log('[App] Starting new game');
        }

        // Set up state change listeners
        setupStateListeners();

        // Initial UI render
        HP.Renderer.update();

        // Start game loop
        HP.GameLoop.start();

        // Initialize market orders
        if (HP.MarketOrders) {
            HP.MarketOrders.initialize();
        }

        // Start auto-save
        HP.SaveManager.startAutoSave();

        // Set up before unload handler
        window.addEventListener('beforeunload', function() {
            HP.SaveManager.save();
        });

        // Set up visibility change handler
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                HP.SaveManager.save();
            } else {
                var saveInfo = HP.SaveManager.getSaveInfo();
                if (saveInfo) {
                    HP.GameLoop.processOfflineProgress(saveInfo.timestamp);
                    HP.Renderer.update();
                }
            }
        });

        isInitialized = true;
        console.log('[App] Initialization complete!');

        // Show welcome message
        if (!hasLoaded) {
            setTimeout(function() {
                HP.Notifications.info('Welcome to High Profits! Buy equipment and seeds to start growing.');
            }, 500);
        }
    }

    /**
     * Set up listeners for state changes
     */
    function setupStateListeners() {
        HP.State.addListener(function(key, value, state) {
            if (key === 'levelUp') {
                handleLevelUp(value);
            }
        });
    }

    /**
     * Handle level up event
     */
    function handleLevelUp(data) {
        HP.Notifications.levelUp(data.level, data.rank);
        HP.Renderer.update();
        
        // Check for level-based tutorial hints
        if (HP.Tutorial) {
            HP.Tutorial.checkLevelHint(data.level);
        }
    }

    /**
     * Get initialization status
     */
    function isReady() {
        return isInitialized;
    }

    /**
     * Restart the game
     */
    function restart() {
        HP.GameLoop.stop();
        HP.SaveManager.stopAutoSave();
        isInitialized = false;
        init();
    }

    /**
     * Get game version info
     */
    function getVersion() {
        return {
            name: 'High Profits',
            version: '2.0.0',
            build: 'grow-system'
        };
    }

    // Public API
    return {
        init: init,
        isReady: isReady,
        restart: restart,
        getVersion: getVersion
    };
})();

// Auto-initialize when DOM is ready
(function() {
    'use strict';

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', HP.App.init);
    } else {
        HP.App.init();
    }
})();
