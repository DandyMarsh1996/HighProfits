/**
 * HighProfits - Particle Effects
 * Sparkles on harvest, coins on sale
 */
var HP = HP || {};

HP.Particles = (function() {
    'use strict';

    var container = null;

    function getContainer() {
        if (container) return container;
        container = document.getElementById('particles-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'particles-container';
            container.className = 'particles-container';
            container.setAttribute('aria-hidden', 'true');
            document.body.insertBefore(container, document.body.firstChild);
        }
        return container;
    }

    function getPosition(options) {
        if (options.x != null && options.y != null) {
            return { x: options.x, y: options.y };
        }
        if (options.element) {
            var rect = options.element.getBoundingClientRect();
            return {
                x: rect.left + rect.width / 2,
                y: rect.top + rect.height / 2
            };
        }
        return { x: window.innerWidth / 2, y: window.innerHeight / 2 };
    }

    /**
     * Emit harvest sparkles (around an element or at x,y)
     */
    function emitHarvest(options) {
        options = options || {};
        var pos = getPosition(options);
        var count = 10;
        var chars = ['✨', '⭐', '✦', '✧', '◆'];
        var el = getContainer();

        for (var i = 0; i < count; i++) {
            var p = document.createElement('div');
            p.className = 'particle particle-sparkle';
            p.textContent = chars[Math.floor(Math.random() * chars.length)];
            p.style.left = pos.x + 'px';
            p.style.top = pos.y + 'px';
            var angle = (i / count) * Math.PI * 2 + Math.random() * 0.5;
            var dist = 30 + Math.random() * 50;
            var tx = Math.cos(angle) * dist;
            var ty = -40 - Math.random() * 60 - dist * 0.5;
            p.style.setProperty('--tx', tx + 'px');
            p.style.setProperty('--ty', ty + 'px');
            p.style.animationDelay = (i * 0.03) + 's';
            el.appendChild(p);
            setTimeout(function(node) {
                if (node.parentNode) node.parentNode.removeChild(node);
            }, 900, p);
        }
    }

    /**
     * Emit coin burst (sale)
     */
    function emitSale(options) {
        options = options || {};
        var pos = getPosition(options);
        var count = 8;
        var el = getContainer();

        for (var i = 0; i < count; i++) {
            var p = document.createElement('div');
            p.className = 'particle particle-coin';
            p.textContent = '¢';
            p.style.left = pos.x + 'px';
            p.style.top = pos.y + 'px';
            var angle = (i / count) * Math.PI * 2 + Math.random() * 0.4;
            var dist = 25 + Math.random() * 45;
            var tx = Math.cos(angle) * dist;
            var ty = -30 - Math.random() * 50 - dist * 0.3;
            p.style.setProperty('--tx', tx + 'px');
            p.style.setProperty('--ty', ty + 'px');
            p.style.animationDelay = (i * 0.04) + 's';
            el.appendChild(p);
            setTimeout(function(node) {
                if (node.parentNode) node.parentNode.removeChild(node);
            }, 800, p);
        }
    }

    return {
        emitHarvest: emitHarvest,
        emitSale: emitSale
    };
})();
