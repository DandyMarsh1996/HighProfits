/**
 * Error boundary – catches errors and shows a user-friendly message instead of breaking.
 */
var HP = HP || {};

HP.ErrorHandler = (function() {
    'use strict';

    var errorOverlay = null;

    function createOverlay() {
        if (errorOverlay) return;
        errorOverlay = document.createElement('div');
        errorOverlay.id = 'error-boundary-overlay';
        errorOverlay.className = 'error-boundary-overlay';
        errorOverlay.innerHTML = '<div class="error-boundary-content">' +
            '<h2>Something went wrong</h2>' +
            '<p class="error-boundary-message">The game encountered an error. You can try refreshing the page.</p>' +
            '<button type="button" id="error-boundary-dismiss" class="error-boundary-dismiss">Dismiss</button>' +
            '</div>';
        errorOverlay.classList.add('hidden');
        errorOverlay.addEventListener('click', function(e) {
            if (e.target.id === 'error-boundary-dismiss') hide();
        });
        document.body.appendChild(errorOverlay);
    }

    function show(message) {
        createOverlay();
        var msgEl = errorOverlay.querySelector('.error-boundary-message');
        if (msgEl) msgEl.textContent = message || 'The game encountered an error. You can try refreshing the page.';
        errorOverlay.classList.remove('hidden');
    }

    function hide() {
        if (errorOverlay) errorOverlay.classList.add('hidden');
    }

    function wrap(fn, fallbackMessage) {
        return function() {
            try {
                return fn.apply(this, arguments);
            } catch (err) {
                console.error('[ErrorHandler]', err);
                show(fallbackMessage || err.message || 'An unexpected error occurred.');
                return undefined;
            }
        };
    }

    function init() {
        window.addEventListener('error', function(e) {
            if (e.error) {
                console.error('[ErrorHandler] Uncaught:', e.error);
                show('An unexpected error occurred. Try refreshing the page.');
                e.preventDefault();
                return true;
            }
        });
        window.addEventListener('unhandledrejection', function(e) {
            console.error('[ErrorHandler] Unhandled promise:', e.reason);
            show('Something went wrong. Try refreshing the page.');
            e.preventDefault();
        });
        createOverlay();
    }

    return {
        init: init,
        show: show,
        hide: hide,
        wrap: wrap
    };
})();
