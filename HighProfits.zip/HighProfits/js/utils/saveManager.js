/**
 * HighProfits - Save Manager Module
 * Handles localStorage save/load and file export/import
 */
var HP = HP || {};

HP.SaveManager = (function() {
    'use strict';

    // Get constants from data module (with fallbacks for safety)
    function getConstants() {
        if (HP.Data && HP.Data.Constants) {
            return HP.Data.Constants;
        }
        // Fallback values
        return {
            SAVE_KEY: 'highprofits_save',
            SAVE_VERSION: 1,
            AUTO_SAVE_INTERVAL: 60000
        };
    }

    var autoSaveInterval = null;

    /**
     * Save game state to localStorage
     * @returns {boolean} True if successful
     */
    function save() {
        try {
            var constants = getConstants();
            var state = HP.State.exportState();
            var saveData = {
                version: constants.SAVE_VERSION,
                timestamp: Date.now(),
                state: state
            };

            localStorage.setItem(constants.SAVE_KEY, JSON.stringify(saveData));
            
            // Update save indicator
            updateSaveIndicator('saved');
            
            console.log('[SaveManager] Game saved at', new Date().toLocaleTimeString());
            return true;
        } catch (e) {
            console.error('[SaveManager] Failed to save:', e);
            return false;
        }
    }

    /**
     * Update the save status indicator in UI
     */
    function updateSaveIndicator(status) {
        var statusEl = document.getElementById('save-status');
        var textEl = document.getElementById('save-text');
        
        if (!statusEl || !textEl) return;
        
        if (status === 'saving') {
            statusEl.classList.add('saving');
            statusEl.classList.remove('saved');
            textEl.textContent = 'Saving...';
        } else if (status === 'saved') {
            statusEl.classList.remove('saving');
            statusEl.classList.add('saved');
            textEl.textContent = 'Saved!';
            
            // Reset after 2 seconds
            setTimeout(function() {
                if (textEl) textEl.textContent = 'Auto-save on';
                if (statusEl) statusEl.classList.remove('saved');
            }, 2000);
        }
    }

    /**
     * Load game state from localStorage
     * @returns {boolean} True if successful
     */
    function load() {
        try {
            var constants = getConstants();
            var saveJson = localStorage.getItem(constants.SAVE_KEY);
            
            if (!saveJson) {
                console.log('[SaveManager] No save data found');
                return false;
            }

            var saveData = JSON.parse(saveJson);

            // Version migration if needed
            if (saveData.version !== constants.SAVE_VERSION) {
                saveData = migrateVersion(saveData);
            }

            // Import state
            HP.State.importState(saveData.state);

            // Process offline progress
            if (saveData.timestamp) {
                var offlineResult = HP.GameLoop.processOfflineProgress(saveData.timestamp);
                if (offlineResult.processed) {
                    var minutes = Math.floor(offlineResult.seconds / 60);
                    console.log('[SaveManager] Processed', minutes, 'minutes of offline progress');
                }
            }

            console.log('[SaveManager] Game loaded');
            return true;
        } catch (e) {
            console.error('[SaveManager] Failed to load:', e);
            return false;
        }
    }

    /**
     * Check if a save exists
     * @returns {boolean} True if save exists
     */
    function hasSave() {
        var constants = getConstants();
        return localStorage.getItem(constants.SAVE_KEY) !== null;
    }

    /**
     * Clear saved game
     */
    function clear() {
        var constants = getConstants();
        localStorage.removeItem(constants.SAVE_KEY);
        console.log('[SaveManager] Save cleared');
    }

    /**
     * Migrate save data from older versions
     * @param {Object} saveData - Old save data
     * @returns {Object} Migrated save data
     */
    function migrateVersion(saveData) {
        var constants = getConstants();
        console.log('[SaveManager] Migrating save from version', saveData.version, 'to', constants.SAVE_VERSION);
        
        // Add migration logic here as versions change
        // For now, just update the version
        saveData.version = constants.SAVE_VERSION;
        
        return saveData;
    }

    /**
     * Export save to downloadable JSON file
     */
    function exportToFile() {
        try {
            var constants = getConstants();
            var state = HP.State.exportState();
            var saveData = {
                version: constants.SAVE_VERSION,
                timestamp: Date.now(),
                exportedAt: new Date().toISOString(),
                state: state
            };

            var json = JSON.stringify(saveData, null, 2);
            var blob = new Blob([json], { type: 'application/json' });
            var url = URL.createObjectURL(blob);

            // Create download link
            var a = document.createElement('a');
            a.href = url;
            a.download = 'highprofits_save_' + Date.now() + '.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            console.log('[SaveManager] Save exported to file');
        } catch (e) {
            console.error('[SaveManager] Failed to export:', e);
        }
    }

    /**
     * Import save from JSON file
     * @param {File} file - File object to import
     * @param {Function} callback - Callback with success boolean
     */
    function importFromFile(file, callback) {
        if (!file) {
            callback(false);
            return;
        }

        var constants = getConstants();
        var reader = new FileReader();

        reader.onload = function(e) {
            try {
                var saveData = JSON.parse(e.target.result);

                // Validate save data
                if (!saveData.state || !saveData.version) {
                    throw new Error('Invalid save file format');
                }

                // Version migration if needed
                if (saveData.version !== constants.SAVE_VERSION) {
                    saveData = migrateVersion(saveData);
                }

                // Import state
                HP.State.importState(saveData.state);

                // Also save to localStorage
                save();

                console.log('[SaveManager] Save imported from file');
                callback(true);
            } catch (err) {
                console.error('[SaveManager] Failed to import:', err);
                callback(false);
            }
        };

        reader.onerror = function() {
            console.error('[SaveManager] Failed to read file');
            callback(false);
        };

        reader.readAsText(file);
    }

    /**
     * Start auto-save interval
     * @param {number} intervalMs - Interval in milliseconds (default: 30000)
     */
    function startAutoSave(intervalMs) {
        intervalMs = intervalMs || 30000; // Default 30 seconds

        if (autoSaveInterval) {
            clearInterval(autoSaveInterval);
        }

        autoSaveInterval = setInterval(function() {
            updateSaveIndicator('saving');
            setTimeout(function() {
                save();
            }, 300);
        }, intervalMs);

        console.log('[SaveManager] Auto-save started (every', intervalMs / 1000, 'seconds)');
    }

    /**
     * Stop auto-save interval
     */
    function stopAutoSave() {
        if (autoSaveInterval) {
            clearInterval(autoSaveInterval);
            autoSaveInterval = null;
            console.log('[SaveManager] Auto-save stopped');
        }
    }

    /**
     * Get save metadata without loading full state
     * @returns {Object|null} Save metadata
     */
    function getSaveInfo() {
        try {
            var constants = getConstants();
            var saveJson = localStorage.getItem(constants.SAVE_KEY);
            if (!saveJson) {
                return null;
            }

            var saveData = JSON.parse(saveJson);
            return {
                version: saveData.version,
                timestamp: saveData.timestamp,
                date: new Date(saveData.timestamp).toLocaleString()
            };
        } catch (e) {
            return null;
        }
    }

    /**
     * Create a backup of current save
     * @returns {string|null} Backup key or null if failed
     */
    function createBackup() {
        try {
            var constants = getConstants();
            var saveJson = localStorage.getItem(constants.SAVE_KEY);
            if (!saveJson) {
                return null;
            }

            var backupKey = constants.SAVE_KEY + '_backup_' + Date.now();
            localStorage.setItem(backupKey, saveJson);
            console.log('[SaveManager] Backup created:', backupKey);
            return backupKey;
        } catch (e) {
            console.error('[SaveManager] Failed to create backup:', e);
            return null;
        }
    }

    // Public API
    return {
        save: save,
        load: load,
        hasSave: hasSave,
        clear: clear,
        exportToFile: exportToFile,
        importFromFile: importFromFile,
        startAutoSave: startAutoSave,
        stopAutoSave: stopAutoSave,
        getSaveInfo: getSaveInfo,
        createBackup: createBackup
    };
})();
