/**
 * HighProfits - Save Manager Module
 * Handles localStorage save/load and file export/import
 */
var HP = HP || {};

HP.SaveManager = (function() {
    'use strict';

    // Get constants from data module (with fallbacks for safety)
    function getConstants() {
        if (HP.Data && HP.Data.Constants) {
            return HP.Data.Constants;
        }
        // Fallback values
        return {
            SAVE_KEY: 'highprofits_save',
            SAVE_VERSION: 1,
            AUTO_SAVE_INTERVAL: 60000
        };
    }

    var autoSaveInterval = null;

    var BACKUP_KEY_SUFFIX = '_backup';

    function getBlob() {
        var constants = getConstants();
        var key = constants.SAVE_KEY;
        var backupKey = key + BACKUP_KEY_SUFFIX;
        var raw = null;
        try {
            raw = localStorage.getItem(key);
            if (raw) {
                var blob = JSON.parse(raw);
                if (blob && typeof blob === 'object') return blob;
            }
            raw = localStorage.getItem(backupKey);
            if (raw) {
                var blob = JSON.parse(raw);
                if (blob && typeof blob === 'object') {
                    localStorage.setItem(key, raw);
                    console.log('[SaveManager] Restored save from backup key');
                    return blob;
                }
            }
        } catch (e) {
            try {
                raw = localStorage.getItem(backupKey);
                if (raw) {
                    var blob = JSON.parse(raw);
                    if (blob && typeof blob === 'object') {
                        localStorage.setItem(key, raw);
                        console.log('[SaveManager] Restored save from backup after primary read error');
                        return blob;
                    }
                }
            } catch (e2) {}
        }
        return null;
    }

    function setBlob(saveData) {
        var constants = getConstants();
        var key = constants.SAVE_KEY;
        var backupKey = key + BACKUP_KEY_SUFFIX;
        var json = JSON.stringify(saveData);
        try {
            localStorage.setItem(key, json);
            localStorage.setItem(backupKey, json);
        } catch (e) {
            try {
                localStorage.setItem(key, json);
            } catch (e2) {
                throw e;
            }
        }
    }

    /**
     * Save game state to localStorage (per current character).
     * Persists full state (money, inventory, characterName, tutorial, progress, workers, etc.)
     * and character meta (name, titles). Also writes to backup key for resilience.
     * @returns {boolean} True if successful
     */
    function save() {
        try {
            updateSaveIndicator('saving');
            var constants = getConstants();
            var state = HP.State.exportState();
            var cid = state.characterId;
            if (!cid) {
                var legacyPayload = {
                    version: constants.SAVE_VERSION,
                    timestamp: Date.now(),
                    state: state
                };
                var legacyJson = JSON.stringify(legacyPayload);
                localStorage.setItem(constants.SAVE_KEY, legacyJson);
                localStorage.setItem(constants.SAVE_KEY + BACKUP_KEY_SUFFIX, legacyJson);
                updateSaveIndicator('saved');
                return true;
            }
            var blob = getBlob();
            if (!blob || !blob.characters) blob = { version: constants.SAVE_VERSION, currentCharacterId: cid, characters: {} };
            var meta = (blob.characters[cid] && blob.characters[cid].meta) || { createdAt: Date.now(), lastPlayed: Date.now(), unlockedTitles: [], selectedTitleId: 'street_hustler', notes: '' };
            var nameFromState = (state.characterName && String(state.characterName).trim()) ? String(state.characterName).trim() : null;
            var nameFromMeta = (meta.name && String(meta.name).trim()) ? String(meta.name).trim() : null;
            var displayName = nameFromState || nameFromMeta || 'Player';
            state.characterName = displayName;
            blob.characters[cid] = {
                meta: {
                    name: displayName,
                    createdAt: meta.createdAt,
                    lastPlayed: Date.now(),
                    unlockedTitles: state.unlockedTitles || [],
                    selectedTitleId: state.selectedTitleId || 'street_hustler',
                    notes: meta.notes != null ? meta.notes : ''
                },
                state: state
            };
            blob.currentCharacterId = cid;
            blob.version = constants.SAVE_VERSION;
            blob.timestamp = Date.now();
            setBlob(blob);
            updateSaveIndicator('saved');
            console.log('[SaveManager] Game saved at', new Date().toLocaleTimeString(), '| Character:', displayName, '| TutorialStep:', state.tutorialStep, '| TourCompleted:', state.tourCompleted);
            return true;
        } catch (e) {
            console.error('[SaveManager] Failed to save:', e);
            updateSaveIndicator('error');
            if (HP.Notifications) HP.Notifications.error('Failed to save game. You can try again from the save status.');
            return false;
        }
    }

    /**
     * Update the save status indicator in UI
     */
    function updateSaveIndicator(status) {
        var statusEl = document.getElementById('save-status');
        var textEl = document.getElementById('save-text');
        var iconEl = statusEl ? statusEl.querySelector('.save-icon') : null;

        if (!statusEl || !textEl) return;

        if (status === 'saving') {
            statusEl.classList.add('saving');
            statusEl.classList.remove('saved', 'loading', 'error');
            if (iconEl) iconEl.textContent = '\u23F3'; /* ⏳ */
            textEl.textContent = 'Saving...';
        } else if (status === 'loading') {
            statusEl.classList.add('saving');
            statusEl.classList.remove('saved');
            if (iconEl) iconEl.textContent = '\u23F3';
            textEl.textContent = 'Loading...';
        } else if (status === 'saved') {
            statusEl.classList.remove('saving', 'loading', 'error');
            statusEl.classList.add('saved');
            if (iconEl) iconEl.textContent = '\u2713'; /* ✓ */
            textEl.textContent = 'Saved!';
            setTimeout(function() {
                if (textEl) textEl.textContent = 'Auto-save on';
                if (iconEl) iconEl.textContent = '\uD83D\uDCDE'; /* 💾 */
                if (statusEl) statusEl.classList.remove('saved');
            }, 2000);
        } else if (status === 'loaded') {
            statusEl.classList.remove('saving', 'loading', 'error');
            statusEl.classList.add('saved');
            if (iconEl) iconEl.textContent = '\u2713';
            textEl.textContent = 'Loaded!';
            setTimeout(function() {
                if (textEl) textEl.textContent = 'Auto-save on';
                if (iconEl) iconEl.textContent = '\uD83D\uDCDE';
                if (statusEl) statusEl.classList.remove('saved');
            }, 2000);
        } else if (status === 'error') {
            statusEl.classList.add('error');
            statusEl.classList.remove('saving', 'saved', 'loading');
            if (iconEl) iconEl.textContent = '\u26A0'; /* ⚠ */
            textEl.textContent = 'Save failed – click to retry';
            statusEl.setAttribute('role', 'button');
            statusEl.setAttribute('tabindex', '0');
            statusEl.setAttribute('title', 'Retry save');
        } else if (status === 'idle') {
            statusEl.classList.remove('saving', 'saved', 'loading', 'error');
            if (iconEl) iconEl.textContent = '\uD83D\uDCDE';
            textEl.textContent = 'Auto-save on';
            statusEl.removeAttribute('role');
            statusEl.removeAttribute('tabindex');
        }
    }

    /**
     * Load game state from localStorage (current character).
     * Tries primary key then backup key so persistence survives cache eviction.
     * @returns {boolean} True if a character was loaded
     */
    function load() {
        try {
            updateSaveIndicator('loading');
            var constants = getConstants();
            var blob = getBlob();
            if (!blob) {
                console.log('[SaveManager] No save data found (primary or backup)');
                updateSaveIndicator('idle');
                return false;
            }
            var saveData = blob;
            if (saveData.version !== constants.SAVE_VERSION) {
                saveData = migrateVersion(saveData);
                setBlob(saveData);
            }
            if (saveData.characters && saveData.currentCharacterId && saveData.characters[saveData.currentCharacterId]) {
                var charState = saveData.characters[saveData.currentCharacterId].state;
                HP.State.importState(charState);
                if (saveData.timestamp && HP.GameLoop && HP.GameLoop.processOfflineProgress) {
                    var offlineResult = HP.GameLoop.processOfflineProgress(saveData.timestamp);
                    if (offlineResult.processed) {
                        var minutes = Math.floor(offlineResult.seconds / 60);
                        console.log('[SaveManager] Processed', minutes, 'minutes of offline progress');
                    }
                }
                console.log('[SaveManager] Game loaded | Character:', charState.characterName, '| TutorialStep:', charState.tutorialStep, '| TourCompleted:', charState.tourCompleted);
                updateSaveIndicator('loaded');
                return true;
            }
            if (saveData.state) {
                HP.State.importState(saveData.state);
                var state = HP.State.exportState ? HP.State.exportState() : HP.State.getState ? HP.State.getState() : null;
                if (state && !state.characterId) {
                    state.characterId = 'char_legacy';
                    state.characterName = (state.characterName && String(state.characterName).trim()) ? String(state.characterName).trim() : 'Player';
                    if (HP.State.setCharacterId) HP.State.setCharacterId('char_legacy');
                    if (HP.State.setCharacterName) HP.State.setCharacterName(state.characterName);
                }
                if (saveData.timestamp && HP.GameLoop && HP.GameLoop.processOfflineProgress) {
                    var offlineResult = HP.GameLoop.processOfflineProgress(saveData.timestamp);
                    if (offlineResult.processed) {
                        var minutes = Math.floor(offlineResult.seconds / 60);
                        console.log('[SaveManager] Processed', minutes, 'minutes of offline progress');
                    }
                }
                console.log('[SaveManager] Game loaded (legacy) | TutorialStep:', state && state.tutorialStep, '| CharacterName:', state && state.characterName);
                updateSaveIndicator('loaded');
                setTimeout(function() { save(); }, 50);
                return true;
            }
            updateSaveIndicator('idle');
            return false;
        } catch (e) {
            console.error('[SaveManager] Failed to load:', e);
            updateSaveIndicator('idle');
            return false;
        }
    }

    /**
     * Check if a save exists (any character or legacy)
     * @returns {boolean} True if save exists
     */
    function hasSave() {
        return getBlob() !== null;
    }

    /**
     * Get list of characters for select screen
     * @returns {Array} { id, name, lastPlayed }[]
     */
    function getCharacterList() {
        var blob = getBlob();
        if (!blob) return [];
        if (blob.state && !blob.characters) {
            migrateLegacyBlob(blob);
            setBlob(blob);
        }
        if (blob.characters) {
            return Object.keys(blob.characters).map(function(id) {
                var ch = blob.characters[id];
                var m = ch && ch.meta ? ch.meta : {};
                var stateName = (ch && ch.state && ch.state.characterName && String(ch.state.characterName).trim()) ? String(ch.state.characterName).trim() : null;
                var name = (m.name && String(m.name).trim()) ? m.name : (stateName || 'Player');
                return { id: id, name: name, lastPlayed: m.lastPlayed || 0, notes: m.notes != null ? m.notes : '' };
            });
        }
        return [];
    }

    /**
     * Get current character id from blob (no load)
     */
    function getCurrentCharacterId() {
        var blob = getBlob();
        if (!blob) return null;
        return blob.currentCharacterId || (blob.state ? 'char_legacy' : null);
    }

    /**
     * Create a new character and set as current
     * @param {string} name - Character name
     * @returns {string} New character id
     */
    function createCharacter(name) {
        var constants = getConstants();
        var id = 'char_' + Date.now();
        HP.State.reset();
        HP.State.setCharacterId(id);
        var displayName = (name && String(name).trim()) ? String(name).trim() : 'Player';
        HP.State.setCharacterName(displayName);
        var defaultTitle = (HP.Data.Titles && HP.Data.Titles.getDefaultId()) ? HP.Data.Titles.getDefaultId() : 'street_hustler';
        HP.State.setUnlockedTitles([defaultTitle]);
        HP.State.setSelectedTitleId(defaultTitle);
        var state = HP.State.exportState();
        state.characterName = displayName;
        var blob = getBlob();
        if (!blob || !blob.characters) blob = { version: constants.SAVE_VERSION, currentCharacterId: id, characters: {} };
        blob.characters[id] = {
            meta: {
                name: displayName,
                createdAt: Date.now(),
                lastPlayed: Date.now(),
                unlockedTitles: state.unlockedTitles || [defaultTitle],
                selectedTitleId: state.selectedTitleId || defaultTitle,
                notes: ''
            },
            state: state
        };
        blob.currentCharacterId = id;
        blob.version = constants.SAVE_VERSION;
        blob.timestamp = Date.now();
        setBlob(blob);
        console.log('[SaveManager] Character created:', displayName);
        return id;
    }

    /**
     * Set optional note/label for a character (for character select screen)
     * @param {string} id - Character id
     * @param {string} note - Note text (empty to clear)
     * @returns {boolean} True if updated
     */
    function setCharacterNote(id, note) {
        var blob = getBlob();
        if (!blob || !blob.characters || !blob.characters[id]) return false;
        if (!blob.characters[id].meta) blob.characters[id].meta = {};
        blob.characters[id].meta.notes = (note && note.trim()) ? note.trim().slice(0, 80) : '';
        blob.timestamp = Date.now();
        setBlob(blob);
        return true;
    }

    /**
     * Ensure a legacy blob (state but no characters) is migrated to characters format
     * @param {Object} blob - Save blob
     * @returns {Object} Updated blob (mutates and returns)
     */
    function migrateLegacyBlob(blob) {
        if (!blob || !blob.state || blob.characters) return blob;
        var s = blob.state;
        s.characterId = 'char_legacy';
        s.characterName = (s.characterName && s.characterName.trim()) ? s.characterName.trim() : 'Player';
        s.unlockedTitles = s.unlockedTitles || ['street_hustler'];
        s.selectedTitleId = s.selectedTitleId || 'street_hustler';
        s.journalCompleted = s.journalCompleted || {};
        blob.characters = {
            char_legacy: {
                meta: {
                    name: s.characterName,
                    createdAt: blob.timestamp || Date.now(),
                    lastPlayed: blob.timestamp || Date.now(),
                    unlockedTitles: s.unlockedTitles,
                    selectedTitleId: s.selectedTitleId,
                    notes: ''
                },
                state: s
            }
        };
        blob.currentCharacterId = 'char_legacy';
        return blob;
    }

    /**
     * Select a character by id and load their state
     * @param {string} id - Character id
     * @returns {boolean} Success
     */
    function selectCharacter(id) {
        var blob = getBlob();
        if (!blob) return false;
        if (blob.state && !blob.characters && id === 'char_legacy') {
            migrateLegacyBlob(blob);
            setBlob(blob);
        }
        if (!blob.characters || !blob.characters[id]) return false;
        blob.currentCharacterId = id;
        blob.timestamp = Date.now();
        var ch = blob.characters[id];
        var loadedState = ch.state || {};
        var metaName = (ch.meta && ch.meta.name && String(ch.meta.name).trim()) ? String(ch.meta.name).trim() : null;
        var stateName = (loadedState.characterName && String(loadedState.characterName).trim()) ? String(loadedState.characterName).trim() : null;
        var loadedName = stateName || metaName || 'Player';
        if (!loadedState.characterName || !String(loadedState.characterName).trim()) {
            loadedState.characterName = loadedName;
        }
        HP.State.importState(loadedState);
        if (HP.State.setCharacterName) HP.State.setCharacterName(loadedName);
        if (loadedState.tutorialStep != null && typeof loadedState.tutorialStep === 'number') {
            if (HP.State.setTutorialStep) HP.State.setTutorialStep(loadedState.tutorialStep);
        }
        if (loadedState.tutorialCompleted === true && HP.State.completeTutorial) {
            HP.State.completeTutorial();
        }
        if (loadedState.tourCompleted === true && HP.State.setTourCompleted) {
            HP.State.setTourCompleted(true);
        }
        if (blob.characters[id].meta) {
            blob.characters[id].meta.name = loadedName;
        }
        setBlob(blob);
        // Migrate only truly old saves that lack these keys (do not overwrite when already present)
        if (!loadedState.hasOwnProperty('tourCompleted') && HP.State.setTourCompleted) {
            HP.State.setTourCompleted(true);
        }
        if (!loadedState.hasOwnProperty('tutorialStep') && HP.State.setTutorialStep) {
            HP.State.setTutorialStep(loadedState.tutorialStep != null ? loadedState.tutorialStep : 0);
        }
        // Process offline progress
        if (blob.timestamp && HP.GameLoop && HP.GameLoop.processOfflineProgress) {
            HP.GameLoop.processOfflineProgress(blob.timestamp);
        }
        // Immediately save after loading to persist any migrations and ensure blob is in sync
        setTimeout(function() {
            save();
        }, 100);
        console.log('[SaveManager] Character selected:', id, '| Name:', loadedName, '| TutorialStep:', loadedState.tutorialStep, '| TourCompleted:', loadedState.tourCompleted);
        return true;
    }

    /**
     * Delete a character by id. If it was the current character, clears current or selects another.
     * @param {string} id - Character id
     * @returns {boolean} True if deleted
     */
    function deleteCharacter(id) {
        var blob = getBlob();
        if (!blob) return false;
        if (blob.state && !blob.characters && id === 'char_legacy') {
            migrateLegacyBlob(blob);
            setBlob(blob);
        }
        if (!blob.characters || !blob.characters[id]) return false;
        delete blob.characters[id];
        if (blob.currentCharacterId === id) {
            var remaining = Object.keys(blob.characters);
            blob.currentCharacterId = remaining.length > 0 ? remaining[0] : null;
        }
        if (Object.keys(blob.characters).length === 0) {
            var c = getConstants();
            localStorage.removeItem(c.SAVE_KEY);
            localStorage.removeItem(c.SAVE_KEY + BACKUP_KEY_SUFFIX);
            console.log('[SaveManager] Character deleted; no characters left, save cleared');
        } else {
            blob.timestamp = Date.now();
            setBlob(blob);
            console.log('[SaveManager] Character deleted:', id);
        }
        return true;
    }

    /**
     * Clear saved game
     */
    function clear() {
        var constants = getConstants();
        localStorage.removeItem(constants.SAVE_KEY);
        localStorage.removeItem(constants.SAVE_KEY + BACKUP_KEY_SUFFIX);
        console.log('[SaveManager] Save cleared');
    }

    /**
     * Migrate save data from older versions
     * @param {Object} saveData - Old save data
     * @returns {Object} Migrated save data
     */
    function migrateVersion(saveData) {
        var constants = getConstants();
        console.log('[SaveManager] Migrating save from version', saveData.version, 'to', constants.SAVE_VERSION);
        if (saveData.version === 1 && constants.SAVE_VERSION >= 2 && saveData.state) {
            var s = saveData.state;
            s.characterId = 'char_legacy';
            s.characterName = s.characterName || 'Player';
            s.unlockedTitles = s.unlockedTitles || ['street_hustler'];
            s.selectedTitleId = s.selectedTitleId || 'street_hustler';
            s.journalCompleted = s.journalCompleted || {};
            saveData.characters = {
                char_legacy: {
                    meta: {
                        name: s.characterName,
                        createdAt: saveData.timestamp || Date.now(),
                        lastPlayed: saveData.timestamp || Date.now(),
                        unlockedTitles: s.unlockedTitles,
                        selectedTitleId: s.selectedTitleId
                    },
                    state: s
                }
            };
            saveData.currentCharacterId = 'char_legacy';
        }
        saveData.version = constants.SAVE_VERSION;
        return saveData;
    }

    /**
     * Export save to downloadable JSON file
     */
    function exportToFile() {
        try {
            var constants = getConstants();
            var state = HP.State.exportState();
            var saveData = {
                version: constants.SAVE_VERSION,
                timestamp: Date.now(),
                exportedAt: new Date().toISOString(),
                state: state
            };

            var json = JSON.stringify(saveData, null, 2);
            var blob = new Blob([json], { type: 'application/json' });
            var url = URL.createObjectURL(blob);

            // Create download link
            var a = document.createElement('a');
            a.href = url;
            a.download = 'highprofits_save_' + Date.now() + '.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            console.log('[SaveManager] Save exported to file');
        } catch (e) {
            console.error('[SaveManager] Failed to export:', e);
        }
    }

    /**
     * Import save from JSON file
     * @param {File} file - File object to import
     * @param {Function} callback - Callback with success boolean
     */
    function importFromFile(file, callback) {
        if (!file) {
            callback(false);
            return;
        }

        var constants = getConstants();
        var reader = new FileReader();

        reader.onload = function(e) {
            try {
                var saveData = JSON.parse(e.target.result);

                // Validate save data
                if (!saveData.state || !saveData.version) {
                    throw new Error('Invalid save file format');
                }

                // Version migration if needed
                if (saveData.version !== constants.SAVE_VERSION) {
                    saveData = migrateVersion(saveData);
                }

                // Import state (includes characterName, tutorialStep, tutorialCompleted, tourCompleted, progressTriggers)
                HP.State.importState(saveData.state);

                // Persist to localStorage so progress is in browser cache; save() writes current state to blob
                save();

                var state = HP.State.exportState();
                console.log('[SaveManager] Save imported from file | Character:', state.characterName, '| Tutorial:', state.tutorialStep, '| Tour:', state.tourCompleted);
                callback(true);
            } catch (err) {
                console.error('[SaveManager] Failed to import:', err);
                callback(false);
            }
        };

        reader.onerror = function() {
            console.error('[SaveManager] Failed to read file');
            callback(false);
        };

        reader.readAsText(file);
    }

    /**
     * Start auto-save interval. Saves to both primary and backup keys so data persists across refreshes.
     * @param {number} intervalMs - Interval in milliseconds (default: 20000)
     */
    function startAutoSave(intervalMs) {
        intervalMs = intervalMs || 20000; // Default 20 seconds for better persistence

        if (autoSaveInterval) {
            clearInterval(autoSaveInterval);
        }

        autoSaveInterval = setInterval(function() {
            updateSaveIndicator('saving');
            setTimeout(function() {
                save();
            }, 300);
        }, intervalMs);

        console.log('[SaveManager] Auto-save started (every', intervalMs / 1000, 'seconds)');
    }

    /**
     * Stop auto-save interval
     */
    function stopAutoSave() {
        if (autoSaveInterval) {
            clearInterval(autoSaveInterval);
            autoSaveInterval = null;
            console.log('[SaveManager] Auto-save stopped');
        }
    }

    /**
     * Get save metadata without loading full state
     * @returns {Object|null} Save metadata
     */
    function getSaveInfo() {
        try {
            var saveData = getBlob();
            if (!saveData || !saveData.timestamp) return null;
            return {
                version: saveData.version,
                timestamp: saveData.timestamp,
                date: new Date(saveData.timestamp).toLocaleString()
            };
        } catch (e) {
            return null;
        }
    }

    /**
     * Create a backup of current save
     * @returns {string|null} Backup key or null if failed
     */
    function createBackup() {
        try {
            var constants = getConstants();
            var saveJson = localStorage.getItem(constants.SAVE_KEY);
            if (!saveJson) {
                return null;
            }

            var backupKey = constants.SAVE_KEY + '_backup_' + Date.now();
            localStorage.setItem(backupKey, saveJson);
            console.log('[SaveManager] Backup created:', backupKey);
            return backupKey;
        } catch (e) {
            console.error('[SaveManager] Failed to create backup:', e);
            return null;
        }
    }

    // Public API
    return {
        save: save,
        load: load,
        hasSave: hasSave,
        clear: clear,
        getCharacterList: getCharacterList,
        getCurrentCharacterId: getCurrentCharacterId,
        createCharacter: createCharacter,
        setCharacterNote: setCharacterNote,
        selectCharacter: selectCharacter,
        deleteCharacter: deleteCharacter,
        exportToFile: exportToFile,
        importFromFile: importFromFile,
        startAutoSave: startAutoSave,
        stopAutoSave: stopAutoSave,
        getSaveInfo: getSaveInfo,
        createBackup: createBackup
    };
})();
