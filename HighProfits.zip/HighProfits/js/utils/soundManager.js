/**
 * HighProfits - Sound Manager
 * Handles sound effects, ambient, and background music (menu + game themes)
 */
var HP = HP || {};

HP.SoundManager = (function() {
    'use strict';

    var MENU_THEME_URL = 'assets/menu-theme.mp3';
    var GAME_THEME_URL = 'assets/game-theme.mp3';

    var enabled = true;
    var volume = 0.5;
    var ambientEnabled = false;
    var musicEnabled = true;
    var musicVolume = 0.4;
    var audioContext = null;
    var sounds = {};
    var ambientOsc = null;
    var ambientGain = null;
    var menuMusic = null;
    var gameMusic = null;
    var pendingMusic = null;  // 'menu' | 'game' when play() was blocked (autoplay policy)

    function getMenuMusic() {
        if (!menuMusic) {
            menuMusic = new Audio(MENU_THEME_URL);
            menuMusic.loop = true;
            menuMusic.volume = Math.max(0, Math.min(1, musicVolume));
        }
        return menuMusic;
    }

    function getGameMusic() {
        if (!gameMusic) {
            gameMusic = new Audio(GAME_THEME_URL);
            gameMusic.loop = true;
            gameMusic.volume = Math.max(0, Math.min(1, musicVolume));
        }
        return gameMusic;
    }

    /**
     * Initialize sound system
     */
    function init() {
        // Check if user has previously disabled sounds
        var saved = localStorage.getItem('highprofits_sound_enabled');
        if (saved !== null) {
            enabled = saved === 'true';
        }

        var savedVolume = localStorage.getItem('highprofits_sound_volume');
        if (savedVolume !== null) {
            volume = parseFloat(savedVolume);
        }
        var savedAmbient = localStorage.getItem('highprofits_sound_ambient');
        if (savedAmbient !== null) ambientEnabled = savedAmbient === 'true';

        var savedMusic = localStorage.getItem('highprofits_music_enabled');
        if (savedMusic !== null) musicEnabled = savedMusic === 'true';
        var savedMusicVol = localStorage.getItem('highprofits_music_volume');
        if (savedMusicVol !== null) musicVolume = parseFloat(savedMusicVol);

        // Try to create audio context (requires user interaction first)
        try {
            if (typeof AudioContext !== 'undefined') {
                audioContext = new AudioContext();
            } else if (typeof webkitAudioContext !== 'undefined') {
                audioContext = new webkitAudioContext();
            }
        } catch (e) {
            console.log('[SoundManager] Audio context not available:', e);
        }

        console.log('[SoundManager] Initialized (enabled: ' + enabled + ', music: ' + musicEnabled + ')');
    }

    /**
     * Set sound on/off (for Settings menu)
     */
    function setEnabled(value) {
        enabled = !!value;
        localStorage.setItem('highprofits_sound_enabled', enabled.toString());
        if (!enabled) stopAmbient();
    }

    /**
     * Set volume (0.0 to 1.0)
     */
    function setVolume(newVolume) {
        volume = Math.max(0, Math.min(1, newVolume));
        localStorage.setItem('highprofits_sound_volume', volume.toString());
    }

    /**
     * Play a beep sound (simple tone)
     */
    function playBeep(frequency, duration, type) {
        if (!enabled || !audioContext) return;

        try {
            var oscillator = audioContext.createOscillator();
            var gainNode = audioContext.createGain();

            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);

            oscillator.frequency.value = frequency || 440;
            oscillator.type = type || 'sine';

            gainNode.gain.setValueAtTime(0, audioContext.currentTime);
            gainNode.gain.linearRampToValueAtTime(volume * 0.3, audioContext.currentTime + 0.01);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + (duration || 0.1));

            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + (duration || 0.1));
        } catch (e) {
            // Silently fail if audio context not available
        }
    }

    /**
     * Play sound for different events
     */
    function playSound(soundType) {
        if (!enabled) return;

        switch (soundType) {
            case 'click':
                playBeep(600, 0.05, 'sine');
                break;
            case 'success':
                playBeep(523, 0.1, 'sine');
                setTimeout(function() { playBeep(659, 0.1, 'sine'); }, 50);
                setTimeout(function() { playBeep(784, 0.15, 'sine'); }, 100);
                break;
            case 'error':
                playBeep(200, 0.2, 'sawtooth');
                break;
            case 'harvest':
                playBeep(440, 0.1, 'sine');
                setTimeout(function() { playBeep(554, 0.1, 'sine'); }, 80);
                break;
            case 'plant':
                playBeep(330, 0.08, 'sine');
                setTimeout(function() { playBeep(392, 0.08, 'sine'); }, 60);
                break;
            case 'water':
                playBeep(880, 0.05, 'sine');
                break;
            case 'sale':
                playBeep(659, 0.08, 'sine');
                setTimeout(function() { playBeep(784, 0.08, 'sine'); }, 60);
                setTimeout(function() { playBeep(988, 0.1, 'sine'); }, 120);
                break;
            case 'levelup':
                // Ascending scale
                var notes = [523, 659, 784, 1047];
                for (var i = 0; i < notes.length; i++) {
                    setTimeout(function(note) {
                        playBeep(note, 0.15, 'sine');
                    }.bind(null, notes[i]), i * 100);
                }
                break;
            case 'achievement':
                playBeep(880, 0.1, 'sine');
                setTimeout(function() { playBeep(1108, 0.15, 'sine'); }, 100);
                break;
            case 'contract':
                playBeep(587, 0.12, 'sine');
                setTimeout(function() { playBeep(784, 0.12, 'sine'); }, 80);
                setTimeout(function() { playBeep(988, 0.14, 'sine'); }, 160);
                break;
            case 'low_water':
                // Alert - pulsing low tone
                playBeep(300, 0.15, 'square');
                setTimeout(function() { playBeep(300, 0.15, 'square'); }, 200);
                break;
            case 'raid_warning':
                // Siren - alternating high/low
                playBeep(800, 0.2, 'sawtooth');
                setTimeout(function() { playBeep(600, 0.2, 'sawtooth'); }, 150);
                setTimeout(function() { playBeep(800, 0.2, 'sawtooth'); }, 300);
                break;
            case 'raid':
                // Raid - harsh descending tones
                playBeep(900, 0.25, 'sawtooth');
                setTimeout(function() { playBeep(700, 0.25, 'sawtooth'); }, 120);
                setTimeout(function() { playBeep(400, 0.3, 'sawtooth'); }, 250);
                break;
            default:
                playBeep(440, 0.1, 'sine');
        }
    }

    /**
     * Start or stop ambient loop
     */
    function startAmbient() {
        if (!enabled || !ambientEnabled || !audioContext) return;
        stopAmbient();
        try {
            ambientOsc = audioContext.createOscillator();
            ambientGain = audioContext.createGain();
            ambientOsc.frequency.value = 65;
            ambientOsc.type = 'sine';
            ambientGain.gain.value = volume * 0.03;
            ambientOsc.connect(ambientGain);
            ambientGain.connect(audioContext.destination);
            ambientOsc.start(audioContext.currentTime);
        } catch (e) { /* ignore */ }
    }

    function stopAmbient() {
        if (ambientOsc) {
            try {
                ambientOsc.stop(audioContext.currentTime);
            } catch (e) { /* ignore */ }
            ambientOsc = null;
            ambientGain = null;
        }
    }

    function setAmbientEnabled(value) {
        ambientEnabled = !!value;
        localStorage.setItem('highprofits_sound_ambient', ambientEnabled.toString());
        if (ambientEnabled) startAmbient();
        else stopAmbient();
    }

    /**
     * Background music (menu theme and game theme)
     */
    function startMenuMusic() {
        stopGameMusic();
        if (!musicEnabled) return;
        try {
            var el = getMenuMusic();
            el.volume = Math.max(0, Math.min(1, musicVolume));
            el.currentTime = 0;
            el.play()
                .then(function() { pendingMusic = null; })
                .catch(function() { pendingMusic = 'menu'; });
        } catch (e) { pendingMusic = 'menu'; }
    }

    function stopMenuMusic() {
        if (menuMusic) {
            try { menuMusic.pause(); menuMusic.currentTime = 0; } catch (e) {}
        }
    }

    function startGameMusic() {
        stopMenuMusic();
        if (!musicEnabled) return;
        try {
            var el = getGameMusic();
            el.volume = Math.max(0, Math.min(1, musicVolume));
            el.currentTime = 0;
            el.play()
                .then(function() { pendingMusic = null; })
                .catch(function() { pendingMusic = 'game'; });
        } catch (e) { pendingMusic = 'game'; }
    }

    function stopGameMusic() {
        if (gameMusic) {
            try { gameMusic.pause(); gameMusic.currentTime = 0; } catch (e) {}
        }
    }

    function setMusicEnabled(value) {
        musicEnabled = !!value;
        localStorage.setItem('highprofits_music_enabled', musicEnabled.toString());
        if (!musicEnabled) {
            stopMenuMusic();
            stopGameMusic();
        }
    }

    function setMusicVolume(newVol) {
        musicVolume = Math.max(0, Math.min(1, newVol));
        localStorage.setItem('highprofits_music_volume', musicVolume.toString());
        if (menuMusic) menuMusic.volume = musicVolume;
        if (gameMusic) gameMusic.volume = musicVolume;
    }

    /**
     * Resume audio context (required after user interaction)
     */
    function resumeContext() {
        if (audioContext && audioContext.state === 'suspended') {
            audioContext.resume().catch(function(e) {
                console.log('[SoundManager] Could not resume audio context:', e);
            });
        }
    }

    // Resume on first user interaction and retry music if autoplay was blocked
    function onFirstInteraction() {
        resumeContext();
        if (pendingMusic && musicEnabled) {
            if (pendingMusic === 'menu') startMenuMusic();
            else if (pendingMusic === 'game') startGameMusic();
            pendingMusic = null;
        }
    }
    document.addEventListener('click', onFirstInteraction, { once: true });
    document.addEventListener('keydown', onFirstInteraction, { once: true });

    return {
        init: init,
        play: playSound,
        setVolume: setVolume,
        setEnabled: setEnabled,
        setAmbientEnabled: setAmbientEnabled,
        startAmbient: startAmbient,
        stopAmbient: stopAmbient,
        startMenuMusic: startMenuMusic,
        stopMenuMusic: stopMenuMusic,
        startGameMusic: startGameMusic,
        stopGameMusic: stopGameMusic,
        setMusicEnabled: setMusicEnabled,
        setMusicVolume: setMusicVolume,
        isEnabled: function() { return enabled; },
        getVolume: function() { return volume; },
        isAmbientEnabled: function() { return ambientEnabled; },
        isMusicEnabled: function() { return musicEnabled; },
        getMusicVolume: function() { return musicVolume; }
    };
})();
