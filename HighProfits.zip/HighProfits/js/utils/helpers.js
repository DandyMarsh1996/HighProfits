/**
 * HighProfits - Helper Utilities Module
 * Number formatting, calculations, and general utilities
 */
var HP = HP || {};

HP.Helpers = (function() {
    'use strict';

    // Number abbreviations for large numbers
    var abbreviations = [
        { value: 1e15, symbol: 'Q' },   // Quadrillion
        { value: 1e12, symbol: 'T' },   // Trillion
        { value: 1e9, symbol: 'B' },    // Billion
        { value: 1e6, symbol: 'M' },    // Million
        { value: 1e3, symbol: 'K' }     // Thousand
    ];

    return {
        /**
         * Format a number with commas and optional decimal places
         * @param {number} num - Number to format
         * @param {number} decimals - Decimal places (default: 0)
         * @returns {string} Formatted number
         */
        formatNumber: function(num, decimals) {
            decimals = decimals || 0;
            if (num === null || num === undefined || isNaN(num)) {
                return '0';
            }
            return num.toFixed(decimals).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        },

        /**
         * Format a number with abbreviations (K, M, B, T, Q)
         * @param {number} num - Number to format
         * @param {number} decimals - Decimal places (default: 1)
         * @returns {string} Formatted abbreviated number
         */
        formatAbbreviated: function(num, decimals) {
            decimals = decimals !== undefined ? decimals : 1;
            if (num === null || num === undefined || isNaN(num)) {
                return '0';
            }
            
            // Handle negative numbers
            var sign = num < 0 ? '-' : '';
            num = Math.abs(num);
            
            // Find appropriate abbreviation
            for (var i = 0; i < abbreviations.length; i++) {
                if (num >= abbreviations[i].value) {
                    var formatted = (num / abbreviations[i].value).toFixed(decimals);
                    // Remove trailing zeros after decimal
                    formatted = formatted.replace(/\.?0+$/, '');
                    return sign + formatted + abbreviations[i].symbol;
                }
            }
            
            // No abbreviation needed
            return sign + this.formatNumber(Math.floor(num));
        },

        /**
         * Format money with dollar sign
         * @param {number} amount - Amount to format
         * @param {boolean} abbreviated - Use abbreviations for large numbers
         * @returns {string} Formatted money string
         */
        formatMoney: function(amount, abbreviated) {
            if (abbreviated && Math.abs(amount) >= 10000) {
                return '$' + this.formatAbbreviated(amount);
            }
            return '$' + this.formatNumber(amount);
        },

        /**
         * Calculate cost with exponential scaling
         * @param {number} baseCost - Base cost of item
         * @param {number} owned - Number already owned
         * @param {number} quantity - Number to purchase
         * @param {number} multiplier - Cost multiplier (default: 1.15)
         * @returns {number} Total cost for quantity
         */
        calculateCost: function(baseCost, owned, quantity, multiplier) {
            multiplier = multiplier || 1.15;
            var total = 0;
            for (var i = 0; i < quantity; i++) {
                total += Math.floor(baseCost * Math.pow(multiplier, owned + i));
            }
            return total;
        },

        /**
         * Calculate how many items can be afforded
         * @param {number} money - Available money
         * @param {number} baseCost - Base cost of item
         * @param {number} owned - Number already owned
         * @param {number} multiplier - Cost multiplier
         * @returns {number} Maximum affordable quantity
         */
        calculateAffordable: function(money, baseCost, owned, multiplier) {
            multiplier = multiplier || 1.15;
            var count = 0;
            var totalCost = 0;
            
            while (true) {
                var nextCost = Math.floor(baseCost * Math.pow(multiplier, owned + count));
                if (totalCost + nextCost > money) {
                    break;
                }
                totalCost += nextCost;
                count++;
            }
            
            return count;
        },

        /**
         * Format time duration in human readable format
         * @param {number} seconds - Duration in seconds
         * @returns {string} Formatted time string
         */
        formatTime: function(seconds) {
            if (seconds < 60) {
                return Math.floor(seconds) + 's';
            }
            if (seconds < 3600) {
                var mins = Math.floor(seconds / 60);
                var secs = Math.floor(seconds % 60);
                return mins + 'm ' + secs + 's';
            }
            if (seconds < 86400) {
                var hours = Math.floor(seconds / 3600);
                var mins = Math.floor((seconds % 3600) / 60);
                return hours + 'h ' + mins + 'm';
            }
            var days = Math.floor(seconds / 86400);
            var hours = Math.floor((seconds % 86400) / 3600);
            return days + 'd ' + hours + 'h';
        },

        /**
         * Generate a random number between min and max
         * @param {number} min - Minimum value
         * @param {number} max - Maximum value
         * @returns {number} Random number
         */
        randomBetween: function(min, max) {
            return Math.random() * (max - min) + min;
        },

        /**
         * Generate a random integer between min and max (inclusive)
         * @param {number} min - Minimum value
         * @param {number} max - Maximum value
         * @returns {number} Random integer
         */
        randomInt: function(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        },

        /**
         * Clamp a value between min and max
         * @param {number} value - Value to clamp
         * @param {number} min - Minimum bound
         * @param {number} max - Maximum bound
         * @returns {number} Clamped value
         */
        clamp: function(value, min, max) {
            return Math.min(Math.max(value, min), max);
        },

        /**
         * Linear interpolation between two values
         * @param {number} start - Start value
         * @param {number} end - End value
         * @param {number} t - Interpolation factor (0-1)
         * @returns {number} Interpolated value
         */
        lerp: function(start, end, t) {
            return start + (end - start) * t;
        },

        /**
         * Calculate percentage
         * @param {number} value - Current value
         * @param {number} total - Total value
         * @returns {number} Percentage (0-100)
         */
        percentage: function(value, total) {
            if (total === 0) return 0;
            return (value / total) * 100;
        },

        /**
         * Debounce a function
         * @param {Function} func - Function to debounce
         * @param {number} wait - Wait time in ms
         * @returns {Function} Debounced function
         */
        debounce: function(func, wait) {
            var timeout;
            return function() {
                var context = this;
                var args = arguments;
                clearTimeout(timeout);
                timeout = setTimeout(function() {
                    func.apply(context, args);
                }, wait);
            };
        },

        /**
         * Throttle a function
         * @param {Function} func - Function to throttle
         * @param {number} limit - Minimum time between calls in ms
         * @returns {Function} Throttled function
         */
        throttle: function(func, limit) {
            var inThrottle;
            return function() {
                var context = this;
                var args = arguments;
                if (!inThrottle) {
                    func.apply(context, args);
                    inThrottle = true;
                    setTimeout(function() {
                        inThrottle = false;
                    }, limit);
                }
            };
        },

        /**
         * Get DOM element by ID with null check
         * @param {string} id - Element ID
         * @returns {HTMLElement|null} Element or null
         */
        getElement: function(id) {
            return document.getElementById(id);
        },

        /**
         * Safely set text content of an element
         * @param {string} id - Element ID
         * @param {string} text - Text to set
         */
        setText: function(id, text) {
            var el = document.getElementById(id);
            if (el) {
                el.textContent = text;
            }
        },

        /**
         * Safely set innerHTML of an element
         * @param {string} id - Element ID  
         * @param {string} html - HTML to set
         */
        setHTML: function(id, html) {
            var el = document.getElementById(id);
            if (el) {
                el.innerHTML = html;
            }
        }
    };
})();
