/**
 * HighProfits - Tooltip System
 * Provides helpful tooltips for UI elements
 */
var HP = HP || {};

HP.Tooltips = (function() {
    'use strict';

    var activeTooltip = null;
    var tooltipElement = null;

    /**
     * Initialize tooltip system
     */
    function init() {
        // Create tooltip element
        tooltipElement = document.createElement('div');
        tooltipElement.id = 'tooltip';
        tooltipElement.className = 'tooltip';
        document.body.appendChild(tooltipElement);

        // Bind tooltip triggers
        bindTooltips();
    }

    function closest(el, selector) {
        if (!el || !el.nodeType) return null;
        if (typeof el.closest === 'function') return el.closest(selector);
        while (el && el.nodeType === 1) {
            var m = el.matches || el.msMatchesSelector || el.webkitMatchesSelector;
            if (m && m.call(el, selector)) return el;
            el = el.parentElement || el.parentNode;
        }
        return null;
    }

    /**
     * Bind tooltips to elements with data-tooltip attribute
     */
    function bindTooltips() {
        document.addEventListener('mouseenter', function(e) {
            var target = closest(e.target, '[data-tooltip]');
            if (target && target.getAttribute('data-tooltip')) {
                showTooltip(target, target.getAttribute('data-tooltip'));
            }
        }, true);

        document.addEventListener('mouseleave', function(e) {
            var target = closest(e.target, '[data-tooltip]');
            if (target) {
                hideTooltip();
            }
        }, true);
    }

    /**
     * Show tooltip
     */
    function showTooltip(element, text) {
        if (!tooltipElement || !text) return;
        text = String(text).replace(/&#10;/g, '\n');
        tooltipElement.textContent = text;
        tooltipElement.style.display = 'block';

        updatePosition(element);
        activeTooltip = element;
    }

    /**
     * Hide tooltip
     */
    function hideTooltip() {
        if (tooltipElement) {
            tooltipElement.style.display = 'none';
        }
        activeTooltip = null;
    }

    /**
     * Update tooltip position
     */
    function updatePosition(element) {
        if (!tooltipElement || !element) return;

        var rect = element.getBoundingClientRect();
        var tooltipRect = tooltipElement.getBoundingClientRect();
        var x = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
        var y = rect.top - tooltipRect.height - 10;

        // Adjust if tooltip goes off screen
        if (x < 10) x = 10;
        if (x + tooltipRect.width > window.innerWidth - 10) {
            x = window.innerWidth - tooltipRect.width - 10;
        }
        if (y < 10) {
            y = rect.bottom + 10; // Show below instead
        }

        tooltipElement.style.left = x + 'px';
        tooltipElement.style.top = y + 'px';
    }

    /**
     * Create tooltip text for equipment
     */
    function getEquipmentTooltip(equipment) {
        var text = equipment.name + '\n' + equipment.description;
        if (equipment.growthBonus) text += '\n+' + equipment.growthBonus + '% Growth';
        if (equipment.yieldBonus) text += '\n+' + equipment.yieldBonus + '% Yield';
        if (equipment.qualityBonus) text += '\n+' + equipment.qualityBonus + '% Quality';
        if (equipment.waterAmount) text += '\nWater: ' + equipment.waterAmount + 's';
        if (equipment.autoWater) text += '\n⚙️ Auto-watering';
        text += '\nCost: $' + equipment.cost;
        if (equipment.unlockLevel > 1) text += '\n🔒 Level ' + equipment.unlockLevel;
        return text;
    }

    /**
     * Create tooltip text for seeds (strains), including effects, bonuses, and product info
     */
    function getSeedTooltip(seed) {
        if (!seed) return '';
        var text = seed.name + (seed.strainName && seed.strainName !== seed.name ? ' (' + seed.strainName + ')' : '') + '\n' + (seed.description || '');
        text += '\n\nProduces: ' + (seed.strainName || seed.name) + ' (weed, ~' + seed.baseYield + 'g per harvest)';
        text += '\nGrowth: ' + seed.growthTime + 's · Yield: ' + seed.baseYield + 'g · Quality: ' + (seed.quality ? seed.quality.charAt(0).toUpperCase() + seed.quality.slice(1) : '—');
        if (seed.qualityBias > 0) text += '\nQuality bias: +' + seed.qualityBias + '%';
        var effects = HP.Data.StrainEffects && HP.Data.StrainEffects.getEffects ? HP.Data.StrainEffects.getEffects(seed) : [];
        if (effects.length > 0) {
            text += '\n\nEffects:';
            for (var i = 0; i < effects.length; i++) {
                var info = HP.Data.StrainEffects.getInfo ? HP.Data.StrainEffects.getInfo(effects[i]) : { name: effects[i], description: '' };
                text += '\n• ' + (info.name || effects[i]) + ': ' + (info.description || '');
            }
        }
        if (seed.store === 'dealer' && seed.cost != null) text += '\n\nCost: $' + seed.cost;
        if (seed.unlockLevel > 1) text += '\n🔒 Unlock level ' + seed.unlockLevel;
        return text;
    }

    /**
     * Create tooltip text for the "Smoke 1g" button: describes the buff this strain gives
     */
    function getSmokeBuffTooltip(seed) {
        if (!seed) return 'Smoke 1g for a temporary buff.';
        var durationMin = 2;
        if (HP.Data && HP.Data.Constants && HP.Data.Constants.SMOKE_BUFF_DURATION_MS) {
            durationMin = Math.round(HP.Data.Constants.SMOKE_BUFF_DURATION_MS / 60000);
        }
        var buffType = HP.State && HP.State.getBuffTypeForStrain ? HP.State.getBuffTypeForStrain(seed) : 'sale';
        var label = HP.State && HP.State.getBuffTypeLabel ? HP.State.getBuffTypeLabel(buffType) : buffType;
        var detail = '';
        if (buffType === 'growth') detail = ' (10% faster growth)';
        else if (buffType === 'yield') detail = ' (10% more yield)';
        else if (buffType === 'heat') detail = ' (15% less heat gain)';
        else if (buffType === 'sale') detail = ' (10% higher sale price)';
        else if (buffType === 'rep') detail = ' (+1 rep per sale)';
        return 'Smoke 1g: ' + durationMin + ' min buff — ' + label + detail;
    }

    /** Escape tooltip text for use in HTML data-tooltip attribute (newlines and quotes) */
    function escapeTooltipAttr(str) {
        if (str == null) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '&lt;')
            .replace(/\n/g, '&#10;');
    }

    /**
     * Create tooltip text for customers
     */
    function getCustomerTooltip(customer) {
        var text = customer.name + '\n' + customer.description;
        text += '\nBuys: ' + customer.minAmount + 'g - ' + customer.maxAmount + 'g';
        text += '\nPreferred: ' + customer.preferredQuality.join(', ');
        if (customer.bulkDiscount > 0) {
            text += '\nBulk Discount: ' + (customer.bulkDiscount * 100) + '%';
        }
        if (customer.unlockLevel > 1) text += '\n🔒 Level ' + customer.unlockLevel;
        return text;
    }

    /**
     * Create tooltip text for properties
     */
    function getPropertyTooltip(property) {
        var text = property.name + '\n' + property.description;
        text += '\nPlots: ' + property.plotCapacity;
        text += '\nCost: $' + HP.Helpers.formatNumber(property.cost);
        if (property.unlockLevel > 1) text += '\n🔒 Level ' + property.unlockLevel;
        return text;
    }

    return {
        init: init,
        show: showTooltip,
        hide: hideTooltip,
        getEquipmentTooltip: getEquipmentTooltip,
        getSeedTooltip: getSeedTooltip,
        getSmokeBuffTooltip: getSmokeBuffTooltip,
        escapeTooltipAttr: escapeTooltipAttr,
        getCustomerTooltip: getCustomerTooltip,
        getPropertyTooltip: getPropertyTooltip
    };
})();
