/**
 * HighProfits - Tooltip System
 * Provides helpful tooltips for UI elements
 */
var HP = HP || {};

HP.Tooltips = (function() {
    'use strict';

    var activeTooltip = null;
    var tooltipElement = null;

    /**
     * Initialize tooltip system
     */
    function init() {
        // Create tooltip element
        tooltipElement = document.createElement('div');
        tooltipElement.id = 'tooltip';
        tooltipElement.className = 'tooltip';
        document.body.appendChild(tooltipElement);

        // Bind tooltip triggers
        bindTooltips();
    }

    function closest(el, selector) {
        if (!el || !el.nodeType) return null;
        if (typeof el.closest === 'function') return el.closest(selector);
        while (el && el.nodeType === 1) {
            var m = el.matches || el.msMatchesSelector || el.webkitMatchesSelector;
            if (m && m.call(el, selector)) return el;
            el = el.parentElement || el.parentNode;
        }
        return null;
    }

    /**
     * Bind tooltips to elements with data-tooltip attribute
     */
    function bindTooltips() {
        document.addEventListener('mouseenter', function(e) {
            var target = closest(e.target, '[data-tooltip]');
            if (target && target.getAttribute('data-tooltip')) {
                showTooltip(target, target.getAttribute('data-tooltip'));
            }
        }, true);

        document.addEventListener('mouseleave', function(e) {
            var target = closest(e.target, '[data-tooltip]');
            if (target) {
                hideTooltip();
            }
        }, true);
    }

    /**
     * Show tooltip
     */
    function showTooltip(element, text) {
        if (!tooltipElement || !text) return;

        tooltipElement.textContent = text;
        tooltipElement.style.display = 'block';

        updatePosition(element);
        activeTooltip = element;
    }

    /**
     * Hide tooltip
     */
    function hideTooltip() {
        if (tooltipElement) {
            tooltipElement.style.display = 'none';
        }
        activeTooltip = null;
    }

    /**
     * Update tooltip position
     */
    function updatePosition(element) {
        if (!tooltipElement || !element) return;

        var rect = element.getBoundingClientRect();
        var tooltipRect = tooltipElement.getBoundingClientRect();
        var x = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
        var y = rect.top - tooltipRect.height - 10;

        // Adjust if tooltip goes off screen
        if (x < 10) x = 10;
        if (x + tooltipRect.width > window.innerWidth - 10) {
            x = window.innerWidth - tooltipRect.width - 10;
        }
        if (y < 10) {
            y = rect.bottom + 10; // Show below instead
        }

        tooltipElement.style.left = x + 'px';
        tooltipElement.style.top = y + 'px';
    }

    /**
     * Create tooltip text for equipment
     */
    function getEquipmentTooltip(equipment) {
        var text = equipment.name + '\n' + equipment.description;
        if (equipment.growthBonus) text += '\n+' + equipment.growthBonus + '% Growth';
        if (equipment.yieldBonus) text += '\n+' + equipment.yieldBonus + '% Yield';
        if (equipment.qualityBonus) text += '\n+' + equipment.qualityBonus + '% Quality';
        if (equipment.waterAmount) text += '\nWater: ' + equipment.waterAmount + 's';
        if (equipment.autoWater) text += '\n⚙️ Auto-watering';
        text += '\nCost: $' + equipment.cost;
        if (equipment.unlockLevel > 1) text += '\n🔒 Level ' + equipment.unlockLevel;
        return text;
    }

    /**
     * Create tooltip text for seeds
     */
    function getSeedTooltip(seed) {
        var text = seed.name + ' (' + seed.strainName + ')\n' + seed.description;
        text += '\nGrowth Time: ' + seed.growthTime + 's';
        text += '\nBase Yield: ' + seed.baseYield + 'g';
        text += '\nQuality: ' + seed.quality.charAt(0).toUpperCase() + seed.quality.slice(1);
        if (seed.qualityBias > 0) text += '\nQuality Bias: +' + seed.qualityBias + '%';
        text += '\nCost: $' + seed.cost;
        if (seed.unlockLevel > 1) text += '\n🔒 Level ' + seed.unlockLevel;
        return text;
    }

    /**
     * Create tooltip text for customers
     */
    function getCustomerTooltip(customer) {
        var text = customer.name + '\n' + customer.description;
        text += '\nBuys: ' + customer.minAmount + 'g - ' + customer.maxAmount + 'g';
        text += '\nPreferred: ' + customer.preferredQuality.join(', ');
        if (customer.bulkDiscount > 0) {
            text += '\nBulk Discount: ' + (customer.bulkDiscount * 100) + '%';
        }
        if (customer.unlockLevel > 1) text += '\n🔒 Level ' + customer.unlockLevel;
        return text;
    }

    /**
     * Create tooltip text for properties
     */
    function getPropertyTooltip(property) {
        var text = property.name + '\n' + property.description;
        text += '\nPlots: ' + property.plotCapacity;
        text += '\nCost: $' + HP.Helpers.formatNumber(property.cost);
        if (property.unlockLevel > 1) text += '\n🔒 Level ' + property.unlockLevel;
        return text;
    }

    return {
        init: init,
        show: showTooltip,
        hide: hideTooltip,
        getEquipmentTooltip: getEquipmentTooltip,
        getSeedTooltip: getSeedTooltip,
        getCustomerTooltip: getCustomerTooltip,
        getPropertyTooltip: getPropertyTooltip
    };
})();
