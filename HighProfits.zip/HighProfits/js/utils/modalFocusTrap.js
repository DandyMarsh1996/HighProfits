/**
 * Modal focus trap: keep focus inside an open modal for keyboard users.
 * Call trap(modalEl) when showing a modal, release(modalEl) when hiding.
 */
var HP = HP || {};

HP.ModalFocusTrap = (function() {
    'use strict';

    var previousActive = null;
    var currentModal = null;
    var keyHandler = null;

    function getFocusables(container) {
        if (!container || !container.querySelectorAll) return [];
        var selector = 'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
        var nodes = container.querySelectorAll(selector);
        var out = [];
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].offsetParent !== null) out.push(nodes[i]);
        }
        return out;
    }

    function handleKey(e) {
        if (e.key !== 'Tab' || !currentModal) return;
        var focusables = getFocusables(currentModal);
        if (focusables.length === 0) return;
        var first = focusables[0];
        var last = focusables[focusables.length - 1];
        if (e.shiftKey) {
            if (document.activeElement === first) {
                e.preventDefault();
                last.focus();
            }
        } else {
            if (document.activeElement === last) {
                e.preventDefault();
                first.focus();
            }
        }
    }

    function trap(modalEl) {
        if (!modalEl) return;
        release(modalEl);
        previousActive = document.activeElement;
        currentModal = modalEl;
        keyHandler = handleKey;
        document.addEventListener('keydown', keyHandler);

        var focusables = getFocusables(modalEl);
        if (focusables.length > 0) {
            focusables[0].focus();
        }
    }

    function release(modalEl) {
        if (currentModal !== modalEl) return;
        document.removeEventListener('keydown', keyHandler);
        keyHandler = null;
        currentModal = null;
        if (previousActive && typeof previousActive.focus === 'function') {
            previousActive.focus();
        }
        previousActive = null;
    }

    return { trap: trap, release: release };
})();
