/**
 * HighProfits - Production Module
 * Handles raw material generation and packaging logic
 */
var HP = HP || {};

HP.Production = (function() {
    'use strict';

    /**
     * Process production for all drugs with producers
     * Called once per game tick
     * @param {number} deltaTime - Time since last tick in seconds
     */
    function processProduction(deltaTime) {
        var drugIds = HP.Config.getDrugIds();
        var producerConfig = HP.Config.getWorker('producer');
        
        for (var i = 0; i < drugIds.length; i++) {
            var drugId = drugIds[i];
            var workers = HP.State.getWorkers(drugId);
            var producerCount = workers.producers;
            
            if (producerCount > 0) {
                // Calculate raw materials produced
                var rawProduced = producerCount * producerConfig.productionRate * deltaTime;
                
                // Add to inventory (respects storage capacity)
                var actualAdded = HP.State.addRaw(drugId, rawProduced);
                
                // Grant XP for production (scaled)
                if (actualAdded > 0) {
                    HP.State.addXP(Math.floor(actualAdded * 0.5));
                }
            }
        }
    }

    /**
     * Process packaging for all drugs with packers
     * Called once per game tick
     * @param {number} deltaTime - Time since last tick in seconds
     */
    function processPackaging(deltaTime) {
        var drugIds = HP.Config.getDrugIds();
        var packerConfig = HP.Config.getWorker('packer');
        
        for (var i = 0; i < drugIds.length; i++) {
            var drugId = drugIds[i];
            var drugConfig = HP.Config.getDrug(drugId);
            var workers = HP.State.getWorkers(drugId);
            var packerCount = workers.packers;
            
            if (packerCount > 0) {
                var inventory = HP.State.getDrugInventory(drugId);
                
                // Calculate bags that could be produced
                var potentialBags = packerCount * packerConfig.productionRate * deltaTime;
                
                // Calculate raw materials needed
                var rawNeeded = potentialBags * drugConfig.bagSize;
                
                // Limit by available raw materials
                var actualRaw = Math.min(rawNeeded, inventory.raw);
                var actualBags = Math.floor(actualRaw / drugConfig.bagSize);
                
                if (actualBags > 0) {
                    // Remove raw materials
                    HP.State.removeRaw(drugId, actualBags * drugConfig.bagSize);
                    
                    // Add bagged product
                    HP.State.addBagged(drugId, actualBags);
                    
                    // Grant XP for packaging (scaled)
                    HP.State.addXP(Math.floor(actualBags * 2));
                }
            }
        }
    }

    /**
     * Get production rates for a specific drug
     * @param {string} drugId - Drug identifier
     * @returns {Object} Production rates
     */
    function getProductionRates(drugId) {
        var workers = HP.State.getWorkers(drugId);
        var drugConfig = HP.Config.getDrug(drugId);
        var producerConfig = HP.Config.getWorker('producer');
        var packerConfig = HP.Config.getWorker('packer');
        
        var rawPerSecond = workers.producers * producerConfig.productionRate;
        var bagsPerSecond = workers.packers * packerConfig.productionRate;
        var rawConsumedPerSecond = bagsPerSecond * drugConfig.bagSize;
        
        return {
            rawPerSecond: rawPerSecond,
            bagsPerSecond: bagsPerSecond,
            rawConsumedPerSecond: rawConsumedPerSecond,
            netRawPerSecond: rawPerSecond - rawConsumedPerSecond
        };
    }

    /**
     * Get total production rates across all drugs
     * @returns {Object} Total production rates
     */
    function getTotalProductionRates() {
        var drugIds = HP.Config.getDrugIds();
        var totals = {
            rawPerSecond: 0,
            bagsPerSecond: 0
        };
        
        for (var i = 0; i < drugIds.length; i++) {
            var rates = getProductionRates(drugIds[i]);
            totals.rawPerSecond += rates.rawPerSecond;
            totals.bagsPerSecond += rates.bagsPerSecond;
        }
        
        return totals;
    }

    /**
     * Check if storage is full for a drug
     * @param {string} drugId - Drug identifier
     * @returns {boolean} True if storage is full
     */
    function isStorageFull(drugId) {
        var inventory = HP.State.getDrugInventory(drugId);
        var capacity = HP.State.getStorageCapacity();
        var drugConfig = HP.Config.getDrug(drugId);
        
        // Calculate total storage used (raw + bagged * bagSize)
        var used = inventory.raw + (inventory.bagged * drugConfig.bagSize);
        return used >= capacity;
    }

    /**
     * Get storage usage for a drug
     * @param {string} drugId - Drug identifier
     * @returns {Object} Storage usage info
     */
    function getStorageUsage(drugId) {
        var inventory = HP.State.getDrugInventory(drugId);
        var capacity = HP.State.getStorageCapacity();
        var drugConfig = HP.Config.getDrug(drugId);
        
        var used = inventory.raw + (inventory.bagged * drugConfig.bagSize);
        
        return {
            used: used,
            capacity: capacity,
            percentage: HP.Helpers.percentage(used, capacity),
            isFull: used >= capacity
        };
    }

    // Public API
    return {
        processProduction: processProduction,
        processPackaging: processPackaging,
        getProductionRates: getProductionRates,
        getTotalProductionRates: getTotalProductionRates,
        isStorageFull: isStorageFull,
        getStorageUsage: getStorageUsage
    };
})();
