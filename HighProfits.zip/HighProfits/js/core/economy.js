/**
 * HighProfits - Economy Module
 * Handles money transactions, pricing, cost calculations, and sales
 */
var HP = HP || {};

HP.Economy = (function() {
    'use strict';

    /**
     * Get current price for a drug (with variance)
     * @param {string} drugId - Drug identifier
     * @returns {number} Current price per bag
     */
    function getCurrentPrice(drugId) {
        var drugConfig = HP.Config.getDrug(drugId);
        var basePrice = drugConfig.basePrice;
        var variance = drugConfig.priceVariance;
        
        // Apply price variance based on reputation
        var reputation = HP.State.getReputation();
        var reputationModifier = 0.8 + (reputation / 100) * 0.4; // 0.8 to 1.2
        
        return Math.floor(basePrice * reputationModifier);
    }

    /**
     * Process sales for all drugs with dealers
     * Called once per game tick
     * @param {number} deltaTime - Time since last tick in seconds
     */
    function processSales(deltaTime) {
        var drugIds = HP.Config.getDrugIds();
        var dealerConfig = HP.Config.getWorker('dealer');
        
        for (var i = 0; i < drugIds.length; i++) {
            var drugId = drugIds[i];
            var workers = HP.State.getWorkers(drugId);
            var dealerCount = workers.dealers;
            
            if (dealerCount > 0) {
                var inventory = HP.State.getDrugInventory(drugId);
                
                // Calculate bags that could be sold
                var potentialSales = dealerCount * dealerConfig.salesRate * deltaTime;
                
                // Limit by available bagged product
                var actualSales = Math.min(Math.floor(potentialSales), inventory.bagged);
                
                if (actualSales > 0) {
                    // Calculate revenue
                    var price = getCurrentPrice(drugId);
                    var revenue = actualSales * price;
                    
                    // Remove bagged product
                    HP.State.removeBagged(drugId, actualSales);
                    
                    // Add money
                    var actualRevenue = HP.State.addMoney(revenue);
                    
                    // Track sold count
                    HP.State.addSold(drugId, actualSales);
                    
                    // Grant XP for sales (scales with operation size)
                    if (HP.Progression && HP.Progression.calculateXPForSale) {
                        HP.State.addXP(HP.Progression.calculateXPForSale(actualRevenue, 'medium', actualSales, false));
                    } else {
                        HP.State.addXP(actualSales * 1);
                    }
                    
                    // Increase heat slightly for each sale
                    HP.State.addHeat(actualSales * 0.1);
                }
            }
        }
    }

    /**
     * Calculate cost for hiring workers
     * @param {string} workerType - Type of worker (producer, packer, dealer)
     * @param {string} drugId - Drug identifier
     * @param {number} quantity - Number to hire
     * @returns {number} Total cost
     */
    function getHireCost(workerType, drugId, quantity) {
        var workerConfig = HP.Config.getWorker(workerType);
        var currentCount = HP.State.getWorkerCount(drugId, workerType);
        
        return HP.Helpers.calculateCost(
            workerConfig.baseCost,
            currentCount,
            quantity,
            workerConfig.costMultiplier
        );
    }

    /**
     * Hire workers if affordable
     * @param {string} workerType - Type of worker
     * @param {string} drugId - Drug identifier
     * @param {number} quantity - Number to hire
     * @returns {boolean} True if successful
     */
    function hireWorkers(workerType, drugId, quantity) {
        var cost = getHireCost(workerType, drugId, quantity);
        
        if (HP.State.spendMoney(cost)) {
            HP.State.addWorkers(drugId, workerType, quantity);
            return true;
        }
        
        return false;
    }

    /**
     * Get maximum affordable workers
     * @param {string} workerType - Type of worker
     * @param {string} drugId - Drug identifier
     * @returns {number} Maximum affordable
     */
    function getMaxAffordableWorkers(workerType, drugId) {
        var workerConfig = HP.Config.getWorker(workerType);
        var currentCount = HP.State.getWorkerCount(drugId, workerType);
        var money = HP.State.getMoney();
        
        return HP.Helpers.calculateAffordable(
            money,
            workerConfig.baseCost,
            currentCount,
            workerConfig.costMultiplier
        );
    }

    /**
     * Calculate cost for storage upgrade
     * @param {number} quantity - Number of upgrades
     * @returns {number} Total cost
     */
    function getStorageUpgradeCost(quantity) {
        var storageConfig = HP.Config.getStorageConfig();
        var currentLevel = HP.State.getStorage().level;
        
        return HP.Helpers.calculateCost(
            storageConfig.baseCost,
            currentLevel,
            quantity,
            storageConfig.costMultiplier
        );
    }

    /**
     * Upgrade storage if affordable
     * @param {number} quantity - Number of upgrades
     * @returns {boolean} True if successful
     */
    function upgradeStorage(quantity) {
        quantity = quantity || 1;
        var cost = getStorageUpgradeCost(quantity);
        
        if (HP.State.spendMoney(cost)) {
            for (var i = 0; i < quantity; i++) {
                HP.State.upgradeStorage();
            }
            return true;
        }
        
        return false;
    }

    /**
     * Get money per second for a specific drug
     * @param {string} drugId - Drug identifier
     * @returns {number} Money per second
     */
    function getMoneyPerSecond(drugId) {
        var workers = HP.State.getWorkers(drugId);
        var dealerConfig = HP.Config.getWorker('dealer');
        var price = getCurrentPrice(drugId);
        
        return workers.dealers * dealerConfig.salesRate * price;
    }

    /**
     * Get total money per second across all drugs
     * @returns {number} Total money per second
     */
    function getTotalMoneyPerSecond() {
        var drugIds = HP.Config.getDrugIds();
        var total = 0;
        
        for (var i = 0; i < drugIds.length; i++) {
            total += getMoneyPerSecond(drugIds[i]);
        }
        
        return total;
    }

    /**
     * Get potential money per second (if enough bags available)
     * @returns {number} Potential money per second
     */
    function getPotentialMoneyPerSecond() {
        var drugIds = HP.Config.getDrugIds();
        var total = 0;
        
        for (var i = 0; i < drugIds.length; i++) {
            var drugId = drugIds[i];
            var workers = HP.State.getWorkers(drugId);
            var inventory = HP.State.getDrugInventory(drugId);
            var dealerConfig = HP.Config.getWorker('dealer');
            var price = getCurrentPrice(drugId);
            
            // Only count if there are bags to sell
            if (inventory.bagged > 0) {
                total += workers.dealers * dealerConfig.salesRate * price;
            }
        }
        
        return total;
    }

    // Public API
    return {
        getCurrentPrice: getCurrentPrice,
        processSales: processSales,
        getHireCost: getHireCost,
        hireWorkers: hireWorkers,
        getMaxAffordableWorkers: getMaxAffordableWorkers,
        getStorageUpgradeCost: getStorageUpgradeCost,
        upgradeStorage: upgradeStorage,
        getMoneyPerSecond: getMoneyPerSecond,
        getTotalMoneyPerSecond: getTotalMoneyPerSecond,
        getPotentialMoneyPerSecond: getPotentialMoneyPerSecond
    };
})();
