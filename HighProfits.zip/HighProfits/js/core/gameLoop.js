/**
 * HighProfits - Game Loop Module
 * Smooth game loop with separated logic and render updates
 */
var HP = HP || {};

HP.GameLoop = (function() {
    'use strict';

    var isRunning = false;
    var lastLogicTime = 0;
    var lastRenderTime = 0;
    var animationFrameId = null;
    
    // Timing configuration
    var LOGIC_TICK_MS = 1000;    // Game logic runs every 1 second
    var RENDER_TICK_MS = 100;   // Render updates every 100ms for smooth timers

    /**
     * Start the game loop
     */
    function start() {
        if (isRunning) return;
        
        isRunning = true;
        lastLogicTime = performance.now();
        lastRenderTime = performance.now();
        
        animationFrameId = requestAnimationFrame(loop);
        console.log('[GameLoop] Started');
    }

    /**
     * Stop the game loop
     */
    function stop() {
        isRunning = false;
        if (animationFrameId) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = null;
        }
        console.log('[GameLoop] Stopped');
    }

    /**
     * Main loop using requestAnimationFrame
     */
    function loop(timestamp) {
        if (!isRunning) return;

        // Logic tick (every 1 second)
        if (timestamp - lastLogicTime >= LOGIC_TICK_MS) {
            var deltaTime = (timestamp - lastLogicTime) / 1000;
            lastLogicTime = timestamp;
            
            updateLogic(deltaTime, timestamp);
            HP.State.setLastTick(Date.now());
        }

        // Render tick (every 100ms for smooth updates)
        if (timestamp - lastRenderTime >= RENDER_TICK_MS) {
            lastRenderTime = timestamp;
            updateRender();
        }

        animationFrameId = requestAnimationFrame(loop);
    }

    /**
     * Update game logic (plants, heat, etc.)
     */
    function updateLogic(deltaTime) {
        // Track play time (seconds)
        if (HP.State && HP.State.incrementStat) {
            HP.State.incrementStat('playTime', deltaTime);
        }

        // Events: tick active events (check expiry)
        if (HP.Events && HP.Events.Manager && HP.Events.Manager.tick) {
            HP.Events.Manager.tick(deltaTime);
        }

        // Water reservoir: timer adds 1 charge per interval
        if (HP.State && HP.State.tickWaterRefill) {
            HP.State.tickWaterRefill(deltaTime);
        }

        // Update all growing plants and count actively growing plots (for heat)
        var allPlots = HP.State.getAllPlots();
        var growingPlotCount = 0;

        for (var i = 0; i < allPlots.length; i++) {
            var plotData = allPlots[i];
            var plot = plotData.plot;

            if (plot.status === 'growing' && plot.plant) {
                growingPlotCount++;
                var result = HP.Growing.updatePlantGrowth(plot, deltaTime);

                if (result.changed) {
                    if (result.event === 'ready') {
                        HP.Notifications.success(result.message);
                        if (HP.Progression && HP.Progression.calculateXPForPlantReady) {
                            HP.State.addXP(HP.Progression.calculateXPForPlantReady(plot));
                        } else {
                            HP.State.addXP(HP.Data.Constants.XP_PER_PLANT_READY || 5);
                        }
                        // Check tutorial progress (step 3 - waiting for harvest)
                        if (HP.Tutorial && HP.Tutorial.checkProgress) {
                            HP.Tutorial.checkProgress();
                        }
                    } else if (result.event === 'died') {
                        HP.Notifications.error(result.message);
                        HP.State.incrementStat('plantsDied', 1);
                    }
                    // Refresh grow view so plot card and action panel show Harvest / Dead immediately
                    if (HP.Renderer && HP.Renderer.update) {
                        HP.Renderer.update();
                    }
                }
            }
        }

        // Heat: accumulate from growing plots (security upgrades reduce rate), then decay, then check raid
        if (HP.State && HP.Heat) {
            var constants = HP.Data.Constants;
            var heatPerPlot = (constants && constants.HEAT_PER_GROWING_PLOT_PER_SECOND != null) ? constants.HEAT_PER_GROWING_PLOT_PER_SECOND : 0.015;
            var gainMult = HP.Heat.getHeatGainMultiplier ? HP.Heat.getHeatGainMultiplier() : 1;
            var levelBonus = HP.Progression && HP.Progression.getLevelBonus ? HP.Progression.getLevelBonus('heat', HP.State.getLevel()) : 1;
            var eventMult = HP.Events && HP.Events.Manager ? HP.Events.Manager.getModifier('heatGain') : 1;
            var heatGain = growingPlotCount * heatPerPlot * deltaTime * gainMult * levelBonus * eventMult;
            if (heatGain > 0) HP.State.addHeat(heatGain);
            var currentHeat = HP.State.getHeat();
            var decayed = HP.Heat.calculateDecay(currentHeat, deltaTime);
            if (decayed !== currentHeat) HP.State.reduceHeat(currentHeat - decayed);
            var currentHeatAfterDecay = HP.State.getHeat();
            // Raid warning sound at 80%+
            if (currentHeatAfterDecay >= 80 && currentHeatAfterDecay < 100) {
                if (!updateLogic.lastRaidWarning || (Date.now() - updateLogic.lastRaidWarning) > 30000) {
                    updateLogic.lastRaidWarning = Date.now();
                    if (HP.SoundManager) HP.SoundManager.play('raid_warning');
                }
            }
            if (currentHeatAfterDecay >= (HP.State.getState().heat.maxLevel || 100)) {
                if (HP.SoundManager) HP.SoundManager.play('raid');
                var raidResult = HP.State.triggerRaid();
                if (HP.Notifications) {
                    HP.Notifications.error('🚨 RAID! Law enforcement hit your operation. You lost $' + (raidResult.moneyLost || 0) + ' and ' + (raidResult.productLost ? (raidResult.productLost.low + raidResult.productLost.medium + raidResult.productLost.good + raidResult.productLost.premium) : 0) + 'g product. Heat reset.');
                }
                if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
            }
        }

        // Low water warning (when below 20% capacity)
        if (HP.State && HP.State.getWaterReservoir) {
            var reservoir = HP.State.getWaterReservoir();
            var pct = reservoir.capacity > 0 ? (reservoir.current / reservoir.capacity) : 1;
            if (pct < 0.2 && reservoir.current > 0) {
                if (!updateLogic.lastWaterWarning || (Date.now() - updateLogic.lastWaterWarning) > 45000) {
                    updateLogic.lastWaterWarning = Date.now();
                    if (HP.SoundManager) HP.SoundManager.play('low_water');
                    if (HP.Notifications) HP.Notifications.warning('💧 Low water! Only ' + reservoir.current + '/' + reservoir.capacity + ' remaining.');
                }
            }
        }

        // Process worker automation
        if (HP.WorkerAutomation) {
            HP.WorkerAutomation.processWorkers(deltaTime);
        }

        // Check achievements periodically (every 5 seconds)
        var currentTime = Date.now();
        if (Math.floor(currentTime / 1000) % 5 === 0) {
            var unlockedCount = HP.State.checkAchievements();
            if (unlockedCount > 0) {
                var notifications = HP.State.getAchievements().notifications;
                for (var i = 0; i < notifications.length; i++) {
                    var achievement = HP.Data.Achievements.get(notifications[i]);
                    if (achievement) {
                        HP.Notifications.achievement(achievement);
                    }
                }
                HP.State.clearAchievementNotifications();
            }

            // Check challenges periodically
            if (HP.Challenges) {
                var completed = HP.Challenges.checkAllChallenges();
                // Notifications are handled in checkAllChallenges
            }

            // Check and resume paused workers when resources become available
            if (HP.WorkerAutomation) {
                HP.WorkerAutomation.checkAndResumeWorkers();
            }
        }

    }

    /**
     * Update render (UI refresh)
     */
    function updateRender() {
        if (HP.Renderer && HP.Renderer.updateTimers) {
            // Only update dynamic elements (timers, progress bars)
            HP.Renderer.updateTimers();
        }
    }

    /**
     * Force a full UI refresh (called after user actions)
     */
    function forceRender() {
        if (HP.Renderer && HP.Renderer.update) {
            HP.Renderer.update();
        }
    }

    /**
     * Process offline progress
     */
    function processOfflineProgress(lastSaveTimestamp, maxSeconds) {
        var now = Date.now();
        var offlineSeconds = (now - lastSaveTimestamp) / 1000;

        maxSeconds = maxSeconds || HP.Data.Constants.OFFLINE_MAX_SECONDS || 3600;
        offlineSeconds = Math.min(offlineSeconds, maxSeconds);

        if (offlineSeconds < 1) {
            return { processed: false, seconds: 0 };
        }

        console.log('[GameLoop] Processing', Math.floor(offlineSeconds), 'seconds of offline time');

        var chunkSize = 10;
        var processed = 0;

        while (processed < offlineSeconds) {
            var chunk = Math.min(chunkSize, offlineSeconds - processed);
            updateLogic(chunk, Date.now());
            processed += chunk;
        }

        return {
            processed: true,
            seconds: offlineSeconds
        };
    }

    function running() {
        return isRunning;
    }

    return {
        start: start,
        stop: stop,
        forceRender: forceRender,
        processOfflineProgress: processOfflineProgress,
        isRunning: running
    };
})();
