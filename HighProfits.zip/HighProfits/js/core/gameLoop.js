/**
 * HighProfits - Game Loop Module
 * Smooth game loop with separated logic and render updates
 */
var HP = HP || {};

HP.GameLoop = (function() {
    'use strict';

    var isRunning = false;
    var lastLogicTime = 0;
    var lastRenderTime = 0;
    var lastLogicWallTime = 0;   // Wall-clock time of last logic tick (for catch-up when tab/window refocused)
    var animationFrameId = null;
    
    // Timing configuration
    var LOGIC_TICK_MS = 1000;    // Game logic runs every 1 second
    var RENDER_TICK_MS = 100;   // Render updates every 100ms for smooth timers
    var MAX_CATCHUP_SECONDS = 3600;  // Cap catch-up at 1 hour when returning to tab

    /**
     * Start the game loop
     */
    function start() {
        if (isRunning) return;
        
        isRunning = true;
        lastLogicTime = performance.now();
        lastRenderTime = performance.now();
        lastLogicWallTime = Date.now();
        
        animationFrameId = requestAnimationFrame(loop);
        
        // When tab/window regains focus, catch up on time that passed while timers were throttled
        document.addEventListener('visibilitychange', onVisibilityOrFocus);
        window.addEventListener('focus', onVisibilityOrFocus);
        
        console.log('[GameLoop] Started');
    }
    
    /**
     * Called when tab becomes visible or window gains focus - catch up elapsed time
     */
    function onVisibilityOrFocus() {
        if (document.hidden) return;  // Only catch up when we're visible
        catchUpFromTimestamp(lastLogicWallTime);
    }

    /**
     * Stop the game loop
     */
    function stop() {
        isRunning = false;
        if (animationFrameId) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = null;
        }
        document.removeEventListener('visibilitychange', onVisibilityOrFocus);
        window.removeEventListener('focus', onVisibilityOrFocus);
        console.log('[GameLoop] Stopped');
    }
    
    /**
     * Catch up game logic for time elapsed since the given timestamp (e.g. when tab/window was unfocused).
     * Runs updateLogic in chunks, then resets loop timers so the next frame doesn't double-count.
     */
    function catchUpFromTimestamp(sinceTimestamp) {
        var now = Date.now();
        var elapsedSec = (now - sinceTimestamp) / 1000;
        if (elapsedSec < 1) return;
        
        var maxSec = (HP.Data && HP.Data.Constants && HP.Data.Constants.OFFLINE_MAX_SECONDS) || MAX_CATCHUP_SECONDS;
        elapsedSec = Math.min(elapsedSec, maxSec);
        
        var chunkSize = 10;
        var processed = 0;
        while (processed < elapsedSec) {
            var chunk = Math.min(chunkSize, elapsedSec - processed);
            updateLogic(chunk, now);
            processed += chunk;
        }
        
        lastLogicTime = performance.now();
        lastRenderTime = performance.now();
        lastLogicWallTime = Date.now();
        
        if (HP.Renderer && HP.Renderer.update) {
            HP.Renderer.update();
        }
    }
    
    function getLastLogicWallTime() {
        return lastLogicWallTime;
    }

    /**
     * Main loop using requestAnimationFrame
     */
    function loop(timestamp) {
        if (!isRunning) return;

        // Logic tick (every 1 second)
        if (timestamp - lastLogicTime >= LOGIC_TICK_MS) {
            var deltaTime = (timestamp - lastLogicTime) / 1000;
            lastLogicTime = timestamp;
            lastLogicWallTime = Date.now();
            try {
                updateLogic(deltaTime, timestamp);
                HP.State.setLastTick(Date.now());
            } catch (err) {
                console.error('[GameLoop] Logic error:', err);
                if (HP.ErrorHandler && HP.ErrorHandler.show) HP.ErrorHandler.show('A game error occurred. Try refreshing.');
            }
        }

        // Render tick (every 100ms for smooth updates)
        if (timestamp - lastRenderTime >= RENDER_TICK_MS) {
            lastRenderTime = timestamp;
            try {
                updateRender();
            } catch (err) {
                console.error('[GameLoop] Render error:', err);
            }
        }

        animationFrameId = requestAnimationFrame(loop);
    }

    /**
     * Update game logic (plants, heat, etc.)
     */
    function updateLogic(deltaTime) {
        // Track play time (seconds)
        if (HP.State && HP.State.incrementStat) {
            HP.State.incrementStat('playTime', deltaTime);
        }

        // Events: tick active events (check expiry) and try to trigger random events
        if (HP.Events && HP.Events.Manager) {
            if (HP.Events.Manager.tick) HP.Events.Manager.tick(deltaTime);
            // Try to trigger random event every ~60 seconds
            if (!updateLogic.lastRandomEventCheck || (Date.now() - updateLogic.lastRandomEventCheck) > 60000) {
                updateLogic.lastRandomEventCheck = Date.now();
                if (HP.Events.Manager.tryTriggerRandomEvent) {
                    HP.Events.Manager.tryTriggerRandomEvent();
                }
            }
        }

        // Water reservoir: timer adds 1 charge per interval
        if (HP.State && HP.State.tickWaterRefill) {
            HP.State.tickWaterRefill(deltaTime);
        }

        // Stock market: Cookie Clicker-style price drift (every N seconds)
        if (HP.State && HP.State.tickStockMarket) {
            HP.State.tickStockMarket(deltaTime);
        }

        // Update all growing plants and accumulate heat contribution (strain heatResist applied per plot)
        var allPlots = HP.State.getAllPlots();
        var heatContribSum = 0;

        for (var i = 0; i < allPlots.length; i++) {
            var plotData = allPlots[i];
            var plot = plotData.plot;

            if (plot.status === 'growing' && plot.plant) {
                var seedForHeat = HP.Data.Seeds.get(plot.plant.seedId);
                var heatMult = 1;
                if (HP.Data.StrainEffects && HP.Data.StrainEffects.getHeatMultiplier) {
                    heatMult = HP.Data.StrainEffects.getHeatMultiplier(seedForHeat);
                } else if (seedForHeat && seedForHeat.traits && seedForHeat.traits.heatResist != null) {
                    heatMult = seedForHeat.traits.heatResist;
                }
                heatContribSum += heatMult;
                var result = HP.Growing.updatePlantGrowth(plot, deltaTime);

                if (result.changed) {
                    if (result.event === 'ready') {
                        HP.Notifications.success(result.message);
                        if (HP.Progression && HP.Progression.calculateXPForPlantReady) {
                            HP.State.addXP(HP.Progression.calculateXPForPlantReady(plot));
                        } else {
                            HP.State.addXP(HP.Data.Constants.XP_PER_PLANT_READY || 5);
                        }
                        // Check tutorial progress (step 3 - waiting for harvest)
                        if (HP.Tutorial && HP.Tutorial.checkProgress) {
                            HP.Tutorial.checkProgress();
                        }
                        // Defer full refresh to next frame so Harvest option appears immediately
                        if (HP.Renderer && HP.Renderer.update) {
                            requestAnimationFrame(function() {
                                HP.Renderer.update();
                            });
                        }
                    } else if (result.event === 'died') {
                        HP.Notifications.error(result.message);
                        HP.State.incrementStat('plantsDied', 1);
                    }
                    // Refresh grow view so plot card and action panel show Harvest / Dead immediately
                    if (result.event !== 'ready' && HP.Renderer && HP.Renderer.update) {
                        HP.Renderer.update();
                    }
                }
            }
        }

        // Heat: accumulate from growing plots (security upgrades reduce rate). No passive decay – raids are inevitable.
        if (HP.State && HP.Heat) {
            var constants = HP.Data.Constants;
            var heatPerPlot = (constants && constants.HEAT_PER_GROWING_PLOT_PER_SECOND != null) ? constants.HEAT_PER_GROWING_PLOT_PER_SECOND : 0.015;
            var gainMult = HP.Heat.getHeatGainMultiplier ? HP.Heat.getHeatGainMultiplier() : 1;
            var levelBonus = HP.Progression && HP.Progression.getLevelBonus ? HP.Progression.getLevelBonus('heat', HP.State.getLevel()) : 1;
            var eventMult = HP.Events && HP.Events.Manager ? HP.Events.Manager.getModifier('heatGain') : 1;
            var smokeHeatMult = (HP.State && HP.State.getHeatMultiplier) ? HP.State.getHeatMultiplier() : 1;
            var heatGain = heatContribSum * heatPerPlot * deltaTime * gainMult * levelBonus * eventMult * smokeHeatMult;
            if (heatGain > 0) HP.State.addHeat(heatGain);
            var currentHeat = HP.State.getHeat();
            // Raid warning sound at 80%+
            if (currentHeat >= 80 && currentHeat < 100) {
                if (!updateLogic.lastRaidWarning || (Date.now() - updateLogic.lastRaidWarning) > 30000) {
                    updateLogic.lastRaidWarning = Date.now();
                    if (HP.SoundManager) HP.SoundManager.play('raid_warning');
                }
            }
            if (currentHeat >= (HP.State.getState().heat.maxLevel || 100)) {
                if (HP.SoundManager) HP.SoundManager.play('raid');
                var raidResult = HP.State.triggerRaid();
                if (HP.Renderer && HP.Renderer.showRaidModal) HP.Renderer.showRaidModal(raidResult);
                if (HP.Notifications) {
                    var raidProductTotal = raidResult.productLostTotal != null ? raidResult.productLostTotal : (raidResult.productLost ? Object.keys(raidResult.productLost).reduce(function(s, k) { return s + (raidResult.productLost[k] || 0); }, 0) : 0);
                HP.Notifications.error('🚨 RAID! Law enforcement hit your operation. You lost $' + (raidResult.moneyLost || 0) + ' and ' + raidProductTotal + 'g product. Heat reset.');
                }
                if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
            }
        }

        // Low water warning (when below 20% capacity)
        if (HP.State && HP.State.getWaterReservoir) {
            var reservoir = HP.State.getWaterReservoir();
            var pct = reservoir.capacity > 0 ? (reservoir.current / reservoir.capacity) : 1;
            if (pct < 0.2 && reservoir.current > 0) {
                if (!updateLogic.lastWaterWarning || (Date.now() - updateLogic.lastWaterWarning) > 45000) {
                    updateLogic.lastWaterWarning = Date.now();
                    if (HP.SoundManager) HP.SoundManager.play('low_water');
                    if (HP.Notifications) HP.Notifications.warning('💧 Low water! Only ' + reservoir.current + '/' + reservoir.capacity + ' remaining.');
                }
            }
        }

        // Process worker wages (deduct from bank; pause if unpaid)
        if (HP.WorkerAutomation && HP.WorkerAutomation.processWages) {
            HP.WorkerAutomation.processWages(deltaTime);
        }
        // Process worker automation
        if (HP.WorkerAutomation) {
            HP.WorkerAutomation.processWorkers(deltaTime);
        }

        // Check achievements periodically (every 5 seconds)
        var currentTime = Date.now();
        if (Math.floor(currentTime / 1000) % 5 === 0) {
            var unlockedCount = HP.State.checkAchievements();
            if (unlockedCount > 0) {
                var notifications = HP.State.getAchievements().notifications;
                for (var i = 0; i < notifications.length; i++) {
                    var achievement = HP.Data.Achievements.get(notifications[i]);
                    if (achievement) {
                        HP.Notifications.achievement(achievement);
                    }
                }
                HP.State.clearAchievementNotifications();
            }

            // Check challenges periodically
            if (HP.Challenges) {
                var completed = HP.Challenges.checkAllChallenges();
                // Notifications are handled in checkAllChallenges
            }

            // Check and resume paused workers when resources become available
            if (HP.WorkerAutomation) {
                HP.WorkerAutomation.checkAndResumeWorkers();
            }
        }

    }

    /**
     * Update render (UI refresh)
     */
    function updateRender() {
        if (HP.Renderer && HP.Renderer.updateTimers) {
            // Only update dynamic elements (timers, progress bars)
            HP.Renderer.updateTimers();
        }
    }

    /**
     * Force a full UI refresh (called after user actions)
     */
    function forceRender() {
        if (HP.Renderer && HP.Renderer.update) {
            HP.Renderer.update();
        }
    }

    /**
     * Process offline progress
     */
    function processOfflineProgress(lastSaveTimestamp, maxSeconds) {
        var now = Date.now();
        var offlineSeconds = (now - lastSaveTimestamp) / 1000;

        maxSeconds = maxSeconds || HP.Data.Constants.OFFLINE_MAX_SECONDS || 3600;
        offlineSeconds = Math.min(offlineSeconds, maxSeconds);

        if (offlineSeconds < 1) {
            return { processed: false, seconds: 0 };
        }

        console.log('[GameLoop] Processing', Math.floor(offlineSeconds), 'seconds of offline time');

        var chunkSize = 10;
        var processed = 0;

        while (processed < offlineSeconds) {
            var chunk = Math.min(chunkSize, offlineSeconds - processed);
            updateLogic(chunk, Date.now());
            processed += chunk;
        }

        return {
            processed: true,
            seconds: offlineSeconds
        };
    }

    function running() {
        return isRunning;
    }

    return {
        start: start,
        stop: stop,
        forceRender: forceRender,
        processOfflineProgress: processOfflineProgress,
        catchUpFromTimestamp: catchUpFromTimestamp,
        getLastLogicWallTime: getLastLogicWallTime,
        isRunning: running
    };
})();
