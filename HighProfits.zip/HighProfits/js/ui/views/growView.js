/**
 * Grow view – room bonuses, water display; delegates plots/actions/room upgrades to core via ctx.
 */
(function() {
    'use strict';

    function updateRoomBonuses(ctx) {
        var elements = ctx.elements;
        var propertyId = elements.propertySelect ? elements.propertySelect.value : null;
        if (!propertyId) return;

        var bonuses = HP.State.getRoomBonuses(propertyId);
        if (elements.roomGrowthBonus) elements.roomGrowthBonus.textContent = '+' + bonuses.growth + '% Growth';
        if (elements.roomYieldBonus) elements.roomYieldBonus.textContent = '+' + bonuses.yield + '% Yield';
        if (elements.roomQualityBonus) elements.roomQualityBonus.textContent = '+' + bonuses.quality + '% Quality';

        var reservoir = HP.State && HP.State.getWaterReservoir ? HP.State.getWaterReservoir() : { current: 0, capacity: 0, refillAccumulator: 0 };
        if (elements.waterCurrent) elements.waterCurrent.textContent = reservoir.current;
        if (elements.waterCapacity) elements.waterCapacity.textContent = reservoir.capacity;
        var interval = (HP.Data.Constants && HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS != null) ? HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS : 8;
        var acc = reservoir.refillAccumulator || 0;
        var pct = interval > 0 ? Math.min(100, (acc / interval) * 100) : 0;
        var nextSec = Math.ceil(Math.max(0, interval - acc));
        if (elements.waterRefillProgress) elements.waterRefillProgress.style.width = pct + '%';
        if (elements.waterNextCharge) elements.waterNextCharge.textContent = 'Next: ' + nextSec + 's';

        var waterPct = reservoir.capacity > 0 ? (reservoir.current / reservoir.capacity) : 1;
        var isLow = reservoir.current > 0 && waterPct < 0.2;
        var waterGroup = document.getElementById('water-reservoir-group');
        var waterWarning = document.getElementById('water-low-warning');
        if (waterGroup) waterGroup.classList.toggle('water-reservoir-low', isLow);
        if (waterWarning) waterWarning.classList.toggle('hidden', !isLow);
    }

    function updatePropertyUpgradesPanel() {
        var panel = document.getElementById('property-upgrades-panel');
        var content = document.getElementById('property-upgrades-content');
        if (!content || !panel || panel.classList.contains('hidden')) return;

        var propertySelect = document.getElementById('property-select');
        if (!propertySelect) return;
        var propertyId = propertySelect.value;

        var upgrades = HP.State.getPropertyUpgrades ? HP.State.getPropertyUpgrades(propertyId) : { security: 0, ventilation: 0, autoWater: false };
        var securityCost = HP.State.getSecurityUpgradeCost ? HP.State.getSecurityUpgradeCost(propertyId) : 5000;
        var ventilationCost = HP.State.getVentilationUpgradeCost ? HP.State.getVentilationUpgradeCost(propertyId) : 3000;
        var autoWaterCost = HP.State.getAutoWaterCost ? HP.State.getAutoWaterCost(propertyId) : 15000;
        var bank = HP.State.getBank ? HP.State.getBank() : 0;

        var html = '';
        
        // Security
        html += '<div class="upgrade-item">';
        html += '<div class="upgrade-header"><span class="upgrade-icon">🛡️</span><span class="upgrade-name">Security System</span></div>';
        html += '<div class="upgrade-desc">Reduces heat gain from growing plants in this property.</div>';
        html += '<div class="upgrade-level">Level: ' + upgrades.security + ' / 3 <span class="upgrade-bonus">(−' + (upgrades.security * 10) + '% heat gain)</span></div>';
        if (upgrades.security < 3) {
            var canAfford = bank >= securityCost;
            if (!canAfford) {
                var needMore = securityCost - bank;
                html += '<span class="btn-tooltip-wrap" data-tooltip="Need $' + HP.Helpers.formatNumber(needMore) + ' more">';
            }
            html += '<button class="upgrade-btn' + (canAfford ? '' : ' disabled') + '" data-property="' + propertyId + '" data-upgrade-type="security"' + (canAfford ? '' : ' disabled') + '>';
            html += (canAfford ? 'Upgrade' : 'Need') + ' $' + HP.Helpers.formatNumber(securityCost) + '</button>';
            if (!canAfford) html += '</span>';
        } else {
            html += '<span class="btn-tooltip-wrap" data-tooltip="Maximum level reached"><button class="upgrade-btn disabled" disabled>✓ Maxed</button></span>';
        }
        html += '</div>';

        // Ventilation
        html += '<div class="upgrade-item">';
        html += '<div class="upgrade-header"><span class="upgrade-icon">💨</span><span class="upgrade-name">Ventilation</span></div>';
        html += '<div class="upgrade-desc">Increases growth speed for all plants in this property.</div>';
        html += '<div class="upgrade-level">Level: ' + upgrades.ventilation + ' / 3 <span class="upgrade-bonus">(+' + (upgrades.ventilation * 8) + '% growth speed)</span></div>';
        if (upgrades.ventilation < 3) {
            canAfford = bank >= ventilationCost;
            if (!canAfford) {
                needMore = ventilationCost - bank;
                html += '<span class="btn-tooltip-wrap" data-tooltip="Need $' + HP.Helpers.formatNumber(needMore) + ' more">';
            }
            html += '<button class="upgrade-btn' + (canAfford ? '' : ' disabled') + '" data-property="' + propertyId + '" data-upgrade-type="ventilation"' + (canAfford ? '' : ' disabled') + '>';
            html += (canAfford ? 'Upgrade' : 'Need') + ' $' + HP.Helpers.formatNumber(ventilationCost) + '</button>';
            if (!canAfford) html += '</span>';
        } else {
            html += '<span class="btn-tooltip-wrap" data-tooltip="Maximum level reached"><button class="upgrade-btn disabled" disabled>✓ Maxed</button></span>';
        }
        html += '</div>';

        // Auto-water
        html += '<div class="upgrade-item">';
        html += '<div class="upgrade-header"><span class="upgrade-icon">🚿</span><span class="upgrade-name">Auto-Watering System</span></div>';
        html += '<div class="upgrade-desc">Automatically waters all plants in this property when they need it.</div>';
        html += '<div class="upgrade-level">' + (upgrades.autoWater ? '✓ Installed' : 'Not installed') + '</div>';
        if (!upgrades.autoWater) {
            canAfford = bank >= autoWaterCost;
            if (!canAfford) {
                needMore = autoWaterCost - bank;
                html += '<span class="btn-tooltip-wrap" data-tooltip="Need $' + HP.Helpers.formatNumber(needMore) + ' more">';
            }
            html += '<button class="upgrade-btn' + (canAfford ? '' : ' disabled') + '" data-property="' + propertyId + '" data-upgrade-type="autowater"' + (canAfford ? '' : ' disabled') + '>';
            html += (canAfford ? 'Install' : 'Need') + ' $' + HP.Helpers.formatNumber(autoWaterCost) + '</button>';
            if (!canAfford) html += '</span>';
        } else {
            html += '<span class="btn-tooltip-wrap" data-tooltip="Already installed"><button class="upgrade-btn disabled" disabled>✓ Installed</button></span>';
        }
        html += '</div>';

        content.innerHTML = html;
    }

    function update(ctx) {
        ctx.updatePropertySelector();
        updateRoomBonuses(ctx);
        ctx.updatePlotsGrid();
        ctx.updatePlotActions();
        ctx.updateRoomUpgradesPanel();
        updatePropertyUpgradesPanel();
        if (ctx.refreshWorkersView) ctx.refreshWorkersView();
    }

    HP.Renderer._views.grow = { update: update };
})();
