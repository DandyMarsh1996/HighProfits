/**
 * Genetics (Breeding Lab) view – registers with HP.Renderer._views['genetics'].
 */
(function() {
    'use strict';

    function renderParentTraits(seed) {
        var html = '<div style="font-weight: bold; margin-bottom: 4px; color: var(--color-primary);">' + seed.name + '</div>';
        html += '<div class="trait"><span>Growth:</span><span>' + seed.growthTime + 's</span></div>';
        html += '<div class="trait"><span>Yield:</span><span>' + seed.baseYield + 'g</span></div>';
        html += '<div class="trait"><span>Quality:</span><span>' + seed.quality + '</span></div>';
        html += '<div class="trait"><span>Water:</span><span>' + seed.waterConsumption + 'x</span></div>';
        html += '<div class="trait"><span>Q. Bias:</span><span>' + seed.qualityBias + '%</span></div>';
        var effects = HP.Data.StrainEffects && HP.Data.StrainEffects.getEffects ? HP.Data.StrainEffects.getEffects(seed) : [];
        if (effects.length > 0) {
            html += '<div class="strain-effects-list" style="margin-top: 6px; font-size: 0.85em;">';
            for (var i = 0; i < effects.length; i++) {
                var info = HP.Data.StrainEffects.getInfo(effects[i]);
                html += '<span class="effect-badge" title="' + (info.description || '') + '">' + (info.name || effects[i]) + '</span> ';
            }
            html += '</div>';
        }
        return html;
    }

    function renderStrainCard(seed, isHybrid) {
        var tooltipAttr = (HP.Tooltips && HP.Tooltips.getSeedTooltip && HP.Tooltips.escapeTooltipAttr) ? ' data-tooltip="' + HP.Tooltips.escapeTooltipAttr(HP.Tooltips.getSeedTooltip(seed)) + '"' : '';
        var html = '<div class="strain-card' + (isHybrid ? ' hybrid' : '') + '"' + tooltipAttr + '>';
        html += '<div class="strain-header">';
        html += '<span class="strain-icon">' + seed.icon + '</span>';
        html += '<span class="strain-name">' + seed.name + '</span>';
        html += '</div>';

        var mastery = HP.State && HP.State.getStrainMastery ? HP.State.getStrainMastery(seed.id) : null;
        if (mastery && mastery.harvests > 0) {
            var bonus = HP.State.getStrainBonus ? HP.State.getStrainBonus(seed.id) : null;
            var nextAt = (mastery.level + 1) * 10;
            var progress = mastery.harvests % 10;
            html += '<div class="strain-mastery-bar" title="Harvest 10 plants per level (max 5). Per level: +5% yield, +3% quality, -2% growth.">';
            html += '<span class="strain-mastery-label">⭐ Lv.' + mastery.level + '</span>';
            html += '<span class="strain-mastery-harvests">' + mastery.harvests + ' harvests</span>';
            if (mastery.level < 5 && bonus) {
                html += '<span class="strain-mastery-next">' + progress + '/10 to Lv.' + (mastery.level + 1) + '</span>';
            }
            if (bonus && (bonus.yieldBonus > 0 || bonus.qualityBonus > 0 || bonus.growthSpeedBonus > 0)) {
                html += '<span class="strain-mastery-bonuses">+' + bonus.yieldBonus + '% yield, +' + bonus.qualityBonus + '% qual, -' + bonus.growthSpeedBonus + '% growth</span>';
            }
            html += '</div>';
        }

        html += '<div class="strain-desc">' + (seed.description || '') + '</div>';
        html += '<div class="strain-traits">';
        html += '<div>Growth: ' + seed.growthTime + 's</div>';
        html += '<div>Yield: ' + seed.baseYield + 'g</div>';
        html += '<div>Quality: ' + seed.quality + '</div>';
        html += '<div>Water: ' + seed.waterConsumption + 'x</div>';
        html += '<div>Q. Bias: ' + seed.qualityBias + '%</div>';
        html += '<div>Gen: ' + (seed.generation || 1) + '</div>';
        html += '</div>';

        var effects = HP.Data.StrainEffects && HP.Data.StrainEffects.getEffects ? HP.Data.StrainEffects.getEffects(seed) : [];
        if (effects.length > 0) {
            html += '<div class="strain-effects-list" style="margin-top: 6px;">';
            for (var ei = 0; ei < effects.length; ei++) {
                var info = HP.Data.StrainEffects.getInfo(effects[ei]);
                html += '<span class="effect-badge" title="' + (info.description || '') + '">' + (info.name || effects[ei]) + '</span> ';
            }
            html += '</div>';
        }

        if (isHybrid && seed.mutations && seed.mutations.length > 0) {
            html += '<div class="strain-mutations">';
            for (var i = 0; i < seed.mutations.length; i++) {
                var mutInfo = HP.Genetics.getMutationInfo(seed.mutations[i]);
                html += '<span class="mutation-badge" title="' + mutInfo.description + '">' + mutInfo.name + '</span>';
            }
            html += '</div>';
        }

        html += '</div>';
        return html;
    }

    function updateBreedingSection(ctx) {
        var parent1Select = document.getElementById('parent1-select');
        var parent2Select = document.getElementById('parent2-select');
        if (!parent1Select || !parent2Select) return;

        var savedP1 = parent1Select.value;
        var savedP2 = parent2Select.value;

        var inventory = HP.State.getInventory();
        var seeds = inventory.seeds || {};

        var html = '<option value="">Select seed...</option>';
        for (var seedId in seeds) {
            if (seeds[seedId] > 0) {
                var seed = HP.Data.Seeds.get(seedId);
                if (seed) {
                    html += '<option value="' + seedId + '">' + seed.icon + ' ' + seed.name + ' (' + seeds[seedId] + ')</option>';
                }
            }
        }
        parent1Select.innerHTML = html;
        parent2Select.innerHTML = html;

        if (savedP1 && parent1Select.querySelector('option[value="' + String(savedP1).replace(/"/g, '\\"') + '"]')) {
            parent1Select.value = savedP1;
        }
        if (savedP2 && parent2Select.querySelector('option[value="' + String(savedP2).replace(/"/g, '\\"') + '"]')) {
            parent2Select.value = savedP2;
        }

        updateParentInfo(ctx);
    }

    function updateParentInfo(ctx) {
        var parent1Select = document.getElementById('parent1-select');
        var parent2Select = document.getElementById('parent2-select');
        var parent1Info = document.getElementById('parent1-info');
        var parent2Info = document.getElementById('parent2-info');
        var breedBtn = document.getElementById('btn-breed');

        if (!parent1Select || !parent2Select || !parent1Info || !parent2Info || !breedBtn) return;

        var p1Id = parent1Select.value;
        var p2Id = parent2Select.value;

        if (p1Id) {
            var p1 = HP.Data.Seeds.get(p1Id);
            if (p1) {
                parent1Info.innerHTML = renderParentTraits(p1);
            }
        } else {
            parent1Info.innerHTML = '<div style="color: var(--color-text-muted); text-align: center; padding: 20px;">Select a seed</div>';
        }

        if (p2Id) {
            var p2 = HP.Data.Seeds.get(p2Id);
            if (p2) {
                parent2Info.innerHTML = renderParentTraits(p2);
            }
        } else {
            parent2Info.innerHTML = '<div style="color: var(--color-text-muted); text-align: center; padding: 20px;">Select a seed</div>';
        }

        breedBtn.disabled = !(p1Id && p2Id && p1Id !== p2Id);
    }

    function updateStrainLibrary(ctx) {
        var qualityOrder = ctx.qualityOrder;
        var grid = document.getElementById('strain-library-grid');
        if (!grid) return;

        var filterType = document.getElementById('library-filter-type');
        var filterQuality = document.getElementById('library-filter-quality');
        var sortBy = document.getElementById('library-sort-by');
        var searchInput = document.getElementById('library-search');

        var typeFilter = filterType ? filterType.value : 'all';
        var qualityFilterVal = filterQuality ? filterQuality.value : 'all';
        var sortValue = sortBy ? sortBy.value : 'quality-asc';
        var searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';

        var allSeeds = HP.Data.Seeds.getAll();
        var customStrains = HP.State.getCustomStrains();

        var strainsArray = [];

        if (typeFilter === 'all' || typeFilter === 'base') {
            for (var id in allSeeds) {
                var seed = allSeeds[id];
                if (!seed.isHybrid) {
                    strainsArray.push({ strain: seed, isHybrid: false });
                }
            }
        }

        if (typeFilter === 'all' || typeFilter === 'hybrid') {
            for (var hybridId in customStrains) {
                strainsArray.push({ strain: customStrains[hybridId], isHybrid: true });
            }
        }

        if (qualityFilterVal !== 'all') {
            strainsArray = strainsArray.filter(function(item) {
                return item.strain.quality === qualityFilterVal;
            });
        }

        if (searchTerm) {
            strainsArray = strainsArray.filter(function(item) {
                var s = item.strain;
                return s.name.toLowerCase().indexOf(searchTerm) !== -1 ||
                       (s.strainName && s.strainName.toLowerCase().indexOf(searchTerm) !== -1) ||
                       (s.description && s.description.toLowerCase().indexOf(searchTerm) !== -1);
            });
        }

        strainsArray.sort(function(a, b) {
            var seedA = a.strain;
            var seedB = b.strain;

            switch (sortValue) {
                case 'quality-asc':
                    return qualityOrder[seedA.quality] - qualityOrder[seedB.quality];
                case 'quality-desc':
                    return qualityOrder[seedB.quality] - qualityOrder[seedA.quality];
                case 'yield-desc':
                    return seedB.baseYield - seedA.baseYield;
                case 'growth-asc':
                    return seedA.growthTime - seedB.growthTime;
                case 'bias-desc':
                    return seedB.qualityBias - seedA.qualityBias;
                case 'name-asc':
                    return seedA.name.localeCompare(seedB.name);
                default:
                    return qualityOrder[seedA.quality] - qualityOrder[seedB.quality];
            }
        });

        var html = '';

        if (strainsArray.length === 0) {
            html = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--color-text-muted);">No strains match your filters</div>';
        } else {
            for (var i = 0; i < strainsArray.length; i++) {
                html += renderStrainCard(strainsArray[i].strain, strainsArray[i].isHybrid);
            }
        }

        grid.innerHTML = html;
    }

    function update(ctx) {
        updateBreedingSection(ctx);
        updateStrainLibrary(ctx);
    }

    HP.Renderer._views.genetics = { update: update };
})();
