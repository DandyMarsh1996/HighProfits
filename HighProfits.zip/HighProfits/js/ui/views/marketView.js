/**
 * Market view – stock display, orders panel, customers grid.
 */
(function() {
    'use strict';

    function updateOrdersPanel(ctx) {
        var elements = ctx.elements;
        if (!elements.ordersList || !HP.MarketOrders) return;

        var activeOrders = HP.MarketOrders.getAllOrders();
        var orderIds = Object.keys(activeOrders);
        var count = orderIds.length;

        if (elements.ordersCount) elements.ordersCount.textContent = count === 1 ? '1 order' : count + ' orders';
        if (elements.ordersEmpty) {
            if (count === 0) {
                elements.ordersEmpty.classList.remove('hidden');
                elements.ordersList.classList.add('hidden');
            } else {
                elements.ordersEmpty.classList.add('hidden');
                elements.ordersList.classList.remove('hidden');
            }
        }

        var html = '';
        var now = Date.now();
        var inventory = HP.State.getInventory();

        for (var i = 0; i < orderIds.length; i++) {
            var customerId = orderIds[i];
            var order = activeOrders[customerId];
            if (!order || order.expiresAt <= now) continue;

            var customer = HP.Data.Customers && HP.Data.Customers.get(customerId);
            var customerName = customer ? customer.name : customerId;
            var customerIcon = customer ? customer.icon : '🤝';
            var timeLeftSec = Math.max(0, Math.floor((order.expiresAt - now) / 1000));
            var mins = Math.floor(timeLeftSec / 60);
            var secs = timeLeftSec % 60;
            var timeStr = mins + 'm ' + secs + 's';
            var bonusExtra = order.bonusPrice - order.basePrice;
            var hasInventory = inventory.weed[order.quality] >= order.amount;

            html += '<div class="order-card" data-customer-id="' + customerId + '">';
            html += '<div class="order-card-header">';
            html += '<span class="order-card-icon">' + customerIcon + '</span>';
            html += '<span class="order-card-customer">' + customerName + '</span>';
            html += '</div>';
            html += '<div class="order-card-details">';
            html += '<span class="order-card-want">' + order.amount + 'g ' + order.quality + '</span>';
            html += '<span class="order-card-bonus">+$' + HP.Helpers.formatNumber(bonusExtra) + ' bonus</span>';
            html += '<span class="order-card-time">⏱️ ' + timeStr + '</span>';
            html += '</div>';
            if (hasInventory) {
                html += '<button type="button" class="btn-order-quick-sell" data-customer-id="' + customerId + '" data-quality="' + order.quality + '" data-amount="' + order.amount + '" title="Instantly fulfill this order">Quick sell</button>';
            } else {
                html += '<button type="button" class="btn-order-deal" data-customer-id="' + customerId + '" title="Open deal with this buyer">Deal</button>';
            }
            html += '</div>'; // .order-card
        }
        elements.ordersList.innerHTML = html;
    }

    function updateCustomersGrid(ctx) {
        var elements = ctx.elements;
        if (!elements.customersGrid) return;

        var playerLevel = HP.State.getLevel();
        var allCustomers = HP.Data.Customers.getAll();
        var activeOrders = HP.MarketOrders ? HP.MarketOrders.getAllOrders() : {};
        var html = '';

        for (var id in allCustomers) {
            var customer = allCustomers[id];
            var locked = customer.unlockLevel > playerLevel;
            var order = activeOrders[id];
            var cardClass = 'customer-card' + (locked ? ' locked' : '');
            if (order) cardClass += ' has-order';

            html += '<div class="' + cardClass + '" data-customer="' + id + '" tabindex="-1" role="button">';
            html += '<div class="customer-header">';
            html += '<span class="customer-icon">' + customer.icon + '</span>';
            html += '<span class="customer-name">' + customer.name + '</span>';
            if (order) html += '<span class="order-badge">📋 ORDER</span>';
            html += '</div>';
            html += '<div class="customer-desc">' + customer.description + '</div>';
            if (!locked) {
                var rep = HP.State && HP.State.getCustomerReputation ? HP.State.getCustomerReputation(id) : 0;
                html += '<div class="customer-rep">Rep: ' + rep + '</div>';
                html += '<div class="customer-range">Buys ' + customer.minAmount + 'g–' + customer.maxAmount + 'g</div>';
            }
            if (order && !locked) {
                var timeLeft = Math.max(0, Math.floor((order.expiresAt - Date.now()) / 1000));
                var mins = Math.floor(timeLeft / 60);
                var secs = timeLeft % 60;
                html += '<div class="customer-order">';
                html += '<div class="order-title">📋 Wants: ' + order.amount + 'g ' + order.quality + '</div>';
                html += '<div class="order-bonus">+20% bonus if exact match!</div>';
                html += '<div class="order-time">⏱️ ' + mins + 'm ' + secs + 's left</div>';
                html += '</div>';
            }
            html += '<div class="customer-pref">';
            var qualities = ['low', 'medium', 'good', 'premium'];
            for (var q = 0; q < qualities.length; q++) {
                var qual = qualities[q];
                var mult = customer.priceMultiplier[qual];
                if (mult >= 1.1) html += '<span class="pref-tag good">+' + Math.round((mult - 1) * 100) + '% ' + qual + '</span>';
                else if (mult <= 0.7 && mult > 0) html += '<span class="pref-tag bad">' + Math.round((mult - 1) * 100) + '% ' + qual + '</span>';
            }
            html += '</div>';
            if (locked) html += '<div style="font-size:10px;color:#666;margin-top:4px;">🔒 Level ' + customer.unlockLevel + '</div>';
            html += '</div>';
        }
        elements.customersGrid.innerHTML = html;
    }

    /** Update only stock numbers and orders panel (no customer grid) – avoids hover push from full re-render. */
    function updateOrdersAndStockOnly(ctx) {
        var elements = ctx.elements;
        var inventory = HP.State.getInventory();
        if (elements.sellStockLow) elements.sellStockLow.textContent = inventory.weed.low || 0;
        if (elements.sellStockMedium) elements.sellStockMedium.textContent = inventory.weed.medium || 0;
        if (elements.sellStockGood) elements.sellStockGood.textContent = inventory.weed.good || 0;
        if (elements.sellStockPremium) elements.sellStockPremium.textContent = inventory.weed.premium || 0;
        updateOrdersPanel(ctx);
    }

    function update(ctx) {
        var elements = ctx.elements;
        var inventory = HP.State.getInventory();
        if (elements.sellStockLow) elements.sellStockLow.textContent = inventory.weed.low || 0;
        if (elements.sellStockMedium) elements.sellStockMedium.textContent = inventory.weed.medium || 0;
        if (elements.sellStockGood) elements.sellStockGood.textContent = inventory.weed.good || 0;
        if (elements.sellStockPremium) elements.sellStockPremium.textContent = inventory.weed.premium || 0;

        updateOrdersPanel(ctx);
        updateCustomersGrid(ctx);
    }

    HP.Renderer._views.market = { update: update, updateOrdersAndStockOnly: updateOrdersAndStockOnly };
})();
