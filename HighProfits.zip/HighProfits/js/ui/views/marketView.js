/**
 * Market view – stock display, orders panel, customers grid.
 */
(function() {
    'use strict';

    function updateOrdersPanel(ctx) {
        var elements = ctx.elements;
        if (!elements.ordersList || !HP.MarketOrders) return;

        var activeOrders = HP.MarketOrders.getAllOrders();
        var orderIds = Object.keys(activeOrders);
        var count = orderIds.length;

        if (elements.ordersCount) elements.ordersCount.textContent = count === 1 ? '1 order' : count + ' orders';
        if (elements.ordersEmpty) {
            if (count === 0) {
                elements.ordersEmpty.classList.remove('hidden');
                elements.ordersList.classList.add('hidden');
            } else {
                elements.ordersEmpty.classList.add('hidden');
                elements.ordersList.classList.remove('hidden');
            }
        }

        var html = '';
        var now = Date.now();
        var inventory = HP.State.getInventory();
        var seeds = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get : null;

        for (var i = 0; i < orderIds.length; i++) {
            var customerId = orderIds[i];
            var order = activeOrders[customerId];
            if (!order || order.expiresAt <= now) continue;

            var customer = HP.Data.Customers && HP.Data.Customers.get(customerId);
            var customerName = customer ? customer.name : customerId;
            var customerIcon = customer ? customer.icon : '🤝';
            var timeLeftSec = Math.max(0, Math.floor((order.expiresAt - now) / 1000));
            var mins = Math.floor(timeLeftSec / 60);
            var secs = timeLeftSec % 60;
            var timeStr = mins + 'm ' + secs + 's';
            var bonusExtra = order.bonusPrice - order.basePrice;
            var orderSeedId = order.seedId || order.quality;
            var hasInventory = (inventory.weed[orderSeedId] || 0) >= order.amount;
            var seed = seeds ? HP.Data.Seeds.get(orderSeedId) : null;
            var strainLabel = seed ? (seed.strainName || seed.name) : orderSeedId;

            html += '<div class="order-card" data-customer-id="' + customerId + '">';
            html += '<div class="order-card-header">';
            html += '<span class="order-card-icon">' + customerIcon + '</span>';
            html += '<span class="order-card-customer">' + customerName + '</span>';
            html += '</div>';
            html += '<div class="order-card-details">';
            html += '<span class="order-card-want">' + order.amount + 'g ' + strainLabel + '</span>';
            html += '<span class="order-card-bonus">+$' + HP.Helpers.formatNumber(bonusExtra) + ' bonus</span>';
            html += '<span class="order-card-time">⏱️ ' + timeStr + '</span>';
            html += '</div>';
            if (hasInventory) {
                html += '<button type="button" class="btn-order-quick-sell" data-customer-id="' + customerId + '" data-seed-id="' + orderSeedId + '" data-amount="' + order.amount + '" title="Instantly fulfill this order">Quick sell</button>';
            } else {
                html += '<button type="button" class="btn-order-deal" data-customer-id="' + customerId + '" title="Open deal with this buyer">Deal</button>';
            }
            html += '</div>';
        }
        elements.ordersList.innerHTML = html;
    }

    function updateCustomersGrid(ctx) {
        var elements = ctx.elements;
        if (!elements.customersGrid) return;

        var playerLevel = HP.State.getLevel();
        var allCustomers = HP.Data.Customers.getAll();
        var activeOrders = HP.MarketOrders ? HP.MarketOrders.getAllOrders() : {};
        var html = '';

        for (var id in allCustomers) {
            var customer = allCustomers[id];
            var locked = customer.unlockLevel > playerLevel;
            var order = activeOrders[id];
            var cardClass = 'customer-card' + (locked ? ' locked' : '');
            if (order) cardClass += ' has-order';

            html += '<div class="' + cardClass + '" data-customer="' + id + '" tabindex="-1" role="button">';
            html += '<div class="customer-header">';
            html += '<span class="customer-icon">' + customer.icon + '</span>';
            html += '<span class="customer-name">' + customer.name + '</span>';
            if (order) html += '<span class="order-badge">📋 ORDER</span>';
            html += '</div>';
            html += '<div class="customer-desc">' + customer.description + '</div>';
            if (!locked) {
                var rep = HP.State && HP.State.getCustomerReputation ? HP.State.getCustomerReputation(id) : 0;
                var tier = HP.State && HP.State.getRelationshipTier ? HP.State.getRelationshipTier(id) : '';
                html += '<div class="customer-rep">Rep: ' + rep + (tier ? ' (' + tier + ')' : '') + '</div>';
                var specReq = HP.State && HP.State.getSpecialRequest ? HP.State.getSpecialRequest(id) : null;
                if (specReq) {
                    var srSeed = HP.Data.Seeds && HP.Data.Seeds.get(specReq.seedId);
                    var srName = srSeed ? (srSeed.strainName || srSeed.name) : specReq.seedId;
                    html += '<div class="customer-special-req">⭐ Special: ' + specReq.amount + 'g ' + srName + ' → $' + HP.Helpers.formatNumber(specReq.payout) + '</div>';
                }
                html += '<div class="customer-range">Buys ' + customer.minAmount + 'g–' + customer.maxAmount + 'g</div>';
            }
            if (order && !locked) {
                var timeLeft = Math.max(0, Math.floor((order.expiresAt - Date.now()) / 1000));
                var mins = Math.floor(timeLeft / 60);
                var secs = timeLeft % 60;
                var orderSeed = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(order.seedId || order.quality) : null;
                var orderStrainName = orderSeed ? (orderSeed.strainName || orderSeed.name) : (order.seedId || order.quality);
                html += '<div class="customer-order">';
                html += '<div class="order-title">📋 Wants: ' + order.amount + 'g ' + orderStrainName + '</div>';
                html += '<div class="order-bonus">+20% bonus if exact match!</div>';
                html += '<div class="order-time">⏱️ ' + mins + 'm ' + secs + 's left</div>';
                html += '</div>';
            }
            html += '<div class="customer-pref">';
            var qualities = ['low', 'medium', 'good', 'premium'];
            for (var q = 0; q < qualities.length; q++) {
                var qual = qualities[q];
                var mult = customer.priceMultiplier[qual];
                if (mult >= 1.1) html += '<span class="pref-tag good">+' + Math.round((mult - 1) * 100) + '% ' + qual + '</span>';
                else if (mult <= 0.7 && mult > 0) html += '<span class="pref-tag bad">' + Math.round((mult - 1) * 100) + '% ' + qual + '</span>';
            }
            html += '</div>';
            if (customer.strainMultipliers && Object.keys(customer.strainMultipliers).length > 0 && !locked) {
                var bonusStrains = [];
                for (var sid in customer.strainMultipliers) {
                    if (customer.strainMultipliers[sid] > 1) {
                        var s = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(sid) : null;
                        bonusStrains.push(s ? (s.strainName || s.name) : sid);
                    }
                }
                if (bonusStrains.length > 0) {
                    html += '<div class="customer-strain-bonus" title="Pays extra for these strains">⭐ ' + bonusStrains.slice(0, 3).join(', ') + (bonusStrains.length > 3 ? '…' : '') + '</div>';
                }
            }
            if (locked) html += '<div style="font-size:10px;color:#666;margin-top:4px;">🔒 Level ' + customer.unlockLevel + '</div>';
            html += '</div>';
        }
        elements.customersGrid.innerHTML = html;
    }

    function updateStockPanel(ctx) {
        var elements = ctx.elements;
        var inventory = HP.State.getInventory();
        var weed = inventory.weed || {};
        var container = document.getElementById('market-stock-list');
        if (!container) return;
        var seedIds = Object.keys(weed).filter(function(id) { return weed[id] > 0; });
        seedIds.sort(function(a, b) {
            var seedA = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(a) : null;
            var seedB = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(b) : null;
            var nameA = seedA ? (seedA.strainName || seedA.name) : a;
            var nameB = seedB ? (seedB.strainName || seedB.name) : b;
            return nameA.localeCompare(nameB);
        });
        var html = '';
        for (var i = 0; i < seedIds.length; i++) {
            var sid = seedIds[i];
            var seed = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(sid) : null;
            var name = seed ? (seed.strainName || seed.name) : sid;
            var q = seed ? seed.quality : 'low';
            html += '<div class="stock-row-compact">';
            html += '<span class="quality-dot ' + q + '"></span>' + name;
            html += '<span class="stock-val">' + (weed[sid] || 0) + 'g</span>';
            html += '</div>';
        }
        if (seedIds.length === 0) {
            html = '<div class="empty-state"><span class="empty-state-icon" aria-hidden="true">\uD83C\uDF31</span><span class="empty-state-message">No product yet. Harvest plants in Grow Room.</span><div class="empty-state-action">' +
                '<button type="button" class="btn-goto" data-goto-view="grow">Go to Grow Room</button></div></div>';
        }
        container.innerHTML = html;
    }

    function updateDailyGoalsPanel(ctx) {
        var listEl = document.getElementById('daily-goals-list');
        if (!listEl || !HP.State.getDailyGoals) return;
        var dg = HP.State.getDailyGoals();
        var goals = (dg && dg.goals) || [];
        var completed = (dg && dg.completed) || [];
        var html = '';
        for (var i = 0; i < goals.length; i++) {
            var g = goals[i];
            var done = completed.indexOf(g.id) !== -1;
            var label = g.type === 'sell_grams' ? 'Sell ' + g.target + 'g' : g.type === 'harvest_count' ? 'Harvest ' + g.target : 'Earn $' + HP.Helpers.formatNumber(g.target);
            html += '<div class="market-mini-row' + (done ? ' completed' : '') + '">' + (done ? '✓ ' : '') + label + (done ? '' : ' (' + (g.current || 0) + '/' + g.target + ')') + ' → $' + HP.Helpers.formatNumber(g.rewardCash || 0) + '</div>';
        }
        if (goals.length === 0) html = '<div class="market-mini-row"><span class="empty-state-icon" aria-hidden="true">\uD83C\uDFAF</span><span class="empty-state-message">No goals today. New daily goals and rewards appear each day.</span></div>';
        listEl.innerHTML = html;
    }

    function updateContractsPanel(ctx) {
        var listEl = document.getElementById('contracts-list');
        if (!listEl || !HP.State.getActiveContracts) return;
        var contracts = HP.State.getActiveContracts();
        var inventory = HP.State.getWeed ? HP.State.getWeed() : {};
        if (typeof inventory !== 'object') inventory = {};
        var mixed = HP.State.getMixed ? HP.State.getMixed() : {};
        var html = '';
        for (var i = 0; i < contracts.length; i++) {
            var c = contracts[i];
            var customer = HP.Data.Customers && HP.Data.Customers.get(c.customerId);
            var customerName = customer ? customer.name : c.customerId;
            var left = Math.max(0, c.amountRequired - (c.amountFulfilled || 0));
            var isBlendContract = c.seedId === 'mixed' || c.seedId === 'mixed:any' || (c.seedId && c.seedId.indexOf('mixed:') === 0);
            var strainLabel;
            var have = 0;
            var deliverSeedId = c.seedId;
            if (isBlendContract) {
                strainLabel = 'blend';
                if (c.requiredQuality) strainLabel = c.requiredQuality + '+ ' + strainLabel;
                for (var key in mixed) {
                    var m = mixed[key];
                    if (m && m.amount >= left && (!c.requiredQuality || ['low','medium','good','premium'].indexOf(c.requiredQuality) <= ['low','medium','good','premium'].indexOf(m.quality || 'low'))) {
                        have = m.amount;
                        deliverSeedId = 'mixed:' + key;
                        break;
                    }
                }
            } else {
                var seed = HP.Data.Seeds && HP.Data.Seeds.get(c.seedId);
                strainLabel = seed ? (seed.strainName || seed.name) : c.seedId;
                if (c.requiredQuality) strainLabel = c.requiredQuality + '+ ' + strainLabel;
                have = inventory[c.seedId] || 0;
            }
            var timeLeft = Math.max(0, Math.floor((c.expiresAt - Date.now()) / 1000));
            var mins = Math.floor(timeLeft / 60);
            var canDeliver = have >= left && left > 0;
            html += '<div class="market-mini-row contract-row">';
            html += '<span>Deliver ' + left + 'g ' + strainLabel + ' to ' + customerName + ' → $' + HP.Helpers.formatNumber(c.payout) + ' (⏱ ' + mins + 'm)</span>';
            if (canDeliver) {
                html += ' <button type="button" class="btn-deliver-contract action-btn" data-customer-id="' + c.customerId + '" data-seed-id="' + deliverSeedId + '" data-amount="' + left + '" title="Deliver now">Deliver</button>';
            }
            html += '</div>';
        }
        if (contracts.length === 0) {
            html = '<div class="market-mini-row empty-state-inline"><span class="empty-state-icon" aria-hidden="true">\uD83D\uDCCB</span><span class="empty-state-message">No active contracts right now. Sell to buyers to unlock customers; new contracts appear over time. Click "How does this work?" above to learn more.</span></div>';
            if (HP.State.addContract && Math.random() < 0.03) {
                var allC = HP.Data.Customers.getAll();
                var ids = Object.keys(allC).filter(function(id) { return (allC[id].unlockLevel || 1) <= HP.State.getLevel(); });
                if (ids.length > 0) {
                    var custId = ids[Math.floor(Math.random() * ids.length)];
                    var seeds = HP.Data.Seeds && HP.Data.Seeds.getAll ? HP.Data.Seeds.getAll() : {};
                    var seedIds = Object.keys(seeds);
                    var roll = Math.random();
                    if (roll < 0.25 && HP.Mixing && HP.Mixing.getBlendsList && HP.Mixing.getBlendsList().length > 0) {
                        var amt = 10 + Math.floor(Math.random() * 20);
                        var payout = 300 + Math.floor(Math.random() * 500);
                        HP.State.addContract(custId, 'mixed', amt, payout, 600000);
                    } else if (roll < 0.45 && seedIds.length > 0) {
                        var seedId = seedIds[Math.floor(Math.random() * seedIds.length)];
                        var amt = 15 + Math.floor(Math.random() * 25);
                        var payout = 280 + Math.floor(Math.random() * 450);
                        HP.State.addContract(custId, seedId, amt, payout, 600000, { requiredQuality: 'good' });
                    } else if (seedIds.length > 0) {
                        var sid = seedIds[Math.floor(Math.random() * seedIds.length)];
                        var amt = 15 + Math.floor(Math.random() * 25);
                        var payout = 200 + Math.floor(Math.random() * 400);
                        HP.State.addContract(custId, sid, amt, payout, 600000);
                    }
                    if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
                }
            }
        }
        listEl.innerHTML = html;
    }

    function updateOrdersAndStockOnly(ctx) {
        updateStockPanel(ctx);
        updateOrdersPanel(ctx);
        updateContractsPanel(ctx);
    }

    function update(ctx) {
        updateStockPanel(ctx);
        updateOrdersPanel(ctx);
        updateDailyGoalsPanel(ctx);
        updateContractsPanel(ctx);
        updateCustomersGrid(ctx);
    }

    HP.Renderer._views.market = { update: update, updateOrdersAndStockOnly: updateOrdersAndStockOnly };
})();
