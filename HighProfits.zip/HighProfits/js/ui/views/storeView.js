/**
 * Store views: hardware, garden, dealer, realestate. Dispatches by ctx.storeType.
 */
(function() {
    'use strict';

    function renderStoreItem(item, playerLevel, money, type, isOwned) {
        var locked = item.unlockLevel > playerLevel;
        var displayCost = item.cost;
        if (type === 'equipment' && HP.Events && HP.Events.Manager) {
            var costMult = HP.Events.Manager.getModifier('equipmentCost');
            displayCost = Math.floor(item.cost * costMult);
        }
        var canAfford = money >= displayCost;
        isOwned = isOwned || false;
        var itemClass = 'store-item';
        if (locked) itemClass += ' locked';
        if (isOwned) itemClass += ' owned';
        var html = '<div class="' + itemClass + '" tabindex="-1" role="button">';
        html += '<div class="item-header">';
        html += '<span class="item-name">' + (item.icon || '') + ' ' + item.name + '</span>';
        html += '<span class="item-cost">' + (displayCost > 0 ? '$' + HP.Helpers.formatNumber(displayCost) : 'Free') + '</span>';
        html += '</div>';
        html += '<div class="item-desc">' + item.description + '</div>';
        html += '<div class="item-stats">';
        if (item.capacityBonus != null) html += '<span class="stat-tag water">+' + item.capacityBonus + ' capacity</span>';
        if (item.heatReduction != null) html += '<span class="stat-tag heat">−' + Math.round(item.heatReduction * 100) + '% heat</span>';
        if (item.growthBonus) html += '<span class="stat-tag growth">+' + item.growthBonus + '% Growth</span>';
        if (item.yieldBonus) html += '<span class="stat-tag yield">+' + item.yieldBonus + '% Yield</span>';
        if (item.qualityBonus) html += '<span class="stat-tag quality">+' + item.qualityBonus + '% Quality</span>';
        if (item.consumable && item.uses && item.uses > 1) html += '<span class="stat-tag">x' + item.uses + ' uses</span>';
        if (item.waterAmount) html += '<span class="stat-tag water">+' + item.waterAmount + 's Water</span>';
        if (item.plotCapacity) html += '<span class="stat-tag">' + item.plotCapacity + ' plots</span>';
        if (item.growthTime) html += '<span class="stat-tag">' + item.growthTime + 's grow time</span>';
        if (item.launderFeeReduction != null) html += '<span class="stat-tag">−' + item.launderFeeReduction + '% launder fee</span>';
        if (item.dailyLaunderCapacity != null) html += '<span class="stat-tag">$' + (HP.Helpers && HP.Helpers.formatNumber ? HP.Helpers.formatNumber(item.dailyLaunderCapacity) : item.dailyLaunderCapacity) + '/day capacity</span>';
        html += '</div>';
        if (isOwned) {
            html += '<span class="btn-tooltip-wrap" data-tooltip="You already own this"><button class="buy-btn" disabled>✓ Owned</button></span>';
        } else if (locked) {
            html += '<span class="btn-tooltip-wrap" data-tooltip="Reach level ' + item.unlockLevel + ' to unlock"><button class="buy-btn" disabled>🔒 Level ' + item.unlockLevel + '</button></span>';
        } else {
            if (canAfford) {
                html += '<button class="buy-btn" data-type="' + type + '" data-id="' + item.id + '" data-cost="' + displayCost + '">Buy</button>';
            } else {
                var needMore = displayCost - money;
                html += '<span class="btn-tooltip-wrap" data-tooltip="Need $' + HP.Helpers.formatNumber(needMore) + ' more">';
                html += '<button class="buy-btn" data-type="' + type + '" data-id="' + item.id + '" data-cost="' + displayCost + '" disabled>Need $' + HP.Helpers.formatNumber(displayCost) + '</button>';
                html += '</span>';
            }
        }
        html += '</div>';
        return html;
    }

    function updateStoreView(ctx) {
        var storeType = ctx.storeType;
        var storeId = storeType === 'hardware' ? 'hardware_store' : 'garden_centre';
        var targetElement = storeType === 'hardware' ? ctx.elements.hardwareItems : ctx.elements.gardenItems;
        if (!targetElement) return;

        var playerLevel = HP.State.getLevel();
        var money = HP.State.getBank ? HP.State.getBank() : HP.State.getMoney();
        var sections = HP.Data.Equipment.getStoreSections(storeId);
        var html = '';

        for (var s = 0; s < sections.length; s++) {
            var section = sections[s];
            var items = HP.Data.Equipment.getBySection(storeId, section.id);
            html += '<div class="store-section">';
            html += '<div class="section-header">' + section.name + '</div>';
            html += '<div class="section-desc">' + section.description + '</div>';
            html += '<div class="section-items">';
            for (var i = 0; i < items.length; i++) {
                html += renderStoreItem(items[i], playerLevel, money, 'equipment');
            }
            html += '</div></div>';
        }

        if (storeId === 'hardware_store' && HP.Data.WaterUpgrades) {
            var waterUpgrades = HP.Data.WaterUpgrades.getForStore('hardware_store');
            var ownedWater = HP.State.getWaterUpgradesOwned ? HP.State.getWaterUpgradesOwned() : [];
            if (waterUpgrades.length > 0) {
                html += '<div class="store-section">';
                html += '<div class="section-header">🪣 Water Reservoir</div>';
                html += '<div class="section-desc">Increase your water pool capacity. Water refills over time (1 charge per 8s).</div>';
                html += '<div class="section-items">';
                for (var w = 0; w < waterUpgrades.length; w++) {
                    var wu = waterUpgrades[w];
                    var isOwned = ownedWater.indexOf(wu.id) !== -1;
                    html += renderStoreItem(wu, playerLevel, money, 'water_upgrade', isOwned);
                }
                html += '</div></div>';
            }
        }

        if (storeId === 'hardware_store' && HP.Data.HeatReduction) {
            var heatItems = HP.Data.HeatReduction.getForStore('hardware_store');
            var ownedHeat = HP.State.getHeatReductionOwned ? HP.State.getHeatReductionOwned() : [];
            if (heatItems.length > 0) {
                html += '<div class="store-section">';
                html += '<div class="section-header">🛡️ Heat / Security</div>';
                html += '<div class="section-desc">Reduce how fast heat builds while growing. One-time purchase per item.</div>';
                html += '<div class="section-items">';
                for (var h = 0; h < heatItems.length; h++) {
                    var hi = heatItems[h];
                    var isOwned = ownedHeat.indexOf(hi.id) !== -1;
                    html += renderStoreItem(hi, playerLevel, money, 'heat_reduction', isOwned);
                }
                html += '</div></div>';
            }
        }

        targetElement.innerHTML = html;
    }

    function updateDealerView(ctx) {
        var elements = ctx.elements;
        var qualityOrder = ctx.qualityOrder || { low: 1, medium: 2, good: 3, premium: 4 };
        if (!elements.dealerItems) return;

        var playerLevel = HP.State.getLevel();
        var money = HP.State.getCash ? HP.State.getCash() : HP.State.getMoney();
        var allSeeds = HP.Data.Seeds.getAll();
        var filterQuality = document.getElementById('dealer-filter-quality');
        var filterAvailability = document.getElementById('dealer-filter-availability');
        var sortBy = document.getElementById('dealer-sort-by');
        var searchInput = document.getElementById('dealer-search');
        var qualityFilter = filterQuality ? filterQuality.value : 'all';
        var availabilityFilter = filterAvailability ? filterAvailability.value : 'all';
        var sortValue = sortBy ? sortBy.value : 'quality-asc';
        var searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';

        var seedsArray = [];
        for (var id in allSeeds) {
            var seed = allSeeds[id];
            if (seed.isHybrid) continue;
            seedsArray.push(seed);
        }

        seedsArray = seedsArray.filter(function(seed) {
            if (qualityFilter !== 'all' && seed.quality !== qualityFilter) return false;
            if (availabilityFilter === 'unlocked' && seed.unlockLevel > playerLevel) return false;
            if (availabilityFilter === 'affordable' && seed.cost > money) return false;
            if (searchTerm && seed.name.toLowerCase().indexOf(searchTerm) === -1 && (!seed.strainName || seed.strainName.toLowerCase().indexOf(searchTerm) === -1) && (!seed.description || seed.description.toLowerCase().indexOf(searchTerm) === -1)) return false;
            return true;
        });

        seedsArray.sort(function(a, b) {
            switch (sortValue) {
                case 'quality-asc': return qualityOrder[a.quality] - qualityOrder[b.quality];
                case 'quality-desc': return qualityOrder[b.quality] - qualityOrder[a.quality];
                case 'cost-asc': return a.cost - b.cost;
                case 'cost-desc': return b.cost - a.cost;
                case 'yield-desc': return b.baseYield - a.baseYield;
                case 'growth-asc': return a.growthTime - b.growthTime;
                case 'level-asc': return a.unlockLevel - b.unlockLevel;
                case 'name-asc': return a.name.localeCompare(b.name);
                default: return qualityOrder[a.quality] - qualityOrder[b.quality];
            }
        });

        var html = '<div class="store-section">';
        html += '<div class="section-header">🌱 Available Seeds (' + seedsArray.length + ' shown)</div>';
        html += '<div class="section-items">';
        if (seedsArray.length === 0) {
            html += '<div class="empty-message">No seeds match your filters</div>';
        } else {
            for (var i = 0; i < seedsArray.length; i++) {
                html += renderStoreItem(seedsArray[i], playerLevel, money, 'seed');
            }
        }
        html += '</div></div>';
        elements.dealerItems.innerHTML = html;
    }

    function updateRealEstateView(ctx) {
        var elements = ctx.elements;
        var playerLevel = HP.State.getLevel();
        var money = HP.State.getBank ? HP.State.getBank() : HP.State.getMoney();

        if (elements.propertyItems) {
            var ownedProps = HP.State.getOwnedProperties ? HP.State.getOwnedProperties() : [];
            var allProps = HP.Data.Properties.getAll ? HP.Data.Properties.getAll() : {};
            var html = '<div class="store-section">';
            html += '<div class="section-header">🌱 Grow Locations</div>';
            html += '<div class="section-desc">Properties with plots for growing. Each adds cash and bank cap.</div>';
            html += '<div class="section-items">';
            for (var id in allProps) {
                var item = allProps[id];
                var isOwned = ownedProps.indexOf(item.id) !== -1;
                html += renderStoreItem(item, playerLevel, money, 'property', isOwned);
            }
            html += '</div></div>';
            elements.propertyItems.innerHTML = html;
        }

        if (elements.businessItems) {
            var ownedBiz = HP.State.getBusinessesOwned ? HP.State.getBusinessesOwned() : [];
            var allBiz = HP.Data.Businesses && HP.Data.Businesses.getAll ? HP.Data.Businesses.getAll() : [];
            var bizHtml = '<div class="store-section">';
            bizHtml += '<div class="section-header">🏢 Businesses</div>';
            bizHtml += '<div class="section-desc">Own businesses to launder through: lower fees and no heat, but each has limited daily capacity (resets each day). Bank funds required.</div>';
            bizHtml += '<div class="section-items">';
            for (var i = 0; i < allBiz.length; i++) {
                var item = allBiz[i];
                var isOwned = ownedBiz.indexOf(item.id) !== -1;
                bizHtml += renderStoreItem(item, playerLevel, money, 'business', isOwned);
            }
            bizHtml += '</div></div>';
            elements.businessItems.innerHTML = bizHtml;
        }
    }

    function update(ctx) {
        var storeType = ctx.storeType;
        if (storeType === 'hardware' || storeType === 'garden') {
            updateStoreView(ctx);
        } else if (storeType === 'dealer') {
            updateDealerView(ctx);
        } else if (storeType === 'realestate') {
            updateRealEstateView(ctx);
        }
    }

    HP.Renderer._views.hardware = { update: update };
    HP.Renderer._views.garden = { update: update };
    HP.Renderer._views.dealer = { update: update };
    HP.Renderer._views.realestate = { update: update };
})();
