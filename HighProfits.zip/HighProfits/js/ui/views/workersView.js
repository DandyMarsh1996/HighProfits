/**
 * Workers view – registers with HP.Renderer._views['workers'].
 */
(function() {
    'use strict';

    function update(ctx) {
        var elements = ctx.elements;
        if (!elements.workersHireGrid || !elements.workersAssignedList) return;

        var playerLevel = HP.State.getLevel();
        var money = HP.State.getBank ? HP.State.getBank() : HP.State.getMoney();
        var allWorkers = HP.Data.GrowerWorkers.getUnlocked(playerLevel);
        var assignedWorkers = HP.State.getGrowerWorkers();

        // Render hire section
        var hireHtml = '';
        if (allWorkers.length === 0) {
            hireHtml = '<div class="workers-unlock-hint">Level up to unlock more workers. Check back after gaining levels.</div>';
        } else {
            for (var i = 0; i < allWorkers.length; i++) {
                var workerType = allWorkers[i];
                var canAfford = money >= workerType.baseCost;

                hireHtml += '<div class="worker-hire-card">';
                hireHtml += '<div class="worker-icon">' + workerType.icon + '</div>';
                hireHtml += '<div class="worker-info">';
                hireHtml += '<div class="worker-name">' + workerType.name + '</div>';
                hireHtml += '<div class="worker-desc">' + workerType.description + '</div>';
                hireHtml += '<div class="worker-stats">';
                hireHtml += '<span>Efficiency: ' + (workerType.efficiency * 100) + '%</span>';
                hireHtml += '</div>';
                hireHtml += '</div>';
                hireHtml += '<div class="worker-cost">$' + HP.Helpers.formatNumber(workerType.baseCost) + '</div>';
                hireHtml += '<button class="btn-hire-worker" data-worker="' + workerType.id + '"' +
                    (canAfford ? '' : ' disabled') + '>' + (canAfford ? 'Hire' : 'Need $' + workerType.baseCost) + '</button>';
                hireHtml += '</div>';
            }
        }
        elements.workersHireGrid.innerHTML = hireHtml;

        // Render assigned workers
        var assignedHtml = '';
        if (assignedWorkers.length === 0) {
            assignedHtml = '<div class="empty-state">No workers assigned. Hire a worker and assign them to a plot.</div>';
        } else {
            for (var i = 0; i < assignedWorkers.length; i++) {
                var worker = assignedWorkers[i];
                var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
                var plot = HP.State.getPlot(worker.assignedPlot.propertyId, worker.assignedPlot.plotIndex);
                var property = HP.Data.Properties.get(worker.assignedPlot.propertyId);

                var statusClass = worker.status === 'active' ? 'active' : 'paused';
                var statusText = worker.status === 'active' ? '✓ Working' : '⏸ Paused';

                assignedHtml += '<div class="worker-assigned-card ' + statusClass + '">';
                assignedHtml += '<div class="worker-assigned-header">';
                assignedHtml += '<div class="worker-assigned-info">';
                assignedHtml += '<span class="worker-icon-small">' + (workerType ? workerType.icon : '👷') + '</span>';
                assignedHtml += '<div>';
                assignedHtml += '<div class="worker-name">' + (workerType ? workerType.name : 'Worker') + '</div>';
                assignedHtml += '<div class="worker-location">' + (property ? property.icon + ' ' + property.name : 'Unknown') + ' - Plot ' + (worker.assignedPlot.plotIndex + 1) + '</div>';
                assignedHtml += '</div>';
                assignedHtml += '</div>';
                assignedHtml += '<div class="worker-status-badge ' + statusClass + '">' + statusText + '</div>';
                assignedHtml += '</div>';

                assignedHtml += '<div class="worker-config">';
                assignedHtml += '<div class="config-item">';
                assignedHtml += '<span class="config-label">Seed:</span>';
                var seedName = 'Auto';
                if (worker.config.seedId) {
                    var seed = HP.Data.Seeds.get(worker.config.seedId);
                    seedName = seed ? seed.name : worker.config.seedId;
                }
                assignedHtml += '<span class="config-value">' + seedName + '</span>';
                assignedHtml += '</div>';
                if (worker.config.soilId) {
                    var soil = HP.Data.Equipment.get(worker.config.soilId);
                    var soilName = soil ? soil.name : worker.config.soilId;
                    assignedHtml += '<div class="config-item">';
                    assignedHtml += '<span class="config-label">Soil:</span>';
                    assignedHtml += '<span class="config-value">' + soilName + '</span>';
                    assignedHtml += '</div>';
                }
                if (worker.config.fertilizerId) {
                    var fert = HP.Data.Equipment.get(worker.config.fertilizerId);
                    var fertName = fert ? fert.name : worker.config.fertilizerId;
                    assignedHtml += '<div class="config-item">';
                    assignedHtml += '<span class="config-label">Fertilizer:</span>';
                    assignedHtml += '<span class="config-value">' + fertName + '</span>';
                    assignedHtml += '</div>';
                }
                assignedHtml += '</div>';

                assignedHtml += '<div class="worker-actions">';
                assignedHtml += '<button class="btn-configure-worker" data-worker="' + worker.id + '">⚙️ Configure</button>';
                assignedHtml += '<button class="btn-remove-worker" data-worker="' + worker.id + '">🗑️ Remove</button>';
                assignedHtml += '</div>';
                assignedHtml += '</div>';
            }
        }
        elements.workersAssignedList.innerHTML = assignedHtml;
    }

    HP.Renderer._views.workers = { update: update };
})();
