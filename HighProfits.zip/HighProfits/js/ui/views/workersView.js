/**
 * Workers view – registers with HP.Renderer._views['workers'].
 */
(function() {
    'use strict';

    function update(ctx) {
        var elements = ctx.elements;
        if (!elements.workersHireGrid || !elements.workersAssignedList) return;

        var playerLevel = HP.State.getLevel();
        var totalWagePerDay = HP.WorkerAutomation && HP.WorkerAutomation.getTotalWagePerDay ? HP.WorkerAutomation.getTotalWagePerDay() : 0;
        var money = HP.State.getBank ? HP.State.getBank() : HP.State.getMoney();
        var allWorkers = HP.Data.GrowerWorkers.getUnlocked(playerLevel);
        var assignedWorkers = HP.State.getGrowerWorkers();

        // Wage fund display
        var fundEl = document.getElementById('workers-wage-fund-amount');
        if (fundEl && HP.State.getWorkerWageFund) {
            fundEl.textContent = '$' + HP.Helpers.formatNumber(HP.State.getWorkerWageFund());
        }
        var daySec = HP.State.getWorkerDaySeconds ? HP.State.getWorkerDaySeconds() : 720;
        var nextPayEl = document.getElementById('workers-next-pay');
        if (nextPayEl && HP.State.getWorkerDayAccumulator) {
            if (totalWagePerDay > 0) {
                var acc = HP.State.getWorkerDayAccumulator();
                var secLeft = Math.max(0, Math.ceil(daySec - acc));
                nextPayEl.textContent = 'Next pay in ' + secLeft + 's';
            } else {
                nextPayEl.textContent = '';
            }
        }

        // Render hire section
        var hireHtml = '';
        if (allWorkers.length === 0) {
            hireHtml = '<div class="workers-unlock-hint">Level up to unlock more workers. Check back after gaining levels.</div>';
        } else {
            var getHireCost = HP.Events.WorkerActions && HP.Events.WorkerActions.getHireCost;
            for (var i = 0; i < allWorkers.length; i++) {
                var workerType = allWorkers[i];
                var cost = getHireCost ? getHireCost(workerType.id) : workerType.baseCost;
                var canAfford = money >= cost;

                hireHtml += '<div class="worker-hire-card">';
                hireHtml += '<div class="worker-icon">' + workerType.icon + '</div>';
                hireHtml += '<div class="worker-info">';
                hireHtml += '<div class="worker-name">' + workerType.name + '</div>';
                hireHtml += '<div class="worker-desc">' + workerType.description + '</div>';
                hireHtml += '<div class="worker-stats">';
                hireHtml += '<span>Efficiency: ' + (workerType.efficiency * 100) + '%</span>';
                var wagePerDay = (workerType.wagePerDay != null) ? workerType.wagePerDay : 0;
                hireHtml += '<span class="worker-wage">Wage: $' + HP.Helpers.formatNumber(wagePerDay) + '/day</span>';
                if (workerType.traits && workerType.traits.length > 0 && HP.Data.GrowerWorkers.getTraitLabels) {
                    var labels = HP.Data.GrowerWorkers.getTraitLabels();
                    for (var t = 0; t < workerType.traits.length; t++) {
                        var tr = labels[workerType.traits[t]];
                        if (tr) hireHtml += '<span class="worker-trait" title="' + (tr.desc || '') + '">' + (tr.icon || '') + ' ' + (tr.name || workerType.traits[t]) + '</span>';
                    }
                }
                hireHtml += '</div>';
                hireHtml += '</div>';
                hireHtml += '<div class="worker-cost">$' + HP.Helpers.formatNumber(cost) + '</div>';
                hireHtml += '<button class="btn-hire-worker" data-worker="' + workerType.id + '"' +
                    (canAfford ? '' : ' disabled') + '>' + (canAfford ? 'Hire' : 'Need $' + HP.Helpers.formatNumber(cost)) + '</button>';
                hireHtml += '</div>';
            }
        }
        elements.workersHireGrid.innerHTML = hireHtml;

        // Locked workers (next tiers): show "Unlocks at level X"
        var lockedWrap = document.getElementById('workers-locked-wrap');
        var lockedGrid = document.getElementById('workers-locked-grid');
        if (lockedWrap && lockedGrid && HP.Data.GrowerWorkers.getLocked) {
            var locked = HP.Data.GrowerWorkers.getLocked(playerLevel);
            if (locked.length > 0) {
                lockedWrap.classList.remove('hidden');
                var lockedHtml = '';
                for (var l = 0; l < locked.length; l++) {
                    var wt = locked[l];
                    var wagePerDay = (wt.wagePerDay != null) ? wt.wagePerDay : 0;
                    lockedHtml += '<div class="worker-hire-card worker-card-locked">';
                    lockedHtml += '<div class="worker-icon">' + wt.icon + '</div>';
                    lockedHtml += '<div class="worker-info">';
                    lockedHtml += '<div class="worker-name">' + wt.name + '</div>';
                    lockedHtml += '<div class="worker-desc">' + wt.description + '</div>';
                    lockedHtml += '<div class="worker-stats">';
                    lockedHtml += '<span>Efficiency: ' + (wt.efficiency * 100) + '%</span>';
                    lockedHtml += '<span class="worker-wage">Wage: $' + HP.Helpers.formatNumber(wagePerDay) + '/day</span>';
                    if (wt.traits && wt.traits.length > 0 && HP.Data.GrowerWorkers.getTraitLabels) {
                        var labels = HP.Data.GrowerWorkers.getTraitLabels();
                        for (var t = 0; t < wt.traits.length; t++) {
                            var tr = labels[wt.traits[t]];
                            if (tr) lockedHtml += '<span class="worker-trait" title="' + (tr.desc || '') + '">' + (tr.icon || '') + ' ' + (tr.name || wt.traits[t]) + '</span>';
                        }
                    }
                    lockedHtml += '</div></div>';
                    lockedHtml += '<div class="worker-unlock-label">Unlocks at level ' + wt.unlockLevel + '</div>';
                    lockedHtml += '</div>';
                }
                lockedGrid.innerHTML = lockedHtml;
            } else {
                lockedWrap.classList.add('hidden');
            }
        }

        // Render assigned workers
        var assignedHtml = '';
        var wageEl = document.getElementById('workers-wage-summary');
        if (wageEl) wageEl.textContent = totalWagePerDay > 0 ? ('Total wages: $' + HP.Helpers.formatNumber(totalWagePerDay) + '/day (each game day = 12 min)') : '';
        if (assignedWorkers.length === 0) {
            assignedHtml = '<div class="empty-state"><span class="empty-state-icon" aria-hidden="true">\uD83D\uDC77</span><span class="empty-state-message">No workers assigned yet. Hire a worker above, then assign them to a location (property). They will plant, water, and harvest all plots at that property.</span><div class="empty-state-action"><button type="button" class="btn-goto" data-goto-view="grow">Go to Grow Room</button></div></div>';
        } else {
            for (var i = 0; i < assignedWorkers.length; i++) {
                var worker = assignedWorkers[i];
                var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
                var propId = worker.assignedPropertyId != null ? worker.assignedPropertyId : (worker.assignedPlot && worker.assignedPlot.propertyId);
                var property = HP.Data.Properties.get(propId);
                var plotCount = propId ? (HP.State.getPlots(propId) || []).length : 0;

                var statusClass = worker.status === 'active' ? 'active' : 'paused';
                var statusText = worker.status === 'active' ? '✓ Working' : '⏸ Paused';
                var pauseReasonText = '';
                if (worker.status === 'paused' && worker.pauseReason) {
                    pauseReasonText = worker.pauseReason === 'unpaid' ? ' (Unpaid wages)' : (worker.pauseReason === 'no_plot' ? ' (Location missing)' : ' (Needs resources)');
                }

                assignedHtml += '<div class="worker-assigned-card ' + statusClass + '">';
                var workerLevel = worker.level != null ? worker.level : 1;
                var workerXP = worker.xp != null ? worker.xp : 0;
                var maxLevel = HP.Data.WorkerSkills ? HP.Data.WorkerSkills.MAX_LEVEL : 10;
                var xpForNext = workerLevel < maxLevel && HP.Data.WorkerSkills && HP.Data.WorkerSkills.getXPForLevel
                    ? HP.Data.WorkerSkills.getXPForLevel(workerLevel) : 100;
                var xpPct = workerLevel >= maxLevel ? 100 : (xpForNext > 0 ? Math.min(100, (workerXP / xpForNext) * 100) : 0);

                assignedHtml += '<div class="worker-assigned-header">';
                assignedHtml += '<div class="worker-assigned-info">';
                assignedHtml += '<span class="worker-icon-small">' + (workerType ? workerType.icon : '👷') + '</span>';
                assignedHtml += '<div>';
                assignedHtml += '<div class="worker-name-row">';
                assignedHtml += '<span class="worker-name">' + (worker.name || (workerType ? workerType.name : 'Worker')) + '</span>';
                assignedHtml += '<span class="worker-level-badge" title="Level ' + workerLevel + ' – workers gain XP from planting, watering, harvesting">Lvl ' + workerLevel + '</span>';
                assignedHtml += '</div>';
                assignedHtml += '<div class="worker-location">' + (property ? property.icon + ' ' + property.name : 'Unknown') + ' (' + plotCount + ' plots)</div>';
                if (workerLevel < maxLevel) {
                    assignedHtml += '<div class="worker-xp-bar" title="' + workerXP + ' / ' + xpForNext + ' XP to next level">';
                    assignedHtml += '<div class="worker-xp-fill" style="width:' + xpPct + '%"></div>';
                    assignedHtml += '</div>';
                }
                var effectiveStats = HP.WorkerAutomation && HP.WorkerAutomation.getEffectiveStats ? HP.WorkerAutomation.getEffectiveStats(worker) : null;
                if (effectiveStats) {
                    var effPct = Math.round(effectiveStats.efficiency * 100);
                    var waterPct = Math.round(effectiveStats.wateringSpeed * 100);
                    assignedHtml += '<div class="worker-effective-stats" title="Level bonus applies to action speed and yield">Effective: ' + effPct + '% efficiency, ' + waterPct + '% watering</div>';
                }
                assignedHtml += '</div>';
                assignedHtml += '</div>';
                assignedHtml += '<div class="worker-status-badge ' + statusClass + '" title="' + (pauseReasonText ? pauseReasonText.replace(/^ \(/, '').replace(/\)$/, '') : '') + '">' + statusText + pauseReasonText + '</div>';
                assignedHtml += '</div>';

                if (workerType.traits && workerType.traits.length > 0 && HP.Data.GrowerWorkers.getTraitLabels) {
                    var traitLabels = HP.Data.GrowerWorkers.getTraitLabels();
                    assignedHtml += '<div class="worker-traits-inline">';
                    for (var tt = 0; tt < workerType.traits.length; tt++) {
                        var tr2 = traitLabels[workerType.traits[tt]];
                        if (tr2) assignedHtml += '<span class="worker-trait-badge" title="' + (tr2.desc || '') + '">' + (tr2.icon || '') + '</span>';
                    }
                    assignedHtml += '</div>';
                }
                assignedHtml += '<div class="worker-config">';
                assignedHtml += '<div class="config-item">';
                assignedHtml += '<span class="config-label">Seed:</span>';
                var seedName = worker.config.seedId ? (HP.Data.Seeds.get(worker.config.seedId) || {}).name || worker.config.seedId : '—';
                assignedHtml += '<span class="config-value">' + seedName + '</span>';
                assignedHtml += '</div>';
                assignedHtml += '<div class="config-item">';
                assignedHtml += '<span class="config-label">Soil:</span>';
                var soilName = worker.config.soilId ? (HP.Data.Equipment.get(worker.config.soilId) || {}).name || worker.config.soilId : '—';
                assignedHtml += '<span class="config-value">' + soilName + '</span>';
                assignedHtml += '</div>';
                assignedHtml += '<div class="config-item">';
                assignedHtml += '<span class="config-label">Fertilizer:</span>';
                var fertName = worker.config.fertilizerId ? (HP.Data.Equipment.get(worker.config.fertilizerId) || {}).name || worker.config.fertilizerId : '—';
                assignedHtml += '<span class="config-value">' + fertName + '</span>';
                assignedHtml += '</div>';
                assignedHtml += '</div>';

                var nextTier = HP.Data.GrowerWorkers.getNextTier && HP.Data.GrowerWorkers.getNextTier(worker.workerTypeId);
                var canUpgrade = nextTier && playerLevel >= nextTier.unlockLevel;
                var upgradeCost = canUpgrade && HP.Events.WorkerActions && HP.Events.WorkerActions.getUpgradeCost
                    ? HP.Events.WorkerActions.getUpgradeCost(worker.workerTypeId, nextTier.id) : 0;
                var canAffordUpgrade = canUpgrade && money >= upgradeCost;

                assignedHtml += '<div class="worker-actions">';
                if (canUpgrade) {
                    assignedHtml += '<button type="button" class="btn-upgrade-worker action-btn" data-worker="' + worker.id + '" data-next-type="' + nextTier.id + '"' + (canAffordUpgrade ? '' : ' disabled') + ' title="Upgrade to ' + nextTier.name + '">⬆️ Upgrade to ' + nextTier.name + (upgradeCost > 0 ? ' ($' + HP.Helpers.formatNumber(upgradeCost) + ')' : '') + '</button>';
                }
                assignedHtml += '<button class="btn-move-worker" data-worker="' + worker.id + '" title="Move to another plot">📌 Move</button>';
                assignedHtml += '<button class="btn-configure-worker" data-worker="' + worker.id + '">⚙️ Configure</button>';
                assignedHtml += '<button class="btn-remove-worker" data-worker="' + worker.id + '">🗑️ Remove</button>';
                assignedHtml += '</div>';
                assignedHtml += '</div>';
            }
        }
        elements.workersAssignedList.innerHTML = assignedHtml;
    }

    HP.Renderer._views.workers = { update: update };
})();
