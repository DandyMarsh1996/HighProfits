/**
 * Stock Market view – Cookie Clicker-style: list stocks, price, portfolio, buy/sell.
 */
(function() {
    'use strict';

    function getUnlockLevel() {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        return (c.STOCK_MARKET_UNLOCK_LEVEL != null) ? c.STOCK_MARKET_UNLOCK_LEVEL : 10;
    }

    function update(ctx) {
        var level = HP.State.getLevel ? HP.State.getLevel() : 1;
        var unlockLevel = getUnlockLevel();
        var locked = level < unlockLevel;

        var lockedEl = document.getElementById('stock-market-locked');
        var panelEl = document.getElementById('stock-market-panel');
        var unlockLevelEl = document.getElementById('stock-unlock-level');
        if (unlockLevelEl) unlockLevelEl.textContent = unlockLevel;
        if (lockedEl) lockedEl.classList.toggle('hidden', !locked);
        if (panelEl) panelEl.classList.toggle('hidden', locked);

        if (locked) return;

        var bank = HP.State.getBank ? HP.State.getBank() : 0;
        var feePct = (HP.Data.Constants && HP.Data.Constants.STOCK_BROKER_FEE_PERCENT != null) ? HP.Data.Constants.STOCK_BROKER_FEE_PERCENT : 2;
        var bankDisplay = document.getElementById('stock-bank-display');
        var feePctEl = document.getElementById('stock-fee-pct');
        var portfolioValEl = document.getElementById('stock-portfolio-value');
        var tickRemainingEl = document.getElementById('stock-tick-remaining');
        var tickCountdownEl = document.getElementById('stock-tick-countdown');
        if (bankDisplay) bankDisplay.textContent = HP.Helpers.formatNumber(Math.floor(bank));
        if (feePctEl) feePctEl.textContent = feePct;
        if (portfolioValEl && HP.State.getPortfolioValue) portfolioValEl.textContent = HP.Helpers.formatNumber(Math.floor(HP.State.getPortfolioValue()));
        var intervalSec = HP.State.getStockTickIntervalSec ? HP.State.getStockTickIntervalSec() : 60;
        if (tickRemainingEl && HP.State.getStockTickSecondsRemaining) tickRemainingEl.textContent = HP.State.getStockTickSecondsRemaining();

        var listEl = document.getElementById('stock-list');
        if (!listEl || !HP.Data.Stocks || !HP.State.getPrice || !HP.State.getShares) return;

        var stocks = HP.Data.Stocks.getAll();
        var html = '';
        for (var i = 0; i < stocks.length; i++) {
            var s = stocks[i];
            var price = HP.State.getPrice(s.id);
            var resting = HP.State.getRestingPrice ? HP.State.getRestingPrice(s.id) : s.basePrice;
            var shares = HP.State.getShares(s.id);
            var cost1 = Math.ceil(price * 1 * (1 + feePct / 100));
            var cost10 = Math.ceil(price * 10 * (1 + feePct / 100));
            var cost100 = Math.ceil(price * 100 * (1 + feePct / 100));
            var canBuy1 = bank >= cost1;
            var canBuy10 = bank >= cost10;
            var canBuy100 = bank >= cost100;
            html += '<div class="stock-row" data-stock-id="' + s.id + '">';
            html += '<div class="stock-info">';
            html += '<span class="stock-icon">' + (s.icon || '📊') + '</span>';
            html += '<div class="stock-name-ticker">';
            html += '<span class="stock-name">' + s.name + '</span>';
            html += '<span class="stock-ticker">' + (s.ticker || s.id) + '</span>';
            html += '</div>';
            html += '<span class="stock-desc">' + (s.description || '') + '</span>';
            html += '</div>';
            html += '<div class="stock-price-block">';
            html += '<span class="stock-price">$' + HP.Helpers.formatNumber(price) + '</span>';
            html += '<span class="stock-resting" title="Typical value">(base $' + HP.Helpers.formatNumber(resting) + ')</span>';
            html += '</div>';
            html += '<div class="stock-shares">You: <strong>' + shares + '</strong></div>';
            html += '<div class="stock-actions">';
            html += '<button type="button" class="stock-btn buy" data-action="stock-buy" data-stock-id="' + s.id + '" data-shares="1" ' + (canBuy1 ? '' : ' disabled') + '>Buy 1</button>';
            html += '<button type="button" class="stock-btn buy" data-action="stock-buy" data-stock-id="' + s.id + '" data-shares="10" ' + (canBuy10 ? '' : ' disabled') + '>Buy 10</button>';
            html += '<button type="button" class="stock-btn buy" data-action="stock-buy" data-stock-id="' + s.id + '" data-shares="100" ' + (canBuy100 ? '' : ' disabled') + '>Buy 100</button>';
            if (shares >= 1) {
                html += '<button type="button" class="stock-btn sell" data-action="stock-sell" data-stock-id="' + s.id + '" data-shares="1">Sell 1</button>';
                html += '<button type="button" class="stock-btn sell" data-action="stock-sell" data-stock-id="' + s.id + '" data-shares="10" ' + (shares < 10 ? ' disabled' : '') + '>Sell 10</button>';
                html += '<button type="button" class="stock-btn sell" data-action="stock-sell" data-stock-id="' + s.id + '" data-shares="100" ' + (shares < 100 ? ' disabled' : '') + '>Sell 100</button>';
                html += '<button type="button" class="stock-btn sell sell-all" data-action="stock-sell" data-stock-id="' + s.id + '" data-shares="' + shares + '" data-confirm-sell-all="1">Sell all</button>';
            }
            html += '</div>';
            html += '</div>';
        }
        var portfolioValue = HP.State.getPortfolioValue ? HP.State.getPortfolioValue() : 0;
        var hasAnyShares = portfolioValue > 0;
        if (stocks.length === 0) {
            listEl.innerHTML = '<p class="empty-state">No stocks defined.</p>';
        } else if (!hasAnyShares) {
            listEl.innerHTML = html + '<p class="empty-state empty-state-subtle">You don\'t own any shares yet. Buy shares above – prices update every ' + (HP.State.getStockTickIntervalSec ? HP.State.getStockTickIntervalSec() : 60) + 's.</p>';
        } else {
            listEl.innerHTML = html;
        }
    }

    HP.Renderer._views.stocks = { update: update };
})();
