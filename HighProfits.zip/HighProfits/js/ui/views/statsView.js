/**
 * Stats view – registers with HP.Renderer._views['stats'].
 */
(function() {
    'use strict';

    function update(ctx) {
        var elements = ctx.elements;
        var state = HP.State.getState();
        var stats = state.stats || {};
        var money = HP.State.getMoney();
        var heat = HP.State.getHeat();
        var level = HP.State.getLevel();
        var rank = HP.State.getRank();
        var properties = HP.State.getProperties ? HP.State.getProperties() : { owned: [] };

        // Economy
        var el = document.getElementById('stat-total-earned');
        if (el) el.textContent = '$' + HP.Helpers.formatNumber(stats.totalMoneyEarned || 0);
        el = document.getElementById('stat-current-money');
        if (el) el.textContent = '$' + HP.Helpers.formatNumber(money);
        el = document.getElementById('stat-biggest-sale');
        if (el) el.textContent = '$' + HP.Helpers.formatNumber(stats.biggestSale || 0);
        el = document.getElementById('stat-total-sales');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.totalSold || 0) + 'g';

        // Growing
        el = document.getElementById('stat-plants-grown');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.plantsGrown || 0);
        el = document.getElementById('stat-plants-died');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.plantsDied || 0);
        el = document.getElementById('stat-best-harvest');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.bestHarvest || 0) + 'g';
        el = document.getElementById('stat-total-harvested');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.totalHarvested || 0) + 'g';

        // Quality breakdown
        var byQual = stats.harvestedByQuality || { low: 0, medium: 0, good: 0, premium: 0 };
        el = document.getElementById('stat-quality-low');
        if (el) el.textContent = HP.Helpers.formatNumber(byQual.low || 0) + 'g';
        el = document.getElementById('stat-quality-medium');
        if (el) el.textContent = HP.Helpers.formatNumber(byQual.medium || 0) + 'g';
        el = document.getElementById('stat-quality-good');
        if (el) el.textContent = HP.Helpers.formatNumber(byQual.good || 0) + 'g';
        el = document.getElementById('stat-quality-premium');
        if (el) el.textContent = HP.Helpers.formatNumber(byQual.premium || 0) + 'g';

        // Heat
        el = document.getElementById('stat-current-heat');
        if (el) el.textContent = Math.round(heat) + '%';
        el = document.getElementById('stat-raids-total');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.raidsTotal || 0);
        el = document.getElementById('stat-payoffs-total');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.heatPayOffsTotal || 0);
        el = document.getElementById('stat-heat-reduction');
        if (el) {
            var heatMult = HP.Heat && HP.Heat.getHeatGainMultiplier ? HP.Heat.getHeatGainMultiplier() : 1;
            var reduction = Math.round((1 - heatMult) * 100);
            el.textContent = reduction + '%';
        }

        // Time
        el = document.getElementById('stat-play-time');
        if (el) {
            var seconds = Math.floor(stats.playTime || 0);
            var hours = Math.floor(seconds / 3600);
            var mins = Math.floor((seconds % 3600) / 60);
            el.textContent = hours > 0 ? hours + 'h ' + mins + 'm' : mins + 'm';
        }
        el = document.getElementById('stat-current-level');
        if (el) el.textContent = level;
        el = document.getElementById('stat-current-rank');
        if (el) el.textContent = rank;
        el = document.getElementById('stat-properties-owned');
        if (el) el.textContent = (properties.owned || []).length;

        // Strain Mastery
        var masteryEl = document.getElementById('stats-strain-mastery');
        if (masteryEl && HP.State.getAllMasteries) {
            var masteries = HP.State.getAllMasteries();
            var seedIds = Object.keys(masteries);
            var entries = [];
            for (var i = 0; i < seedIds.length; i++) {
                var m = masteries[seedIds[i]];
                if (m && m.harvests > 0) {
                    var seed = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedIds[i]) : null;
                    if (!seed && HP.State.getCustomStrains) {
                        var custom = HP.State.getCustomStrains();
                        seed = custom[seedIds[i]];
                    }
                    entries.push({
                        seedId: seedIds[i],
                        seed: seed,
                        harvests: m.harvests,
                        level: m.level
                    });
                }
            }
            entries.sort(function(a, b) { return b.level - a.level || b.harvests - a.harvests; });

            var html = '';
            if (entries.length === 0) {
                html = '<div class="stats-mastery-empty">Harvest plants to build strain mastery. Each 10 harvests of a strain = +1 level (max 5).</div>';
            } else {
                for (var j = 0; j < entries.length; j++) {
                    var e = entries[j];
                    var name = e.seed ? e.seed.name : e.seedId;
                    var bonus = HP.State.getStrainBonus ? HP.State.getStrainBonus(e.seedId) : null;
                    var bonusStr = bonus && (bonus.yieldBonus > 0 || bonus.qualityBonus > 0) ? ' (+' + bonus.yieldBonus + '% yield, +' + bonus.qualityBonus + '% qual)' : '';
                    html += '<div class="stats-mastery-item">';
                    html += '<span class="stats-mastery-name">' + (e.seed ? e.seed.icon : '🌱') + ' ' + name + '</span>';
                    html += '<span class="stats-mastery-level">Lv.' + e.level + '</span>';
                    html += '<span class="stats-mastery-harvests">' + e.harvests + ' harvests' + bonusStr + '</span>';
                    html += '</div>';
                }
            }
            masteryEl.innerHTML = html;
        }
    }

    HP.Renderer._views.stats = { update: update };
})();
