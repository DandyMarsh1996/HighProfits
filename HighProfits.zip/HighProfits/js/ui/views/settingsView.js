/**
 * Settings view – sound, volume, tutorial hints. Persists to localStorage.
 */
(function() {
    'use strict';

    var SETTINGS_KEYS = {
        sound: 'highprofits_sound_enabled',
        volume: 'highprofits_sound_volume',
        ambient: 'highprofits_sound_ambient',
        tutorialHints: 'highprofits_tutorial_hints',
        fontSize: 'highprofits_font_size',
        highContrast: 'highprofits_high_contrast',
        reducedMotion: 'highprofits_reduced_motion'
    };

    function applyAccessibility() {
        var body = document.body;
        if (!body) return;
        var fs = localStorage.getItem(SETTINGS_KEYS.fontSize) || 'default';
        body.classList.remove('font-size-large', 'font-size-larger');
        if (fs === 'large') body.classList.add('font-size-large');
        else if (fs === 'larger') body.classList.add('font-size-larger');
        if (localStorage.getItem(SETTINGS_KEYS.highContrast) === 'true') body.classList.add('high-contrast');
        else body.classList.remove('high-contrast');
        if (localStorage.getItem(SETTINGS_KEYS.reducedMotion) === 'true') body.classList.add('reduced-motion');
        else body.classList.remove('reduced-motion');
    }
    var bound = false;

    function bindSettingsForm() {
        if (bound) return;
        var soundCb = document.getElementById('setting-sound-enabled');
        var ambientCb = document.getElementById('setting-ambient-enabled');
        var volumeSlider = document.getElementById('setting-volume');
        var volumeValue = document.getElementById('setting-volume-value');
        var tutorialCb = document.getElementById('setting-tutorial-hints');

        if (soundCb) {
            soundCb.addEventListener('change', function() {
                var on = this.checked;
                localStorage.setItem(SETTINGS_KEYS.sound, on ? 'true' : 'false');
                if (HP.SoundManager && HP.SoundManager.setEnabled) HP.SoundManager.setEnabled(on);
            });
        }
        if (ambientCb) {
            ambientCb.addEventListener('change', function() {
                var on = this.checked;
                localStorage.setItem(SETTINGS_KEYS.ambient, on ? 'true' : 'false');
                if (HP.SoundManager && HP.SoundManager.setAmbientEnabled) HP.SoundManager.setAmbientEnabled(on);
            });
        }
        if (volumeSlider && volumeValue) {
            volumeSlider.addEventListener('input', function() {
                var pct = parseInt(this.value, 10);
                var vol = pct / 100;
                localStorage.setItem(SETTINGS_KEYS.volume, vol.toString());
                if (HP.SoundManager && HP.SoundManager.setVolume) HP.SoundManager.setVolume(vol);
                volumeValue.textContent = pct + '%';
            });
        }
        if (tutorialCb) {
            tutorialCb.addEventListener('change', function() {
                var on = this.checked;
                localStorage.setItem(SETTINGS_KEYS.tutorialHints, on ? 'true' : 'false');
            });
        }
        var fontSizeSelect = document.getElementById('setting-font-size');
        var highContrastCb = document.getElementById('setting-high-contrast');
        var reducedMotionCb = document.getElementById('setting-reduced-motion');
        if (fontSizeSelect) {
            fontSizeSelect.addEventListener('change', function() {
                localStorage.setItem(SETTINGS_KEYS.fontSize, this.value);
                applyAccessibility();
            });
        }
        if (highContrastCb) {
            highContrastCb.addEventListener('change', function() {
                localStorage.setItem(SETTINGS_KEYS.highContrast, this.checked ? 'true' : 'false');
                applyAccessibility();
            });
        }
        if (reducedMotionCb) {
            reducedMotionCb.addEventListener('change', function() {
                localStorage.setItem(SETTINGS_KEYS.reducedMotion, this.checked ? 'true' : 'false');
                applyAccessibility();
            });
        }
        var titleSelect = document.getElementById('setting-title');
        if (titleSelect) {
            titleSelect.addEventListener('change', function() {
                var id = this.value;
                if (HP.State && HP.State.setSelectedTitleId) HP.State.setSelectedTitleId(id);
                if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
            });
        }
        bound = true;
    }

    function update(ctx) {
        bindSettingsForm();

        var soundCb = document.getElementById('setting-sound-enabled');
        var ambientCb = document.getElementById('setting-ambient-enabled');
        var volumeSlider = document.getElementById('setting-volume');
        var volumeValue = document.getElementById('setting-volume-value');
        var tutorialCb = document.getElementById('setting-tutorial-hints');

        if (soundCb) {
            var soundSaved = localStorage.getItem(SETTINGS_KEYS.sound);
            soundCb.checked = soundSaved !== 'false';
        }
        if (ambientCb) {
            var ambientSaved = localStorage.getItem(SETTINGS_KEYS.ambient);
            ambientCb.checked = ambientSaved === 'true';
        }
        if (volumeSlider && volumeValue) {
            var volSaved = localStorage.getItem(SETTINGS_KEYS.volume);
            var vol = volSaved != null ? parseFloat(volSaved) : 0.5;
            vol = Math.max(0, Math.min(1, vol));
            var pct = Math.round(vol * 100);
            volumeSlider.value = pct;
            volumeValue.textContent = pct + '%';
        }
        if (tutorialCb) {
            var hintsSaved = localStorage.getItem(SETTINGS_KEYS.tutorialHints);
            tutorialCb.checked = hintsSaved !== 'false';
        }
        var fontSizeSelect = document.getElementById('setting-font-size');
        var highContrastCb = document.getElementById('setting-high-contrast');
        var reducedMotionCb = document.getElementById('setting-reduced-motion');
        if (fontSizeSelect) {
            fontSizeSelect.value = localStorage.getItem(SETTINGS_KEYS.fontSize) || 'default';
        }
        if (highContrastCb) {
            highContrastCb.checked = localStorage.getItem(SETTINGS_KEYS.highContrast) === 'true';
        }
        if (reducedMotionCb) {
            reducedMotionCb.checked = localStorage.getItem(SETTINGS_KEYS.reducedMotion) === 'true';
        }
        applyAccessibility();
        var titleSelect = document.getElementById('setting-title');
        if (titleSelect && HP.State && HP.Data.Titles) {
            var unlocked = HP.State.getUnlockedTitles ? HP.State.getUnlockedTitles() : [];
            var selected = HP.State.getSelectedTitleId ? HP.State.getSelectedTitleId() : 'street_hustler';
            var defaultId = HP.Data.Titles.getDefaultId ? HP.Data.Titles.getDefaultId() : 'street_hustler';
            var all = HP.Data.Titles.getAll ? HP.Data.Titles.getAll() : [];
            var opts = [];
            all.forEach(function(t) {
                if (t.default || unlocked.indexOf(t.id) !== -1) opts.push(t);
            });
            titleSelect.innerHTML = opts.map(function(t) {
                return '<option value="' + t.id + '"' + (t.id === selected ? ' selected' : '') + '>' + t.name + '</option>';
            }).join('');
        }
    }

    HP.Renderer._views.settings = { update: update };
    HP.Accessibility = { apply: applyAccessibility };
})();
