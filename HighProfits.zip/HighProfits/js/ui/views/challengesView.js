/**
 * Challenges view – registers with HP.Renderer._views['challenges'].
 */
(function() {
    'use strict';

    function formatTimeForChallenge(seconds) {
        seconds = Math.max(0, Math.floor(Number(seconds) || 0));
        if (seconds < 60) return seconds + 's';
        var minsTotal = Math.floor(seconds / 60);
        if (minsTotal < 60) return minsTotal + 'm';
        var hours = Math.floor(minsTotal / 60);
        var mins = minsTotal % 60;
        if (mins === 0) return hours + 'h';
        return hours + 'h ' + mins + 'm';
    }

    function inferChallengeCategory(challenge) {
        if (!challenge) return 'General';
        switch (challenge.type) {
            case HP.Challenges.CHALLENGE_TYPES.EARN_TOTAL: return 'Money';
            case HP.Challenges.CHALLENGE_TYPES.SELL_TOTAL: return 'Sales';
            case HP.Challenges.CHALLENGE_TYPES.HARVEST_TOTAL: return 'Harvesting';
            case HP.Challenges.CHALLENGE_TYPES.GROW_TOTAL: return 'Harvesting';
            case HP.Challenges.CHALLENGE_TYPES.REACH_LEVEL: return 'Progression';
            case HP.Challenges.CHALLENGE_TYPES.OWN_PROPERTIES: return 'Properties';
            case HP.Challenges.CHALLENGE_TYPES.ROOM_UPGRADES_TOTAL: return 'Upgrades';
            case HP.Challenges.CHALLENGE_TYPES.GROWER_WORKERS_TOTAL: return 'Workers';
            case HP.Challenges.CHALLENGE_TYPES.OWN_SEEDS_TOTAL: return 'Inventory';
            case HP.Challenges.CHALLENGE_TYPES.OWN_EQUIPMENT_TOTAL: return 'Inventory';
            case HP.Challenges.CHALLENGE_TYPES.PLAY_TIME_SECONDS: return 'Time';
            default: return 'General';
        }
    }

    function inferChallengeSubCategory(challenge) {
        if (!challenge) return 'Milestones';
        if (challenge.type === HP.Challenges.CHALLENGE_TYPES.OWN_SEEDS_TOTAL || challenge.type === HP.Challenges.CHALLENGE_TYPES.OWN_EQUIPMENT_TOTAL) {
            return 'Stockpiles';
        }
        return 'Milestones';
    }

    function update(ctx) {
        var elements = ctx.elements;
        var challengeFilters = ctx.challengeFilters;
        if (!elements.challengesGrid || !HP.Challenges) return;

        var state = HP.State.getState();
        var playerLevel = state.level;
        var allChallenges = HP.Challenges.getAvailableChallenges(playerLevel);
        var completedChallenges = HP.State.getChallenges().completed;

        if (elements.challengeStatusFilter) {
            challengeFilters.status = elements.challengeStatusFilter.value || challengeFilters.status || 'all';
        }
        if (elements.challengeCategoryFilter) {
            challengeFilters.category = elements.challengeCategoryFilter.value || challengeFilters.category || 'all';
        }
        if (elements.challengeSubFilter) {
            challengeFilters.sub = elements.challengeSubFilter.value || challengeFilters.sub || 'all';
        }

        // Build category/sub lists from available challenges
        var chCats = {};
        var chSubsByCat = {};
        for (var i = 0; i < allChallenges.length; i++) {
            var ch = allChallenges[i];
            var cat = ch.category || inferChallengeCategory(ch);
            var sub = ch.subCategory || inferChallengeSubCategory(ch);
            chCats[cat] = true;
            if (!chSubsByCat[cat]) chSubsByCat[cat] = {};
            chSubsByCat[cat][sub] = true;
        }

        var chCatList = Object.keys(chCats);
        chCatList.sort();

        if (elements.challengeCategoryFilter) {
            var prev = elements.challengeCategoryFilter.value || 'all';
            var htmlCat = '<option value="all">All categories</option>';
            for (var ci = 0; ci < chCatList.length; ci++) {
                htmlCat += '<option value="' + chCatList[ci] + '">' + chCatList[ci] + '</option>';
            }
            elements.challengeCategoryFilter.innerHTML = htmlCat;
            if (prev && (prev === 'all' || chCats[prev])) elements.challengeCategoryFilter.value = prev;
            challengeFilters.category = elements.challengeCategoryFilter.value || 'all';
        }

        if (elements.challengeSubFilter) {
            var prevS = elements.challengeSubFilter.value || 'all';
            var subsMap2 = {};
            if (challengeFilters.category !== 'all') {
                subsMap2 = chSubsByCat[challengeFilters.category] || {};
            } else {
                for (var catKey2 in chSubsByCat) {
                    for (var subKey2 in chSubsByCat[catKey2]) subsMap2[subKey2] = true;
                }
            }
            var subList2 = Object.keys(subsMap2);
            subList2.sort();
            var htmlSub = '<option value="all">All sections</option>';
            for (var si2 = 0; si2 < subList2.length; si2++) {
                htmlSub += '<option value="' + subList2[si2] + '">' + subList2[si2] + '</option>';
            }
            elements.challengeSubFilter.innerHTML = htmlSub;
            elements.challengeSubFilter.disabled = false;
            if (prevS && (prevS === 'all' || subsMap2[prevS])) {
                elements.challengeSubFilter.value = prevS;
            } else {
                elements.challengeSubFilter.value = 'all';
            }
            challengeFilters.sub = elements.challengeSubFilter.value || 'all';
        }

        var html = '';
        for (var i = 0; i < allChallenges.length; i++) {
            var challenge = allChallenges[i];
            var chCat = challenge.category || inferChallengeCategory(challenge);
            var chSub = challenge.subCategory || inferChallengeSubCategory(challenge);
            if (challengeFilters.category !== 'all' && chCat !== challengeFilters.category) continue;
            if (challengeFilters.sub !== 'all' && chSub !== challengeFilters.sub) continue;

            var isCompleted = completedChallenges.indexOf(challenge.id) !== -1;
            var progress = HP.Challenges.checkChallengeProgress(challenge, state);
            var statusFilter = challengeFilters.status || 'all';
            if (statusFilter === 'completed' && !isCompleted) continue;
            if (statusFilter === 'in_progress' && (isCompleted || (progress.progress === 0))) continue;
            if (statusFilter === 'not_started' && (isCompleted || (progress.progress > 0))) continue;

            var cardClass = 'challenge-card';
            if (isCompleted) cardClass += ' completed';

            html += '<div class="' + cardClass + '">';
            html += '<div class="challenge-header">';
            html += '<div class="challenge-icon">' + challenge.icon + '</div>';
            html += '<div class="challenge-info">';
            html += '<div class="challenge-name">' + challenge.name + '</div>';
            html += '<div class="challenge-desc">' + challenge.description + '</div>';
            html += '<div class="achievement-meta">' + chCat + ' • ' + chSub + '</div>';
            html += '</div>';
            if (isCompleted) {
                html += '<div class="challenge-badge">✓</div>';
            }
            html += '</div>';

            html += '<div class="challenge-progress">';
            html += '<div class="progress-bar">';
            html += '<div class="progress-fill" style="width: ' + progress.percentage + '%"></div>';
            html += '</div>';
            if (challenge.type === HP.Challenges.CHALLENGE_TYPES.PLAY_TIME_SECONDS) {
                html += '<div class="progress-text">' + formatTimeForChallenge(progress.progress) + ' / ' + formatTimeForChallenge(progress.target) + '</div>';
            } else {
                html += '<div class="progress-text">' + progress.progress + ' / ' + progress.target + '</div>';
            }
            html += '</div>';

            if (isCompleted) {
                html += '<div class="challenge-reward completed">';
                html += 'Reward: +$' + challenge.reward.money + ' +' + challenge.reward.xp + ' XP';
                html += '</div>';
            } else {
                html += '<div class="challenge-reward">';
                html += 'Reward: +$' + challenge.reward.money + ' +' + challenge.reward.xp + ' XP';
                html += '</div>';
            }

            html += '</div>';
        }

        if (html === '') {
            html = '<div class="empty-state"><span class="empty-state-icon" aria-hidden="true">\uD83C\uDFAF</span><span class="empty-state-message">No challenges match the filters, or none are available at your level yet. Level up to unlock more challenges and rewards.</span></div>';
        }
        elements.challengesGrid.innerHTML = html;
    }

    HP.Renderer._views.challenges = { update: update };
})();
