/**
 * Inventory view – weed counts, seeds list, equipment list with filtering/sorting.
 */
(function() {
    'use strict';

    var qualityOrder = { low: 1, medium: 2, good: 3, premium: 4 };
    var filtersBound = false;

    function bindInventorySellButtons() {
        document.querySelectorAll('.sell-item-btn').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                var type = this.getAttribute('data-type');
                var id = this.getAttribute('data-id');
                if (type === 'equipment') HP.Events.sellEquipment(id);
                else if (type === 'seed') HP.Events.sellSeeds(id);
            });
        });
    }

    function bindFilters() {
        if (filtersBound) return;
        var seedsFilter = document.getElementById('inv-seeds-filter');
        var seedsSort = document.getElementById('inv-seeds-sort');
        var seedsSearch = document.getElementById('inv-seeds-search');
        var equipFilter = document.getElementById('inv-equip-filter');
        var equipSort = document.getElementById('inv-equip-sort');
        var equipSearch = document.getElementById('inv-equip-search');

        var triggerUpdate = function() {
            if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
        };

        if (seedsFilter) seedsFilter.addEventListener('change', triggerUpdate);
        if (seedsSort) seedsSort.addEventListener('change', triggerUpdate);
        if (seedsSearch) {
            seedsSearch.addEventListener('input', triggerUpdate);
            seedsSearch.addEventListener('keydown', function(e) { e.stopPropagation(); });
        }
        if (equipFilter) equipFilter.addEventListener('change', triggerUpdate);
        if (equipSort) equipSort.addEventListener('change', triggerUpdate);
        if (equipSearch) {
            equipSearch.addEventListener('input', triggerUpdate);
            equipSearch.addEventListener('keydown', function(e) { e.stopPropagation(); });
        }
        filtersBound = true;
    }

    function updateLaunderPanel() {
        var cashDisplay = document.getElementById('launder-cash-display');
        var bankDisplay = document.getElementById('launder-bank-display');
        var cashCapEl = document.getElementById('launder-cash-cap');
        var bankCapEl = document.getElementById('launder-bank-cap');
        var feeText = document.getElementById('launder-fee-text');
        var channelInput = document.getElementById('launder-channel');
        var channelListEl = document.getElementById('launder-channel-list');
        if (cashDisplay) cashDisplay.textContent = HP.Helpers.formatNumber(Math.floor(HP.State.getCash ? HP.State.getCash() : 0));
        if (bankDisplay) bankDisplay.textContent = HP.Helpers.formatNumber(Math.floor(HP.State.getBank ? HP.State.getBank() : 0));
        if (cashCapEl && HP.State.getCashCap) cashCapEl.textContent = HP.Helpers.formatNumber(HP.State.getCashCap());
        if (bankCapEl && HP.State.getBankCap) bankCapEl.textContent = HP.Helpers.formatNumber(HP.State.getBankCap());

        var launderActions = HP.Events && HP.Events.LaunderActions;
        var channels = launderActions && launderActions.getChannels ? launderActions.getChannels() : [];
        var selectedChannel = (channelInput && channelInput.value) || 'contact';
        var validIds = channels.map(function(c) { return c.id; });
        if (validIds.indexOf(selectedChannel) === -1) {
            selectedChannel = 'contact';
            if (channelInput) channelInput.value = 'contact';
        }
        if (channelListEl && channels.length) {
            var html = '';
            for (var i = 0; i < channels.length; i++) {
                var ch = channels[i];
                var selected = ch.id === selectedChannel ? ' launder-channel-selected' : '';
                var capText = ch.capacityRemaining != null ? ' ($' + HP.Helpers.formatNumber(ch.capacityRemaining) + ' left today)' : ' (no limit)';
                html += '<button type="button" class="launder-channel-btn' + selected + '" data-channel="' + ch.id + '" title="' + ch.feePercent + '% fee' + capText + '">' + ch.label + capText + '</button>';
            }
            channelListEl.innerHTML = html;
        } else if (channelListEl) {
            channelListEl.innerHTML = '<span class="launder-no-channels">Grey contact only</span>';
        }
        if (feeText && launderActions && launderActions.getFeePercent) {
            var feePct = launderActions.getFeePercent(selectedChannel);
            var label = selectedChannel === 'contact' ? 'Grey contact' : (HP.Data.Businesses && HP.Data.Businesses.get ? (HP.Data.Businesses.get(selectedChannel).name || selectedChannel) : selectedChannel);
            feeText.textContent = label + ': ' + feePct + '% fee' + (selectedChannel !== 'contact' && HP.State.getLaunderCapacityRemaining ? ' · $' + HP.Helpers.formatNumber(HP.State.getLaunderCapacityRemaining(selectedChannel)) + ' capacity left today' : '');
        }
    }

    function updateFallbackHustlePanel() {
        var panel = document.getElementById('fallback-hustle-panel');
        var btn = document.getElementById('btn-fallback-hustle');
        var statusEl = document.getElementById('fallback-hustle-status');
        if (!panel || !HP.Events || !HP.Events.LaunderActions || !HP.Events.LaunderActions.getFallbackHustleStatus) return;
        var status = HP.Events.LaunderActions.getFallbackHustleStatus();
        if (status.visible) {
            panel.classList.remove('hidden');
            if (btn) {
                btn.disabled = !status.canUse;
                btn.textContent = status.canUse ? 'Do a quick hustle (+$' + HP.Helpers.formatNumber(status.amount) + ' cash)' : 'Do a quick hustle';
            }
            if (statusEl) {
                if (status.canUse) {
                    statusEl.textContent = '';
                } else {
                    var mins = Math.ceil(status.cooldownRemainingMs / 60000);
                    var secs = Math.ceil((status.cooldownRemainingMs % 60000) / 1000);
                    statusEl.textContent = 'Next available in ' + mins + 'm ' + secs + 's';
                }
            }
        } else {
            panel.classList.add('hidden');
            if (statusEl) statusEl.textContent = '';
        }
    }

    function getSeedsFilteredSorted(inventory) {
        var filterEl = document.getElementById('inv-seeds-filter');
        var sortEl = document.getElementById('inv-seeds-sort');
        var searchEl = document.getElementById('inv-seeds-search');
        var qualityFilter = filterEl ? filterEl.value : 'all';
        var sortValue = sortEl ? sortEl.value : 'name-asc';
        var searchTerm = searchEl ? searchEl.value.toLowerCase().trim() : '';

        var items = [];
        for (var seedId in inventory.seeds) {
            if (inventory.seeds[seedId] > 0) {
                var seed = HP.Data.Seeds.get(seedId);
                if (!seed) continue;
                items.push({ id: seedId, data: seed, qty: inventory.seeds[seedId] });
            }
        }

        // Filter by quality
        if (qualityFilter !== 'all') {
            items = items.filter(function(item) {
                return item.data.quality === qualityFilter;
            });
        }

        // Filter by search term
        if (searchTerm) {
            items = items.filter(function(item) {
                return item.data.name.toLowerCase().indexOf(searchTerm) !== -1 ||
                       (item.data.strainName && item.data.strainName.toLowerCase().indexOf(searchTerm) !== -1);
            });
        }

        // Sort
        items.sort(function(a, b) {
            switch (sortValue) {
                case 'name-asc': return a.data.name.localeCompare(b.data.name);
                case 'name-desc': return b.data.name.localeCompare(a.data.name);
                case 'qty-desc': return b.qty - a.qty;
                case 'qty-asc': return a.qty - b.qty;
                case 'quality-desc': return qualityOrder[b.data.quality] - qualityOrder[a.data.quality];
                case 'quality-asc': return qualityOrder[a.data.quality] - qualityOrder[b.data.quality];
                case 'value-desc': return b.data.cost - a.data.cost;
                default: return a.data.name.localeCompare(b.data.name);
            }
        });

        return items;
    }

    function getEquipmentFilteredSorted(inventory) {
        var filterEl = document.getElementById('inv-equip-filter');
        var sortEl = document.getElementById('inv-equip-sort');
        var searchEl = document.getElementById('inv-equip-search');
        var typeFilter = filterEl ? filterEl.value : 'all';
        var sortValue = sortEl ? sortEl.value : 'name-asc';
        var searchTerm = searchEl ? searchEl.value.toLowerCase().trim() : '';

        var items = [];
        for (var equipId in inventory.equipment) {
            if (inventory.equipment[equipId] > 0) {
                var equip = HP.Data.Equipment.get(equipId);
                if (!equip) continue;
                items.push({ id: equipId, data: equip, qty: inventory.equipment[equipId] });
            }
        }

        // Filter by type/section
        if (typeFilter !== 'all') {
            items = items.filter(function(item) {
                return item.data.section === typeFilter;
            });
        }

        // Filter by search term
        if (searchTerm) {
            items = items.filter(function(item) {
                return item.data.name.toLowerCase().indexOf(searchTerm) !== -1 ||
                       (item.data.description && item.data.description.toLowerCase().indexOf(searchTerm) !== -1);
            });
        }

        // Sort
        items.sort(function(a, b) {
            switch (sortValue) {
                case 'name-asc': return a.data.name.localeCompare(b.data.name);
                case 'name-desc': return b.data.name.localeCompare(a.data.name);
                case 'qty-desc': return b.qty - a.qty;
                case 'qty-asc': return a.qty - b.qty;
                case 'value-desc': return b.data.cost - a.data.cost;
                default: return a.data.name.localeCompare(b.data.name);
            }
        });

        return items;
    }

    function renderSeedRow(item) {
        var seed = item.data;
        var sellPrice = Math.floor(seed.cost * 0.5);
        var html = '<div class="inv-item-row">';
        html += '<span class="inv-item-name">' + seed.icon + ' ' + seed.name;
        html += '<span class="quality-badge ' + seed.quality + '">' + seed.quality + '</span>';
        html += '</span>';
        html += '<span class="inv-item-count">x' + item.qty + '</span>';
        html += '<button class="sell-item-btn" data-type="seed" data-id="' + item.id + '">Sell $' + sellPrice + '</button>';
        html += '</div>';
        return html;
    }

    function renderEquipmentRow(item) {
        var equip = item.data;
        var sellPrice = Math.floor(equip.cost * 0.5);
        var sectionLabel = equip.section ? equip.section.charAt(0).toUpperCase() + equip.section.slice(1) : '';
        var html = '<div class="inv-item-row">';
        html += '<span class="inv-item-name">' + equip.icon + ' ' + equip.name;
        if (sectionLabel) html += '<span class="type-badge">' + sectionLabel + '</span>';
        html += '</span>';
        html += '<span class="inv-item-count">x' + item.qty + '</span>';
        html += '<button class="sell-item-btn" data-type="equipment" data-id="' + item.id + '">Sell $' + sellPrice + '</button>';
        html += '</div>';
        return html;
    }

    function update(ctx) {
        var elements = ctx.elements;
        var inventory = HP.State.getInventory();

        bindFilters();
        updateLaunderPanel();
        updateFallbackHustlePanel();

        // Smoke buff status (one buff at a time)
        var smokeStatusEl = document.getElementById('smoke-buff-status');
        if (smokeStatusEl && HP.State.getActiveSmokeBuff) {
            var buff = HP.State.getActiveSmokeBuff();
            if (buff) {
                var remaining = Math.max(0, Math.ceil((buff.expiresAt - Date.now()) / 1000));
                var mins = Math.floor(remaining / 60);
                var secs = remaining % 60;
                var label = HP.State.getBuffTypeLabel ? HP.State.getBuffTypeLabel(buff.buffType) : buff.buffType;
                smokeStatusEl.textContent = 'Current buff: ' + (buff.strainName || buff.seedId) + ' — ' + label + ' (' + mins + ':' + (secs < 10 ? '0' : '') + secs + ' left)';
                smokeStatusEl.className = 'smoke-buff-status smoke-buff-active';
            } else {
                smokeStatusEl.textContent = 'No active buff';
                smokeStatusEl.className = 'smoke-buff-status';
            }
        }

        // Weed stock by strain (with Smoke 1g when no active buff)
        var weedListEl = document.getElementById('inv-weed-list');
        if (weedListEl) {
            var weed = inventory.weed || {};
            var seedIds = Object.keys(weed).filter(function(id) { return weed[id] > 0; });
            seedIds.sort(function(a, b) {
                var seedA = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(a) : null;
                var seedB = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(b) : null;
                var nameA = seedA ? (seedA.strainName || seedA.name) : a;
                var nameB = seedB ? (seedB.strainName || seedB.name) : b;
                return nameA.localeCompare(nameB);
            });
            var hasActiveBuff = HP.State.getActiveSmokeBuff ? !!HP.State.getActiveSmokeBuff() : false;
            var weedHtml = '';
            for (var w = 0; w < seedIds.length; w++) {
                var sid = seedIds[w];
                var seed = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(sid) : null;
                var name = seed ? (seed.strainName || seed.name) : sid;
                var q = seed ? seed.quality : 'low';
                var amt = weed[sid] || 0;
                weedHtml += '<div class="stock-item">';
                weedHtml += '<span class="quality-dot ' + q + '"></span>' + name;
                weedHtml += '<span class="stock-count">' + amt + 'g</span>';
                if (!hasActiveBuff && amt >= 1 && HP.State.setActiveSmokeBuff && HP.State.removeWeed) {
                    weedHtml += '<button type="button" class="btn-smoke inv-btn" data-action="smoke" data-seed-id="' + sid + '" title="Smoke 1g for a temporary buff">Smoke 1g</button>';
                }
                weedHtml += '</div>';
            }
            weedListEl.innerHTML = seedIds.length ? weedHtml : '<div class="empty-state">No product yet. Harvest plants in Grow Room.<div class="empty-state-action"><button type="button" class="btn-goto" data-goto-view="grow">Go to Grow Room</button></div></div>';
        }

        // Seeds with filtering/sorting
        if (elements.seedsInventory) {
            var seedItems = getSeedsFilteredSorted(inventory);
            var seedsHtml = '';
            for (var i = 0; i < seedItems.length; i++) {
                seedsHtml += renderSeedRow(seedItems[i]);
            }
            if (seedsHtml) {
                elements.seedsInventory.innerHTML = seedsHtml;
            } else {
                var filterActive = (document.getElementById('inv-seeds-filter') && document.getElementById('inv-seeds-filter').value !== 'all') ||
                                   (document.getElementById('inv-seeds-search') && document.getElementById('inv-seeds-search').value.trim());
                elements.seedsInventory.innerHTML = filterActive ? '<div class="empty-state">No seeds match filters</div>' : '<div class="empty-state">No seeds yet. Buy seeds at the Seed Dealer.<div class="empty-state-action"><button type="button" class="btn-goto" data-goto-view="dealer">Go to Seed Dealer</button></div></div>';
            }
        }

        // Equipment with filtering/sorting
        if (elements.equipmentInventory) {
            var equipItems = getEquipmentFilteredSorted(inventory);
            var equipHtml = '';
            for (var j = 0; j < equipItems.length; j++) {
                equipHtml += renderEquipmentRow(equipItems[j]);
            }
            if (equipHtml) {
                elements.equipmentInventory.innerHTML = equipHtml;
            } else {
                var eqFilterActive = (document.getElementById('inv-equip-filter') && document.getElementById('inv-equip-filter').value !== 'all') ||
                                     (document.getElementById('inv-equip-search') && document.getElementById('inv-equip-search').value.trim());
                elements.equipmentInventory.innerHTML = eqFilterActive ? '<div class="empty-state">No equipment matches filters</div>' : '<div class="empty-state">No equipment yet. Buy at Hardware or Garden Centre.<div class="empty-state-action"><button type="button" class="btn-goto" data-goto-view="hardware">Go to Hardware</button> <button type="button" class="btn-goto" data-goto-view="garden">Go to Garden Centre</button></div></div>';
            }
        }

        bindInventorySellButtons();
    }

    HP.Renderer._views.inventory = { update: update };
})();
