/**
 * Inventory view – weed counts, seeds list, equipment list with filtering/sorting.
 */
(function() {
    'use strict';

    var qualityOrder = { low: 1, medium: 2, good: 3, premium: 4 };
    var filtersBound = false;

    function bindInventorySellButtons() {
        document.querySelectorAll('.sell-item-btn').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                var type = this.getAttribute('data-type');
                var id = this.getAttribute('data-id');
                if (type === 'equipment') HP.Events.sellEquipment(id);
                else if (type === 'seed') HP.Events.sellSeeds(id);
            });
        });
    }

    function bindFilters() {
        if (filtersBound) return;
        var seedsFilter = document.getElementById('inv-seeds-filter');
        var seedsSort = document.getElementById('inv-seeds-sort');
        var seedsSearch = document.getElementById('inv-seeds-search');
        var equipFilter = document.getElementById('inv-equip-filter');
        var equipSort = document.getElementById('inv-equip-sort');
        var equipSearch = document.getElementById('inv-equip-search');

        var triggerUpdate = function() {
            if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
        };

        if (seedsFilter) seedsFilter.addEventListener('change', triggerUpdate);
        if (seedsSort) seedsSort.addEventListener('change', triggerUpdate);
        if (seedsSearch) {
            seedsSearch.addEventListener('input', triggerUpdate);
            seedsSearch.addEventListener('keydown', function(e) { e.stopPropagation(); });
        }
        if (equipFilter) equipFilter.addEventListener('change', triggerUpdate);
        if (equipSort) equipSort.addEventListener('change', triggerUpdate);
        if (equipSearch) {
            equipSearch.addEventListener('input', triggerUpdate);
            equipSearch.addEventListener('keydown', function(e) { e.stopPropagation(); });
        }
        filtersBound = true;
    }

    function updateLaunderPanel() {
        var cashDisplay = document.getElementById('launder-cash-display');
        var bankDisplay = document.getElementById('launder-bank-display');
        var cashCapEl = document.getElementById('launder-cash-cap');
        var bankCapEl = document.getElementById('launder-bank-cap');
        var feeText = document.getElementById('launder-fee-text');
        if (cashDisplay) cashDisplay.textContent = HP.Helpers.formatNumber(Math.floor(HP.State.getCash ? HP.State.getCash() : 0));
        if (bankDisplay) bankDisplay.textContent = HP.Helpers.formatNumber(Math.floor(HP.State.getBank ? HP.State.getBank() : 0));
        if (cashCapEl && HP.State.getCashCap) cashCapEl.textContent = HP.Helpers.formatNumber(HP.State.getCashCap());
        if (bankCapEl && HP.State.getBankCap) bankCapEl.textContent = HP.Helpers.formatNumber(HP.State.getBankCap());
        if (feeText && HP.Events && HP.Events.LaunderActions && HP.Events.LaunderActions.getFeePercent) {
            feeText.textContent = HP.Events.LaunderActions.getFeePercent() + '% fee';
        }
    }

    function getSeedsFilteredSorted(inventory) {
        var filterEl = document.getElementById('inv-seeds-filter');
        var sortEl = document.getElementById('inv-seeds-sort');
        var searchEl = document.getElementById('inv-seeds-search');
        var qualityFilter = filterEl ? filterEl.value : 'all';
        var sortValue = sortEl ? sortEl.value : 'name-asc';
        var searchTerm = searchEl ? searchEl.value.toLowerCase().trim() : '';

        var items = [];
        for (var seedId in inventory.seeds) {
            if (inventory.seeds[seedId] > 0) {
                var seed = HP.Data.Seeds.get(seedId);
                if (!seed) continue;
                items.push({ id: seedId, data: seed, qty: inventory.seeds[seedId] });
            }
        }

        // Filter by quality
        if (qualityFilter !== 'all') {
            items = items.filter(function(item) {
                return item.data.quality === qualityFilter;
            });
        }

        // Filter by search term
        if (searchTerm) {
            items = items.filter(function(item) {
                return item.data.name.toLowerCase().indexOf(searchTerm) !== -1 ||
                       (item.data.strainName && item.data.strainName.toLowerCase().indexOf(searchTerm) !== -1);
            });
        }

        // Sort
        items.sort(function(a, b) {
            switch (sortValue) {
                case 'name-asc': return a.data.name.localeCompare(b.data.name);
                case 'name-desc': return b.data.name.localeCompare(a.data.name);
                case 'qty-desc': return b.qty - a.qty;
                case 'qty-asc': return a.qty - b.qty;
                case 'quality-desc': return qualityOrder[b.data.quality] - qualityOrder[a.data.quality];
                case 'quality-asc': return qualityOrder[a.data.quality] - qualityOrder[b.data.quality];
                case 'value-desc': return b.data.cost - a.data.cost;
                default: return a.data.name.localeCompare(b.data.name);
            }
        });

        return items;
    }

    function getEquipmentFilteredSorted(inventory) {
        var filterEl = document.getElementById('inv-equip-filter');
        var sortEl = document.getElementById('inv-equip-sort');
        var searchEl = document.getElementById('inv-equip-search');
        var typeFilter = filterEl ? filterEl.value : 'all';
        var sortValue = sortEl ? sortEl.value : 'name-asc';
        var searchTerm = searchEl ? searchEl.value.toLowerCase().trim() : '';

        var items = [];
        for (var equipId in inventory.equipment) {
            if (inventory.equipment[equipId] > 0) {
                var equip = HP.Data.Equipment.get(equipId);
                if (!equip) continue;
                items.push({ id: equipId, data: equip, qty: inventory.equipment[equipId] });
            }
        }

        // Filter by type/section
        if (typeFilter !== 'all') {
            items = items.filter(function(item) {
                return item.data.section === typeFilter;
            });
        }

        // Filter by search term
        if (searchTerm) {
            items = items.filter(function(item) {
                return item.data.name.toLowerCase().indexOf(searchTerm) !== -1 ||
                       (item.data.description && item.data.description.toLowerCase().indexOf(searchTerm) !== -1);
            });
        }

        // Sort
        items.sort(function(a, b) {
            switch (sortValue) {
                case 'name-asc': return a.data.name.localeCompare(b.data.name);
                case 'name-desc': return b.data.name.localeCompare(a.data.name);
                case 'qty-desc': return b.qty - a.qty;
                case 'qty-asc': return a.qty - b.qty;
                case 'value-desc': return b.data.cost - a.data.cost;
                default: return a.data.name.localeCompare(b.data.name);
            }
        });

        return items;
    }

    function renderSeedRow(item) {
        var seed = item.data;
        var sellPrice = Math.floor(seed.cost * 0.5);
        var html = '<div class="inv-item-row">';
        html += '<span class="inv-item-name">' + seed.icon + ' ' + seed.name;
        html += '<span class="quality-badge ' + seed.quality + '">' + seed.quality + '</span>';
        html += '</span>';
        html += '<span class="inv-item-count">x' + item.qty + '</span>';
        html += '<button class="sell-item-btn" data-type="seed" data-id="' + item.id + '">Sell $' + sellPrice + '</button>';
        html += '</div>';
        return html;
    }

    function renderEquipmentRow(item) {
        var equip = item.data;
        var sellPrice = Math.floor(equip.cost * 0.5);
        var sectionLabel = equip.section ? equip.section.charAt(0).toUpperCase() + equip.section.slice(1) : '';
        var html = '<div class="inv-item-row">';
        html += '<span class="inv-item-name">' + equip.icon + ' ' + equip.name;
        if (sectionLabel) html += '<span class="type-badge">' + sectionLabel + '</span>';
        html += '</span>';
        html += '<span class="inv-item-count">x' + item.qty + '</span>';
        html += '<button class="sell-item-btn" data-type="equipment" data-id="' + item.id + '">Sell $' + sellPrice + '</button>';
        html += '</div>';
        return html;
    }

    function update(ctx) {
        var elements = ctx.elements;
        var inventory = HP.State.getInventory();

        bindFilters();
        updateLaunderPanel();

        // Weed stock
        if (elements.invWeedLow) elements.invWeedLow.textContent = inventory.weed.low || 0;
        if (elements.invWeedMedium) elements.invWeedMedium.textContent = inventory.weed.medium || 0;
        if (elements.invWeedGood) elements.invWeedGood.textContent = inventory.weed.good || 0;
        if (elements.invWeedPremium) elements.invWeedPremium.textContent = inventory.weed.premium || 0;

        // Seeds with filtering/sorting
        if (elements.seedsInventory) {
            var seedItems = getSeedsFilteredSorted(inventory);
            var seedsHtml = '';
            for (var i = 0; i < seedItems.length; i++) {
                seedsHtml += renderSeedRow(seedItems[i]);
            }
            if (seedsHtml) {
                elements.seedsInventory.innerHTML = seedsHtml;
            } else {
                var filterActive = (document.getElementById('inv-seeds-filter') && document.getElementById('inv-seeds-filter').value !== 'all') ||
                                   (document.getElementById('inv-seeds-search') && document.getElementById('inv-seeds-search').value.trim());
                elements.seedsInventory.innerHTML = filterActive ? '<div class="empty-state">No seeds match filters</div>' : '<div class="empty-state">No seeds yet</div>';
            }
        }

        // Equipment with filtering/sorting
        if (elements.equipmentInventory) {
            var equipItems = getEquipmentFilteredSorted(inventory);
            var equipHtml = '';
            for (var j = 0; j < equipItems.length; j++) {
                equipHtml += renderEquipmentRow(equipItems[j]);
            }
            if (equipHtml) {
                elements.equipmentInventory.innerHTML = equipHtml;
            } else {
                var eqFilterActive = (document.getElementById('inv-equip-filter') && document.getElementById('inv-equip-filter').value !== 'all') ||
                                     (document.getElementById('inv-equip-search') && document.getElementById('inv-equip-search').value.trim());
                elements.equipmentInventory.innerHTML = eqFilterActive ? '<div class="empty-state">No equipment matches filters</div>' : '<div class="empty-state">No equipment yet</div>';
            }
        }

        bindInventorySellButtons();
    }

    HP.Renderer._views.inventory = { update: update };
})();
