/**
 * Journal view – completion journal by category
 */
(function() {
    'use strict';

    function update(ctx) {
        var categoriesEl = document.getElementById('journal-categories');
        var summaryEl = document.getElementById('journal-summary');
        if (!categoriesEl) return;

        var journal = HP.Data.Journal;
        var completed = HP.State.getJournalCompleted ? HP.State.getJournalCompleted() : {};
        var allEntries = journal ? journal.getAll() : [];
        var total = allEntries.length;
        var done = 0;
        for (var id in completed) { if (completed[id]) done++; }

        if (summaryEl) summaryEl.textContent = done + ' / ' + total + ' completed';

        var cats = journal ? journal.getCategories() : {};
        var catOrder = [];
        for (var cid in cats) catOrder.push({ id: cid, name: cats[cid].name, order: cats[cid].order || 0 });
        catOrder.sort(function(a, b) { return a.order - b.order; });

        var html = '';
        for (var c = 0; c < catOrder.length; c++) {
            var cat = catOrder[c];
            var entries = journal.getByCategory(cat.id);
            if (entries.length === 0) continue;
            html += '<div class="journal-category">';
            html += '<h3>' + cat.name + '</h3>';
            html += '<div class="journal-entries">';
            for (var e = 0; e < entries.length; e++) {
                var ent = entries[e];
                var isDone = !!completed[ent.id];
                html += '<div class="journal-entry' + (isDone ? ' completed' : '') + '">';
                html += '<span class="journal-entry-check">' + (isDone ? '✓' : '○') + '</span>';
                html += '<div><span class="journal-entry-name">' + ent.name + '</span>';
                html += '<div class="journal-entry-desc">' + ent.description + '</div>';
                if (ent.rewardTitleId) {
                    var title = HP.Data.Titles && HP.Data.Titles.get(ent.rewardTitleId);
                    var titleName = title ? title.name : 'Unknown';
                    html += '<div class="journal-entry-reward">🏆 Unlocks title: ' + titleName + '</div>';
                }
                html += '</div></div>';
            }
            html += '</div></div>';
        }
        categoriesEl.innerHTML = html || '<p class="empty-state">No journal entries.</p>';
    }

    HP.Renderer._views.journal = { update: update };
})();
