/**
 * Achievements view – registers with HP.Renderer._views['achievements'].
 */
(function() {
    'use strict';

    function inferAchievementCategory(achievement) {
        var id = achievement && achievement.id ? achievement.id : '';
        if (id.indexOf('money') === 0 || id.indexOf('hundred') === 0 || id.indexOf('thousand') === 0) return 'Money';
        if (id.indexOf('gramsSold') === 0 || id.indexOf('firstSale') === 0) return 'Sales';
        if (id.indexOf('plantsHarvested') === 0 || id.indexOf('firstHarvest') === 0) return 'Harvesting';
        if (id.indexOf('reachLevel') === 0 || id === 'levelFive' || id === 'levelTen') return 'Progression';
        if (id.indexOf('ownProperties') === 0 || id.indexOf('own_') === 0 || id === 'firstProperty') return 'Properties';
        if (id.indexOf('roomUpgrades') === 0) return 'Upgrades';
        if (id.indexOf('growerWorkers') === 0) return 'Workers';
        if (id.indexOf('stockpile') === 0) return 'Inventory';
        if (id.indexOf('playTime') === 0) return 'Time';
        return 'General';
    }

    function inferAchievementSubCategory(achievement) {
        var id = achievement && achievement.id ? achievement.id : '';
        if (id.indexOf('own_') === 0) return 'Specific';
        return 'Milestones';
    }

    function update(ctx) {
        var elements = ctx.elements;
        var achievementFilters = ctx.achievementFilters;
        if (!elements.achievementsGrid) return;

        var achievements = HP.State.getAchievements();
        var allAchievements = HP.Data.Achievements.getAll();
        var unlockedIds = achievements.unlocked;
        var total = Object.keys(allAchievements).length;
        var unlocked = unlockedIds.length;
        var progress = total > 0 ? Math.round((unlocked / total) * 100) : 0;

        // Resolve current filters from UI (persist across renders)
        if (elements.achievementStatusFilter) {
            achievementFilters.status = elements.achievementStatusFilter.value || achievementFilters.status || 'all';
        }
        if (elements.achievementCategoryFilter) {
            achievementFilters.category = elements.achievementCategoryFilter.value || achievementFilters.category || 'all';
        }
        if (elements.achievementSubFilter) {
            achievementFilters.sub = elements.achievementSubFilter.value || achievementFilters.sub || 'all';
        }

        // Update stats
        if (elements.achievementsUnlocked) elements.achievementsUnlocked.textContent = unlocked;
        if (elements.achievementsTotal) elements.achievementsTotal.textContent = total;
        if (elements.achievementsProgress) elements.achievementsProgress.textContent = progress + '%';

        // Build category/subcategory lists
        var categoriesMap = {};
        var subsByCategory = {};
        var ids = HP.Data.Achievements.getIds();
        for (var i = 0; i < ids.length; i++) {
            var a = allAchievements[ids[i]];
            if (!a) continue;
            var cat = a.category || inferAchievementCategory(a);
            var sub = a.subCategory || inferAchievementSubCategory(a);
            categoriesMap[cat] = true;
            if (!subsByCategory[cat]) subsByCategory[cat] = {};
            subsByCategory[cat][sub] = true;
        }

        var categoryList = Object.keys(categoriesMap);
        categoryList.sort();
        categoryList.unshift('All');

        var selectedCat = achievementFilters.category || 'all';
        if (selectedCat === 'All') selectedCat = 'all';

        if (elements.achievementCategoryFilter) {
            var prevCat = elements.achievementCategoryFilter.value || 'all';
            var catHtml = '<option value="all">All categories</option>';
            for (var c = 0; c < categoryList.length; c++) {
                if (categoryList[c] === 'All') continue;
                catHtml += '<option value="' + categoryList[c] + '">' + categoryList[c] + '</option>';
            }
            elements.achievementCategoryFilter.innerHTML = catHtml;
            if (prevCat && (prevCat === 'all' || categoriesMap[prevCat])) {
                elements.achievementCategoryFilter.value = prevCat;
            }
            achievementFilters.category = elements.achievementCategoryFilter.value || 'all';
            selectedCat = achievementFilters.category;
        }

        // Subcategory options depend on selected category
        if (elements.achievementSubFilter) {
            var prevSub = elements.achievementSubFilter.value || 'all';
            var subsMap = {};
            if (selectedCat && selectedCat !== 'all') {
                subsMap = subsByCategory[selectedCat] || {};
            } else {
                for (var catKey in subsByCategory) {
                    for (var subKey in subsByCategory[catKey]) subsMap[subKey] = true;
                }
            }

            var subList = Object.keys(subsMap);
            subList.sort();
            var subHtml = '<option value="all">All sections</option>';
            for (var s = 0; s < subList.length; s++) {
                subHtml += '<option value="' + subList[s] + '">' + subList[s] + '</option>';
            }
            elements.achievementSubFilter.innerHTML = subHtml;
            elements.achievementSubFilter.disabled = false;
            if (prevSub && (prevSub === 'all' || subsMap[prevSub])) {
                elements.achievementSubFilter.value = prevSub;
            } else {
                elements.achievementSubFilter.value = 'all';
            }
            achievementFilters.sub = elements.achievementSubFilter.value || 'all';
        }

        // Render achievements grid
        var html = '';
        var achievementIds = HP.Data.Achievements.getIds();

        for (var i = 0; i < achievementIds.length; i++) {
            var id = achievementIds[i];
            var achievement = allAchievements[id];
            var isUnlocked = unlockedIds.indexOf(id) !== -1;
            if (!achievement) continue;

            var statusFilter = achievementFilters.status || 'all';
            if (statusFilter === 'unlocked' && !isUnlocked) continue;
            if (statusFilter === 'locked' && isUnlocked) continue;

            var aCat = achievement.category || inferAchievementCategory(achievement);
            var aSub = achievement.subCategory || inferAchievementSubCategory(achievement);
            if (achievementFilters.category !== 'all' && aCat !== achievementFilters.category) continue;
            if (achievementFilters.sub !== 'all' && aSub !== achievementFilters.sub) continue;

            var cardClass = 'achievement-card';
            if (isUnlocked) cardClass += ' unlocked';

            html += '<div class="' + cardClass + '">';
            html += '<div class="achievement-icon">' + (isUnlocked ? achievement.emoji : '🔒') + '</div>';
            html += '<div class="achievement-content">';
            html += '<div class="achievement-name">' + achievement.name + '</div>';
            html += '<div class="achievement-desc">' + achievement.description + '</div>';
            html += '<div class="achievement-meta">' + aCat + ' • ' + aSub + '</div>';
            if (achievement.xpReward && isUnlocked) {
                html += '<div class="achievement-reward">+' + achievement.xpReward + ' XP</div>';
            }
            html += '</div>';
            if (isUnlocked) {
                html += '<div class="achievement-badge">✓</div>';
            }
            html += '</div>';
        }

        elements.achievementsGrid.innerHTML = html;
    }

    HP.Renderer._views.achievements = { update: update };
})();
