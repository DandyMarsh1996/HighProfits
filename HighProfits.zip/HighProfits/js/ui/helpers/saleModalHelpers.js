/**
 * Sale modal pure helpers – customer request generation, fulfillable options.
 * Used by HP.Renderer. Load before renderer.js.
 */
var HP = HP || {};
HP.RendererHelpers = HP.RendererHelpers || {};

HP.RendererHelpers.SaleModal = (function() {
    'use strict';

    function getFulfillableOptions(customer) {
        if (!customer || !HP.State || !HP.State.getWeed) return [];
        var minA = customer.minAmount || 1;
        var maxA = customer.maxAmount || 1;
        var weed = HP.State.getWeed(); // all strains { seedId: amount }
        var options = [];
        for (var seedId in weed) {
            var available = weed[seedId] || 0;
            if (available >= minA) {
                var amount = Math.min(maxA, Math.floor(available));
                if (amount >= minA) options.push({ seedId: seedId, amount: amount });
            }
        }
        var blends = (HP.Mixing && HP.Mixing.getBlendsList) ? HP.Mixing.getBlendsList() : [];
        for (var i = 0; i < blends.length; i++) {
            var bl = blends[i];
            if (bl.amount >= minA) {
                var amt = Math.min(maxA, Math.floor(bl.amount));
                if (amt >= minA) options.push({ seedId: 'mixed:' + bl.blendKey, amount: amt });
            }
        }
        return options;
    }

    function getSeedIdsByQuality(quality) {
        var seeds = HP.Data.Seeds && HP.Data.Seeds.getAll ? HP.Data.Seeds.getAll() : {};
        var ids = [];
        for (var id in seeds) {
            if (seeds[id].quality === quality) ids.push(id);
        }
        return ids;
    }

    function generateCustomerRequest(customer, preferFulfillable) {
        var options = preferFulfillable ? getFulfillableOptions(customer) : [];
        var requestedSeedId;
        var requestedAmount;
        if (options.length > 0) {
            var pick = options[Math.floor(Math.random() * options.length)];
            requestedSeedId = pick.seedId;
            requestedAmount = pick.amount;
        } else {
            requestedAmount = Math.floor(Math.random() * (customer.maxAmount - customer.minAmount + 1)) + customer.minAmount;
            var quality = (customer.preferredQuality && customer.preferredQuality.length > 0)
                ? customer.preferredQuality[Math.floor(Math.random() * customer.preferredQuality.length)]
                : ['low', 'medium', 'good', 'premium'][Math.floor(Math.random() * 4)];
            var seedIds = getSeedIdsByQuality(quality);
            requestedSeedId = seedIds.length > 0 ? seedIds[Math.floor(Math.random() * seedIds.length)] : (HP.Data.Seeds && HP.Data.Seeds.getIds ? HP.Data.Seeds.getIds()[0] : 'basic_seed');
        }
        return { seedId: requestedSeedId, amount: requestedAmount };
    }

    return {
        getFulfillableOptions: getFulfillableOptions,
        generateCustomerRequest: generateCustomerRequest
    };
})();
