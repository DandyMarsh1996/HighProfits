/**
 * Sale modal pure helpers – customer request generation, fulfillable options.
 * Used by HP.Renderer. Load before renderer.js.
 */
var HP = HP || {};
HP.RendererHelpers = HP.RendererHelpers || {};

HP.RendererHelpers.SaleModal = (function() {
    'use strict';

    function getFulfillableOptions(customer) {
        if (!customer || !HP.State) return [];
        var minA = customer.minAmount || 1;
        var maxA = customer.maxAmount || 1;
        var qualities = customer.preferredQuality && customer.preferredQuality.length > 0
            ? customer.preferredQuality.slice()
            : ['low', 'medium', 'good', 'premium'];
        var options = [];
        var q;
        for (q = 0; q < qualities.length; q++) {
            var qual = qualities[q];
            var available = HP.State.getWeed ? HP.State.getWeed(qual) : 0;
            if (available >= minA) {
                var amount = Math.min(maxA, Math.floor(available));
                if (amount >= minA) options.push({ quality: qual, amount: amount });
            }
        }
        var anyQualities = ['low', 'medium', 'good', 'premium'];
        for (q = 0; q < anyQualities.length; q++) {
            qual = anyQualities[q];
            if (qualities.indexOf(qual) !== -1) continue;
            available = HP.State.getWeed ? HP.State.getWeed(qual) : 0;
            if (available >= minA) {
                amount = Math.min(maxA, Math.floor(available));
                if (amount >= minA) options.push({ quality: qual, amount: amount });
            }
        }
        return options;
    }

    function generateCustomerRequest(customer, preferFulfillable) {
        var options = preferFulfillable ? getFulfillableOptions(customer) : [];
        var requestedQuality;
        var requestedAmount;
        if (options.length > 0) {
            var pick = options[Math.floor(Math.random() * options.length)];
            requestedQuality = pick.quality;
            requestedAmount = pick.amount;
        } else {
            requestedAmount = Math.floor(Math.random() * (customer.maxAmount - customer.minAmount + 1)) + customer.minAmount;
            if (customer.preferredQuality && customer.preferredQuality.length > 0) {
                if (Math.random() < 0.7) {
                    requestedQuality = customer.preferredQuality[Math.floor(Math.random() * customer.preferredQuality.length)];
                } else {
                    var allQ = ['low', 'medium', 'good', 'premium'];
                    requestedQuality = allQ[Math.floor(Math.random() * allQ.length)];
                }
            } else {
                var allQ = ['low', 'medium', 'good', 'premium'];
                requestedQuality = allQ[Math.floor(Math.random() * allQ.length)];
            }
        }
        return { quality: requestedQuality, amount: requestedAmount };
    }

    return {
        getFulfillableOptions: getFulfillableOptions,
        generateCustomerRequest: generateCustomerRequest
    };
})();
