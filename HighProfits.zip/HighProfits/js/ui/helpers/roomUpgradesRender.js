/**
 * Room upgrades panel HTML rendering. Used by HP.Renderer. Load before renderer.js.
 */
var HP = HP || {};
HP.RendererHelpers = HP.RendererHelpers || {};

HP.RendererHelpers.RoomUpgradesRender = (function() {
    'use strict';

    function renderPanelHtml(propertyId, playerLevel, money, installedUpgrades, categories) {
        var html = '';
        for (var c = 0; c < categories.length; c++) {
            var cat = categories[c];
            var items = HP.Data.RoomUpgrades.getByCategory(cat.id);

            html += '<div class="upgrade-category">';
            html += '<div class="category-header">' + cat.name + '</div>';
            html += '<div class="category-items">';

            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                var isInstalled = installedUpgrades.indexOf(item.id) !== -1;
                var locked = item.unlockLevel > playerLevel;
                var canAfford = money >= item.cost;

                var itemClass = 'upgrade-item';
                if (isInstalled) itemClass += ' installed';
                if (locked) itemClass += ' locked';

                html += '<div class="' + itemClass + '">';
                html += '<div class="upgrade-header">';
                html += '<span class="upgrade-name">' + item.icon + ' ' + item.name + '</span>';
                html += '<span class="upgrade-cost">$' + item.cost + '</span>';
                html += '</div>';
                html += '<div class="upgrade-desc">' + item.description + '</div>';
                html += '<div class="upgrade-stats">';
                if (item.growthBonus) html += '<span class="stat-tag growth">+' + item.growthBonus + '% Growth</span>';
                if (item.yieldBonus) html += '<span class="stat-tag yield">+' + item.yieldBonus + '% Yield</span>';
                if (item.qualityBonus) html += '<span class="stat-tag quality">+' + item.qualityBonus + '% Quality</span>';
                html += '</div>';

                if (isInstalled) {
                    var sellPrice = Math.floor(item.cost * 0.5);
                    html += '<button class="upgrade-btn sell-upgrade" data-upgrade="' + item.id + '">Sell $' + sellPrice + '</button>';
                } else if (locked) {
                    html += '<span class="btn-tooltip-wrap" data-tooltip="Reach level ' + item.unlockLevel + ' to unlock"><button class="upgrade-btn" disabled>🔒 Level ' + item.unlockLevel + '</button></span>';
                } else {
                    if (canAfford) {
                        html += '<button class="upgrade-btn buy-upgrade" data-upgrade="' + item.id + '">Install</button>';
                    } else {
                        var needMore = item.cost - money;
                        html += '<span class="btn-tooltip-wrap" data-tooltip="Need $' + HP.Helpers.formatNumber(needMore) + ' more">';
                        html += '<button class="upgrade-btn buy-upgrade" data-upgrade="' + item.id + '" disabled>Need $' + item.cost + '</button>';
                        html += '</span>';
                    }
                }

                html += '</div>';
            }

            html += '</div></div>';
        }
        return html;
    }

    return { renderPanelHtml: renderPanelHtml };
})();
