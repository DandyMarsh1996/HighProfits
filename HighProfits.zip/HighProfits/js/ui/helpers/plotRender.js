/**
 * Plot rendering helpers – buildPlotCard, renderPlotContent, equipment, watering.
 * Used by HP.Renderer for the grow view. Load before renderer.js.
 */
var HP = HP || {};
HP.RendererHelpers = HP.RendererHelpers || {};

HP.RendererHelpers.PlotRender = (function() {
    'use strict';

    function renderPlotContent(plot) {
        var html = '';
        if (plot.status === 'empty') {
            html += '<div class="plot-icon">📦</div>';
            html += '<div class="plot-label">Empty</div>';
        } else if (plot.status === 'setup') {
            html += '<div class="plot-icon">✅</div>';
            html += '<div class="plot-label">Ready to Plant</div>';
        } else if (plot.status === 'growing') {
            var progress = HP.Growing.getGrowthProgress(plot.plant);
            var waterLevel = HP.Growing.getWaterLevel(plot.plant);
            var isHydrated = plot.plant.isHydrated;
            var growIcon = isHydrated ? '🌿' : '🥀';
            var growLabel = isHydrated ? 'Growing' : 'Needs Water!';

            html += '<div class="plot-icon">' + growIcon + '</div>';
            html += '<div class="plot-label">' + growLabel + '</div>';
            html += '<div class="plot-progress-bar"><div class="plot-progress" style="width:' + progress + '%"></div></div>';
            html += '<div class="plot-time">' + HP.Growing.getTimeRemaining(plot.plant) + ' left</div>';

            var waterClass = waterLevel > 50 ? 'water-good' : (waterLevel > 20 ? 'water-low' : 'water-critical');
            html += '<div class="water-bar ' + waterClass + '"><div class="water-fill" style="width:' + waterLevel + '%"></div></div>';
        } else if (plot.status === 'harvest') {
            html += '<div class="plot-icon">🌿</div>';
            html += '<div class="plot-label">Harvest!</div>';
        } else if (plot.status === 'dead') {
            html += '<div class="plot-icon">💀</div>';
            html += '<div class="plot-label">Dead</div>';
        }
        return html;
    }

    function buildPlotCard(propertyId, index, plot, opts) {
        var plotClass = 'plot-card ' + plot.status;
        var isSelected = opts.selectedPlot && opts.selectedPlot.propertyId === propertyId && opts.selectedPlot.plotIndex === index;
        var assignedWorker = HP.State.getWorkerByPlot ? HP.State.getWorkerByPlot(propertyId, index) : null;

        if (isSelected) plotClass += ' selected';
        if (assignedWorker) plotClass += ' has-worker';

        var html = '<div class="' + plotClass + '" data-property="' + propertyId + '" data-index="' + index + '" tabindex="-1" role="button">';
        if (assignedWorker) {
            var workerType = HP.Data.GrowerWorkers.get(assignedWorker.workerTypeId);
            var workerTitle = assignedWorker.name || (workerType ? workerType.name : 'Worker');
            if (assignedWorker.status === 'paused' && assignedWorker.pauseReason) {
                var reason = assignedWorker.pauseReason === 'unpaid' ? 'Unpaid wages' : (assignedWorker.pauseReason === 'no_plot' ? 'Plot missing' : 'Needs resources');
                workerTitle += ' – Paused: ' + reason;
            }
            html += '<div class="plot-worker-badge' + (assignedWorker.status === 'paused' ? ' paused' : '') + '" title="' + workerTitle + '">👷</div>';
        }
        html += '<div class="plot-number">Plot ' + (index + 1) + '</div>';
        html += '<div class="plot-content">' + renderPlotContent(plot) + '</div>';
        html += '</div>';
        return html;
    }

    function renderEquipmentSection(inventory, plot, slot, label, storeView, storeLabel) {
        var html = '<div class="action-divider">' + label + '</div>';
        var hasItems = false;
        var currentEquip = plot.equipment[slot];

        if (currentEquip) {
            var equipId = (typeof currentEquip === 'string') ? currentEquip : (currentEquip && currentEquip.id ? currentEquip.id : null);
            var equip = equipId ? HP.Data.Equipment.get(equipId) : null;
            html += '<div class="installed-equip">';
            var usesLeft = (currentEquip && typeof currentEquip === 'object' && typeof currentEquip.usesLeft === 'number') ? currentEquip.usesLeft : null;
            var usesText = (equip && equip.consumable && typeof usesLeft === 'number') ? (' <span class="equip-uses">(' + usesLeft + ' use' + (usesLeft !== 1 ? 's' : '') + ' left)</span>') : '';
            html += '<span class="current-equip">✓ ' + (equip ? equip.icon : '') + ' ' + (equip ? equip.name : 'Equipment') + usesText + '</span>';
            var canRemove = (plot.status !== 'growing' && plot.status !== 'harvest') || (slot === 'fertilizer');
            if (canRemove && equip && !equip.consumable) {
                html += '<button class="action-btn remove-btn uninstall-equip" data-slot="' + slot + '">Remove</button>';
            }
            if (canRemove && equip && equip.consumable && slot === 'fertilizer') {
                html += '<button class="action-btn remove-btn uninstall-equip" data-slot="' + slot + '">Remove</button>';
            }
            html += '</div>';
            return html;
        }

        for (var equipId in inventory.equipment) {
            if (inventory.equipment[equipId] > 0) {
                var equip = HP.Data.Equipment.get(equipId);
                var equipSlot = equip.slot || HP.Growing.getEquipmentSlot(equip);
                if (equipSlot === slot) {
                    html += '<button class="action-btn install-equip" data-equip="' + equipId + '">' +
                        equip.icon + ' ' + equip.name + ' (' + inventory.equipment[equipId] + ')</button>';
                    hasItems = true;
                }
            }
        }

        if (!hasItems) {
            html += '<span class="empty-hint">Buy from store</span>';
            if (storeView && storeLabel) {
                html += '<button type="button" class="action-btn go-to-store-btn" data-view="' + storeView + '">Go to ' + storeLabel + '</button>';
            }
        }
        return html;
    }

    function renderWateringButtons(inventory) {
        var html = '';
        var wateringCans = HP.Data.Equipment.getWateringCans();
        for (var i = 0; i < wateringCans.length; i++) {
            var can = wateringCans[i];
            var count = inventory.equipment[can.id] || 0;
            if (count > 0) {
                html += '<button class="action-btn water-btn" data-can="' + can.id + '">' +
                    can.icon + ' ' + can.name + ' (+' + can.waterAmount + 's)</button>';
            }
        }
        if (!html) {
            html += '<span class="empty-hint">Buy a watering can from Hardware Store</span>';
            html += '<button type="button" class="action-btn go-to-store-btn" data-view="hardware">Go to Hardware Store</button>';
        }
        return html;
    }

    return {
        renderPlotContent: renderPlotContent,
        buildPlotCard: buildPlotCard,
        renderEquipmentSection: renderEquipmentSection,
        renderWateringButtons: renderWateringButtons
    };
})();
