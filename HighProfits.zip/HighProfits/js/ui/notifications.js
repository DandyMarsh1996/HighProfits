/**
 * HighProfits - Notifications System
 * Handles all in-game notifications and alerts
 */
var HP = HP || {};

HP.Notifications = (function() {
    'use strict';

    // Notification queue for stacking
    var queue = [];
    var isProcessing = false;
    var activeNotifications = [];
    var notificationId = 0;

    // Configuration
    var config = {
        maxVisible: 3,
        duration: 3000,
        fadeTime: 300,
        stackDelay: 200
    };

    /**
     * Show a notification
     * @param {string} message - Message to display
     * @param {string} type - Type: 'success', 'error', 'info', 'warning'
     * @param {Object} options - Additional options
     */
    function show(message, type, options) {
        type = type || 'info';
        options = options || {};

        var notification = {
            id: ++notificationId,
            message: message,
            type: type,
            duration: options.duration || config.duration,
            icon: options.icon || getDefaultIcon(type)
        };

        queue.push(notification);
        processQueue();
    }

    /**
     * Process the notification queue
     */
    function processQueue() {
        if (isProcessing || queue.length === 0) return;
        if (activeNotifications.length >= config.maxVisible) return;

        isProcessing = true;
        var notification = queue.shift();
        displayNotification(notification);

        setTimeout(function() {
            isProcessing = false;
            processQueue();
        }, config.stackDelay);
    }

    var notificationTimeouts = {};

    /**
     * Display a notification on screen (in fixed top-right container; click to dismiss; pause on hover)
     */
    function displayNotification(notification) {
        var container = document.getElementById('notification-container');
        if (!container) container = document.body;

        var el = document.createElement('div');
        el.className = 'notification notification-' + notification.type;
        el.setAttribute('data-notification-id', notification.id);
        el.style.borderColor = getTypeColor(notification.type);
        el.style.color = getTypeColor(notification.type);
        el.style.boxShadow = '0 0 15px ' + getTypeGlow(notification.type);

        var content = '';
        if (notification.icon) {
            content += '<span class="notification-icon">' + notification.icon + '</span> ';
        }
        content += '<span class="notification-message">' + notification.message + '</span>';
        el.innerHTML = content;

        function scheduleRemove() {
            notificationTimeouts[notification.id] = setTimeout(function() {
                removeNotification(notification.id);
                delete notificationTimeouts[notification.id];
            }, notification.duration);
        }

        function clearRemove() {
            if (notificationTimeouts[notification.id]) {
                clearTimeout(notificationTimeouts[notification.id]);
                delete notificationTimeouts[notification.id];
            }
        }

        el.addEventListener('click', function() {
            removeNotification(notification.id);
        });
        el.addEventListener('mouseenter', clearRemove);
        el.addEventListener('mouseleave', scheduleRemove);

        container.appendChild(el);
        activeNotifications.push(notification.id);

        requestAnimationFrame(function() {
            el.classList.add('notification-visible');
        });

        scheduleRemove();
    }

    /**
     * Remove a notification
     */
    function removeNotification(id) {
        if (notificationTimeouts[id]) {
            clearTimeout(notificationTimeouts[id]);
            delete notificationTimeouts[id];
        }
        var el = document.querySelector('[data-notification-id="' + id + '"]');
        if (!el) return;

        el.classList.remove('notification-visible');
        el.classList.add('notification-leaving');

        setTimeout(function() {
            if (el.parentNode) {
                el.parentNode.removeChild(el);
            }
            var index = activeNotifications.indexOf(id);
            if (index > -1) {
                activeNotifications.splice(index, 1);
            }
            processQueue();
        }, config.fadeTime);
    }

    /**
     * Get default icon for notification type
     */
    function getDefaultIcon(type) {
        switch (type) {
            case 'success': return '✓';
            case 'error': return '✗';
            case 'warning': return '⚠';
            case 'info': return 'ℹ';
            case 'levelup': return '⬆';
            case 'unlock': return '🔓';
            case 'achievement': return '🏆';
            default: return '';
        }
    }

    /**
     * Get color for notification type
     */
    function getTypeColor(type) {
        switch (type) {
            case 'success': return '#00ff88';
            case 'error': return '#ff4444';
            case 'warning': return '#ffaa00';
            case 'info': return '#00aaff';
            case 'levelup': return '#ffff00';
            case 'unlock': return '#ff00ff';
            case 'achievement': return '#ffd700';
            default: return '#00ff88';
        }
    }

    /**
     * Get glow color for notification type
     */
    function getTypeGlow(type) {
        switch (type) {
            case 'success': return 'rgba(0, 255, 136, 0.4)';
            case 'error': return 'rgba(255, 68, 68, 0.4)';
            case 'warning': return 'rgba(255, 170, 0, 0.4)';
            case 'info': return 'rgba(0, 170, 255, 0.4)';
            case 'levelup': return 'rgba(255, 255, 0, 0.5)';
            case 'unlock': return 'rgba(255, 0, 255, 0.4)';
            case 'achievement': return 'rgba(255, 215, 0, 0.5)';
            default: return 'rgba(0, 255, 136, 0.4)';
        }
    }

    // Convenience methods
    function success(message, options) {
        if (HP.SoundManager) HP.SoundManager.play('success');
        show(message, 'success', options);
    }

    function error(message, options) {
        if (HP.SoundManager) HP.SoundManager.play('error');
        show(message, 'error', options);
    }

    function warning(message, options) {
        if (HP.SoundManager) HP.SoundManager.play('error');
        show(message, 'warning', options);
    }

    function info(message, options) {
        show(message, 'info', options);
    }

    function levelUp(level, rankName) {
        if (HP.SoundManager) HP.SoundManager.play('levelup');
        show('Level Up! You are now a ' + rankName + ' (Level ' + level + ')', 'levelup', {
            duration: 4000,
            icon: '⭐'
        });
    }

    function drugUnlocked(drug) {
        if (HP.SoundManager) HP.SoundManager.play('success');
        show('New Product Unlocked: ' + drug.emoji + ' ' + drug.name + '!', 'unlock', {
            duration: 4000,
            icon: '🔓'
        });
    }

    function achievement(achievementObj) {
        if (HP.SoundManager) HP.SoundManager.play('achievement');
        if (typeof achievementObj === 'string') {
            // Legacy support
            show(achievementObj, 'achievement', {
                duration: 5000,
                icon: '🏆'
            });
        } else {
            // New format with achievement object
            show(achievementObj.emoji + ' ' + achievementObj.name + ' - ' + achievementObj.description, 'achievement', {
                duration: 5000,
                icon: achievementObj.emoji || '🏆'
            });
        }
    }

    // Public API
    return {
        show: show,
        success: success,
        error: error,
        warning: warning,
        info: info,
        levelUp: levelUp,
        drugUnlocked: drugUnlocked,
        achievement: achievement
    };
})();
