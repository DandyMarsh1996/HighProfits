/**
 * HighProfits - Renderer Module
 * Handles all DOM updates
 */
var HP = HP || {};

HP.Renderer = (function() {
    'use strict';

    var elements = {};
    var currentView = 'grow';
    var selectedPlot = null;
    var selectedPlots = []; // Array of {propertyId, plotIndex}
    var bulkSelectMode = false;
    var achievementFilters = { category: 'all', sub: 'all', status: 'all' };
    var challengeFilters = { category: 'all', sub: 'all', status: 'all' };

    function toggleBulkSelectMode() {
        bulkSelectMode = !bulkSelectMode;
        var panel = document.getElementById('bulk-actions-panel');
        var btn = document.getElementById('btn-select-mode');
        
        if (bulkSelectMode) {
            if (panel) panel.classList.remove('hidden');
            if (btn) {
                btn.classList.add('active');
                btn.textContent = '✓ Selection Mode';
            }
        } else {
            if (panel) panel.classList.add('hidden');
            if (btn) {
                btn.classList.remove('active');
                btn.textContent = '📋 Select Mode';
            }
            selectedPlots = [];
            updateBulkSelection();
        }
        updatePlotsGrid();
    }

    function togglePlotSelection(propertyId, plotIndex) {
        if (!bulkSelectMode) return;

        var index = selectedPlots.findIndex(function(p) {
            return p.propertyId === propertyId && p.plotIndex === plotIndex;
        });

        if (index > -1) {
            selectedPlots.splice(index, 1);
        } else {
            selectedPlots.push({propertyId: propertyId, plotIndex: plotIndex});
        }

        updateBulkSelection();
        updatePlotsGrid();
    }

    function clearSelection() {
        selectedPlots = [];
        updateBulkSelection();
        updatePlotsGrid();
    }

    function updateBulkSelection() {
        var countEl = document.getElementById('selected-count');
        if (countEl) {
            countEl.textContent = selectedPlots.length + ' plot' + (selectedPlots.length !== 1 ? 's' : '') + ' selected';
        }
    }

    function isPlotSelected(propertyId, plotIndex) {
        return selectedPlots.some(function(p) {
            return p.propertyId === propertyId && p.plotIndex === plotIndex;
        });
    }

    function init() {
        // Top bar
        elements.moneyAmount = document.getElementById('money-amount');
        elements.playerRank = document.getElementById('player-rank');
        elements.playerLevel = document.getElementById('player-level');
        elements.heatBar = document.getElementById('heat-bar');
        elements.heatText = document.getElementById('heat-text');
        elements.heatReduceBtn = document.getElementById('heat-reduce-btn');
        elements.heatReducePanel = document.getElementById('heat-reduce-panel');
        elements.heatCostBribe = document.getElementById('heat-cost-bribe');
        elements.heatCostHide = document.getElementById('heat-cost-hide');
        elements.heatCostCleaners = document.getElementById('heat-cost-cleaners');
        elements.xpBar = document.getElementById('xp-bar');
        elements.currentXP = document.getElementById('current-xp');
        elements.xpToNext = document.getElementById('xp-to-next');

        // Grow view
        elements.propertySelect = document.getElementById('property-select');
        elements.plotsGrid = document.getElementById('plots-grid');
        elements.selectedPlotNum = document.getElementById('selected-plot-num');
        elements.plotStatusBadge = document.getElementById('plot-status-badge');
        elements.plotEquipment = document.getElementById('plot-equipment');
        elements.plotButtons = document.getElementById('plot-buttons');
        
        // Room upgrades
        elements.roomGrowthBonus = document.getElementById('room-growth-bonus');
        elements.roomYieldBonus = document.getElementById('room-yield-bonus');
        elements.roomQualityBonus = document.getElementById('room-quality-bonus');
        elements.waterCurrent = document.getElementById('water-current');
        elements.waterCapacity = document.getElementById('water-capacity');
        elements.waterRefillProgress = document.getElementById('water-refill-progress');
        elements.waterNextCharge = document.getElementById('water-next-charge');
        elements.roomUpgradesPanel = document.getElementById('room-upgrades-panel');
        elements.roomUpgradesContent = document.getElementById('room-upgrades-content');

        // Inventory view
        elements.invWeedLow = document.getElementById('inv-weed-low');
        elements.invWeedMedium = document.getElementById('inv-weed-medium');
        elements.invWeedGood = document.getElementById('inv-weed-good');
        elements.invWeedPremium = document.getElementById('inv-weed-premium');
        elements.seedsInventory = document.getElementById('seeds-inventory');
        elements.equipmentInventory = document.getElementById('equipment-inventory');

        // Store views
        elements.hardwareItems = document.getElementById('hardware-items');
        elements.gardenItems = document.getElementById('garden-items');
        elements.dealerItems = document.getElementById('dealer-items');
        elements.propertyItems = document.getElementById('property-items');

        // Market view
        elements.ordersList = document.getElementById('orders-list');
        elements.ordersCount = document.getElementById('orders-count');
        elements.ordersEmpty = document.getElementById('orders-empty');
        elements.sellStockLow = document.getElementById('sell-stock-low');
        elements.sellStockMedium = document.getElementById('sell-stock-medium');
        elements.sellStockGood = document.getElementById('sell-stock-good');
        elements.sellStockPremium = document.getElementById('sell-stock-premium');
        elements.customersGrid = document.getElementById('customers-grid');
        elements.saleModal = document.getElementById('sale-modal');
        elements.sellTotal = document.getElementById('sell-total');
        elements.salePricePerGram = document.getElementById('sale-price-per-gram');
        elements.saleBonus = document.getElementById('sale-bonus');
        elements.saleCustomerRep = document.getElementById('sale-customer-rep');
        elements.saleDealEffect = document.getElementById('sale-deal-effect');

        // Achievements view
        elements.achievementsGrid = document.getElementById('achievements-grid');
        elements.achievementsUnlocked = document.getElementById('achievements-unlocked');
        elements.achievementsTotal = document.getElementById('achievements-total');
        elements.achievementsProgress = document.getElementById('achievements-progress');
        elements.achievementStatusFilter = document.getElementById('achievement-status-filter');
        elements.achievementCategoryFilter = document.getElementById('achievement-category-filter');
        elements.achievementSubFilter = document.getElementById('achievement-sub-filter');

        // Challenges view
        elements.challengesGrid = document.getElementById('challenges-grid');
        elements.challengeStatusFilter = document.getElementById('challenge-status-filter');
        elements.challengeCategoryFilter = document.getElementById('challenge-category-filter');
        elements.challengeSubFilter = document.getElementById('challenge-sub-filter');

        // Workers view
        elements.workersHireGrid = document.getElementById('workers-hire-grid');
        elements.workersAssignedList = document.getElementById('workers-assigned-list');
        elements.workerAssignModal = document.getElementById('worker-assign-modal');
        elements.workerPlotSelect = document.getElementById('worker-plot-select');
        elements.workerSeedSelect = document.getElementById('worker-seed-select');
        elements.workerSoilSelect = document.getElementById('worker-soil-select');
        elements.workerFertilizerSelect = document.getElementById('worker-fertilizer-select');

        console.log('[Renderer] Initialized');
    }

    function switchView(viewName) {
        var views = document.querySelectorAll('.content-view');
        views.forEach(function(view) {
            view.classList.remove('active');
        });

        var targetView = document.getElementById('view-' + viewName);
        if (targetView) {
            targetView.classList.add('active');
            currentView = viewName;
        }

        var navBtns = document.querySelectorAll('.nav-btn');
        navBtns.forEach(function(btn) {
            btn.classList.remove('active');
            if (btn.getAttribute('data-view') === viewName) {
                btn.classList.add('active');
            }
        });

        update();
    }

    function update() {
        updateTopBar();

        switch (currentView) {
            case 'grow':
                updateGrowView();
                break;
            case 'inventory':
                updateInventoryView();
                break;
            case 'hardware':
            case 'garden':
                updateStoreView(currentView);
                break;
            case 'dealer':
                updateDealerView();
                break;
            case 'realestate':
                updateRealEstateView();
                break;
            case 'market':
                updateMarketView();
                break;
            case 'achievements':
                updateAchievementsView();
                break;
            case 'challenges':
                updateChallengesView();
                break;
            case 'workers':
                updateWorkersView();
                break;
            case 'stats':
                updateStatsView();
                break;
            case 'genetics':
                updateGeneticsView();
                break;
        }
    }

    function updateTopBar() {
        var money = HP.State.getMoney();
        var xp = HP.State.getXP();
        var level = HP.State.getLevel();
        var rank = HP.State.getRank();

        if (elements.moneyAmount) {
            elements.moneyAmount.textContent = HP.Helpers.formatNumber(Math.floor(money));
        }
        if (elements.playerRank) elements.playerRank.textContent = rank;
        if (elements.playerLevel) elements.playerLevel.textContent = level;

        var nextRank = HP.Data.Ranks.getNext(level);
        if (nextRank && elements.xpBar) {
            var currentRank = HP.Data.Ranks.getByLevel(level);
            var xpProgress = xp - currentRank.xpRequired;
            var xpNeeded = nextRank.xpRequired - currentRank.xpRequired;
            var percentage = Math.min((xpProgress / xpNeeded) * 100, 100);
            elements.xpBar.style.width = percentage + '%';

            if (elements.currentXP) elements.currentXP.textContent = Math.floor(xp);
            if (elements.xpToNext) elements.xpToNext.textContent = nextRank.xpRequired;
        }

        updateHeatDisplay();
    }

    function updateHeatDisplay() {
        if (!elements.heatBar && !elements.heatText) return;
        var heat = HP.State && HP.State.getHeat ? HP.State.getHeat() : 0;
        var maxHeat = (HP.State && HP.State.getState && HP.State.getState().heat) ? HP.State.getState().heat.maxLevel : 100;
        var pct = Math.min(100, Math.round((heat / maxHeat) * 100));
        if (elements.heatBar) {
            elements.heatBar.style.width = pct + '%';
            var cat = HP.Heat && HP.Heat.getHeatCategory ? HP.Heat.getHeatCategory(heat) : null;
            elements.heatBar.style.backgroundColor = cat && cat.color ? cat.color : '#ff6600';
            if (pct >= 80) {
                elements.heatBar.classList.add('heat-bar-high');
            } else {
                elements.heatBar.classList.remove('heat-bar-high');
            }
        }
        if (elements.heatText) elements.heatText.textContent = pct + '%';
        if (elements.heatReducePanel && !elements.heatReducePanel.classList.contains('hidden')) {
            var money = HP.State.getMoney();
            var payOffCount = HP.State.getHeatPayOffCount ? HP.State.getHeatPayOffCount() : 0;
            var options = HP.Heat && HP.Heat.getReductionOptions ? HP.Heat.getReductionOptions(money, payOffCount) : [];
            for (var i = 0; i < options.length; i++) {
                var opt = options[i];
                var costEl = opt.id === 'bribe' ? elements.heatCostBribe : (opt.id === 'hide' ? elements.heatCostHide : elements.heatCostCleaners);
                if (costEl) costEl.textContent = HP.Helpers.formatNumber(opt.cost);
                var btn = elements.heatReducePanel && elements.heatReducePanel.querySelector('.heat-payoff-btn[data-action="' + opt.id + '"]');
                if (btn) {
                    btn.classList.toggle('disabled', !opt.canAfford);
                    btn.disabled = !opt.canAfford;
                }
            }
        }
    }

    function updateGrowView() {
        updatePropertySelector();
        updateRoomBonuses();
        updatePlotsGrid();
        updatePlotActions();
        updateRoomUpgradesPanel();
        updateWorkersView(); // Also update workers view when in grow view
    }

    function updateRoomBonuses() {
        var propertyId = elements.propertySelect ? elements.propertySelect.value : null;
        if (!propertyId) return;

        var bonuses = HP.State.getRoomBonuses(propertyId);

        if (elements.roomGrowthBonus) {
            elements.roomGrowthBonus.textContent = '+' + bonuses.growth + '% Growth';
        }
        if (elements.roomYieldBonus) {
            elements.roomYieldBonus.textContent = '+' + bonuses.yield + '% Yield';
        }
        if (elements.roomQualityBonus) {
            elements.roomQualityBonus.textContent = '+' + bonuses.quality + '% Quality';
        }

        var reservoir = HP.State && HP.State.getWaterReservoir ? HP.State.getWaterReservoir() : { current: 0, capacity: 0, refillAccumulator: 0 };
        if (elements.waterCurrent) elements.waterCurrent.textContent = reservoir.current;
        if (elements.waterCapacity) elements.waterCapacity.textContent = reservoir.capacity;

        var interval = (HP.Data.Constants && HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS != null) ? HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS : 8;
        var acc = reservoir.refillAccumulator || 0;
        var pct = interval > 0 ? Math.min(100, (acc / interval) * 100) : 0;
        var nextSec = Math.ceil(Math.max(0, interval - acc));
        if (elements.waterRefillProgress) elements.waterRefillProgress.style.width = pct + '%';
        if (elements.waterNextCharge) elements.waterNextCharge.textContent = 'Next: ' + nextSec + 's';
    }

    function updateRoomUpgradesPanel() {
        if (!elements.roomUpgradesContent) return;

        var propertyId = elements.propertySelect ? elements.propertySelect.value : null;
        if (!propertyId) return;

        var playerLevel = HP.State.getLevel();
        var money = HP.State.getMoney();
        var installedUpgrades = HP.State.getRoomUpgrades(propertyId);
        var categories = HP.Data.RoomUpgrades.getCategories();

        var html = '';

        for (var c = 0; c < categories.length; c++) {
            var cat = categories[c];
            var items = HP.Data.RoomUpgrades.getByCategory(cat.id);

            html += '<div class="upgrade-category">';
            html += '<div class="category-header">' + cat.name + '</div>';
            html += '<div class="category-items">';

            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                var isInstalled = installedUpgrades.indexOf(item.id) !== -1;
                var locked = item.unlockLevel > playerLevel;
                var canAfford = money >= item.cost;

                var itemClass = 'upgrade-item';
                if (isInstalled) itemClass += ' installed';
                if (locked) itemClass += ' locked';

                html += '<div class="' + itemClass + '">';
                html += '<div class="upgrade-header">';
                html += '<span class="upgrade-name">' + item.icon + ' ' + item.name + '</span>';
                html += '<span class="upgrade-cost">$' + item.cost + '</span>';
                html += '</div>';
                html += '<div class="upgrade-desc">' + item.description + '</div>';
                html += '<div class="upgrade-stats">';
                if (item.growthBonus) html += '<span class="stat-tag growth">+' + item.growthBonus + '% Growth</span>';
                if (item.yieldBonus) html += '<span class="stat-tag yield">+' + item.yieldBonus + '% Yield</span>';
                if (item.qualityBonus) html += '<span class="stat-tag quality">+' + item.qualityBonus + '% Quality</span>';
                html += '</div>';

                if (isInstalled) {
                    var sellPrice = Math.floor(item.cost * 0.5);
                    html += '<button class="upgrade-btn sell-upgrade" data-upgrade="' + item.id + '">Sell $' + sellPrice + '</button>';
                } else if (locked) {
                    html += '<button class="upgrade-btn" disabled>🔒 Level ' + item.unlockLevel + '</button>';
                } else {
                    html += '<button class="upgrade-btn buy-upgrade" data-upgrade="' + item.id + '"' + 
                        (canAfford ? '' : ' disabled') + '>' + (canAfford ? 'Install' : 'Need $' + item.cost) + '</button>';
                }

                html += '</div>';
            }

            html += '</div></div>';
        }

        elements.roomUpgradesContent.innerHTML = html;
        bindRoomUpgradeButtons();
    }

    function bindRoomUpgradeButtons() {
        var propertyId = elements.propertySelect ? elements.propertySelect.value : null;
        if (!propertyId) return;

        document.querySelectorAll('.buy-upgrade').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                HP.Events.buyRoomUpgrade(propertyId, this.getAttribute('data-upgrade'));
            });
        });

        document.querySelectorAll('.sell-upgrade').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                HP.Events.sellRoomUpgrade(propertyId, this.getAttribute('data-upgrade'));
            });
        });
    }

    function toggleRoomUpgradesPanel(show) {
        if (elements.roomUpgradesPanel) {
            if (show) {
                elements.roomUpgradesPanel.classList.remove('hidden');
                updateRoomUpgradesPanel();
            } else {
                elements.roomUpgradesPanel.classList.add('hidden');
            }
        }
    }

    function updatePropertySelector() {
        if (!elements.propertySelect) return;

        var owned = HP.State.getOwnedProperties();
        var currentValue = elements.propertySelect.value;

        elements.propertySelect.innerHTML = '';

        for (var i = 0; i < owned.length; i++) {
            var propId = owned[i];
            var prop = HP.Data.Properties.get(propId);
            var option = document.createElement('option');
            option.value = propId;
            option.textContent = prop.icon + ' ' + prop.name + ' (' + prop.plotCapacity + ' plots)';
            elements.propertySelect.appendChild(option);
        }

        if (currentValue && owned.indexOf(currentValue) !== -1) {
            elements.propertySelect.value = currentValue;
        }
    }

    function updatePlotsGrid() {
        if (!elements.plotsGrid || !elements.propertySelect) return;

        var propertyId = elements.propertySelect.value;
        var plots = HP.State.getPlots(propertyId);

        var html = '';
        for (var i = 0; i < plots.length; i++) {
            var plot = plots[i];
            var plotClass = 'plot-card ' + plot.status;
            var isSelected = selectedPlot && selectedPlot.propertyId === propertyId && selectedPlot.plotIndex === i;
            var isBulkSelected = isPlotSelected(propertyId, i);
            var assignedWorker = HP.State.getWorkerByPlot(propertyId, i);
            
            if (isSelected && !bulkSelectMode) plotClass += ' selected';
            if (isBulkSelected) plotClass += ' bulk-selected';
            if (bulkSelectMode) plotClass += ' selectable';
            if (assignedWorker) plotClass += ' has-worker';

            html += '<div class="' + plotClass + '" data-property="' + propertyId + '" data-index="' + i + '">';
            if (bulkSelectMode) {
                html += '<div class="bulk-checkbox">' + (isBulkSelected ? '✓' : '☐') + '</div>';
            }
            if (assignedWorker) {
                var workerType = HP.Data.GrowerWorkers.get(assignedWorker.workerTypeId);
                html += '<div class="plot-worker-badge" title="Worker assigned: ' + (workerType ? workerType.name : 'Worker') + '">👷</div>';
            }
            html += '<div class="plot-number">Plot ' + (i + 1) + '</div>';
            html += renderPlotContent(plot);
            html += '</div>';
        }

        elements.plotsGrid.innerHTML = html;

        var plotCards = elements.plotsGrid.querySelectorAll('.plot-card');
        plotCards.forEach(function(card) {
            card.addEventListener('click', function() {
                var propId = this.getAttribute('data-property');
                var idx = parseInt(this.getAttribute('data-index'), 10);
                
                if (bulkSelectMode) {
                    togglePlotSelection(propId, idx);
                } else {
                    selectPlot(propId, idx);
                }
            });
        });
    }

    function renderPlotContent(plot) {
        var html = '';

        if (plot.status === 'empty') {
            html += '<div class="plot-icon">📦</div>';
            html += '<div class="plot-label">Empty</div>';
        } else if (plot.status === 'setup') {
            html += '<div class="plot-icon">✅</div>';
            html += '<div class="plot-label">Ready to Plant</div>';
        } else if (plot.status === 'growing') {
            var progress = HP.Growing.getGrowthProgress(plot.plant);
            var waterLevel = HP.Growing.getWaterLevel(plot.plant);
            var isHydrated = plot.plant.isHydrated;

            // Growth stage: seedling (0-33%), vegetative (33-66%), flowering (66-100%)
            var stage = progress < 33 ? 'seedling' : (progress < 66 ? 'vegetative' : 'flowering');
            var stageIcon = isHydrated ? (stage === 'seedling' ? '🌱' : (stage === 'vegetative' ? '🌿' : '🌸')) : '🥀';
            var stageLabel = isHydrated ? (stage === 'seedling' ? 'Seedling' : (stage === 'vegetative' ? 'Vegetative' : 'Flowering')) : 'Needs Water!';

            html += '<div class="plot-icon growth-stage growth-stage-' + stage + '">' + stageIcon + '</div>';
            html += '<div class="plot-label">' + stageLabel + '</div>';
            
            // Growth bar
            html += '<div class="plot-progress-bar"><div class="plot-progress" style="width:' + progress + '%"></div></div>';
            html += '<div class="plot-time">' + HP.Growing.getTimeRemaining(plot.plant) + ' left</div>';
            
            // Water bar
            var waterClass = waterLevel > 50 ? 'water-good' : (waterLevel > 20 ? 'water-low' : 'water-critical');
            html += '<div class="water-bar ' + waterClass + '"><div class="water-fill" style="width:' + waterLevel + '%"></div></div>';
        } else if (plot.status === 'harvest') {
            html += '<div class="plot-icon">🌿</div>';
            html += '<div class="plot-label">Harvest!</div>';
        } else if (plot.status === 'dead') {
            html += '<div class="plot-icon">💀</div>';
            html += '<div class="plot-label">Dead</div>';
        }

        return html;
    }

    function selectPlot(propertyId, plotIndex) {
        selectedPlot = { propertyId: propertyId, plotIndex: plotIndex };
        updatePlotsGrid();
        updatePlotActions();
    }

    function updatePlotActions() {
        if (!selectedPlot) {
            if (elements.selectedPlotNum) elements.selectedPlotNum.textContent = '-';
            if (elements.plotStatusBadge) {
                elements.plotStatusBadge.textContent = 'Select a plot';
                elements.plotStatusBadge.className = 'status-badge';
            }
            if (elements.plotEquipment) elements.plotEquipment.innerHTML = '';
            if (elements.plotButtons) elements.plotButtons.innerHTML = '';
            return;
        }

        var plot = HP.State.getPlot(selectedPlot.propertyId, selectedPlot.plotIndex);
        if (!plot) return;

        if (elements.selectedPlotNum) {
            elements.selectedPlotNum.textContent = selectedPlot.plotIndex + 1;
        }

        // Status badge
        if (elements.plotStatusBadge) {
            var statusText = plot.status.charAt(0).toUpperCase() + plot.status.slice(1);
            if (plot.plant) {
                var seed = HP.Data.Seeds.get(plot.plant.seedId);
                statusText = seed.name;
                if (!plot.plant.isHydrated && plot.status === 'growing') {
                    statusText += ' - NEEDS WATER';
                }
            }
            elements.plotStatusBadge.textContent = statusText;
            elements.plotStatusBadge.className = 'status-badge ' + plot.status;
        }

        // Equipment list
        if (elements.plotEquipment) {
            var equipHtml = '';
            var hasEquip = false;
            for (var slot in plot.equipment) {
                if (plot.equipment[slot]) {
                    var slotValue = plot.equipment[slot];
                    var equipId = (typeof slotValue === 'string') ? slotValue : (slotValue && slotValue.id ? slotValue.id : null);
                    var equip = equipId ? HP.Data.Equipment.get(equipId) : null;
                    if (equip) {
                        var usesLeft = (slotValue && typeof slotValue === 'object' && typeof slotValue.usesLeft === 'number') ? slotValue.usesLeft : null;
                        var usesText = (equip.consumable && typeof usesLeft === 'number') ? (' <span class="equip-uses">(' + usesLeft + ' use' + (usesLeft !== 1 ? 's' : '') + ' left)</span>') : '';
                        equipHtml += '<span class="equip-tag">' + equip.icon + ' ' + equip.name + usesText + '</span>';
                    }
                    hasEquip = true;
                }
            }
            elements.plotEquipment.innerHTML = hasEquip ? equipHtml : '<span class="empty-state">No equipment</span>';
        }

        // Action buttons
        if (elements.plotButtons) {
            var buttonsHtml = '';
            var inventory = HP.State.getInventory();

            if (plot.status === 'growing') {
                // Show water button and watering can options
                buttonsHtml += '<div class="action-divider">💧 Water Plant</div>';
                buttonsHtml += renderWateringButtons(inventory);
            } else if (plot.status === 'empty' || plot.status === 'setup') {
                // Equipment installation
                buttonsHtml += renderEquipmentSection(inventory, plot, 'pot', '🪴 Pots', 'garden', 'Garden Centre');
                buttonsHtml += renderEquipmentSection(inventory, plot, 'soil', '🟫 Soil', 'garden', 'Garden Centre');
                buttonsHtml += renderEquipmentSection(inventory, plot, 'light', '💡 Lights', 'hardware', 'Hardware Store');
                buttonsHtml += renderEquipmentSection(inventory, plot, 'fan', '🌀 Ventilation', 'hardware', 'Hardware Store');
                buttonsHtml += renderEquipmentSection(inventory, plot, 'fertilizer', '🧪 Fertilizer', 'garden', 'Garden Centre');

                // Planting (only if ready)
                if (plot.status === 'setup') {
                    buttonsHtml += '<div class="action-divider">🌱 Plant Seeds</div>';
                    var hasSeeds = false;
                    for (var seedId in inventory.seeds) {
                        if (inventory.seeds[seedId] > 0) {
                            var seed = HP.Data.Seeds.get(seedId);
                            buttonsHtml += '<button class="action-btn plant-seed" data-seed="' + seedId + '">' +
                                seed.icon + ' ' + seed.name + ' (' + inventory.seeds[seedId] + ')</button>';
                            hasSeeds = true;
                        }
                    }
                    if (!hasSeeds) {
                        buttonsHtml += '<span class="empty-hint">Buy seeds from Seed Dealer</span>';
                        buttonsHtml += '<button type="button" class="action-btn go-to-store-btn" data-view="dealer">Go to Seed Dealer</button>';
                    }
                }
            } else if (plot.status === 'harvest') {
                buttonsHtml += '<button class="action-btn harvest-btn" id="btn-harvest">🌿 Harvest Plant</button>';
            } else if (plot.status === 'dead') {
                buttonsHtml += '<button class="action-btn" id="btn-clear-dead">🗑️ Clear Dead Plant</button>';
            }

            elements.plotButtons.innerHTML = buttonsHtml;
            bindPlotActionButtons();
        }
    }

    function renderEquipmentSection(inventory, plot, slot, label, storeView, storeLabel) {
        var html = '<div class="action-divider">' + label + '</div>';
        var hasItems = false;
        var currentEquip = plot.equipment[slot];

        if (currentEquip) {
            var equipId = (typeof currentEquip === 'string') ? currentEquip : (currentEquip && currentEquip.id ? currentEquip.id : null);
            var equip = equipId ? HP.Data.Equipment.get(equipId) : null;
            html += '<div class="installed-equip">';
            var usesLeft = (currentEquip && typeof currentEquip === 'object' && typeof currentEquip.usesLeft === 'number') ? currentEquip.usesLeft : null;
            var usesText = (equip && equip.consumable && typeof usesLeft === 'number') ? (' <span class="equip-uses">(' + usesLeft + ' use' + (usesLeft !== 1 ? 's' : '') + ' left)</span>') : '';
            html += '<span class="current-equip">✓ ' + (equip ? equip.icon : '') + ' ' + (equip ? equip.name : 'Equipment') + usesText + '</span>';
            // Only show remove button if plot is not growing and item is not consumable
            if (plot.status !== 'growing' && plot.status !== 'harvest') {
                if (equip && !equip.consumable) {
                    html += '<button class="action-btn remove-btn uninstall-equip" data-slot="' + slot + '">Remove</button>';
                }
            }
            html += '</div>';
            return html;
        }

        for (var equipId in inventory.equipment) {
            if (inventory.equipment[equipId] > 0) {
                var equip = HP.Data.Equipment.get(equipId);
                var equipSlot = equip.slot || HP.Growing.getEquipmentSlot(equip);
                if (equipSlot === slot) {
                    html += '<button class="action-btn install-equip" data-equip="' + equipId + '">' +
                        equip.icon + ' ' + equip.name + ' (' + inventory.equipment[equipId] + ')</button>';
                    hasItems = true;
                }
            }
        }

        if (!hasItems) {
            html += '<span class="empty-hint">Buy from store</span>';
            if (storeView && storeLabel) {
                html += '<button type="button" class="action-btn go-to-store-btn" data-view="' + storeView + '">Go to ' + storeLabel + '</button>';
            }
        }
        return html;
    }

    function renderWateringButtons(inventory) {
        var html = '';
        var hasWateringCan = false;

        // Get all watering equipment from inventory
        var wateringCans = HP.Data.Equipment.getWateringCans();
        for (var i = 0; i < wateringCans.length; i++) {
            var can = wateringCans[i];
            var count = inventory.equipment[can.id] || 0;
            if (count > 0) {
                html += '<button class="action-btn water-btn" data-can="' + can.id + '">' +
                    can.icon + ' ' + can.name + ' (+' + can.waterAmount + 's)</button>';
                hasWateringCan = true;
            }
        }

        if (!hasWateringCan) {
            html += '<span class="empty-hint">Buy a watering can from Hardware Store</span>';
            html += '<button type="button" class="action-btn go-to-store-btn" data-view="hardware">Go to Hardware Store</button>';
        }

        return html;
    }

    function bindPlotActionButtons() {
        // Equipment installation
        document.querySelectorAll('.install-equip').forEach(function(btn) {
            btn.addEventListener('click', function() {
                HP.Events.installEquipment(selectedPlot.propertyId, selectedPlot.plotIndex, this.getAttribute('data-equip'));
            });
        });

        // Equipment uninstallation
        document.querySelectorAll('.uninstall-equip').forEach(function(btn) {
            btn.addEventListener('click', function() {
                HP.Events.uninstallEquipment(selectedPlot.propertyId, selectedPlot.plotIndex, this.getAttribute('data-slot'));
            });
        });

        // Planting
        document.querySelectorAll('.plant-seed').forEach(function(btn) {
            btn.addEventListener('click', function() {
                HP.Events.plantSeed(selectedPlot.propertyId, selectedPlot.plotIndex, this.getAttribute('data-seed'));
            });
        });

        // Watering
        document.querySelectorAll('.water-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                HP.Events.waterPlant(selectedPlot.propertyId, selectedPlot.plotIndex, this.getAttribute('data-can'));
            });
        });

        // Harvest
        var harvestBtn = document.getElementById('btn-harvest');
        if (harvestBtn) {
            harvestBtn.addEventListener('click', function() {
                HP.Events.harvestPlant(selectedPlot.propertyId, selectedPlot.plotIndex);
            });
        }

        // Clear dead
        var clearBtn = document.getElementById('btn-clear-dead');
        if (clearBtn) {
            clearBtn.addEventListener('click', function() {
                HP.Events.clearDeadPlant(selectedPlot.propertyId, selectedPlot.plotIndex);
            });
        }

        // Go to store (navigate to relevant store when missing items)
        document.querySelectorAll('.go-to-store-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var view = this.getAttribute('data-view');
                if (view) switchView(view);
            });
        });
    }

    function updateInventoryView() {
        var inventory = HP.State.getInventory();

        if (elements.invWeedLow) elements.invWeedLow.textContent = inventory.weed.low || 0;
        if (elements.invWeedMedium) elements.invWeedMedium.textContent = inventory.weed.medium || 0;
        if (elements.invWeedGood) elements.invWeedGood.textContent = inventory.weed.good || 0;
        if (elements.invWeedPremium) elements.invWeedPremium.textContent = inventory.weed.premium || 0;

        // Seeds
        if (elements.seedsInventory) {
            var seedsHtml = '';
            for (var seedId in inventory.seeds) {
                if (inventory.seeds[seedId] > 0) {
                    var seed = HP.Data.Seeds.get(seedId);
                    var sellPrice = Math.floor(seed.cost * 0.5);
                    seedsHtml += '<div class="inv-item-row">';
                    seedsHtml += '<span class="inv-item-name">' + seed.icon + ' ' + seed.name + '</span>';
                    seedsHtml += '<span class="inv-item-count">x' + inventory.seeds[seedId] + '</span>';
                    seedsHtml += '<button class="sell-item-btn" data-type="seed" data-id="' + seedId + '">Sell $' + sellPrice + '</button>';
                    seedsHtml += '</div>';
                }
            }
            elements.seedsInventory.innerHTML = seedsHtml || '<div class="empty-state">No seeds yet</div>';
        }

        // Equipment
        if (elements.equipmentInventory) {
            var equipHtml = '';
            for (var equipId in inventory.equipment) {
                if (inventory.equipment[equipId] > 0) {
                    var equip = HP.Data.Equipment.get(equipId);
                    var sellPrice = Math.floor(equip.cost * 0.5);
                    equipHtml += '<div class="inv-item-row">';
                    equipHtml += '<span class="inv-item-name">' + equip.icon + ' ' + equip.name + '</span>';
                    equipHtml += '<span class="inv-item-count">x' + inventory.equipment[equipId] + '</span>';
                    equipHtml += '<button class="sell-item-btn" data-type="equipment" data-id="' + equipId + '">Sell $' + sellPrice + '</button>';
                    equipHtml += '</div>';
                }
            }
            elements.equipmentInventory.innerHTML = equipHtml || '<div class="empty-state">No equipment yet</div>';
        }

        // Bind sell buttons
        bindInventorySellButtons();
    }

    function bindInventorySellButtons() {
        document.querySelectorAll('.sell-item-btn').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                var type = this.getAttribute('data-type');
                var id = this.getAttribute('data-id');
                
                if (type === 'equipment') {
                    HP.Events.sellEquipment(id);
                } else if (type === 'seed') {
                    HP.Events.sellSeeds(id);
                }
            });
        });
    }

    /**
     * Update store view with sections
     */
    function updateStoreView(storeType) {
        var storeId = storeType === 'hardware' ? 'hardware_store' : 'garden_centre';
        var targetElement = storeType === 'hardware' ? elements.hardwareItems : elements.gardenItems;
        
        if (!targetElement) return;

        var playerLevel = HP.State.getLevel();
        var money = HP.State.getMoney();
        var sections = HP.Data.Equipment.getStoreSections(storeId);

        var html = '';

        for (var s = 0; s < sections.length; s++) {
            var section = sections[s];
            var items = HP.Data.Equipment.getBySection(storeId, section.id);

            html += '<div class="store-section">';
            html += '<div class="section-header">' + section.name + '</div>';
            html += '<div class="section-desc">' + section.description + '</div>';
            html += '<div class="section-items">';

            for (var i = 0; i < items.length; i++) {
                html += renderStoreItem(items[i], playerLevel, money, 'equipment');
            }

            html += '</div></div>';
        }

        if (storeId === 'hardware_store' && HP.Data.WaterUpgrades) {
            var waterUpgrades = HP.Data.WaterUpgrades.getForStore('hardware_store');
            var ownedWater = HP.State.getWaterUpgradesOwned ? HP.State.getWaterUpgradesOwned() : [];
            if (waterUpgrades.length > 0) {
                html += '<div class="store-section">';
                html += '<div class="section-header">🪣 Water Reservoir</div>';
                html += '<div class="section-desc">Increase your water pool capacity. Water refills over time (1 charge per 8s).</div>';
                html += '<div class="section-items">';
                for (var w = 0; w < waterUpgrades.length; w++) {
                    var wu = waterUpgrades[w];
                    var isOwned = ownedWater.indexOf(wu.id) !== -1;
                    html += renderStoreItem(wu, playerLevel, money, 'water_upgrade', isOwned);
                }
                html += '</div></div>';
            }
        }

        if (storeId === 'hardware_store' && HP.Data.HeatReduction) {
            var heatItems = HP.Data.HeatReduction.getForStore('hardware_store');
            var ownedHeat = HP.State.getHeatReductionOwned ? HP.State.getHeatReductionOwned() : [];
            if (heatItems.length > 0) {
                html += '<div class="store-section">';
                html += '<div class="section-header">🛡️ Heat / Security</div>';
                html += '<div class="section-desc">Reduce how fast heat builds while growing. One-time purchase per item.</div>';
                html += '<div class="section-items">';
                for (var h = 0; h < heatItems.length; h++) {
                    var hi = heatItems[h];
                    var isOwned = ownedHeat.indexOf(hi.id) !== -1;
                    html += renderStoreItem(hi, playerLevel, money, 'heat_reduction', isOwned);
                }
                html += '</div></div>';
            }
        }

        targetElement.innerHTML = html;
    }

    // Quality order for sorting
    var qualityOrder = { low: 1, medium: 2, good: 3, premium: 4 };

    function updateDealerView() {
        if (!elements.dealerItems) return;

        var playerLevel = HP.State.getLevel();
        var money = HP.State.getMoney();
        var allSeeds = HP.Data.Seeds.getAll();

        // Get filter/sort values
        var filterQuality = document.getElementById('dealer-filter-quality');
        var filterAvailability = document.getElementById('dealer-filter-availability');
        var sortBy = document.getElementById('dealer-sort-by');
        var searchInput = document.getElementById('dealer-search');

        var qualityFilter = filterQuality ? filterQuality.value : 'all';
        var availabilityFilter = filterAvailability ? filterAvailability.value : 'all';
        var sortValue = sortBy ? sortBy.value : 'quality-asc';
        var searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';

        // Convert to array for filtering and sorting
        var seedsArray = [];
        for (var id in allSeeds) {
            var seed = allSeeds[id];
            // Skip hybrids in the dealer (they're in breeding lab)
            if (seed.isHybrid) continue;
            seedsArray.push(seed);
        }

        // Apply filters
        seedsArray = seedsArray.filter(function(seed) {
            // Quality filter
            if (qualityFilter !== 'all' && seed.quality !== qualityFilter) return false;
            
            // Availability filter
            if (availabilityFilter === 'unlocked' && seed.unlockLevel > playerLevel) return false;
            if (availabilityFilter === 'affordable' && seed.cost > money) return false;
            
            // Search filter
            if (searchTerm && seed.name.toLowerCase().indexOf(searchTerm) === -1 &&
                seed.strainName.toLowerCase().indexOf(searchTerm) === -1 &&
                seed.description.toLowerCase().indexOf(searchTerm) === -1) {
                return false;
            }
            
            return true;
        });

        // Apply sorting
        seedsArray.sort(function(a, b) {
            switch(sortValue) {
                case 'quality-asc':
                    return qualityOrder[a.quality] - qualityOrder[b.quality];
                case 'quality-desc':
                    return qualityOrder[b.quality] - qualityOrder[a.quality];
                case 'cost-asc':
                    return a.cost - b.cost;
                case 'cost-desc':
                    return b.cost - a.cost;
                case 'yield-desc':
                    return b.baseYield - a.baseYield;
                case 'growth-asc':
                    return a.growthTime - b.growthTime;
                case 'level-asc':
                    return a.unlockLevel - b.unlockLevel;
                case 'name-asc':
                    return a.name.localeCompare(b.name);
                default:
                    return qualityOrder[a.quality] - qualityOrder[b.quality];
            }
        });

        var html = '<div class="store-section">';
        html += '<div class="section-header">🌱 Available Seeds (' + seedsArray.length + ' shown)</div>';
        html += '<div class="section-items">';

        if (seedsArray.length === 0) {
            html += '<div class="empty-message">No seeds match your filters</div>';
        } else {
            for (var i = 0; i < seedsArray.length; i++) {
                html += renderStoreItem(seedsArray[i], playerLevel, money, 'seed');
            }
        }

        html += '</div></div>';
        elements.dealerItems.innerHTML = html;
    }

    function updateRealEstateView() {
        if (!elements.propertyItems) return;

        var playerLevel = HP.State.getLevel();
        var money = HP.State.getMoney();
        var owned = HP.State.getOwnedProperties();
        var allProps = HP.Data.Properties.getAll();

        var html = '<div class="store-section">';
        html += '<div class="section-header">🏠 Properties for Sale</div>';
        html += '<div class="section-items">';

        for (var id in allProps) {
            var item = allProps[id];
            var isOwned = owned.indexOf(item.id) !== -1;
            html += renderStoreItem(item, playerLevel, money, 'property', isOwned);
        }

        html += '</div></div>';
        elements.propertyItems.innerHTML = html;
    }

    function renderStoreItem(item, playerLevel, money, type, isOwned) {
        var locked = item.unlockLevel > playerLevel;
        var displayCost = item.cost;
        
        // Apply event modifier to equipment costs (supply shortage)
        if (type === 'equipment' && HP.Events && HP.Events.Manager) {
            var costMult = HP.Events.Manager.getModifier('equipmentCost');
            displayCost = Math.floor(item.cost * costMult);
        }
        
        var canAfford = money >= displayCost;
        isOwned = isOwned || false;

        var itemClass = 'store-item';
        if (locked) itemClass += ' locked';
        if (isOwned) itemClass += ' owned';

        var html = '<div class="' + itemClass + '">';
        html += '<div class="item-header">';
        html += '<span class="item-name">' + (item.icon || '') + ' ' + item.name + '</span>';
        html += '<span class="item-cost">' + (displayCost > 0 ? '$' + HP.Helpers.formatNumber(displayCost) : 'Free') + '</span>';
        html += '</div>';
        html += '<div class="item-desc">' + item.description + '</div>';

        // Stats
        html += '<div class="item-stats">';
        if (item.capacityBonus != null) html += '<span class="stat-tag water">+' + item.capacityBonus + ' capacity</span>';
        if (item.heatReduction != null) html += '<span class="stat-tag heat">−' + Math.round(item.heatReduction * 100) + '% heat</span>';
        if (item.growthBonus) html += '<span class="stat-tag growth">+' + item.growthBonus + '% Growth</span>';
        if (item.yieldBonus) html += '<span class="stat-tag yield">+' + item.yieldBonus + '% Yield</span>';
        if (item.qualityBonus) html += '<span class="stat-tag quality">+' + item.qualityBonus + '% Quality</span>';
        if (item.consumable && item.uses && item.uses > 1) html += '<span class="stat-tag">x' + item.uses + ' uses</span>';
        if (item.waterAmount) html += '<span class="stat-tag water">+' + item.waterAmount + 's Water</span>';
        if (item.plotCapacity) html += '<span class="stat-tag">' + item.plotCapacity + ' plots</span>';
        if (item.growthTime) html += '<span class="stat-tag">' + item.growthTime + 's grow time</span>';
        html += '</div>';

        // Button
        if (isOwned) {
            html += '<button class="buy-btn" disabled>✓ Owned</button>';
        } else if (locked) {
            html += '<button class="buy-btn" disabled>🔒 Level ' + item.unlockLevel + '</button>';
        } else {
            html += '<button class="buy-btn" data-type="' + type + '" data-id="' + item.id + '" data-cost="' + displayCost + '"' + 
                (canAfford ? '' : ' disabled') + '>' + (canAfford ? 'Buy' : 'Need $' + HP.Helpers.formatNumber(displayCost)) + '</button>';
        }

        html += '</div>';
        return html;
    }

    var selectedCustomer = null;

    function updateMarketView() {
        var inventory = HP.State.getInventory();

        if (elements.sellStockLow) elements.sellStockLow.textContent = inventory.weed.low || 0;
        if (elements.sellStockMedium) elements.sellStockMedium.textContent = inventory.weed.medium || 0;
        if (elements.sellStockGood) elements.sellStockGood.textContent = inventory.weed.good || 0;
        if (elements.sellStockPremium) elements.sellStockPremium.textContent = inventory.weed.premium || 0;

        updateOrdersPanel();
        updateCustomersGrid();
    }

    function updateOrdersPanel() {
        if (!elements.ordersList || !HP.MarketOrders) return;

        var activeOrders = HP.MarketOrders.getAllOrders();
        var orderIds = Object.keys(activeOrders);
        var count = orderIds.length;

        if (elements.ordersCount) {
            elements.ordersCount.textContent = count === 1 ? '1 order' : count + ' orders';
        }
        if (elements.ordersEmpty) {
            if (count === 0) {
                elements.ordersEmpty.classList.remove('hidden');
                elements.ordersList.classList.add('hidden');
            } else {
                elements.ordersEmpty.classList.add('hidden');
                elements.ordersList.classList.remove('hidden');
            }
        }

        var html = '';
        var now = Date.now();
        var inventory = HP.State.getInventory();
        
        for (var i = 0; i < orderIds.length; i++) {
            var customerId = orderIds[i];
            var order = activeOrders[customerId];
            if (!order || order.expiresAt <= now) continue;

            var customer = HP.Data.Customers && HP.Data.Customers.get(customerId);
            var customerName = customer ? customer.name : customerId;
            var customerIcon = customer ? customer.icon : '🤝';

            var timeLeftSec = Math.max(0, Math.floor((order.expiresAt - now) / 1000));
            var mins = Math.floor(timeLeftSec / 60);
            var secs = timeLeftSec % 60;
            var timeStr = mins + 'm ' + secs + 's';

            var bonusExtra = order.bonusPrice - order.basePrice;
            
            // Check if player has enough inventory to fulfill order
            var hasInventory = inventory.weed[order.quality] >= order.amount;
            
            html += '<div class="order-card" data-customer-id="' + customerId + '">';
            html += '<div class="order-card-header">';
            html += '<span class="order-card-icon">' + customerIcon + '</span>';
            html += '<span class="order-card-customer">' + customerName + '</span>';
            html += '</div>';
            html += '<div class="order-card-details">';
            html += '<span class="order-card-want">' + order.amount + 'g ' + order.quality + '</span>';
            html += '<span class="order-card-bonus">+$' + HP.Helpers.formatNumber(bonusExtra) + ' bonus</span>';
            html += '<span class="order-card-time">⏱️ ' + timeStr + '</span>';
            html += '</div>';
            
            if (hasInventory) {
                html += '<button type="button" class="btn-order-quick-sell" data-customer-id="' + customerId + '" data-quality="' + order.quality + '" data-amount="' + order.amount + '" title="Instantly fulfill this order">Quick sell</button>';
            } else {
                html += '<button type="button" class="btn-order-deal" data-customer-id="' + customerId + '" title="Open deal with this buyer">Deal</button>';
            }
            
            html += '</div>'; // .order-card
        }
        elements.ordersList.innerHTML = html;
        bindOrderDealButtons();
        bindOrderQuickSellButtons();
    }

    function bindOrderQuickSellButtons() {
        if (!elements.ordersList) return;
        elements.ordersList.querySelectorAll('.btn-order-quick-sell').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var customerId = btn.getAttribute('data-customer-id');
                var quality = btn.getAttribute('data-quality');
                var amount = parseInt(btn.getAttribute('data-amount'));
                
                // Directly sell to fulfill the order
                if (HP.Events && HP.Events.quickSellOrder) {
                    HP.Events.quickSellOrder(customerId, quality, amount);
                }
            });
        });
    }

    function bindOrderDealButtons() {
        if (!elements.ordersList) return;
        elements.ordersList.querySelectorAll('.btn-order-deal').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var customerId = this.getAttribute('data-customer-id');
                if (customerId) openSaleModal(customerId);
            });
        });
    }

    function updateCustomersGrid() {
        if (!elements.customersGrid) return;

        var playerLevel = HP.State.getLevel();
        var allCustomers = HP.Data.Customers.getAll();
        var activeOrders = HP.MarketOrders ? HP.MarketOrders.getAllOrders() : {};

        var html = '';

        for (var id in allCustomers) {
            var customer = allCustomers[id];
            var locked = customer.unlockLevel > playerLevel;
            var order = activeOrders[id];

            var cardClass = 'customer-card' + (locked ? ' locked' : '');
            if (order) cardClass += ' has-order';

            html += '<div class="' + cardClass + '" data-customer="' + id + '">';
            html += '<div class="customer-header">';
            html += '<span class="customer-icon">' + customer.icon + '</span>';
            html += '<span class="customer-name">' + customer.name + '</span>';
            if (order) {
                html += '<span class="order-badge">📋 ORDER</span>';
            }
            html += '</div>';
            html += '<div class="customer-desc">' + customer.description + '</div>';
            if (!locked) {
                var rep = HP.State && HP.State.getCustomerReputation ? HP.State.getCustomerReputation(id) : 0;
                html += '<div class="customer-rep">Rep: ' + rep + '</div>';
                html += '<div class="customer-range">Buys ' + customer.minAmount + 'g–' + customer.maxAmount + 'g</div>';
            }

            // Show active order if exists
            if (order && !locked) {
                var timeLeft = Math.max(0, Math.floor((order.expiresAt - Date.now()) / 1000));
                var mins = Math.floor(timeLeft / 60);
                var secs = timeLeft % 60;
                html += '<div class="customer-order">';
                html += '<div class="order-title">📋 Wants: ' + order.amount + 'g ' + order.quality + '</div>';
                html += '<div class="order-bonus">+20% bonus if exact match!</div>';
                html += '<div class="order-time">⏱️ ' + mins + 'm ' + secs + 's left</div>';
                html += '</div>';
            }

            // Show preferred qualities
            html += '<div class="customer-pref">';
            var qualities = ['low', 'medium', 'good', 'premium'];
            for (var q = 0; q < qualities.length; q++) {
                var qual = qualities[q];
                var mult = customer.priceMultiplier[qual];
                if (mult >= 1.1) {
                    html += '<span class="pref-tag good">+' + Math.round((mult - 1) * 100) + '% ' + qual + '</span>';
                } else if (mult <= 0.7 && mult > 0) {
                    html += '<span class="pref-tag bad">' + Math.round((mult - 1) * 100) + '% ' + qual + '</span>';
                }
            }
            html += '</div>';

            if (locked) {
                html += '<div style="font-size:10px;color:#666;margin-top:4px;">🔒 Level ' + customer.unlockLevel + '</div>';
            }

            html += '</div>';
        }

        elements.customersGrid.innerHTML = html;
        bindCustomerCards();
    }

    function bindCustomerCards() {
        document.querySelectorAll('.customer-card:not(.locked)').forEach(function(card) {
            card.addEventListener('click', function() {
                var customerId = this.getAttribute('data-customer');
                openSaleModal(customerId);
            });
        });
    }

    function getFulfillableOptions(customer) {
        if (!customer || !HP.State) return [];
        var minA = customer.minAmount || 1;
        var maxA = customer.maxAmount || 1;
        var qualities = customer.preferredQuality && customer.preferredQuality.length > 0
            ? customer.preferredQuality.slice()
            : ['low', 'medium', 'good', 'premium'];
        var options = [];
        for (var q = 0; q < qualities.length; q++) {
            var qual = qualities[q];
            var available = HP.State.getWeed(qual) || 0;
            if (available >= minA) {
                var amount = Math.min(maxA, Math.floor(available));
                if (amount >= minA) options.push({ quality: qual, amount: amount });
            }
        }
        var anyQualities = ['low', 'medium', 'good', 'premium'];
        for (var a = 0; a < anyQualities.length; a++) {
            var qual = anyQualities[a];
            if (qualities.indexOf(qual) !== -1) continue;
            var available = HP.State.getWeed(qual) || 0;
            if (available >= minA) {
                var amount = Math.min(maxA, Math.floor(available));
                if (amount >= minA) options.push({ quality: qual, amount: amount });
            }
        }
        return options;
    }

    function generateCustomerRequest(customer, preferFulfillable) {
        var options = preferFulfillable ? getFulfillableOptions(customer) : [];
        var requestedQuality;
        var requestedAmount;
        if (options.length > 0) {
            var pick = options[Math.floor(Math.random() * options.length)];
            requestedQuality = pick.quality;
            requestedAmount = pick.amount;
        } else {
            requestedAmount = Math.floor(Math.random() * (customer.maxAmount - customer.minAmount + 1)) + customer.minAmount;
            if (customer.preferredQuality && customer.preferredQuality.length > 0) {
                if (Math.random() < 0.7) {
                    requestedQuality = customer.preferredQuality[Math.floor(Math.random() * customer.preferredQuality.length)];
                } else {
                    var allQ = ['low', 'medium', 'good', 'premium'];
                    requestedQuality = allQ[Math.floor(Math.random() * allQ.length)];
                }
            } else {
                var allQ = ['low', 'medium', 'good', 'premium'];
                requestedQuality = allQ[Math.floor(Math.random() * allQ.length)];
            }
        }
        return { quality: requestedQuality, amount: requestedAmount };
    }

    function setAndDisplayRequest(customer, request) {
        if (!customer.currentRequest) customer.currentRequest = {};
        customer.currentRequest.quality = request.quality;
        customer.currentRequest.amount = request.amount;
        var qualityEl = document.getElementById('request-quality');
        var amountEl = document.getElementById('request-amount');
        if (qualityEl) qualityEl.textContent = request.quality.charAt(0).toUpperCase() + request.quality.slice(1);
        if (amountEl) amountEl.textContent = request.amount + 'g';
    }

    function openSaleModal(customerId) {
        var customer = HP.Data.Customers.get(customerId);
        if (!customer) return;

        selectedCustomer = customerId;

        document.getElementById('modal-customer-icon').textContent = customer.icon;
        document.getElementById('modal-customer-name').textContent = customer.name;
        document.getElementById('modal-customer-desc').textContent = customer.description;

        var request = generateCustomerRequest(customer, true);
        setAndDisplayRequest(customer, request);

        if (elements.saleModal) {
            elements.saleModal.classList.remove('hidden');
        }

        updateSellTotal();
    }

    function regenerateCustomerRequest() {
        if (!selectedCustomer) return;
        var customer = HP.Data.Customers.get(selectedCustomer);
        if (!customer) return;
        var request = generateCustomerRequest(customer, true);
        setAndDisplayRequest(customer, request);
        updateSellTotal();
    }

    function closeSaleModal() {
        selectedCustomer = null;
        if (elements.saleModal) {
            elements.saleModal.classList.add('hidden');
        }
    }

    function updateSellTotal() {
        if (!elements.sellTotal) return;
        if (!selectedCustomer) return;

        var customer = HP.Data.Customers.get(selectedCustomer);
        if (!customer || !customer.currentRequest) return;

        var quality = customer.currentRequest.quality;
        var amount = customer.currentRequest.amount;
        var available = HP.State.getWeed(quality);

        // Check if player has enough stock
        var sellBtn = document.getElementById('btn-sell');
        var statusEl = document.getElementById('sale-status');
        
        if (available < amount) {
            if (elements.salePricePerGram) elements.salePricePerGram.textContent = '$0.00';
            if (elements.sellTotal) elements.sellTotal.textContent = '$0';
            if (sellBtn) sellBtn.disabled = true;
            if (statusEl) {
                statusEl.textContent = '❌ Not enough stock! You have ' + available + 'g, but customer wants ' + amount + 'g.';
                statusEl.className = 'sale-status error';
            }
            return;
        }

        var priceInfo = HP.Data.Customers.calculatePrice(selectedCustomer, quality, amount);
        if (!priceInfo) {
            if (elements.salePricePerGram) elements.salePricePerGram.textContent = '$0.00';
            if (elements.sellTotal) elements.sellTotal.textContent = '$0';
            if (sellBtn) sellBtn.disabled = true;
            if (elements.saleCustomerRep) elements.saleCustomerRep.textContent = '0';
            if (elements.saleDealEffect) elements.saleDealEffect.textContent = '';
            return;
        }

        var rep = HP.State && HP.State.getCustomerReputation ? HP.State.getCustomerReputation(selectedCustomer) : 0;
        if (elements.saleCustomerRep) elements.saleCustomerRep.textContent = rep;

        var dealEl = document.querySelector('.deal-type-btn.selected');
        var dealType = (dealEl && dealEl.getAttribute('data-deal')) || 'normal';
        var constants = HP.Data.Constants || {};
        var discountMult = constants.REP_DEAL_DISCOUNT_PRICE_MULT != null ? constants.REP_DEAL_DISCOUNT_PRICE_MULT : 0.85;
        var overchargeMult = constants.REP_DEAL_OVERCHARGE_PRICE_MULT != null ? constants.REP_DEAL_OVERCHARGE_PRICE_MULT : 1.20;
        var displayTotal = priceInfo.total;
        var dealEffectText = '';
        if (dealType === 'discount') {
            displayTotal = Math.floor(priceInfo.total * discountMult);
            dealEffectText = '15% discount applied. Reputation: +3';
        } else if (dealType === 'overcharge') {
            displayTotal = Math.floor(priceInfo.total * overchargeMult);
            dealEffectText = '20% overcharge. Reputation: -2';
        } else {
            dealEffectText = 'Reputation: +1';
        }

        if (elements.salePricePerGram) {
            elements.salePricePerGram.textContent = '$' + priceInfo.pricePerGram.toFixed(2);
        }

        if (elements.saleBonus) {
            var bonusPercent = Math.round((priceInfo.multiplier - 1) * 100);
            if (bonusPercent > 0) {
                elements.saleBonus.textContent = '+' + bonusPercent + '%';
                elements.saleBonus.style.color = '#00ff88';
            } else if (bonusPercent < 0) {
                elements.saleBonus.textContent = bonusPercent + '%';
                elements.saleBonus.style.color = '#ff6b6b';
            } else {
                elements.saleBonus.textContent = '0%';
                elements.saleBonus.style.color = '#888';
            }
        }

        var repBonusRow = document.getElementById('rep-bonus-row');
        var saleRepBonus = document.getElementById('sale-rep-bonus');
        if (priceInfo.reputationBonus && priceInfo.reputationBonus > 1 && repBonusRow && saleRepBonus) {
            repBonusRow.style.display = 'flex';
            var repBonusPct = Math.round((priceInfo.reputationBonus - 1) * 100);
            saleRepBonus.textContent = '+' + repBonusPct + '%';
            saleRepBonus.style.color = '#ba68c8';
        } else if (repBonusRow) {
            repBonusRow.style.display = 'none';
        }

        if (elements.sellTotal) {
            elements.sellTotal.textContent = '$' + HP.Helpers.formatNumber(displayTotal);
        }

        if (elements.saleDealEffect) {
            elements.saleDealEffect.textContent = dealEffectText;
            elements.saleDealEffect.className = 'sale-deal-effect ' + dealType;
        }

        if (sellBtn) {
            sellBtn.disabled = false;
        }

        if (statusEl) {
            statusEl.textContent = '✓ You have enough stock to fulfill this order.';
            statusEl.className = 'sale-status success';
        }
    }

    function getSelectedCustomer() {
        return selectedCustomer;
    }

    /**
     * Update achievements view
     */
    function updateAchievementsView() {
        if (!elements.achievementsList) return;

        var count = HP.Achievements.getCount();
        if (elements.achievementCount) {
            elements.achievementCount.textContent = count.unlocked + '/' + count.total;
        }

        var categories = HP.Data.Achievements.getCategories();
        var unlocked = HP.State.getUnlockedAchievements();

        var html = '';

        for (var c = 0; c < categories.length; c++) {
            var cat = categories[c];
            var achievements = HP.Data.Achievements.getByCategory(cat.id);

            html += '<div class="achievement-category">';
            html += '<div class="achievement-cat-header">' + cat.name + '</div>';
            html += '<div class="achievement-list">';

            for (var i = 0; i < achievements.length; i++) {
                var ach = achievements[i];
                var isUnlocked = unlocked.indexOf(ach.id) !== -1;
                var progress = HP.Achievements.getProgress(ach.id);

                var achClass = 'achievement-item' + (isUnlocked ? ' unlocked' : '');

                html += '<div class="' + achClass + '">';
                html += '<div class="achievement-icon">' + ach.icon + '</div>';
                html += '<div class="achievement-info">';
                html += '<div class="achievement-name">' + ach.name + '</div>';
                html += '<div class="achievement-desc">' + ach.description + '</div>';
                
                if (!isUnlocked && progress) {
                    html += '<div class="achievement-progress-bar"><div class="achievement-progress" style="width:' + progress.percentage + '%"></div></div>';
                    html += '<div class="achievement-progress-text">' + progress.current + ' / ' + progress.required + '</div>';
                }

                if (ach.reward) {
                    html += '<div class="achievement-reward">Reward: +$' + ach.reward.amount + '</div>';
                }

                html += '</div>';
                if (isUnlocked) {
                    html += '<div class="achievement-check">✓</div>';
                }
                html += '</div>';
            }

            html += '</div></div>';
        }

        elements.achievementsList.innerHTML = html;
    }

    function getSelectedPlot() { return selectedPlot; }
    function getCurrentView() { return currentView; }

    /**
     * Update dynamic tooltips for bars
     */
    function updateTooltips() {
        // Heat tooltip
        var heat = HP.State.getHeat();
        var maxHeat = HP.State.getState().heat.maxLevel || 100;
        var heatMult = HP.Heat && HP.Heat.getHeatGainMultiplier ? HP.Heat.getHeatGainMultiplier() : 1;
        var reduction = Math.round((1 - heatMult) * 100);
        var heatTooltip = 'Heat: ' + Math.round(heat) + '/' + maxHeat;
        if (reduction > 0) heatTooltip += ' (−' + reduction + '% from security)';
        var heatBarContainer = document.getElementById('heat-bar-container');
        if (heatBarContainer) heatBarContainer.title = heatTooltip;

        // Water tooltip
        var reservoir = HP.State.getWaterReservoir();
        var waterTooltip = 'Water: ' + reservoir.current + '/' + reservoir.capacity;
        if (reservoir.current < reservoir.capacity) {
            var refillInterval = HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS || 8;
            var timeToNext = Math.ceil(refillInterval - (reservoir.refillAccumulator || 0));
            waterTooltip += ' (next charge in ' + timeToNext + 's)';
        } else {
            waterTooltip += ' (full)';
        }
        var waterDisplay = document.getElementById('water-reservoir-display');
        if (waterDisplay) waterDisplay.title = waterTooltip;
        var waterTimer = document.getElementById('water-refill-timer');
        if (waterTimer) waterTimer.title = waterTooltip;

        // XP tooltip
        var xp = HP.State.getXP();
        var level = HP.State.getLevel();
        var nextRank = HP.Data.Ranks.getNext(level);
        var xpTooltip = 'XP: ' + HP.Helpers.formatNumber(xp);
        if (nextRank) {
            var currentRank = HP.Data.Ranks.getByLevel(level);
            xpTooltip += ' / ' + HP.Helpers.formatNumber(nextRank.xpRequired) + ' (Level ' + level + ' → ' + nextRank.level + ')';
        } else {
            xpTooltip += ' (Max level)';
        }
        var xpBarContainer = document.getElementById('xp-bar-container');
        if (xpBarContainer) xpBarContainer.title = xpTooltip;
    }

    /**
     * Lightweight update for timers and progress bars only
     * Called frequently (100ms) for smooth animations
     */
    function updateTimers() {
        // Heat bar (always visible in top bar)
        if (elements.heatBar || elements.heatText) updateHeatDisplay();

        // Update tooltips
        updateTooltips();

        // Update market orders panel and customer cards if on market view
        if (currentView === 'market') {
            var now = Date.now();
            if (!updateTimers.lastOrderUpdate || (now - updateTimers.lastOrderUpdate) > 1000) {
                updateTimers.lastOrderUpdate = now;
                if (elements.ordersList) updateOrdersPanel();
                if (elements.customersGrid) updateCustomersGrid();
            }
        }

        // Update water refill timer when on grow view
        if (currentView === 'grow' && HP.State && HP.State.getWaterReservoir) {
            var reservoir = HP.State.getWaterReservoir();
            if (reservoir && elements.waterCurrent) {
                elements.waterCurrent.textContent = reservoir.current;
                if (elements.waterCapacity) elements.waterCapacity.textContent = reservoir.capacity;
                var interval = (HP.Data.Constants && HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS != null) ? HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS : 8;
                var acc = reservoir.refillAccumulator || 0;
                var pct = interval > 0 ? Math.min(100, (acc / interval) * 100) : 0;
                var nextSec = Math.ceil(Math.max(0, interval - acc));
                if (elements.waterRefillProgress) elements.waterRefillProgress.style.width = pct + '%';
                if (elements.waterNextCharge) elements.waterNextCharge.textContent = 'Next: ' + nextSec + 's';
            }
        }

        // Only update plots if on grow view
        if (currentView !== 'grow') return;
        if (!elements.plotsGrid) return;

        var propertyId = elements.propertySelect ? elements.propertySelect.value : null;
        if (!propertyId) return;

        var plots = HP.State.getPlots(propertyId);
        var plotCards = elements.plotsGrid.querySelectorAll('.plot-card');

        plotCards.forEach(function(card, index) {
            var plot = plots[index];
            if (!plot || plot.status !== 'growing' || !plot.plant) return;

            // Update progress bar
            var progressBar = card.querySelector('.plot-progress');
            if (progressBar) {
                var progress = HP.Growing.getGrowthProgress(plot.plant);
                progressBar.style.width = progress + '%';
            }

            // Update time remaining
            var timeEl = card.querySelector('.plot-time');
            if (timeEl) {
                timeEl.textContent = HP.Growing.getTimeRemaining(plot.plant) + ' left';
            }

            // Update water bar
            var waterFill = card.querySelector('.water-fill');
            if (waterFill) {
                var waterLevel = HP.Growing.getWaterLevel(plot.plant);
                waterFill.style.width = waterLevel + '%';
            }

            // Update water status (icon and label)
            var isHydrated = plot.plant.isHydrated;
            var iconEl = card.querySelector('.plot-icon');
            var labelEl = card.querySelector('.plot-label');
            
            if (iconEl) {
                iconEl.textContent = isHydrated ? '🌱' : '🥀';
            }
            if (labelEl) {
                labelEl.textContent = isHydrated ? 'Growing' : 'Needs Water!';
            }

            // Update water bar color class
            var waterBar = card.querySelector('.water-bar');
            if (waterBar) {
                var waterLevel = HP.Growing.getWaterLevel(plot.plant);
                waterBar.classList.remove('water-good', 'water-low', 'water-critical');
                if (waterLevel > 50) {
                    waterBar.classList.add('water-good');
                } else if (waterLevel > 20) {
                    waterBar.classList.add('water-low');
                } else {
                    waterBar.classList.add('water-critical');
                }
            }
        });

        // Update selected plot panel water info if visible
        if (selectedPlot && elements.plotStatusBadge) {
            var plot = HP.State.getPlot(selectedPlot.propertyId, selectedPlot.plotIndex);
            if (plot && plot.plant && plot.status === 'growing') {
                var seed = HP.Data.Seeds.get(plot.plant.seedId);
                var statusText = seed.name;
                if (!plot.plant.isHydrated) {
                    statusText += ' - NEEDS WATER';
                }
                elements.plotStatusBadge.textContent = statusText;
            }
        }
    }

    return {
        init: init,
        update: update,
        updateTimers: updateTimers,
        switchView: switchView,
        selectPlot: selectPlot,
        getSelectedPlot: getSelectedPlot,
        getCurrentView: getCurrentView,
        updateSellTotal: updateSellTotal,
        regenerateCustomerRequest: regenerateCustomerRequest,
        toggleRoomUpgradesPanel: toggleRoomUpgradesPanel,
        closeSaleModal: closeSaleModal,
        getSelectedCustomer: getSelectedCustomer,
        toggleBulkSelectMode: toggleBulkSelectMode,
        clearSelection: clearSelection,
        getSelectedPlots: function() { return selectedPlots.slice(); },
        isBulkSelectMode: function() { return bulkSelectMode; },
        openWorkerAssignModal: openWorkerAssignModal,
        closeWorkerAssignModal: closeWorkerAssignModal
    };

    function updateAchievementsView() {
        if (!elements.achievementsGrid) return;

        var achievements = HP.State.getAchievements();
        var allAchievements = HP.Data.Achievements.getAll();
        var unlockedIds = achievements.unlocked;
        var total = Object.keys(allAchievements).length;
        var unlocked = unlockedIds.length;
        var progress = total > 0 ? Math.round((unlocked / total) * 100) : 0;

        function inferAchievementCategory(achievement) {
            var id = achievement && achievement.id ? achievement.id : '';
            if (id.indexOf('money') === 0 || id.indexOf('hundred') === 0 || id.indexOf('thousand') === 0) return 'Money';
            if (id.indexOf('gramsSold') === 0 || id.indexOf('firstSale') === 0) return 'Sales';
            if (id.indexOf('plantsHarvested') === 0 || id.indexOf('firstHarvest') === 0) return 'Harvesting';
            if (id.indexOf('reachLevel') === 0 || id === 'levelFive' || id === 'levelTen') return 'Progression';
            if (id.indexOf('ownProperties') === 0 || id.indexOf('own_') === 0 || id === 'firstProperty') return 'Properties';
            if (id.indexOf('roomUpgrades') === 0) return 'Upgrades';
            if (id.indexOf('growerWorkers') === 0) return 'Workers';
            if (id.indexOf('stockpile') === 0) return 'Inventory';
            if (id.indexOf('playTime') === 0) return 'Time';
            return 'General';
        }

        function inferAchievementSubCategory(achievement) {
            var id = achievement && achievement.id ? achievement.id : '';
            if (id.indexOf('own_') === 0) return 'Specific';
            return 'Milestones';
        }

        // Resolve current filters from UI (persist across renders)
        if (elements.achievementStatusFilter) {
            achievementFilters.status = elements.achievementStatusFilter.value || achievementFilters.status || 'all';
        }
        if (elements.achievementCategoryFilter) {
            achievementFilters.category = elements.achievementCategoryFilter.value || achievementFilters.category || 'all';
        }
        if (elements.achievementSubFilter) {
            achievementFilters.sub = elements.achievementSubFilter.value || achievementFilters.sub || 'all';
        }

        // Update stats
        if (elements.achievementsUnlocked) elements.achievementsUnlocked.textContent = unlocked;
        if (elements.achievementsTotal) elements.achievementsTotal.textContent = total;
        if (elements.achievementsProgress) elements.achievementsProgress.textContent = progress + '%';

        // Build category/subcategory lists
        var categoriesMap = {};
        var subsByCategory = {};
        var ids = HP.Data.Achievements.getIds();
        for (var i = 0; i < ids.length; i++) {
            var a = allAchievements[ids[i]];
            if (!a) continue;
            var cat = a.category || inferAchievementCategory(a);
            var sub = a.subCategory || inferAchievementSubCategory(a);
            categoriesMap[cat] = true;
            if (!subsByCategory[cat]) subsByCategory[cat] = {};
            subsByCategory[cat][sub] = true;
        }

        var categoryList = Object.keys(categoriesMap);
        categoryList.sort();
        categoryList.unshift('All');

        var selectedCat = achievementFilters.category || 'all';
        if (selectedCat === 'All') selectedCat = 'all';

        if (elements.achievementCategoryFilter) {
            var prevCat = elements.achievementCategoryFilter.value || 'all';
            var catHtml = '<option value="all">All categories</option>';
            for (var c = 0; c < categoryList.length; c++) {
                if (categoryList[c] === 'All') continue;
                catHtml += '<option value="' + categoryList[c] + '">' + categoryList[c] + '</option>';
            }
            elements.achievementCategoryFilter.innerHTML = catHtml;
            if (prevCat && (prevCat === 'all' || categoriesMap[prevCat])) {
                elements.achievementCategoryFilter.value = prevCat;
            }
            achievementFilters.category = elements.achievementCategoryFilter.value || 'all';
            selectedCat = achievementFilters.category;
        }

        // Subcategory options depend on selected category
        if (elements.achievementSubFilter) {
            var prevSub = elements.achievementSubFilter.value || 'all';
            var subsMap = {};
            if (selectedCat && selectedCat !== 'all') {
                subsMap = subsByCategory[selectedCat] || {};
            } else {
                // All categories: include all subs
                for (var catKey in subsByCategory) {
                    for (var subKey in subsByCategory[catKey]) subsMap[subKey] = true;
                }
            }

            var subList = Object.keys(subsMap);
            subList.sort();
            var subHtml = '<option value="all">All sections</option>';
            for (var s = 0; s < subList.length; s++) {
                subHtml += '<option value="' + subList[s] + '">' + subList[s] + '</option>';
            }
            elements.achievementSubFilter.innerHTML = subHtml;
            elements.achievementSubFilter.disabled = false;
            if (prevSub && (prevSub === 'all' || subsMap[prevSub])) {
                elements.achievementSubFilter.value = prevSub;
            } else {
                elements.achievementSubFilter.value = 'all';
            }
            achievementFilters.sub = elements.achievementSubFilter.value || 'all';
        }

        // Render achievements grid
        var html = '';
        var achievementIds = HP.Data.Achievements.getIds();

        for (var i = 0; i < achievementIds.length; i++) {
            var id = achievementIds[i];
            var achievement = allAchievements[id];
            var isUnlocked = unlockedIds.indexOf(id) !== -1;
            if (!achievement) continue;

            var statusFilter = achievementFilters.status || 'all';
            if (statusFilter === 'unlocked' && !isUnlocked) continue;
            if (statusFilter === 'locked' && isUnlocked) continue;

            var aCat = achievement.category || inferAchievementCategory(achievement);
            var aSub = achievement.subCategory || inferAchievementSubCategory(achievement);
            if (achievementFilters.category !== 'all' && aCat !== achievementFilters.category) continue;
            if (achievementFilters.sub !== 'all' && aSub !== achievementFilters.sub) continue;

            var cardClass = 'achievement-card';
            if (isUnlocked) cardClass += ' unlocked';

            html += '<div class="' + cardClass + '">';
            html += '<div class="achievement-icon">' + (isUnlocked ? achievement.emoji : '🔒') + '</div>';
            html += '<div class="achievement-content">';
            html += '<div class="achievement-name">' + achievement.name + '</div>';
            html += '<div class="achievement-desc">' + achievement.description + '</div>';
            html += '<div class="achievement-meta">' + aCat + ' • ' + aSub + '</div>';
            if (achievement.xpReward && isUnlocked) {
                html += '<div class="achievement-reward">+' + achievement.xpReward + ' XP</div>';
            }
            html += '</div>';
            if (isUnlocked) {
                html += '<div class="achievement-badge">✓</div>';
            }
            html += '</div>';
        }

        elements.achievementsGrid.innerHTML = html;
    }

    function updateChallengesView() {
        if (!elements.challengesGrid || !HP.Challenges) return;

        var state = HP.State.getState();
        var playerLevel = state.level;
        var allChallenges = HP.Challenges.getAvailableChallenges(playerLevel);
        var completedChallenges = HP.State.getChallenges().completed;

        function formatTimeForChallenge(seconds) {
            seconds = Math.max(0, Math.floor(Number(seconds) || 0));
            if (seconds < 60) return seconds + 's';
            var minsTotal = Math.floor(seconds / 60);
            if (minsTotal < 60) return minsTotal + 'm';
            var hours = Math.floor(minsTotal / 60);
            var mins = minsTotal % 60;
            if (mins === 0) return hours + 'h';
            return hours + 'h ' + mins + 'm';
        }

        function inferChallengeCategory(challenge) {
            if (!challenge) return 'General';
            switch (challenge.type) {
                case HP.Challenges.CHALLENGE_TYPES.EARN_TOTAL: return 'Money';
                case HP.Challenges.CHALLENGE_TYPES.SELL_TOTAL: return 'Sales';
                case HP.Challenges.CHALLENGE_TYPES.HARVEST_TOTAL: return 'Harvesting';
                case HP.Challenges.CHALLENGE_TYPES.GROW_TOTAL: return 'Harvesting';
                case HP.Challenges.CHALLENGE_TYPES.REACH_LEVEL: return 'Progression';
                case HP.Challenges.CHALLENGE_TYPES.OWN_PROPERTIES: return 'Properties';
                case HP.Challenges.CHALLENGE_TYPES.ROOM_UPGRADES_TOTAL: return 'Upgrades';
                case HP.Challenges.CHALLENGE_TYPES.GROWER_WORKERS_TOTAL: return 'Workers';
                case HP.Challenges.CHALLENGE_TYPES.OWN_SEEDS_TOTAL: return 'Inventory';
                case HP.Challenges.CHALLENGE_TYPES.OWN_EQUIPMENT_TOTAL: return 'Inventory';
                case HP.Challenges.CHALLENGE_TYPES.PLAY_TIME_SECONDS: return 'Time';
                default: return 'General';
            }
        }

        function inferChallengeSubCategory(challenge) {
            if (!challenge) return 'Milestones';
            if (challenge.type === HP.Challenges.CHALLENGE_TYPES.OWN_SEEDS_TOTAL || challenge.type === HP.Challenges.CHALLENGE_TYPES.OWN_EQUIPMENT_TOTAL) {
                return 'Stockpiles';
            }
            return 'Milestones';
        }

        if (elements.challengeStatusFilter) {
            challengeFilters.status = elements.challengeStatusFilter.value || challengeFilters.status || 'all';
        }
        if (elements.challengeCategoryFilter) {
            challengeFilters.category = elements.challengeCategoryFilter.value || challengeFilters.category || 'all';
        }
        if (elements.challengeSubFilter) {
            challengeFilters.sub = elements.challengeSubFilter.value || challengeFilters.sub || 'all';
        }

        // Build category/sub lists from available challenges
        var chCats = {};
        var chSubsByCat = {};
        for (var i = 0; i < allChallenges.length; i++) {
            var ch = allChallenges[i];
            var cat = ch.category || inferChallengeCategory(ch);
            var sub = ch.subCategory || inferChallengeSubCategory(ch);
            chCats[cat] = true;
            if (!chSubsByCat[cat]) chSubsByCat[cat] = {};
            chSubsByCat[cat][sub] = true;
        }

        var chCatList = Object.keys(chCats);
        chCatList.sort();

        if (elements.challengeCategoryFilter) {
            var prev = elements.challengeCategoryFilter.value || 'all';
            var htmlCat = '<option value="all">All categories</option>';
            for (var ci = 0; ci < chCatList.length; ci++) {
                htmlCat += '<option value="' + chCatList[ci] + '">' + chCatList[ci] + '</option>';
            }
            elements.challengeCategoryFilter.innerHTML = htmlCat;
            if (prev && (prev === 'all' || chCats[prev])) elements.challengeCategoryFilter.value = prev;
            challengeFilters.category = elements.challengeCategoryFilter.value || 'all';
        }

        if (elements.challengeSubFilter) {
            var prevS = elements.challengeSubFilter.value || 'all';
            var subsMap2 = {};
            if (challengeFilters.category !== 'all') {
                subsMap2 = chSubsByCat[challengeFilters.category] || {};
            } else {
                for (var catKey2 in chSubsByCat) {
                    for (var subKey2 in chSubsByCat[catKey2]) subsMap2[subKey2] = true;
                }
            }
            var subList2 = Object.keys(subsMap2);
            subList2.sort();
            var htmlSub = '<option value="all">All sections</option>';
            for (var si2 = 0; si2 < subList2.length; si2++) {
                htmlSub += '<option value="' + subList2[si2] + '">' + subList2[si2] + '</option>';
            }
            elements.challengeSubFilter.innerHTML = htmlSub;
            elements.challengeSubFilter.disabled = false;
            if (prevS && (prevS === 'all' || subsMap2[prevS])) {
                elements.challengeSubFilter.value = prevS;
            } else {
                elements.challengeSubFilter.value = 'all';
            }
            challengeFilters.sub = elements.challengeSubFilter.value || 'all';
        }

        var html = '';
        for (var i = 0; i < allChallenges.length; i++) {
            var challenge = allChallenges[i];
            var chCat = challenge.category || inferChallengeCategory(challenge);
            var chSub = challenge.subCategory || inferChallengeSubCategory(challenge);
            if (challengeFilters.category !== 'all' && chCat !== challengeFilters.category) continue;
            if (challengeFilters.sub !== 'all' && chSub !== challengeFilters.sub) continue;

            var isCompleted = completedChallenges.indexOf(challenge.id) !== -1;
            var progress = HP.Challenges.checkChallengeProgress(challenge, state);
            var statusFilter = challengeFilters.status || 'all';
            if (statusFilter === 'completed' && !isCompleted) continue;
            if (statusFilter === 'in_progress' && (isCompleted || (progress.progress === 0))) continue;
            if (statusFilter === 'not_started' && (isCompleted || (progress.progress > 0))) continue;

            var cardClass = 'challenge-card';
            if (isCompleted) cardClass += ' completed';

            html += '<div class="' + cardClass + '">';
            html += '<div class="challenge-header">';
            html += '<div class="challenge-icon">' + challenge.icon + '</div>';
            html += '<div class="challenge-info">';
            html += '<div class="challenge-name">' + challenge.name + '</div>';
            html += '<div class="challenge-desc">' + challenge.description + '</div>';
            html += '<div class="achievement-meta">' + chCat + ' • ' + chSub + '</div>';
            html += '</div>';
            if (isCompleted) {
                html += '<div class="challenge-badge">✓</div>';
            }
            html += '</div>';
            
            html += '<div class="challenge-progress">';
            html += '<div class="progress-bar">';
            html += '<div class="progress-fill" style="width: ' + progress.percentage + '%"></div>';
            html += '</div>';
            if (challenge.type === HP.Challenges.CHALLENGE_TYPES.PLAY_TIME_SECONDS) {
                html += '<div class="progress-text">' + formatTimeForChallenge(progress.progress) + ' / ' + formatTimeForChallenge(progress.target) + '</div>';
            } else {
                html += '<div class="progress-text">' + progress.progress + ' / ' + progress.target + '</div>';
            }
            html += '</div>';

            if (isCompleted) {
                html += '<div class="challenge-reward completed">';
                html += 'Reward: +$' + challenge.reward.money + ' +' + challenge.reward.xp + ' XP';
                html += '</div>';
            } else {
                html += '<div class="challenge-reward">';
                html += 'Reward: +$' + challenge.reward.money + ' +' + challenge.reward.xp + ' XP';
                html += '</div>';
            }

            html += '</div>';
        }

        elements.challengesGrid.innerHTML = html;
    }

    function updateWorkersView() {
        if (!elements.workersHireGrid || !elements.workersAssignedList) return;

        var playerLevel = HP.State.getLevel();
        var money = HP.State.getMoney();
        var allWorkers = HP.Data.GrowerWorkers.getUnlocked(playerLevel);
        var assignedWorkers = HP.State.getGrowerWorkers();

        // Render hire section
        var hireHtml = '';
        if (allWorkers.length === 0) {
            hireHtml = '<div class="workers-unlock-hint">Level up to unlock more workers. Check back after gaining levels.</div>';
        } else {
            for (var i = 0; i < allWorkers.length; i++) {
                var workerType = allWorkers[i];
                var canAfford = money >= workerType.baseCost;
                
                hireHtml += '<div class="worker-hire-card">';
                hireHtml += '<div class="worker-icon">' + workerType.icon + '</div>';
                hireHtml += '<div class="worker-info">';
                hireHtml += '<div class="worker-name">' + workerType.name + '</div>';
                hireHtml += '<div class="worker-desc">' + workerType.description + '</div>';
                hireHtml += '<div class="worker-stats">';
                hireHtml += '<span>Efficiency: ' + (workerType.efficiency * 100) + '%</span>';
                hireHtml += '</div>';
                hireHtml += '</div>';
                hireHtml += '<div class="worker-cost">$' + HP.Helpers.formatNumber(workerType.baseCost) + '</div>';
                hireHtml += '<button class="btn-hire-worker" data-worker="' + workerType.id + '"' + 
                    (canAfford ? '' : ' disabled') + '>' + (canAfford ? 'Hire' : 'Need $' + workerType.baseCost) + '</button>';
                hireHtml += '</div>';
            }
        }
        elements.workersHireGrid.innerHTML = hireHtml;

        // Render assigned workers
        var assignedHtml = '';
        if (assignedWorkers.length === 0) {
            assignedHtml = '<div class="empty-state">No workers assigned. Hire a worker and assign them to a plot.</div>';
        } else {
            for (var i = 0; i < assignedWorkers.length; i++) {
                var worker = assignedWorkers[i];
                var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
                var plot = HP.State.getPlot(worker.assignedPlot.propertyId, worker.assignedPlot.plotIndex);
                var property = HP.Data.Properties.get(worker.assignedPlot.propertyId);
                
                var statusClass = worker.status === 'active' ? 'active' : 'paused';
                var statusText = worker.status === 'active' ? '✓ Working' : '⏸ Paused';
                
                assignedHtml += '<div class="worker-assigned-card ' + statusClass + '">';
                assignedHtml += '<div class="worker-assigned-header">';
                assignedHtml += '<div class="worker-assigned-info">';
                assignedHtml += '<span class="worker-icon-small">' + (workerType ? workerType.icon : '👷') + '</span>';
                assignedHtml += '<div>';
                assignedHtml += '<div class="worker-name">' + (workerType ? workerType.name : 'Worker') + '</div>';
                assignedHtml += '<div class="worker-location">' + (property ? property.icon + ' ' + property.name : 'Unknown') + ' - Plot ' + (worker.assignedPlot.plotIndex + 1) + '</div>';
                assignedHtml += '</div>';
                assignedHtml += '</div>';
                assignedHtml += '<div class="worker-status-badge ' + statusClass + '">' + statusText + '</div>';
                assignedHtml += '</div>';
                
                assignedHtml += '<div class="worker-config">';
                assignedHtml += '<div class="config-item">';
                assignedHtml += '<span class="config-label">Seed:</span>';
                var seedName = 'Auto';
                if (worker.config.seedId) {
                    var seed = HP.Data.Seeds.get(worker.config.seedId);
                    seedName = seed ? seed.name : worker.config.seedId;
                }
                assignedHtml += '<span class="config-value">' + seedName + '</span>';
                assignedHtml += '</div>';
                if (worker.config.soilId) {
                    var soil = HP.Data.Equipment.get(worker.config.soilId);
                    var soilName = soil ? soil.name : worker.config.soilId;
                    assignedHtml += '<div class="config-item">';
                    assignedHtml += '<span class="config-label">Soil:</span>';
                    assignedHtml += '<span class="config-value">' + soilName + '</span>';
                    assignedHtml += '</div>';
                }
                if (worker.config.fertilizerId) {
                    var fert = HP.Data.Equipment.get(worker.config.fertilizerId);
                    var fertName = fert ? fert.name : worker.config.fertilizerId;
                    assignedHtml += '<div class="config-item">';
                    assignedHtml += '<span class="config-label">Fertilizer:</span>';
                    assignedHtml += '<span class="config-value">' + fertName + '</span>';
                    assignedHtml += '</div>';
                }
                assignedHtml += '</div>';
                
                assignedHtml += '<div class="worker-actions">';
                assignedHtml += '<button class="btn-configure-worker" data-worker="' + worker.id + '">⚙️ Configure</button>';
                assignedHtml += '<button class="btn-remove-worker" data-worker="' + worker.id + '">🗑️ Remove</button>';
                assignedHtml += '</div>';
                assignedHtml += '</div>';
            }
        }
        elements.workersAssignedList.innerHTML = assignedHtml;
    }

    function updateStatsView() {
        var state = HP.State.getState();
        var stats = state.stats || {};
        var money = HP.State.getMoney();
        var heat = HP.State.getHeat();
        var level = HP.State.getLevel();
        var rank = HP.State.getRank();
        var properties = HP.State.getProperties();

        // Economy
        var el = document.getElementById('stat-total-earned');
        if (el) el.textContent = '$' + HP.Helpers.formatNumber(stats.totalMoneyEarned || 0);
        el = document.getElementById('stat-current-money');
        if (el) el.textContent = '$' + HP.Helpers.formatNumber(money);
        el = document.getElementById('stat-biggest-sale');
        if (el) el.textContent = '$' + HP.Helpers.formatNumber(stats.biggestSale || 0);
        el = document.getElementById('stat-total-sales');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.totalSold || 0) + 'g';

        // Growing
        el = document.getElementById('stat-plants-grown');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.plantsGrown || 0);
        el = document.getElementById('stat-plants-died');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.plantsDied || 0);
        el = document.getElementById('stat-best-harvest');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.bestHarvest || 0) + 'g';
        el = document.getElementById('stat-total-harvested');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.totalHarvested || 0) + 'g';

        // Quality breakdown
        var byQual = stats.harvestedByQuality || { low: 0, medium: 0, good: 0, premium: 0 };
        el = document.getElementById('stat-quality-low');
        if (el) el.textContent = HP.Helpers.formatNumber(byQual.low || 0) + 'g';
        el = document.getElementById('stat-quality-medium');
        if (el) el.textContent = HP.Helpers.formatNumber(byQual.medium || 0) + 'g';
        el = document.getElementById('stat-quality-good');
        if (el) el.textContent = HP.Helpers.formatNumber(byQual.good || 0) + 'g';
        el = document.getElementById('stat-quality-premium');
        if (el) el.textContent = HP.Helpers.formatNumber(byQual.premium || 0) + 'g';

        // Heat
        el = document.getElementById('stat-current-heat');
        if (el) el.textContent = Math.round(heat) + '%';
        el = document.getElementById('stat-raids-total');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.raidsTotal || 0);
        el = document.getElementById('stat-payoffs-total');
        if (el) el.textContent = HP.Helpers.formatNumber(stats.heatPayOffsTotal || 0);
        el = document.getElementById('stat-heat-reduction');
        if (el) {
            var heatMult = HP.Heat && HP.Heat.getHeatGainMultiplier ? HP.Heat.getHeatGainMultiplier() : 1;
            var reduction = Math.round((1 - heatMult) * 100);
            el.textContent = reduction + '%';
        }

        // Time
        el = document.getElementById('stat-play-time');
        if (el) {
            var seconds = Math.floor(stats.playTime || 0);
            var hours = Math.floor(seconds / 3600);
            var mins = Math.floor((seconds % 3600) / 60);
            el.textContent = hours > 0 ? hours + 'h ' + mins + 'm' : mins + 'm';
        }
        el = document.getElementById('stat-current-level');
        if (el) el.textContent = level;
        el = document.getElementById('stat-current-rank');
        if (el) el.textContent = rank;
        el = document.getElementById('stat-properties-owned');
        if (el) el.textContent = (properties.owned || []).length;
    }

    function updateGeneticsView() {
        updateBreedingSection();
        updateStrainLibrary();
    }

    function updateBreedingSection() {
        var parent1Select = document.getElementById('parent1-select');
        var parent2Select = document.getElementById('parent2-select');
        if (!parent1Select || !parent2Select) return;

        var inventory = HP.State.getInventory();
        var seeds = inventory.seeds || {};

        // Populate parent selects
        var html = '<option value="">Select seed...</option>';
        for (var seedId in seeds) {
            if (seeds[seedId] > 0) {
                var seed = HP.Data.Seeds.get(seedId);
                if (seed) {
                    html += '<option value="' + seedId + '">' + seed.icon + ' ' + seed.name + ' (' + seeds[seedId] + ')</option>';
                }
            }
        }
        parent1Select.innerHTML = html;
        parent2Select.innerHTML = html;

        updateParentInfo();
    }

    function updateParentInfo() {
        var parent1Select = document.getElementById('parent1-select');
        var parent2Select = document.getElementById('parent2-select');
        var parent1Info = document.getElementById('parent1-info');
        var parent2Info = document.getElementById('parent2-info');
        var breedBtn = document.getElementById('btn-breed');

        if (!parent1Select || !parent2Select || !parent1Info || !parent2Info || !breedBtn) return;

        var p1Id = parent1Select.value;
        var p2Id = parent2Select.value;

        // Update parent 1 info
        if (p1Id) {
            var p1 = HP.Data.Seeds.get(p1Id);
            if (p1) {
                parent1Info.innerHTML = renderParentTraits(p1);
            }
        } else {
            parent1Info.innerHTML = '<div style="color: var(--color-text-muted); text-align: center; padding: 20px;">Select a seed</div>';
        }

        // Update parent 2 info
        if (p2Id) {
            var p2 = HP.Data.Seeds.get(p2Id);
            if (p2) {
                parent2Info.innerHTML = renderParentTraits(p2);
            }
        } else {
            parent2Info.innerHTML = '<div style="color: var(--color-text-muted); text-align: center; padding: 20px;">Select a seed</div>';
        }

        // Enable breed button if both parents selected
        breedBtn.disabled = !(p1Id && p2Id && p1Id !== p2Id);
    }

    function renderParentTraits(seed) {
        var html = '<div style="font-weight: bold; margin-bottom: 4px; color: var(--color-primary);">' + seed.name + '</div>';
        html += '<div class="trait"><span>Growth:</span><span>' + seed.growthTime + 's</span></div>';
        html += '<div class="trait"><span>Yield:</span><span>' + seed.baseYield + 'g</span></div>';
        html += '<div class="trait"><span>Quality:</span><span>' + seed.quality + '</span></div>';
        html += '<div class="trait"><span>Water:</span><span>' + seed.waterConsumption + 'x</span></div>';
        html += '<div class="trait"><span>Q. Bias:</span><span>' + seed.qualityBias + '%</span></div>';
        return html;
    }

    function updateStrainLibrary() {
        var grid = document.getElementById('strain-library-grid');
        if (!grid) return;

        // Get filter/sort values
        var filterType = document.getElementById('library-filter-type');
        var filterQuality = document.getElementById('library-filter-quality');
        var sortBy = document.getElementById('library-sort-by');
        var searchInput = document.getElementById('library-search');

        var typeFilter = filterType ? filterType.value : 'all';
        var qualityFilterVal = filterQuality ? filterQuality.value : 'all';
        var sortValue = sortBy ? sortBy.value : 'quality-asc';
        var searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';

        var allSeeds = HP.Data.Seeds.getAll();
        var customStrains = HP.State.getCustomStrains();

        // Build array of all strains
        var strainsArray = [];

        // Add base strains
        if (typeFilter === 'all' || typeFilter === 'base') {
            for (var id in allSeeds) {
                var seed = allSeeds[id];
                if (!seed.isHybrid) {
                    strainsArray.push({ strain: seed, isHybrid: false });
                }
            }
        }

        // Add hybrids
        if (typeFilter === 'all' || typeFilter === 'hybrid') {
            for (var hybridId in customStrains) {
                strainsArray.push({ strain: customStrains[hybridId], isHybrid: true });
            }
        }

        // Apply quality filter
        if (qualityFilterVal !== 'all') {
            strainsArray = strainsArray.filter(function(item) {
                return item.strain.quality === qualityFilterVal;
            });
        }

        // Apply search filter
        if (searchTerm) {
            strainsArray = strainsArray.filter(function(item) {
                var s = item.strain;
                return s.name.toLowerCase().indexOf(searchTerm) !== -1 ||
                       (s.strainName && s.strainName.toLowerCase().indexOf(searchTerm) !== -1) ||
                       (s.description && s.description.toLowerCase().indexOf(searchTerm) !== -1);
            });
        }

        // Apply sorting
        strainsArray.sort(function(a, b) {
            var seedA = a.strain;
            var seedB = b.strain;
            
            switch(sortValue) {
                case 'quality-asc':
                    return qualityOrder[seedA.quality] - qualityOrder[seedB.quality];
                case 'quality-desc':
                    return qualityOrder[seedB.quality] - qualityOrder[seedA.quality];
                case 'yield-desc':
                    return seedB.baseYield - seedA.baseYield;
                case 'growth-asc':
                    return seedA.growthTime - seedB.growthTime;
                case 'bias-desc':
                    return seedB.qualityBias - seedA.qualityBias;
                case 'name-asc':
                    return seedA.name.localeCompare(seedB.name);
                default:
                    return qualityOrder[seedA.quality] - qualityOrder[seedB.quality];
            }
        });

        var html = '';
        
        if (strainsArray.length === 0) {
            html = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--color-text-muted);">No strains match your filters</div>';
        } else {
            for (var i = 0; i < strainsArray.length; i++) {
                html += renderStrainCard(strainsArray[i].strain, strainsArray[i].isHybrid);
            }
        }

        grid.innerHTML = html;
    }

    function renderStrainCard(seed, isHybrid) {
        var html = '<div class="strain-card' + (isHybrid ? ' hybrid' : '') + '">';
        html += '<div class="strain-header">';
        html += '<span class="strain-icon">' + seed.icon + '</span>';
        html += '<span class="strain-name">' + seed.name + '</span>';
        html += '</div>';
        html += '<div class="strain-desc">' + (seed.description || '') + '</div>';
        html += '<div class="strain-traits">';
        html += '<div>Growth: ' + seed.growthTime + 's</div>';
        html += '<div>Yield: ' + seed.baseYield + 'g</div>';
        html += '<div>Quality: ' + seed.quality + '</div>';
        html += '<div>Water: ' + seed.waterConsumption + 'x</div>';
        html += '<div>Q. Bias: ' + seed.qualityBias + '%</div>';
        html += '<div>Gen: ' + (seed.generation || 1) + '</div>';
        html += '</div>';
        
        if (isHybrid && seed.mutations && seed.mutations.length > 0) {
            html += '<div class="strain-mutations">';
            for (var i = 0; i < seed.mutations.length; i++) {
                var mutInfo = HP.Genetics.getMutationInfo(seed.mutations[i]);
                html += '<span class="mutation-badge" title="' + mutInfo.description + '">' + mutInfo.name + '</span>';
            }
            html += '</div>';
        }
        
        html += '</div>';
        return html;
    }

    function openWorkerAssignModal(workerTypeId) {
        if (!elements.workerAssignModal) return;

        // Populate plot selector
        var owned = HP.State.getOwnedProperties();
        var plotHtml = '<option value="">Select a plot...</option>';
        for (var i = 0; i < owned.length; i++) {
            var propId = owned[i];
            var property = HP.Data.Properties.get(propId);
            var plots = HP.State.getPlots(propId);
            for (var j = 0; j < plots.length; j++) {
                var hasWorker = HP.State.getWorkerByPlot(propId, j);
                if (!hasWorker) {
                    plotHtml += '<option value="' + propId + ':' + j + '">' + property.icon + ' ' + property.name + ' - Plot ' + (j + 1) + '</option>';
                }
            }
        }
        if (elements.workerPlotSelect) {
            elements.workerPlotSelect.innerHTML = plotHtml;
        }

        // Populate seed selector
        var inventory = HP.State.getInventory();
        var seedHtml = '<option value="">Auto (use best available)</option>';
        var allSeeds = HP.Data.Seeds.getAll();
        for (var seedId in allSeeds) {
            var seed = allSeeds[seedId];
            var hasSeed = (inventory.seeds[seedId] || 0) > 0;
            seedHtml += '<option value="' + seedId + '"' + (!hasSeed ? ' disabled' : '') + '>' + 
                seed.icon + ' ' + seed.name + (!hasSeed ? ' (none)' : '') + '</option>';
        }
        if (elements.workerSeedSelect) {
            elements.workerSeedSelect.innerHTML = seedHtml;
        }

        // Populate soil selector
        var soilHtml = '<option value="">None</option>';
        var allEquipment = HP.Data.Equipment.getAll();
        for (var equipId in allEquipment) {
            var equip = allEquipment[equipId];
            if (equip.slot === 'soil') {
                var hasEquip = (inventory.equipment[equipId] || 0) > 0;
                soilHtml += '<option value="' + equipId + '"' + (!hasEquip ? ' disabled' : '') + '>' + 
                    equip.icon + ' ' + equip.name + (!hasEquip ? ' (none)' : '') + '</option>';
            }
        }
        if (elements.workerSoilSelect) {
            elements.workerSoilSelect.innerHTML = soilHtml;
        }

        // Populate fertilizer selector
        var fertHtml = '<option value="">None</option>';
        for (var equipId in allEquipment) {
            var equip = allEquipment[equipId];
            if (equip.slot === 'fertilizer') {
                var hasEquip = (inventory.equipment[equipId] || 0) > 0;
                fertHtml += '<option value="' + equipId + '"' + (!hasEquip ? ' disabled' : '') + '>' + 
                    equip.icon + ' ' + equip.name + (!hasEquip ? ' (none)' : '') + '</option>';
            }
        }
        if (elements.workerFertilizerSelect) {
            elements.workerFertilizerSelect.innerHTML = fertHtml;
        }

        // Store worker type for assignment
        if (elements.workerAssignModal) {
            elements.workerAssignModal.setAttribute('data-worker-type', workerTypeId);
            elements.workerAssignModal.classList.remove('hidden');
            
            // Reset assign button
            var assignBtn = document.getElementById('btn-assign-worker');
            if (assignBtn) {
                assignBtn.textContent = 'Assign Worker';
                assignBtn.removeAttribute('data-update-worker');
            }
            
            // Enable plot select
            if (elements.workerPlotSelect) {
                elements.workerPlotSelect.disabled = false;
            }
        }
    }

    function closeWorkerAssignModal() {
        if (elements.workerAssignModal) {
            elements.workerAssignModal.classList.add('hidden');
        }
    }
})();
