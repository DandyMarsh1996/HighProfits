/**
 * HighProfits - Renderer Module
 * Handles all DOM updates. See docs/ARCHITECTURE.md for split guidelines.
 */
var HP = HP || {};

HP.Renderer = (function() {
    'use strict';

    // ========== SHARED STATE ==========
    var elements = {};
    var currentView = 'grow';
    var selectedPlot = null;
    var selectedPlots = []; // Array of {propertyId, plotIndex}
    var bulkSelectMode = false;
    var achievementFilters = { category: 'all', sub: 'all', status: 'all' };
    var challengeFilters = { category: 'all', sub: 'all', status: 'all' };
    var _views = {};

    function toggleBulkSelectMode() {
        bulkSelectMode = !bulkSelectMode;
        var panel = document.getElementById('bulk-actions-panel');
        var btn = document.getElementById('btn-select-mode');
        
        if (bulkSelectMode) {
            if (panel) panel.classList.remove('hidden');
            if (btn) {
                btn.classList.add('active');
                btn.textContent = '✓ Selection Mode';
            }
        } else {
            if (panel) panel.classList.add('hidden');
            if (btn) {
                btn.classList.remove('active');
                btn.textContent = '📋 Select Mode';
            }
            selectedPlots = [];
            updateBulkSelection();
        }
        updatePlotsGrid();
    }

    function togglePlotSelection(propertyId, plotIndex) {
        if (!bulkSelectMode) return;

        var index = selectedPlots.findIndex(function(p) {
            return p.propertyId === propertyId && p.plotIndex === plotIndex;
        });

        if (index > -1) {
            selectedPlots.splice(index, 1);
        } else {
            selectedPlots.push({propertyId: propertyId, plotIndex: plotIndex});
        }

        updateBulkSelection();
        updatePlotsGrid();
    }

    function clearSelection() {
        selectedPlots = [];
        updateBulkSelection();
        updatePlotsGrid();
    }

    function updateBulkSelection() {
        var countEl = document.getElementById('selected-count');
        if (countEl) {
            countEl.textContent = selectedPlots.length + ' plot' + (selectedPlots.length !== 1 ? 's' : '') + ' selected';
        }
    }

    function isPlotSelected(propertyId, plotIndex) {
        return selectedPlots.some(function(p) {
            return p.propertyId === propertyId && p.plotIndex === plotIndex;
        });
    }

    // ========== INIT & ELEMENT REFS ==========
    function init() {
        // Top bar
        elements.moneyAmount = document.getElementById('money-amount');
        elements.moneyCashAmount = document.getElementById('money-cash-amount');
        elements.moneyBankAmount = document.getElementById('money-bank-amount');
        elements.playerNameTitle = document.getElementById('player-name-title');
        elements.playerLevel = document.getElementById('player-level');
        elements.heatBar = document.getElementById('heat-bar');
        elements.heatText = document.getElementById('heat-text');
        elements.heatReduceBtn = document.getElementById('heat-reduce-btn');
        elements.heatReducePanel = document.getElementById('heat-reduce-panel');
        elements.heatCostBribe = document.getElementById('heat-cost-bribe');
        elements.heatCostHide = document.getElementById('heat-cost-hide');
        elements.heatCostCleaners = document.getElementById('heat-cost-cleaners');
        elements.heatRaidWarning = document.getElementById('heat-raid-warning');
        elements.xpBar = document.getElementById('xp-bar');
        elements.currentXP = document.getElementById('current-xp');
        elements.xpToNext = document.getElementById('xp-to-next');
        elements.eventIndicator = document.getElementById('event-indicator');
        elements.eventIndicatorIcon = document.getElementById('event-indicator-icon');
        elements.eventIndicatorName = document.getElementById('event-indicator-name');
        elements.eventIndicatorTimer = document.getElementById('event-indicator-timer');

        // Grow view
        elements.propertySelect = document.getElementById('property-select');
        elements.plotsGrid = document.getElementById('plots-grid');
        elements.selectedPlotNum = document.getElementById('selected-plot-num');
        elements.plotStatusBadge = document.getElementById('plot-status-badge');
        elements.plotEquipment = document.getElementById('plot-equipment');
        elements.plotButtons = document.getElementById('plot-buttons');
        
        // Room upgrades
        elements.roomGrowthBonus = document.getElementById('room-growth-bonus');
        elements.roomYieldBonus = document.getElementById('room-yield-bonus');
        elements.roomQualityBonus = document.getElementById('room-quality-bonus');
        elements.waterCurrent = document.getElementById('water-current');
        elements.waterCapacity = document.getElementById('water-capacity');
        elements.waterRefillProgress = document.getElementById('water-refill-progress');
        elements.waterNextCharge = document.getElementById('water-next-charge');
        elements.roomUpgradesPanel = document.getElementById('room-upgrades-panel');
        elements.roomUpgradesContent = document.getElementById('room-upgrades-content');

        // Inventory view
        elements.invWeedLow = document.getElementById('inv-weed-low');
        elements.invWeedMedium = document.getElementById('inv-weed-medium');
        elements.invWeedGood = document.getElementById('inv-weed-good');
        elements.invWeedPremium = document.getElementById('inv-weed-premium');
        elements.seedsInventory = document.getElementById('seeds-inventory');
        elements.equipmentInventory = document.getElementById('equipment-inventory');

        // Store views
        elements.hardwareItems = document.getElementById('hardware-items');
        elements.gardenItems = document.getElementById('garden-items');
        elements.dealerItems = document.getElementById('dealer-items');
        elements.propertyItems = document.getElementById('property-items');
        elements.businessItems = document.getElementById('business-items');

        // Market view
        elements.ordersList = document.getElementById('orders-list');
        elements.ordersCount = document.getElementById('orders-count');
        elements.ordersEmpty = document.getElementById('orders-empty');
        elements.sellStockLow = document.getElementById('sell-stock-low');
        elements.sellStockMedium = document.getElementById('sell-stock-medium');
        elements.sellStockGood = document.getElementById('sell-stock-good');
        elements.sellStockPremium = document.getElementById('sell-stock-premium');
        elements.customersGrid = document.getElementById('customers-grid');
        elements.saleModal = document.getElementById('sale-modal');
        elements.sellTotal = document.getElementById('sell-total');
        elements.salePricePerGram = document.getElementById('sale-price-per-gram');
        elements.saleBonus = document.getElementById('sale-bonus');
        elements.saleCustomerRep = document.getElementById('sale-customer-rep');
        elements.saleDealEffect = document.getElementById('sale-deal-effect');

        // Achievements view
        elements.achievementsGrid = document.getElementById('achievements-grid');
        elements.achievementsUnlocked = document.getElementById('achievements-unlocked');
        elements.achievementsTotal = document.getElementById('achievements-total');
        elements.achievementsProgress = document.getElementById('achievements-progress');
        elements.achievementStatusFilter = document.getElementById('achievement-status-filter');
        elements.achievementCategoryFilter = document.getElementById('achievement-category-filter');
        elements.achievementSubFilter = document.getElementById('achievement-sub-filter');

        // Challenges view
        elements.challengesGrid = document.getElementById('challenges-grid');
        elements.challengeStatusFilter = document.getElementById('challenge-status-filter');
        elements.challengeCategoryFilter = document.getElementById('challenge-category-filter');
        elements.challengeSubFilter = document.getElementById('challenge-sub-filter');

        // Workers view
        elements.workersHireGrid = document.getElementById('workers-hire-grid');
        elements.workersAssignedList = document.getElementById('workers-assigned-list');
        elements.workerAssignModal = document.getElementById('worker-assign-modal');
        elements.workerPlotSelect = document.getElementById('worker-plot-select');
        elements.workerSeedSelect = document.getElementById('worker-seed-select');
        elements.workerSoilSelect = document.getElementById('worker-soil-select');
        elements.workerFertilizerSelect = document.getElementById('worker-fertilizer-select');

        console.log('[Renderer] Initialized');
    }

    // ========== SWITCH VIEW & UPDATE LOOP ==========
    function switchView(viewName) {
        var views = document.querySelectorAll('.content-view');
        views.forEach(function(view) {
            view.classList.remove('active');
        });

        var targetView = document.getElementById('view-' + viewName);
        if (targetView) {
            targetView.classList.add('active');
            currentView = viewName;
        }

        var navBtns = document.querySelectorAll('.nav-btn');
        navBtns.forEach(function(btn) {
            btn.classList.remove('active');
            if (btn.getAttribute('data-view') === viewName) {
                btn.classList.add('active');
            }
        });

        update();
    }

    function buildCtx(viewName) {
        var ctx = {
            elements: elements,
            achievementFilters: achievementFilters,
            challengeFilters: challengeFilters,
            qualityOrder: qualityOrder
        };
        if (viewName === 'grow') {
            ctx.updatePropertySelector = updatePropertySelector;
            ctx.updatePlotsGrid = updatePlotsGrid;
            ctx.updatePlotActions = updatePlotActions;
            ctx.updateRoomUpgradesPanel = updateRoomUpgradesPanel;
            ctx.refreshWorkersView = function() {
                if (_views.workers && _views.workers.update) _views.workers.update(buildCtx('workers'));
            };
        }
        if (viewName === 'hardware' || viewName === 'garden' || viewName === 'dealer' || viewName === 'realestate') {
            ctx.storeType = viewName;
        }
        return ctx;
    }

    function update() {
        try {
            updateTopBar();

            switch (currentView) {
            case 'grow':
            case 'inventory':
            case 'market':
            case 'hardware':
            case 'garden':
            case 'dealer':
            case 'realestate':
            case 'achievements':
            case 'challenges':
            case 'workers':
            case 'stats':
            case 'journal':
            case 'genetics':
            case 'settings':
                if (_views[currentView] && _views[currentView].update) {
                    _views[currentView].update(buildCtx(currentView));
                }
                break;
        }
        } catch (err) {
            console.error('[Renderer] Update error:', err);
            if (HP.ErrorHandler && HP.ErrorHandler.show) HP.ErrorHandler.show('Display error. Try refreshing.');
        }
    }

    function updateAfterSale() {
        updateTopBar();
        if (_views.market && _views.market.update) {
            _views.market.update(buildCtx('market'));
        }
    }

    function updateAfterHarvest() {
        updateTopBar();
        updatePlotsGrid();
        updatePlotActions();
    }

    function updateTopBar() {
        var cash = HP.State.getCash ? HP.State.getCash() : HP.State.getMoney();
        var bank = HP.State.getBank ? HP.State.getBank() : 0;
        var money = cash + bank;
        var xp = HP.State.getXP();
        var level = HP.State.getLevel();
        var charName = HP.State.getCharacterName ? HP.State.getCharacterName() : 'Player';
        var titleId = HP.State.getSelectedTitleId ? HP.State.getSelectedTitleId() : 'street_hustler';
        var title = HP.Data.Titles && HP.Data.Titles.get ? HP.Data.Titles.get(titleId) : null;
        var titleName = title ? title.name : 'Street Hustler';

        if (elements.moneyAmount) elements.moneyAmount.textContent = HP.Helpers.formatNumber(Math.floor(money));
        if (elements.moneyCashAmount) elements.moneyCashAmount.textContent = HP.Helpers.formatNumber(Math.floor(cash));
        if (elements.moneyBankAmount) elements.moneyBankAmount.textContent = HP.Helpers.formatNumber(Math.floor(bank));
        if (elements.playerNameTitle) elements.playerNameTitle.textContent = charName + ' · ' + titleName;
        if (elements.playerLevel) elements.playerLevel.textContent = level;

        var nextRank = HP.Data.Ranks.getNext(level);
        if (nextRank && elements.xpBar) {
            var currentRank = HP.Data.Ranks.getByLevel(level);
            var xpProgress = xp - currentRank.xpRequired;
            var xpNeeded = nextRank.xpRequired - currentRank.xpRequired;
            var percentage = Math.min((xpProgress / xpNeeded) * 100, 100);
            elements.xpBar.style.width = percentage + '%';

            if (elements.currentXP) elements.currentXP.textContent = Math.floor(xp);
            if (elements.xpToNext) elements.xpToNext.textContent = nextRank.xpRequired;
        }

        updateHeatDisplay();
        updateEventIndicator();
    }

    function updateEventIndicator() {
        var container = elements.eventIndicator;
        var iconEl = elements.eventIndicatorIcon;
        var nameEl = elements.eventIndicatorName;
        var timerEl = elements.eventIndicatorTimer;
        if (!container || !iconEl || !nameEl || !timerEl) return;

        var activeEvent = HP.Events && HP.Events.Manager ? HP.Events.Manager.getActiveEvent() : null;
        if (!activeEvent) {
            container.classList.add('hidden');
            return;
        }

        var def = activeEvent.definition;
        container.classList.remove('hidden');
        iconEl.textContent = def.icon || '📰';
        nameEl.textContent = def.name || 'Event';
        var remaining = HP.Events.Manager.getTimeRemaining ? HP.Events.Manager.getTimeRemaining() : 0;
        var mins = Math.floor(remaining / 60);
        var secs = Math.floor(remaining % 60);
        timerEl.textContent = mins + ':' + (secs < 10 ? '0' : '') + secs;
        container.setAttribute('data-tooltip', def.description || '');
    }

    // ========== TOP BAR & HEAT ==========
    function updateHeatDisplay() {
        if (!elements.heatBar && !elements.heatText) return;
        var heat = HP.State && HP.State.getHeat ? HP.State.getHeat() : 0;
        var maxHeat = (HP.State && HP.State.getState && HP.State.getState().heat) ? HP.State.getState().heat.maxLevel : 100;
        var pct = Math.min(100, Math.round((heat / maxHeat) * 100));
        if (elements.heatBar) {
            elements.heatBar.style.width = pct + '%';
            var cat = HP.Heat && HP.Heat.getHeatCategory ? HP.Heat.getHeatCategory(heat) : null;
            elements.heatBar.style.backgroundColor = cat && cat.color ? cat.color : '#ff6600';
            if (pct >= 80) {
                elements.heatBar.classList.add('heat-bar-high');
            } else {
                elements.heatBar.classList.remove('heat-bar-high');
            }
        }
        if (elements.heatText) elements.heatText.textContent = pct + '%';
        if (elements.heatRaidWarning) {
            if (pct >= 80) {
                elements.heatRaidWarning.classList.remove('hidden');
            } else {
                elements.heatRaidWarning.classList.add('hidden');
            }
        }
        if (elements.heatReducePanel && !elements.heatReducePanel.classList.contains('hidden')) {
            var cash = HP.State.getCash ? HP.State.getCash() : HP.State.getMoney();
            var payOffCount = HP.State.getHeatPayOffCount ? HP.State.getHeatPayOffCount() : 0;
            var options = HP.Heat && HP.Heat.getReductionOptions ? HP.Heat.getReductionOptions(cash, payOffCount) : [];
            for (var i = 0; i < options.length; i++) {
                var opt = options[i];
                var costEl = opt.id === 'bribe' ? elements.heatCostBribe : (opt.id === 'hide' ? elements.heatCostHide : elements.heatCostCleaners);
                if (costEl) costEl.textContent = HP.Helpers.formatNumber(opt.cost);
                var btn = elements.heatReducePanel && elements.heatReducePanel.querySelector('.heat-payoff-btn[data-action="' + opt.id + '"]');
                if (btn) {
                    btn.classList.toggle('disabled', !opt.canAfford);
                    btn.disabled = !opt.canAfford;
                    var wrap = document.getElementById('heat-payoff-wrap-' + opt.id);
                    if (wrap) {
                        if (opt.canAfford) {
                            wrap.removeAttribute('data-tooltip');
                        } else {
                            wrap.setAttribute('data-tooltip', 'Need $' + HP.Helpers.formatNumber(opt.cost) + ' more (use cash)');
                        }
                    }
                }
            }
        }
    }

    // Grow view: room bonuses moved to js/ui/views/growView.js; plot/room helpers stay here for updateAfterHarvest and toggleRoomUpgradesPanel

    function updateRoomUpgradesPanel() {
        if (!elements.roomUpgradesContent) return;

        var propertyId = elements.propertySelect ? elements.propertySelect.value : null;
        if (!propertyId) return;

        var playerLevel = HP.State.getLevel();
        var money = HP.State.getBank ? HP.State.getBank() : HP.State.getMoney();
        var installedUpgrades = HP.State.getRoomUpgrades(propertyId);
        var categories = HP.Data.RoomUpgrades.getCategories();

        elements.roomUpgradesContent.innerHTML = HP.RendererHelpers.RoomUpgradesRender.renderPanelHtml(
            propertyId, playerLevel, money, installedUpgrades, categories
        );
        bindRoomUpgradeButtons();
    }

    function bindRoomUpgradeButtons() {
        var propertyId = elements.propertySelect ? elements.propertySelect.value : null;
        if (!propertyId) return;

        document.querySelectorAll('.buy-upgrade').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                HP.Events.buyRoomUpgrade(propertyId, this.getAttribute('data-upgrade'));
            });
        });

        document.querySelectorAll('.sell-upgrade').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                HP.Events.sellRoomUpgrade(propertyId, this.getAttribute('data-upgrade'));
            });
        });
    }

    function toggleRoomUpgradesPanel(show) {
        if (elements.roomUpgradesPanel) {
            if (show) {
                elements.roomUpgradesPanel.classList.remove('hidden');
                updateRoomUpgradesPanel();
            } else {
                elements.roomUpgradesPanel.classList.add('hidden');
            }
        }
    }

    function updatePropertySelector() {
        if (!elements.propertySelect) return;

        var owned = HP.State.getOwnedProperties();
        var currentValue = elements.propertySelect.value;

        elements.propertySelect.innerHTML = '';

        for (var i = 0; i < owned.length; i++) {
            var propId = owned[i];
            var prop = HP.Data.Properties.get(propId);
            var option = document.createElement('option');
            option.value = propId;
            option.textContent = prop.icon + ' ' + prop.name + ' (' + prop.plotCapacity + ' plots)';
            elements.propertySelect.appendChild(option);
        }

        if (currentValue && owned.indexOf(currentValue) !== -1) {
            elements.propertySelect.value = currentValue;
        }
    }

    var lastRenderedPropertyId = null;
    var lastRenderedPlotCount = 0;
    var plotsGridEventsBound = false;

    function updatePlotsGrid() {
        if (!elements.plotsGrid || !elements.propertySelect) return;

        var propertyId = elements.propertySelect.value;
        var plots = HP.State.getPlots(propertyId);

        // Bind event delegation once (handles all plot clicks)
        if (!plotsGridEventsBound) {
            elements.plotsGrid.addEventListener('click', function(e) {
                var card = e.target.closest('.plot-card');
                if (!card) return;
                var propId = card.getAttribute('data-property');
                var idx = parseInt(card.getAttribute('data-index'), 10);
                if (bulkSelectMode) {
                    togglePlotSelection(propId, idx);
                } else {
                    selectPlot(propId, idx);
                }
            });
            plotsGridEventsBound = true;
        }

        // Check if we need a full rebuild (property changed or plot count changed)
        var existingCards = elements.plotsGrid.querySelectorAll('.plot-card');
        var needsFullRebuild = propertyId !== lastRenderedPropertyId || plots.length !== existingCards.length;

        if (needsFullRebuild) {
            // Full rebuild - create all new HTML
            var html = '';
            var plotOpts = { selectedPlot: selectedPlot, bulkSelectMode: bulkSelectMode, isPlotSelected: isPlotSelected };
            for (var i = 0; i < plots.length; i++) {
                html += HP.RendererHelpers.PlotRender.buildPlotCard(propertyId, i, plots[i], plotOpts);
            }
            elements.plotsGrid.innerHTML = html;
            lastRenderedPropertyId = propertyId;
            lastRenderedPlotCount = plots.length;
        } else {
            // Incremental update - update each card in-place
            for (var j = 0; j < plots.length; j++) {
                updatePlotCardInPlace(existingCards[j], propertyId, j, plots[j]);
            }
        }
    }

    function updatePlotCardInPlace(card, propertyId, index, plot) {
        // Update classes
        var isSelected = selectedPlot && selectedPlot.propertyId === propertyId && selectedPlot.plotIndex === index;
        var isBulkSelected = isPlotSelected(propertyId, index);
        var assignedWorker = HP.State.getWorkerByPlot(propertyId, index);

        // Remove all status classes, then add current ones
        card.className = 'plot-card ' + plot.status;
        if (isSelected && !bulkSelectMode) card.classList.add('selected');
        if (isBulkSelected) card.classList.add('bulk-selected');
        if (bulkSelectMode) card.classList.add('selectable');
        if (assignedWorker) card.classList.add('has-worker');

        // Update bulk checkbox if in bulk mode
        var checkboxEl = card.querySelector('.bulk-checkbox');
        if (bulkSelectMode) {
            if (!checkboxEl) {
                checkboxEl = document.createElement('div');
                checkboxEl.className = 'bulk-checkbox';
                card.insertBefore(checkboxEl, card.firstChild);
            }
            checkboxEl.textContent = isBulkSelected ? '✓' : '☐';
        } else if (checkboxEl) {
            checkboxEl.remove();
        }

        // Update worker badge
        var workerBadge = card.querySelector('.plot-worker-badge');
        if (assignedWorker) {
            var workerType = HP.Data.GrowerWorkers.get(assignedWorker.workerTypeId);
            if (!workerBadge) {
                workerBadge = document.createElement('div');
                workerBadge.className = 'plot-worker-badge';
                var plotNum = card.querySelector('.plot-number');
                if (plotNum) card.insertBefore(workerBadge, plotNum);
                else card.appendChild(workerBadge);
            }
            workerBadge.title = 'Worker assigned: ' + (workerType ? workerType.name : 'Worker');
            workerBadge.textContent = '👷';
        } else if (workerBadge) {
            workerBadge.remove();
        }

        // Update plot content (only the inner content part)
        var contentEl = card.querySelector('.plot-content');
        if (!contentEl) {
            contentEl = document.createElement('div');
            contentEl.className = 'plot-content';
            card.appendChild(contentEl);
        }
        contentEl.innerHTML = HP.RendererHelpers.PlotRender.renderPlotContent(plot);
    }

    function selectPlot(propertyId, plotIndex) {
        selectedPlot = { propertyId: propertyId, plotIndex: plotIndex };
        updatePlotsGrid();
        updatePlotActions();
    }

    function updatePlotActions() {
        if (!selectedPlot) {
            if (elements.selectedPlotNum) elements.selectedPlotNum.textContent = '-';
            if (elements.plotStatusBadge) {
                elements.plotStatusBadge.textContent = 'Select a plot';
                elements.plotStatusBadge.className = 'status-badge';
            }
            if (elements.plotEquipment) elements.plotEquipment.innerHTML = '';
            if (elements.plotButtons) elements.plotButtons.innerHTML = '';
            return;
        }

        var plot = HP.State.getPlot(selectedPlot.propertyId, selectedPlot.plotIndex);
        if (!plot) return;

        if (elements.selectedPlotNum) {
            elements.selectedPlotNum.textContent = selectedPlot.plotIndex + 1;
        }

        // Status badge
        if (elements.plotStatusBadge) {
            var statusText = plot.status.charAt(0).toUpperCase() + plot.status.slice(1);
            if (plot.plant) {
                var seed = HP.Data.Seeds.get(plot.plant.seedId);
                statusText = seed.name;
                if (!plot.plant.isHydrated && plot.status === 'growing') {
                    statusText += ' - NEEDS WATER';
                }
            }
            elements.plotStatusBadge.textContent = statusText;
            elements.plotStatusBadge.className = 'status-badge ' + plot.status;
        }

        // Equipment list
        if (elements.plotEquipment) {
            var equipHtml = '';
            var hasEquip = false;
            for (var slot in plot.equipment) {
                if (plot.equipment[slot]) {
                    var slotValue = plot.equipment[slot];
                    var equipId = (typeof slotValue === 'string') ? slotValue : (slotValue && slotValue.id ? slotValue.id : null);
                    var equip = equipId ? HP.Data.Equipment.get(equipId) : null;
                    if (equip) {
                        var usesLeft = (slotValue && typeof slotValue === 'object' && typeof slotValue.usesLeft === 'number') ? slotValue.usesLeft : null;
                        var usesText = (equip.consumable && typeof usesLeft === 'number') ? (' <span class="equip-uses">(' + usesLeft + ' use' + (usesLeft !== 1 ? 's' : '') + ' left)</span>') : '';
                        equipHtml += '<span class="equip-tag">' + equip.icon + ' ' + equip.name + usesText + '</span>';
                    }
                    hasEquip = true;
                }
            }
            elements.plotEquipment.innerHTML = hasEquip ? equipHtml : '<span class="empty-state">No equipment</span>';
        }

        // Action buttons
        if (elements.plotButtons) {
            var buttonsHtml = '';
            var inventory = HP.State.getInventory();

            if (plot.status === 'growing' || plot.status === 'harvest') {
                // Show planted seed in locked-in style (same as equipment)
                if (plot.plant) {
                    var plantedSeed = HP.Data.Seeds.get(plot.plant.seedId);
                    if (plantedSeed) {
                        buttonsHtml += '<div class="action-divider">🌱 Planted</div>';
                        buttonsHtml += '<div class="installed-equip">';
                        buttonsHtml += '<span class="current-equip">✓ ' + plantedSeed.icon + ' ' + plantedSeed.name + '</span>';
                        buttonsHtml += '</div>';
                    }
                }
            }

            if (plot.status === 'growing') {
                // Show water button and watering can options
                buttonsHtml += '<div class="action-divider">💧 Water Plant</div>';
                buttonsHtml += HP.RendererHelpers.PlotRender.renderWateringButtons(inventory);
            } else if (plot.status === 'empty' || plot.status === 'setup') {
                // Equipment installation
                var renderEquip = HP.RendererHelpers.PlotRender.renderEquipmentSection;
                buttonsHtml += renderEquip(inventory, plot, 'pot', '🪴 Pots', 'garden', 'Garden Centre');
                buttonsHtml += renderEquip(inventory, plot, 'soil', '🟫 Soil', 'garden', 'Garden Centre');
                buttonsHtml += renderEquip(inventory, plot, 'light', '💡 Lights', 'hardware', 'Hardware Store');
                buttonsHtml += renderEquip(inventory, plot, 'fan', '🌀 Ventilation', 'hardware', 'Hardware Store');
                buttonsHtml += renderEquip(inventory, plot, 'fertilizer', '🧪 Fertilizer', 'garden', 'Garden Centre');

                // Planting (only if ready)
                if (plot.status === 'setup') {
                    buttonsHtml += '<div class="action-divider">🌱 Plant Seeds</div>';
                    var hasSeeds = false;
                    for (var seedId in inventory.seeds) {
                        if (inventory.seeds[seedId] > 0) {
                            var seed = HP.Data.Seeds.get(seedId);
                            buttonsHtml += '<button type="button" class="action-btn plant-seed" data-property="' + selectedPlot.propertyId + '" data-plot-index="' + selectedPlot.plotIndex + '" data-seed="' + seedId + '">' +
                                seed.icon + ' ' + seed.name + ' (' + inventory.seeds[seedId] + ')</button>';
                            hasSeeds = true;
                        }
                    }
                    if (!hasSeeds) {
                        buttonsHtml += '<span class="empty-hint">Buy seeds from Seed Dealer</span>';
                        buttonsHtml += '<button type="button" class="action-btn go-to-store-btn" data-view="dealer" data-context="plot">Go to Seed Dealer</button>';
                    }
                }
            } else if (plot.status === 'harvest') {
                buttonsHtml += '<button type="button" class="action-btn harvest-btn" data-property="' + selectedPlot.propertyId + '" data-plot-index="' + selectedPlot.plotIndex + '">🌿 Harvest Plant</button>';
            } else if (plot.status === 'dead') {
                buttonsHtml += '<button type="button" class="action-btn btn-clear-dead" data-property="' + selectedPlot.propertyId + '" data-plot-index="' + selectedPlot.plotIndex + '">🗑️ Clear Dead Plant</button>';
            }

            elements.plotButtons.innerHTML = buttonsHtml;
            // Plot action clicks handled by event delegation in events.js
        }
    }

    // Quality order for sorting (used by buildCtx and dealer view)
    var qualityOrder = { low: 1, medium: 2, good: 3, premium: 4 };

    var selectedCustomer = null;

    function setAndDisplayRequest(customer, request) {
        if (!customer.currentRequest) customer.currentRequest = {};
        customer.currentRequest.quality = request.quality;
        customer.currentRequest.amount = request.amount;
        var qualityEl = document.getElementById('request-quality');
        var amountEl = document.getElementById('request-amount');
        if (qualityEl) qualityEl.textContent = request.quality.charAt(0).toUpperCase() + request.quality.slice(1);
        if (amountEl) amountEl.textContent = request.amount + 'g';
    }

    // ========== SALE MODAL ==========
    function openSaleModal(customerId) {
        var customer = HP.Data.Customers.get(customerId);
        if (!customer) return;

        selectedCustomer = customerId;

        document.getElementById('modal-customer-icon').textContent = customer.icon;
        document.getElementById('modal-customer-name').textContent = customer.name;
        document.getElementById('modal-customer-desc').textContent = customer.description;

        var request = HP.RendererHelpers.SaleModal.generateCustomerRequest(customer, true);
        setAndDisplayRequest(customer, request);

        if (elements.saleModal) {
            elements.saleModal.classList.remove('hidden');
            requestAnimationFrame(function() {
                var btn = document.getElementById('btn-close-sale');
                if (btn) btn.focus();
            });
        }

        updateSellTotal();
    }

    function regenerateCustomerRequest() {
        if (!selectedCustomer) return;
        var customer = HP.Data.Customers.get(selectedCustomer);
        if (!customer) return;
        var request = HP.RendererHelpers.SaleModal.generateCustomerRequest(customer, true);
        setAndDisplayRequest(customer, request);
        updateSellTotal();
    }

    function closeSaleModal() {
        selectedCustomer = null;
        if (elements.saleModal) {
            elements.saleModal.classList.add('hidden');
        }
    }

    function showRaidModal(raidResult) {
        var msgEl = document.getElementById('raid-message');
        var modalEl = document.getElementById('raid-modal');
        if (!msgEl || !modalEl) return;
        var moneyLost = raidResult.moneyLost || 0;
        var productLost = raidResult.productLost || { low: 0, medium: 0, good: 0, premium: 0 };
        var totalProduct = (productLost.low || 0) + (productLost.medium || 0) + (productLost.good || 0) + (productLost.premium || 0);
        var constants = HP.Data.Constants || {};
        var moneyPct = (constants.RAID_MONEY_LOSS_PERCENT != null) ? constants.RAID_MONEY_LOSS_PERCENT : 25;
        var productPct = (constants.RAID_PRODUCT_LOSS_PERCENT != null) ? constants.RAID_PRODUCT_LOSS_PERCENT : 30;
        msgEl.textContent = 'Law enforcement hit your operation. You lost $' + HP.Helpers.formatNumber(moneyLost) + ' (' + moneyPct + '% of cash) and ' + HP.Helpers.formatNumber(totalProduct) + 'g product (' + productPct + '%). Heat has been reset.';
        modalEl.classList.remove('hidden');
    }

    function closeRaidModal() {
        var modalEl = document.getElementById('raid-modal');
        if (modalEl) modalEl.classList.add('hidden');
    }

    function updateSellTotal() {
        if (!elements.sellTotal) return;
        if (!selectedCustomer) return;

        var customer = HP.Data.Customers.get(selectedCustomer);
        if (!customer || !customer.currentRequest) return;

        var quality = customer.currentRequest.quality;
        var amount = customer.currentRequest.amount;
        var available = HP.State.getWeed(quality);

        // Check if player has enough stock
        var sellBtn = document.getElementById('btn-sell');
        var statusEl = document.getElementById('sale-status');
        
        if (available < amount) {
            if (elements.salePricePerGram) elements.salePricePerGram.textContent = '$0.00';
            if (elements.sellTotal) elements.sellTotal.textContent = '$0';
            if (sellBtn) sellBtn.disabled = true;
            if (statusEl) {
                statusEl.textContent = '❌ Not enough stock! You have ' + available + 'g, but customer wants ' + amount + 'g.';
                statusEl.className = 'sale-status error';
            }
            return;
        }

        var priceInfo = HP.Data.Customers.calculatePrice(selectedCustomer, quality, amount);
        if (!priceInfo) {
            if (elements.salePricePerGram) elements.salePricePerGram.textContent = '$0.00';
            if (elements.sellTotal) elements.sellTotal.textContent = '$0';
            if (sellBtn) sellBtn.disabled = true;
            if (elements.saleCustomerRep) elements.saleCustomerRep.textContent = '0';
            if (elements.saleDealEffect) elements.saleDealEffect.textContent = '';
            return;
        }

        var rep = HP.State && HP.State.getCustomerReputation ? HP.State.getCustomerReputation(selectedCustomer) : 0;
        if (elements.saleCustomerRep) elements.saleCustomerRep.textContent = rep;

        var dealEl = document.querySelector('.deal-type-btn.selected');
        var dealType = (dealEl && dealEl.getAttribute('data-deal')) || 'normal';
        var constants = HP.Data.Constants || {};
        var discountMult = constants.REP_DEAL_DISCOUNT_PRICE_MULT != null ? constants.REP_DEAL_DISCOUNT_PRICE_MULT : 0.85;
        var overchargeMult = constants.REP_DEAL_OVERCHARGE_PRICE_MULT != null ? constants.REP_DEAL_OVERCHARGE_PRICE_MULT : 1.20;
        var displayTotal = priceInfo.total;
        var dealEffectText = '';
        if (dealType === 'discount') {
            displayTotal = Math.floor(priceInfo.total * discountMult);
            dealEffectText = '15% discount applied. Reputation: +3';
        } else if (dealType === 'overcharge') {
            displayTotal = Math.floor(priceInfo.total * overchargeMult);
            dealEffectText = '20% overcharge. Reputation: -2';
        } else {
            dealEffectText = 'Reputation: +1';
        }

        if (elements.salePricePerGram) {
            elements.salePricePerGram.textContent = '$' + priceInfo.pricePerGram.toFixed(2);
        }

        if (elements.saleBonus) {
            var bonusPercent = Math.round((priceInfo.multiplier - 1) * 100);
            if (bonusPercent > 0) {
                elements.saleBonus.textContent = '+' + bonusPercent + '%';
                elements.saleBonus.style.color = '#00ff88';
            } else if (bonusPercent < 0) {
                elements.saleBonus.textContent = bonusPercent + '%';
                elements.saleBonus.style.color = '#ff6b6b';
            } else {
                elements.saleBonus.textContent = '0%';
                elements.saleBonus.style.color = '#888';
            }
        }

        var repBonusRow = document.getElementById('rep-bonus-row');
        var saleRepBonus = document.getElementById('sale-rep-bonus');
        if (priceInfo.reputationBonus && priceInfo.reputationBonus > 1 && repBonusRow && saleRepBonus) {
            repBonusRow.style.display = 'flex';
            var repBonusPct = Math.round((priceInfo.reputationBonus - 1) * 100);
            saleRepBonus.textContent = '+' + repBonusPct + '%';
            saleRepBonus.style.color = '#ba68c8';
        } else if (repBonusRow) {
            repBonusRow.style.display = 'none';
        }

        if (elements.sellTotal) {
            elements.sellTotal.textContent = '$' + HP.Helpers.formatNumber(displayTotal);
        }

        if (elements.saleDealEffect) {
            elements.saleDealEffect.textContent = dealEffectText;
            elements.saleDealEffect.className = 'sale-deal-effect ' + dealType;
        }

        if (sellBtn) {
            sellBtn.disabled = false;
        }

        if (statusEl) {
            statusEl.textContent = '✓ You have enough stock to fulfill this order.';
            statusEl.className = 'sale-status success';
        }
    }

    function getSelectedCustomer() {
        return selectedCustomer;
    }

    function getSelectedPlot() { return selectedPlot; }
    function getCurrentView() { return currentView; }

    /**
     * Update dynamic tooltips for bars
     */
    function updateTooltips() {
        // Heat tooltip
        var heat = HP.State.getHeat();
        var maxHeat = HP.State.getState().heat.maxLevel || 100;
        var heatMult = HP.Heat && HP.Heat.getHeatGainMultiplier ? HP.Heat.getHeatGainMultiplier() : 1;
        var reduction = Math.round((1 - heatMult) * 100);
        var heatTooltip = 'Heat: ' + Math.round(heat) + '/' + maxHeat;
        if (reduction > 0) heatTooltip += ' (−' + reduction + '% from security)';
        var heatBarContainer = document.getElementById('heat-bar-container');
        if (heatBarContainer) heatBarContainer.title = heatTooltip;

        // Water tooltip
        var reservoir = HP.State.getWaterReservoir();
        var waterTooltip = 'Water: ' + reservoir.current + '/' + reservoir.capacity;
        if (reservoir.current < reservoir.capacity) {
            var refillInterval = HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS || 8;
            var timeToNext = Math.ceil(refillInterval - (reservoir.refillAccumulator || 0));
            waterTooltip += ' (next charge in ' + timeToNext + 's)';
        } else {
            waterTooltip += ' (full)';
        }
        var waterDisplay = document.getElementById('water-reservoir-display');
        if (waterDisplay) waterDisplay.title = waterTooltip;
        var waterTimer = document.getElementById('water-refill-timer');
        if (waterTimer) waterTimer.title = waterTooltip;

        // XP tooltip
        var xp = HP.State.getXP();
        var level = HP.State.getLevel();
        var nextRank = HP.Data.Ranks.getNext(level);
        var xpTooltip = 'XP: ' + HP.Helpers.formatNumber(xp);
        if (nextRank) {
            var currentRank = HP.Data.Ranks.getByLevel(level);
            xpTooltip += ' / ' + HP.Helpers.formatNumber(nextRank.xpRequired) + ' (Level ' + level + ' → ' + nextRank.level + ')';
        } else {
            xpTooltip += ' (Max level)';
        }
        var xpBarContainer = document.getElementById('xp-bar-container');
        if (xpBarContainer) xpBarContainer.title = xpTooltip;
    }

    /**
     * Lightweight update for timers and progress bars only
     * Called frequently (100ms) for smooth animations
     * Throttled on store/dealer views to prevent hover flicker
     */
    function updateTimers() {
        var now = Date.now();
        var isStoreOrDealerView = (currentView === 'dealer' || currentView === 'hardware' || currentView === 'garden' || currentView === 'realestate');

        // On store/dealer views, only update heat and tooltips every 1s to avoid flicker on hover
        if (isStoreOrDealerView) {
            if (!updateTimers.lastThrottledUpdate || (now - updateTimers.lastThrottledUpdate) > 1000) {
                updateTimers.lastThrottledUpdate = now;
                if (elements.heatBar || elements.heatText) updateHeatDisplay();
                updateEventIndicator();
                updateTooltips();
            }
            return;
        }

        // Heat bar (always visible in top bar)
        if (elements.heatBar || elements.heatText) updateHeatDisplay();

        // Active event indicator (countdown)
        updateEventIndicator();

        // Update tooltips
        updateTooltips();

        // On market view: update orders/stock every 1s; full customer grid only every 10s to avoid hover push
        if (currentView === 'market' && _views.market) {
            if (!updateTimers.lastOrderUpdate || (now - updateTimers.lastOrderUpdate) > 1000) {
                updateTimers.lastOrderUpdate = now;
                if (_views.market.updateOrdersAndStockOnly) {
                    _views.market.updateOrdersAndStockOnly(buildCtx('market'));
                } else if (_views.market.update) {
                    _views.market.update(buildCtx('market'));
                }
            }
            if (!updateTimers.lastMarketFullUpdate || (now - updateTimers.lastMarketFullUpdate) > 10000) {
                updateTimers.lastMarketFullUpdate = now;
                if (_views.market.update) _views.market.update(buildCtx('market'));
            }
        }

        // Update water refill timer when on grow view
        if (currentView === 'grow' && HP.State && HP.State.getWaterReservoir) {
            var reservoir = HP.State.getWaterReservoir();
            if (reservoir && elements.waterCurrent) {
                elements.waterCurrent.textContent = reservoir.current;
                if (elements.waterCapacity) elements.waterCapacity.textContent = reservoir.capacity;
                var interval = (HP.Data.Constants && HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS != null) ? HP.Data.Constants.WATER_REFILL_INTERVAL_SECONDS : 8;
                var acc = reservoir.refillAccumulator || 0;
                var pct = interval > 0 ? Math.min(100, (acc / interval) * 100) : 0;
                var nextSec = Math.ceil(Math.max(0, interval - acc));
                if (elements.waterRefillProgress) elements.waterRefillProgress.style.width = pct + '%';
                if (elements.waterNextCharge) elements.waterNextCharge.textContent = 'Next: ' + nextSec + 's';

                var waterPct = reservoir.capacity > 0 ? (reservoir.current / reservoir.capacity) : 1;
                var isLow = reservoir.current > 0 && waterPct < 0.2;
                var waterGroup = document.getElementById('water-reservoir-group');
                var waterWarning = document.getElementById('water-low-warning');
                if (waterGroup) waterGroup.classList.toggle('water-reservoir-low', isLow);
                if (waterWarning) waterWarning.classList.toggle('hidden', !isLow);
            }
        }

        // Only update plots if on grow view
        if (currentView !== 'grow') return;
        if (!elements.plotsGrid) return;

        var propertyId = elements.propertySelect ? elements.propertySelect.value : null;
        if (!propertyId) return;

        var plots = HP.State.getPlots(propertyId);
        var plotCards = elements.plotsGrid.querySelectorAll('.plot-card');

        plotCards.forEach(function(card, index) {
            var plot = plots[index];
            if (!plot || plot.status !== 'growing' || !plot.plant) return;

            // Update progress bar
            var progressBar = card.querySelector('.plot-progress');
            if (progressBar) {
                var progress = HP.Growing.getGrowthProgress(plot.plant);
                progressBar.style.width = progress + '%';
            }

            // Update time remaining
            var timeEl = card.querySelector('.plot-time');
            if (timeEl) {
                timeEl.textContent = HP.Growing.getTimeRemaining(plot.plant) + ' left';
            }

            // Update water bar
            var waterFill = card.querySelector('.water-fill');
            if (waterFill) {
                var waterLevel = HP.Growing.getWaterLevel(plot.plant);
                waterFill.style.width = waterLevel + '%';
            }

            // Update water status (icon and label)
            var isHydrated = plot.plant.isHydrated;
            var iconEl = card.querySelector('.plot-icon');
            var labelEl = card.querySelector('.plot-label');
            
            if (iconEl) {
                iconEl.textContent = isHydrated ? '🌱' : '🥀';
            }
            if (labelEl) {
                labelEl.textContent = isHydrated ? 'Growing' : 'Needs Water!';
            }

            // Update water bar color class
            var waterBar = card.querySelector('.water-bar');
            if (waterBar) {
                var waterLevel = HP.Growing.getWaterLevel(plot.plant);
                waterBar.classList.remove('water-good', 'water-low', 'water-critical');
                if (waterLevel > 50) {
                    waterBar.classList.add('water-good');
                } else if (waterLevel > 20) {
                    waterBar.classList.add('water-low');
                } else {
                    waterBar.classList.add('water-critical');
                }
            }
        });

        // Update selected plot panel water info if visible
        if (selectedPlot && elements.plotStatusBadge) {
            var plot = HP.State.getPlot(selectedPlot.propertyId, selectedPlot.plotIndex);
            if (plot && plot.plant && plot.status === 'growing') {
                var seed = HP.Data.Seeds.get(plot.plant.seedId);
                var statusText = seed.name;
                if (!plot.plant.isHydrated) {
                    statusText += ' - NEEDS WATER';
                }
                elements.plotStatusBadge.textContent = statusText;
            }
        }
    }

    // View modules (achievements, challenges, workers, stats, genetics) register via HP.Renderer._views

    function openWorkerAssignModal(workerTypeId) {
        if (!elements.workerAssignModal) return;

        // Populate plot selector
        var owned = HP.State.getOwnedProperties();
        var plotHtml = '<option value="">Select a plot...</option>';
        for (var i = 0; i < owned.length; i++) {
            var propId = owned[i];
            var property = HP.Data.Properties.get(propId);
            var plots = HP.State.getPlots(propId);
            for (var j = 0; j < plots.length; j++) {
                var hasWorker = HP.State.getWorkerByPlot(propId, j);
                if (!hasWorker) {
                    plotHtml += '<option value="' + propId + ':' + j + '">' + property.icon + ' ' + property.name + ' - Plot ' + (j + 1) + '</option>';
                }
            }
        }
        if (elements.workerPlotSelect) {
            elements.workerPlotSelect.innerHTML = plotHtml;
        }

        // Populate seed selector
        var inventory = HP.State.getInventory();
        var seedHtml = '<option value="">Auto (use best available)</option>';
        var allSeeds = HP.Data.Seeds.getAll();
        for (var seedId in allSeeds) {
            var seed = allSeeds[seedId];
            var hasSeed = (inventory.seeds[seedId] || 0) > 0;
            seedHtml += '<option value="' + seedId + '"' + (!hasSeed ? ' disabled' : '') + '>' + 
                seed.icon + ' ' + seed.name + (!hasSeed ? ' (none)' : '') + '</option>';
        }
        if (elements.workerSeedSelect) {
            elements.workerSeedSelect.innerHTML = seedHtml;
        }

        // Populate soil selector
        var soilHtml = '<option value="">None</option>';
        var allEquipment = HP.Data.Equipment.getAll();
        for (var equipId in allEquipment) {
            var equip = allEquipment[equipId];
            if (equip.slot === 'soil') {
                var hasEquip = (inventory.equipment[equipId] || 0) > 0;
                soilHtml += '<option value="' + equipId + '"' + (!hasEquip ? ' disabled' : '') + '>' + 
                    equip.icon + ' ' + equip.name + (!hasEquip ? ' (none)' : '') + '</option>';
            }
        }
        if (elements.workerSoilSelect) {
            elements.workerSoilSelect.innerHTML = soilHtml;
        }

        // Populate fertilizer selector
        var fertHtml = '<option value="">None</option>';
        for (var equipId in allEquipment) {
            var equip = allEquipment[equipId];
            if (equip.slot === 'fertilizer') {
                var hasEquip = (inventory.equipment[equipId] || 0) > 0;
                fertHtml += '<option value="' + equipId + '"' + (!hasEquip ? ' disabled' : '') + '>' + 
                    equip.icon + ' ' + equip.name + (!hasEquip ? ' (none)' : '') + '</option>';
            }
        }
        if (elements.workerFertilizerSelect) {
            elements.workerFertilizerSelect.innerHTML = fertHtml;
        }

        // Store worker type for assignment
        if (elements.workerAssignModal) {
            elements.workerAssignModal.setAttribute('data-worker-type', workerTypeId);
            elements.workerAssignModal.classList.remove('hidden');
            
            // Reset assign button
            var assignBtn = document.getElementById('btn-assign-worker');
            if (assignBtn) {
                assignBtn.textContent = 'Assign Worker';
                assignBtn.removeAttribute('data-update-worker');
            }
            
            // Enable plot select
            if (elements.workerPlotSelect) {
                elements.workerPlotSelect.disabled = false;
            }

            requestAnimationFrame(function() {
                var first = elements.workerPlotSelect || document.getElementById('btn-close-worker-modal');
                if (first) first.focus();
            });
        }
    }

    function closeWorkerAssignModal() {
        if (elements.workerAssignModal) {
            elements.workerAssignModal.classList.add('hidden');
        }
    }

    return {
        init: init,
        update: update,
        updateAfterSale: updateAfterSale,
        updateAfterHarvest: updateAfterHarvest,
        updateTimers: updateTimers,
        switchView: switchView,
        selectPlot: selectPlot,
        getSelectedPlot: getSelectedPlot,
        getCurrentView: getCurrentView,
        updateSellTotal: updateSellTotal,
        regenerateCustomerRequest: regenerateCustomerRequest,
        toggleRoomUpgradesPanel: toggleRoomUpgradesPanel,
        closeSaleModal: closeSaleModal,
        openSaleModal: openSaleModal,
        showRaidModal: showRaidModal,
        closeRaidModal: closeRaidModal,
        getSelectedCustomer: getSelectedCustomer,
        toggleBulkSelectMode: toggleBulkSelectMode,
        clearSelection: clearSelection,
        getSelectedPlots: function() { return selectedPlots.slice(); },
        isBulkSelectMode: function() { return bulkSelectMode; },
        openWorkerAssignModal: openWorkerAssignModal,
        closeWorkerAssignModal: closeWorkerAssignModal,
        _views: _views
    };
})();
