/**
 * In-app confirm and input dialogs (replaces confirm() / prompt()).
 * Use event delegation or bind once; Escape closes; focus trap in modals.
 */
var HP = HP || {};

HP.ConfirmDialog = (function() {
    'use strict';

    var confirmEl, messageEl, confirmBtn, cancelBtns;
    var inputEl, inputDialogEl, inputLabelEl, inputFieldEl, inputSaveBtn, inputCancelBtns;
    var _onConfirm, _onCancel, _onInputSave, _onInputCancel;

    function getFocusables(container) {
        if (!container) return [];
        var sel = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
        var nodes = container.querySelectorAll(sel);
        return Array.prototype.filter.call(nodes, function(n) {
            return n.offsetParent !== null && !n.disabled;
        });
    }

    function trapFocus(e, dialogEl) {
        if (e.key !== 'Tab' || !dialogEl) return;
        var focusables = getFocusables(dialogEl);
        if (focusables.length === 0) return;
        var first = focusables[0];
        var last = focusables[focusables.length - 1];
        if (e.shiftKey) {
            if (document.activeElement === first) {
                e.preventDefault();
                last.focus();
            }
        } else {
            if (document.activeElement === last) {
                e.preventDefault();
                first.focus();
            }
        }
    }

    function showConfirm(options, onConfirm, onCancel) {
        confirmEl = document.getElementById('confirm-dialog');
        messageEl = document.getElementById('confirm-dialog-message');
        confirmBtn = document.getElementById('confirm-dialog-confirm-btn');
        if (!confirmEl || !messageEl || !confirmBtn) return;

        var msg = (options && options.message) || 'Continue?';
        var confirmLabel = (options && options.confirmLabel) || 'Confirm';
        var danger = options && options.danger;

        messageEl.textContent = msg;
        confirmBtn.textContent = confirmLabel;
        confirmBtn.classList.toggle('btn-danger', !!danger);
        _onConfirm = typeof onConfirm === 'function' ? onConfirm : null;
        _onCancel = typeof onCancel === 'function' ? onCancel : null;

        confirmEl.classList.remove('hidden');
        confirmEl.setAttribute('aria-hidden', 'false');
        requestAnimationFrame(function() {
            var first = getFocusables(confirmEl)[0];
            if (first) first.focus();
        });

        cancelBtns = confirmEl.querySelectorAll('.confirm-dialog-cancel');
        cancelBtns.forEach(function(btn) {
            btn.addEventListener('click', handleConfirmCancel);
        });
        confirmBtn.onclick = handleConfirmConfirm;
        document.addEventListener('keydown', confirmKeyHandler);
    }

    function handleConfirmCancel() {
        closeConfirm();
    }

    function handleConfirmConfirm() {
        var cb = _onConfirm;
        hideConfirm();
        if (cb) cb();
    }

    function confirmKeyHandler(e) {
        if (e.key === 'Escape') {
            e.preventDefault();
            handleConfirmCancel();
            return;
        }
        trapFocus(e, confirmEl);
    }

    function hideConfirm() {
        if (!confirmEl) return;
        confirmEl.classList.add('hidden');
        confirmEl.setAttribute('aria-hidden', 'true');
        confirmBtn.classList.remove('btn-danger');
        _onCancel = null;
        _onConfirm = null;
        if (cancelBtns && cancelBtns.length) {
            cancelBtns.forEach(function(btn) {
                btn.removeEventListener('click', handleConfirmCancel);
            });
        }
        confirmBtn.onclick = null;
        document.removeEventListener('keydown', confirmKeyHandler);
    }

    function closeConfirm() {
        if (_onCancel) _onCancel();
        hideConfirm();
    }

    function showInput(options, onSave, onCancel) {
        inputDialogEl = document.getElementById('input-dialog');
        inputLabelEl = document.getElementById('input-dialog-label');
        inputFieldEl = document.getElementById('input-dialog-field');
        inputSaveBtn = document.getElementById('input-dialog-save-btn');
        var titleEl = document.getElementById('input-dialog-title');
        if (!inputDialogEl || !inputFieldEl || !inputSaveBtn) return;

        var title = (options && options.title) || 'Input';
        var label = (options && options.label) || 'Value';
        var value = (options && options.value) != null ? String(options.value) : '';
        var placeholder = (options && options.placeholder) || '';
        var maxLength = (options && options.maxLength) != null ? options.maxLength : 80;

        if (titleEl) titleEl.textContent = title;
        if (inputLabelEl) inputLabelEl.textContent = label;
        inputFieldEl.value = value;
        inputFieldEl.placeholder = placeholder;
        inputFieldEl.maxLength = maxLength;
        _onInputSave = typeof onSave === 'function' ? onSave : null;
        _onInputCancel = typeof onCancel === 'function' ? onCancel : null;

        inputDialogEl.classList.remove('hidden');
        inputDialogEl.setAttribute('aria-hidden', 'false');
        requestAnimationFrame(function() {
            inputFieldEl.focus();
            inputFieldEl.select();
        });

        inputCancelBtns = inputDialogEl.querySelectorAll('.input-dialog-cancel');
        inputCancelBtns.forEach(function(btn) {
            btn.addEventListener('click', handleInputCancel);
        });
        inputSaveBtn.onclick = handleInputSave;
        inputFieldEl.onkeydown = function(e) {
            if (e.key === 'Escape') {
                e.preventDefault();
                handleInputCancel();
            }
        };
        document.addEventListener('keydown', inputKeyHandler);
    }

    function handleInputSave() {
        var val = inputFieldEl ? inputFieldEl.value : '';
        hideInput();
        if (_onInputSave) _onInputSave(val);
    }

    function handleInputCancel() {
        closeInput();
    }

    function inputKeyHandler(e) {
        if (e.key === 'Escape') {
            e.preventDefault();
            handleInputCancel();
            return;
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            handleInputSave();
            return;
        }
        trapFocus(e, inputDialogEl);
    }

    function hideInput() {
        if (!inputDialogEl) return;
        inputDialogEl.classList.add('hidden');
        inputDialogEl.setAttribute('aria-hidden', 'true');
        _onInputSave = null;
        _onInputCancel = null;
        if (inputCancelBtns && inputCancelBtns.length) {
            inputCancelBtns.forEach(function(btn) {
                btn.removeEventListener('click', handleInputCancel);
            });
        }
        inputSaveBtn.onclick = null;
        inputFieldEl.onkeydown = null;
        document.removeEventListener('keydown', inputKeyHandler);
    }

    function closeInput() {
        if (_onInputCancel) _onInputCancel();
        hideInput();
    }

    return {
        showConfirm: showConfirm,
        showInput: showInput,
        hideConfirm: hideConfirm,
        closeConfirm: closeConfirm,
        hideInput: hideInput,
        closeInput: closeInput,
        isConfirmVisible: function() {
            var el = document.getElementById('confirm-dialog');
            return el && !el.classList.contains('hidden');
        },
        isInputVisible: function() {
            var el = document.getElementById('input-dialog');
            return el && !el.classList.contains('hidden');
        }
    };
})();
