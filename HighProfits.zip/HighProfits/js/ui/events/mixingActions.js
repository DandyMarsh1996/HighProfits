/**
 * Mixing Lab actions: perform mix from Inventory view
 */
(function() {
    'use strict';

    function performMix() {
        var selectA = document.getElementById('mix-strain-a');
        var selectB = document.getElementById('mix-strain-b');
        var selectC = document.getElementById('mix-strain-c');
        var amountEl = document.getElementById('mix-amount');
        if (!selectA || !selectB || !amountEl) return;
        var seedId1 = selectA.value;
        var seedId2 = selectB.value;
        var seedId3 = (selectC && selectC.value) ? selectC.value : '';
        var amount = parseInt(amountEl.value, 10) || 1;
        if (!seedId1 || !seedId2) {
            HP.Notifications.error('Select at least two strains to mix.');
            return;
        }
        if (seedId1 === seedId2) {
            HP.Notifications.error('Pick two different strains.');
            return;
        }
        if (seedId3 && (seedId3 === seedId1 || seedId3 === seedId2)) {
            HP.Notifications.error('Premium mix needs three different strains.');
            return;
        }
        var result;
        if (seedId3 && HP.Mixing && HP.Mixing.doMix3 && HP.Mixing.canMix3 && HP.Mixing.canMix3(seedId1, seedId2, seedId3, amount)) {
            result = HP.Mixing.doMix3(seedId1, seedId2, seedId3, amount);
        } else if (HP.Mixing && HP.Mixing.doMix) {
            result = HP.Mixing.doMix(seedId1, seedId2, amount);
        } else {
            HP.Notifications.error('Could not mix.');
            return;
        }
        if (result.success) {
            HP.Notifications.success('Created ' + result.amount + 'g blend (' + result.quality + '). Sells at a markup on the Green Market.');
            if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
        } else {
            HP.Notifications.error(result.error || 'Could not mix.');
        }
    }

    function bind() {
        document.body.addEventListener('click', function(e) {
            var target = e.target && (e.target.closest ? e.target.closest('[data-action="mix"]') : e.target);
            if (!target || target.getAttribute('data-action') !== 'mix') return;
            e.preventDefault();
            performMix();
        });
    }

    HP.Events.MixingActions = {
        bind: bind,
        performMix: performMix
    };
})();
