/**
 * Smoke product action: consume 1g of a strain to get a temporary buff (one at a time).
 */
(function() {
    'use strict';
    var GRAMS_PER_USE = 1;

    function bind() {
        document.body.addEventListener('click', function(e) {
            var btn = e.target && e.target.closest && e.target.closest('[data-action="smoke"]');
            if (!btn) return;
            e.preventDefault();
            e.stopPropagation();
            var seedId = btn.getAttribute('data-seed-id');
            if (!seedId) return;
            if (!HP.State.getActiveSmokeBuff) return;
            if (HP.State.getActiveSmokeBuff()) {
                HP.Notifications.info('You already have an active buff. Wait for it to expire before smoking again.');
                return;
            }
            var amount = HP.State.getWeed ? HP.State.getWeed(seedId) : 0;
            if (amount < GRAMS_PER_USE) {
                HP.Notifications.error('You need at least 1g of this strain to smoke.');
                return;
            }
            var seed = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedId) : null;
            var strainName = seed ? (seed.strainName || seed.name) : seedId;
            var buffType = HP.State.getBuffTypeForStrain ? HP.State.getBuffTypeForStrain(seed) : 'sale';
            HP.State.removeWeed(seedId, GRAMS_PER_USE);
            HP.State.setActiveSmokeBuff(seedId, strainName, buffType);
            var label = HP.State.getBuffTypeLabel ? HP.State.getBuffTypeLabel(buffType) : buffType;
            HP.Notifications.success('Smoked 1g ' + strainName + '. Buff: ' + label + '.');
            if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
        });
    }

    HP.Events = HP.Events || {};
    HP.Events.SmokeActions = { bind: bind };
})();
