/**
 * Plot actions: delegation (harvest, plant, water, equip), room upgrade toggle.
 */
(function() {
    'use strict';
    var refreshUI = function() { HP.Events.refreshUI(); };
    var checkAchievements = function() { HP.Events.checkAchievements(); };
    var checkTutorialProgress = function() { HP.Events.checkTutorialProgress(); };

    function bindRoomUpgradeToggle() {
        var openBtn = document.getElementById('btn-location-upgrades');
        var closeBtn = document.getElementById('btn-close-upgrades');
        if (openBtn) openBtn.addEventListener('click', function() { HP.Renderer.toggleRoomUpgradesPanel(true); });
        if (closeBtn) closeBtn.addEventListener('click', function() { HP.Renderer.toggleRoomUpgradesPanel(false); });
    }

    function installEquipment(propertyId, plotIndex, equipmentId) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) { HP.Notifications.error('Invalid plot'); return; }
        if (HP.State.getEquipment(equipmentId) < 1) { HP.Notifications.error('Equipment not in inventory'); return; }
        var result = HP.Growing.installEquipment(plot, equipmentId);
        if (result.success) {
            HP.State.removeEquipment(equipmentId, 1);
            HP.Notifications.success(result.message);
            if (HP.Progression && HP.Progression.calculateXPForEquipmentInstall) HP.State.addXP(HP.Progression.calculateXPForEquipmentInstall(equipmentId));
            else if (HP.Data.Constants.XP_PER_EQUIPMENT_INSTALL) HP.State.addXP(HP.Data.Constants.XP_PER_EQUIPMENT_INSTALL);
        } else HP.Notifications.error(result.message);
        refreshUI();
    }

    function plantSeed(propertyId, plotIndex, seedId) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) { HP.Notifications.error('Invalid plot'); return; }
        if (HP.State.getSeeds(seedId) < 1) { HP.Notifications.error('No seeds in inventory'); return; }
        var roomBonuses = HP.State.getRoomBonuses(propertyId);
        var result = HP.Growing.plantSeed(plot, seedId, roomBonuses, propertyId);
        if (result.success) {
            HP.State.removeSeeds(seedId, 1);
            HP.Notifications.success(result.message);
            if (HP.Progression && HP.Progression.calculateXPForPlanting) HP.State.addXP(HP.Progression.calculateXPForPlanting(seedId));
            else if (HP.Data.Constants.XP_PER_SEED_PLANTED) HP.State.addXP(HP.Data.Constants.XP_PER_SEED_PLANTED);
            if (HP.SoundManager) HP.SoundManager.play('plant');
            checkTutorialProgress();
        } else HP.Notifications.error(result.message);
        refreshUI();
    }

    function waterPlant(propertyId, plotIndex, canId) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) { HP.Notifications.error('Invalid plot'); return; }
        if (HP.State.getEquipment(canId) < 1) { HP.Notifications.error('No watering can in inventory'); return; }
        var can = HP.Data.Equipment.get(canId);
        if (!can || !can.waterAmount) { HP.Notifications.error('Invalid watering equipment'); return; }
        var waterCost = HP.Data.Constants && HP.Data.Constants.WATER_COST_PER_USE != null ? HP.Data.Constants.WATER_COST_PER_USE : 1;
        if (HP.State.getWaterReservoir().current < waterCost) { HP.Notifications.error('Out of water. Refill at the tap.'); return; }
        var result = HP.Growing.waterPlant(plot, can.waterAmount);
        if (result.success) {
            HP.State.useWater(waterCost);
            HP.State.incrementStat('plantsWatered', 1);
            HP.Notifications.success('💧 Watered! +' + can.waterAmount + 's hydration');
            if (HP.SoundManager) HP.SoundManager.play('water');
            checkTutorialProgress();
        } else HP.Notifications.error(result.message);
        refreshUI();
    }

    function harvestAll(propertyId) {
        if (!propertyId) return;
        var plots = HP.State.getPlots(propertyId);
        var harvested = 0;
        for (var i = 0; i < plots.length; i++) {
            var plot = HP.State.getPlot(propertyId, i);
            if (plot && plot.status === 'harvest') {
                harvestPlant(propertyId, i);
                harvested++;
            }
        }
        if (harvested > 0) {
            if (HP.State.incrementStat) HP.State.incrementStat('harvestAllCount', 1);
            if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
        }
    }

    function harvestPlant(propertyId, plotIndex) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) { HP.Notifications.error('Invalid plot'); return; }
        var result = HP.Growing.harvestPlant(plot);
        if (result.success) {
            if (HP.State.getDailyGoals && HP.State.addProgress) {
                var dg = HP.State.addProgress('harvest_count', 1);
                if (dg && dg.completed && HP.Notifications) HP.Notifications.success('🎯 Daily goal: +$' + HP.Helpers.formatNumber(dg.reward));
            }
            HP.State.addWeed(result.seedId, result.yield);
            if (HP.Progression && HP.Progression.calculateXPForHarvest) HP.State.addXP(HP.Progression.calculateXPForHarvest(plot, result));
            else HP.State.addXP(HP.Data.Constants.XP_PER_HARVEST);
            HP.State.incrementStat('plantsGrown', 1);
            var stats = HP.State.getStats();
            if (result.yield > (stats.bestHarvest || 0)) HP.State.setStat('bestHarvest', result.yield);
            
            // Track strain mastery
            if (plot.plant && plot.plant.seedId && HP.State.incrementStrainHarvests) {
                var masteryResult = HP.State.incrementStrainHarvests(plot.plant.seedId);
                if (masteryResult.leveledUp) {
                    var seed = HP.Data.Seeds.get(plot.plant.seedId);
                    var seedName = seed ? seed.name : 'strain';
                    HP.Notifications.info('🌟 Mastery Level Up! ' + seedName + ' → Level ' + masteryResult.newLevel);
                }
            }
            
            var plotCard = document.querySelector('.plot-card[data-property="' + propertyId + '"][data-index="' + plotIndex + '"]');
            if (HP.Particles && plotCard) HP.Particles.emitHarvest({ element: plotCard });
            if (HP.SoundManager) HP.SoundManager.play('harvest');
            HP.Notifications.success(result.message);
            if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
            checkTutorialProgress();
            if (HP.Renderer && HP.Renderer.updateAfterHarvest) HP.Renderer.updateAfterHarvest();
        } else HP.Notifications.error(result.message);
        refreshUI();
        requestAnimationFrame(function() { refreshUI(); });
    }

    function clearDeadPlant(propertyId, plotIndex) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) return;
        HP.Growing.clearDeadPlant(plot);
        HP.Notifications.info('Cleared dead plant');
        refreshUI();
    }

    function uninstallEquipment(propertyId, plotIndex, slot) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) { HP.Notifications.error('Invalid plot'); return; }
        var result = HP.Growing.uninstallEquipment(plot, slot);
        if (result.success) {
            var equip = HP.Data.Equipment.get(result.equipmentId);
            if (equip && !equip.consumable) {
                HP.State.addEquipment(result.equipmentId, 1);
                HP.Notifications.success(result.message + ' - returned to inventory');
            } else HP.Notifications.info(result.message + ' - discarded');
        } else HP.Notifications.error(result.message);
        refreshUI();
    }

    function bindPlotActionDelegation() {
        document.body.addEventListener('click', function(e) {
            var target = e.target;
            if (!target.closest) return;
            // Harvest all: button lives in grow header, not in #plot-buttons
            var harvestAllBtn = target.closest('.harvest-all-btn');
            if (harvestAllBtn) {
                e.preventDefault(); e.stopPropagation();
                var propId = harvestAllBtn.getAttribute('data-property');
                if (propId) harvestAll(propId);
                return;
            }

            var plotButtonsPanel = target.closest('#plot-buttons');
            if (!plotButtonsPanel) return;

            var harvestBtn = target.closest('.harvest-btn');
            if (harvestBtn) {
                e.preventDefault(); e.stopPropagation();
                var propId = harvestBtn.getAttribute('data-property');
                var plotIdx = parseInt(harvestBtn.getAttribute('data-plot-index'), 10);
                if (propId && !isNaN(plotIdx)) harvestPlant(propId, plotIdx);
                return;
            }

            var clearBtn = target.closest('.btn-clear-dead');
            if (clearBtn) {
                e.preventDefault(); e.stopPropagation();
                var propId = clearBtn.getAttribute('data-property');
                var plotIdx = parseInt(clearBtn.getAttribute('data-plot-index'), 10);
                if (propId && !isNaN(plotIdx)) clearDeadPlant(propId, plotIdx);
                return;
            }

            var sel = HP.Renderer && HP.Renderer.getSelectedPlot ? HP.Renderer.getSelectedPlot() : null;

            var plantBtn = target.closest('.plant-seed');
            if (plantBtn && sel) {
                e.preventDefault(); e.stopPropagation();
                var seedId = plantBtn.getAttribute('data-seed');
                if (seedId) plantSeed(sel.propertyId, sel.plotIndex, seedId);
                return;
            }

            var waterBtn = target.closest('.water-btn');
            if (waterBtn && sel) {
                e.preventDefault(); e.stopPropagation();
                var canId = waterBtn.getAttribute('data-can');
                if (canId) waterPlant(sel.propertyId, sel.plotIndex, canId);
                return;
            }

            var installBtn = target.closest('.install-equip');
            if (installBtn && sel) {
                e.preventDefault(); e.stopPropagation();
                var equipId = installBtn.getAttribute('data-equip');
                if (equipId) installEquipment(sel.propertyId, sel.plotIndex, equipId);
                return;
            }

            var uninstallBtn = target.closest('.uninstall-equip');
            if (uninstallBtn && sel) {
                e.preventDefault(); e.stopPropagation();
                var slot = uninstallBtn.getAttribute('data-slot');
                if (slot) uninstallEquipment(sel.propertyId, sel.plotIndex, slot);
                return;
            }

            var storeBtn = target.closest('.go-to-store-btn');
            if (storeBtn) {
                e.preventDefault(); e.stopPropagation();
                var view = storeBtn.getAttribute('data-view');
                if (view && HP.Renderer && HP.Renderer.switchView) HP.Renderer.switchView(view);
            }
        });
    }

    function bind() {
        bindPlotActionDelegation();
        bindRoomUpgradeToggle();
    }

    HP.Events.PlotActions = {
        bind: bind,
        installEquipment: installEquipment,
        uninstallEquipment: uninstallEquipment,
        plantSeed: plantSeed,
        waterPlant: waterPlant,
        harvestPlant: harvestPlant,
        harvestAll: harvestAll,
        clearDeadPlant: clearDeadPlant
    };
})();
