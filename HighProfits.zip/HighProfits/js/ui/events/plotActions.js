/**
 * Plot actions: delegation (harvest, plant, water, equip), quick actions, bulk actions, room upgrade toggle.
 */
(function() {
    'use strict';
    var refreshUI = function() { HP.Events.refreshUI(); };
    var checkAchievements = function() { HP.Events.checkAchievements(); };
    var checkTutorialProgress = function() { HP.Events.checkTutorialProgress(); };

    function bulkWaterSelected() {
        var selected = HP.Renderer.getSelectedPlots();
        if (selected.length === 0) { HP.Notifications.info('No plots selected'); return; }
        var watered = 0, inventory = HP.State.getInventory(), wateringCans = HP.Data.Equipment.getWateringCans();
        var bestCan = null;
        for (var i = 0; i < wateringCans.length; i++) {
            var can = wateringCans[i];
            if (inventory.equipment[can.id] > 0) {
                if (!bestCan || can.waterAmount > bestCan.waterAmount) bestCan = can;
            }
        }
        if (!bestCan) { HP.Notifications.error('No watering can in inventory!'); return; }
        var waterCost = HP.Data.Constants && HP.Data.Constants.WATER_COST_PER_USE != null ? HP.Data.Constants.WATER_COST_PER_USE : 1;
        var reservoir = HP.State.getWaterReservoir();
        for (var i = 0; i < selected.length; i++) {
            var plotData = selected[i], plot = HP.State.getPlot(plotData.propertyId, plotData.plotIndex);
            if (plot && plot.status === 'growing' && plot.plant && !plot.plant.isHydrated) {
                if (reservoir.current < waterCost) {
                    HP.Notifications.error('Out of water after ' + watered + ' plot' + (watered !== 1 ? 's' : '') + '. Refill at the tap.');
                    break;
                }
                var result = HP.Growing.waterPlant(plot, bestCan.waterAmount);
                if (result.success) {
                    HP.State.useWater(waterCost);
                    watered++;
                    reservoir = HP.State.getWaterReservoir();
                }
            }
        }
        if (watered > 0) {
            if (HP.SoundManager) HP.SoundManager.play('water');
            HP.Notifications.success('💧 Watered ' + watered + ' selected plot' + (watered > 1 ? 's' : ''));
        } else { HP.Notifications.info('No plots needed watering'); }
        refreshUI();
    }

    function bulkHarvestSelected() {
        var selected = HP.Renderer.getSelectedPlots();
        if (selected.length === 0) { HP.Notifications.info('No plots selected'); return; }
        var harvested = 0, totalYield = 0, qualities = {};
        for (var i = 0; i < selected.length; i++) {
            var plotData = selected[i], plot = HP.State.getPlot(plotData.propertyId, plotData.plotIndex);
            if (plot && plot.status === 'harvest') {
                var result = HP.Growing.harvestPlant(plot);
                if (result.success) {
                    HP.State.addWeed(result.quality, result.yield);
                    if (HP.Progression && HP.Progression.calculateXPForHarvest) HP.State.addXP(HP.Progression.calculateXPForHarvest(plot, result));
                    else HP.State.addXP(HP.Data.Constants.XP_PER_HARVEST);
                    HP.State.incrementStat('plantsGrown', 1);
                    harvested++;
                    totalYield += result.yield;
                    qualities[result.quality] = (qualities[result.quality] || 0) + result.yield;
                }
            }
        }
        if (harvested > 0) {
            var qualityStr = Object.keys(qualities).map(function(q) { return qualities[q] + 'g ' + q; }).join(', ');
            if (HP.SoundManager) HP.SoundManager.play('harvest');
            HP.Notifications.success('🌿 Harvested ' + harvested + ' plot' + (harvested > 1 ? 's' : '') + '! (' + qualityStr + ')');
            if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
            checkAchievements();
        } else { HP.Notifications.info('No plots ready to harvest'); }
        refreshUI();
    }

    function bulkPlantSelected() {
        var selected = HP.Renderer.getSelectedPlots();
        if (selected.length === 0) { HP.Notifications.info('No plots selected'); return; }
        var inventory = HP.State.getInventory(), allSeeds = HP.Data.Seeds.getAll();
        var bestSeed = null, bestSeedId = null;
        for (var seedId in allSeeds) {
            if (inventory.seeds[seedId] > 0) {
                var seed = allSeeds[seedId];
                if (!bestSeed || seed.cost > bestSeed.cost) { bestSeed = seed; bestSeedId = seedId; }
            }
        }
        if (!bestSeed) { HP.Notifications.error('No seeds in inventory!'); return; }
        var planted = 0;
        for (var i = 0; i < selected.length; i++) {
            var plotData = selected[i], plot = HP.State.getPlot(plotData.propertyId, plotData.plotIndex);
            if (plot && (plot.status === 'empty' || plot.status === 'setup') && HP.State.getSeeds(bestSeedId) > 0) {
                var roomBonuses = HP.State.getRoomBonuses(plotData.propertyId);
                var result = HP.Growing.plantSeed(plot, bestSeedId, roomBonuses, plotData.propertyId);
                if (result.success) {
                    HP.State.removeSeeds(bestSeedId, 1);
                    planted++;
                    if (HP.Progression && HP.Progression.calculateXPForPlanting) HP.State.addXP(HP.Progression.calculateXPForPlanting(bestSeedId));
                }
            }
        }
        if (planted > 0) HP.Notifications.success('🌱 Planted ' + planted + ' plot' + (planted > 1 ? 's' : '') + ' with ' + bestSeed.name);
        else HP.Notifications.info('No plots ready to plant');
        refreshUI();
    }

    function bulkInstallEquipment() {
        var selected = HP.Renderer.getSelectedPlots();
        if (selected.length === 0) { HP.Notifications.info('No plots selected'); return; }
        var inventory = HP.State.getInventory(), playerLevel = HP.State.getLevel(), installed = 0;
        for (var i = 0; i < selected.length; i++) {
            var plotData = selected[i], plot = HP.State.getPlot(plotData.propertyId, plotData.plotIndex);
            if (!plot || (plot.status !== 'empty' && plot.status !== 'setup')) continue;
            var slots = ['pot', 'soil', 'light', 'fan', 'fertilizer'];
            for (var s = 0; s < slots.length; s++) {
                var slot = slots[s];
                if (plot.equipment[slot]) continue;
                var bestEquip = null, allEquip = HP.Data.Equipment.getAll();
                for (var equipId in allEquip) {
                    var equip = allEquip[equipId];
                    var equipSlot = equip.slot || HP.Growing.getEquipmentSlot(equip);
                    if (equipSlot === slot && inventory.equipment[equipId] > 0 && equip.unlockLevel <= playerLevel) {
                        if (!bestEquip || equip.cost > bestEquip.cost) bestEquip = equip;
                    }
                }
                if (bestEquip) {
                    var result = HP.Growing.installEquipment(plot, bestEquip.id);
                    if (result.success) {
                        HP.State.removeEquipment(bestEquip.id, 1);
                        installed++;
                        if (HP.Progression && HP.Progression.calculateXPForEquipmentInstall) HP.State.addXP(HP.Progression.calculateXPForEquipmentInstall(bestEquip.id));
                        else if (HP.Data.Constants.XP_PER_EQUIPMENT_INSTALL) HP.State.addXP(HP.Data.Constants.XP_PER_EQUIPMENT_INSTALL);
                    }
                }
            }
        }
        if (installed > 0) HP.Notifications.success('⚙️ Installed ' + installed + ' equipment piece' + (installed > 1 ? 's' : ''));
        else HP.Notifications.info('No equipment to install or plots already equipped');
        refreshUI();
    }

    function bulkClearSelected() {
        var selected = HP.Renderer.getSelectedPlots();
        if (selected.length === 0) { HP.Notifications.info('No plots selected'); return; }
        var cleared = 0;
        for (var i = 0; i < selected.length; i++) {
            var plotData = selected[i], plot = HP.State.getPlot(plotData.propertyId, plotData.plotIndex);
            if (plot && plot.status === 'dead') { HP.Growing.clearDeadPlant(plot); cleared++; }
        }
        if (cleared > 0) HP.Notifications.success('🗑️ Cleared ' + cleared + ' dead plant' + (cleared > 1 ? 's' : ''));
        else HP.Notifications.info('No dead plants to clear');
        refreshUI();
    }

    function waterAllPlants() {
        var propertySelect = document.getElementById('property-select');
        if (!propertySelect) return;
        var propertyId = propertySelect.value, plots = HP.State.getPlots(propertyId), inventory = HP.State.getInventory();
        var wateringCans = HP.Data.Equipment.getWateringCans(), bestCan = null, bestWaterAmount = 0;
        for (var i = 0; i < wateringCans.length; i++) {
            var can = wateringCans[i];
            if ((inventory.equipment[can.id] || 0) > 0 && can.waterAmount > bestWaterAmount) { bestCan = can; bestWaterAmount = can.waterAmount; }
        }
        if (!bestCan) { HP.Notifications.error('No watering can in inventory!'); return; }
        var waterCost = HP.Data.Constants && HP.Data.Constants.WATER_COST_PER_USE != null ? HP.Data.Constants.WATER_COST_PER_USE : 1;
        var reservoir = HP.State.getWaterReservoir(), watered = 0;
        for (var i = 0; i < plots.length; i++) {
            var plot = plots[i];
            if (plot.status === 'growing' && plot.plant && !plot.plant.isHydrated) {
                if (reservoir.current < waterCost) {
                    HP.Notifications.error('Out of water after ' + watered + ' plant' + (watered !== 1 ? 's' : '') + '. Refill at the tap.');
                    break;
                }
                var result = HP.Growing.waterPlant(plot, bestCan.waterAmount);
                if (result && result.success) {
                    HP.State.useWater(waterCost);
                    watered++;
                    reservoir = HP.State.getWaterReservoir();
                }
            }
        }
        if (watered > 0) HP.Notifications.success('💧 Watered ' + watered + ' plant' + (watered > 1 ? 's' : '') + '!');
        else HP.Notifications.info('No plants need water right now');
        refreshUI();
    }

    function harvestAllPlants() {
        var propertySelect = document.getElementById('property-select');
        if (!propertySelect) return;
        var propertyId = propertySelect.value, plots = HP.State.getPlots(propertyId), harvested = 0, totalYield = 0, qualities = {};
        for (var i = 0; i < plots.length; i++) {
            var plot = plots[i];
            if (plot.status === 'harvest') {
                var result = HP.Growing.harvestPlant(plot);
                if (result.success) {
                    HP.State.addWeed(result.quality, result.yield);
                    if (HP.Progression && HP.Progression.calculateXPForHarvest) HP.State.addXP(HP.Progression.calculateXPForHarvest(plot, result));
                    else HP.State.addXP(HP.Data.Constants.XP_PER_HARVEST);
                    HP.State.incrementStat('plantsGrown', 1);
                    if (result.yield && HP.State.getStat('bestHarvest') != null && result.yield > HP.State.getStat('bestHarvest')) HP.State.setStat('bestHarvest', result.yield);
                    if (result.quality && HP.State.getStat('harvestedByQuality') != null) {
                        var byQual = HP.State.getStat('harvestedByQuality');
                        byQual[result.quality] = (byQual[result.quality] || 0) + result.yield;
                        HP.State.setStat('harvestedByQuality', byQual);
                    }
                    harvested++;
                    totalYield += result.yield;
                    qualities[result.quality] = (qualities[result.quality] || 0) + result.yield;
                }
            }
        }
        if (harvested > 0) {
            var qualityStr = Object.keys(qualities).map(function(q) { return qualities[q] + 'g ' + q; }).join(', ');
            var plotsEl = document.getElementById('plots-grid');
            if (HP.Particles && plotsEl) HP.Particles.emitHarvest({ element: plotsEl });
            if (HP.SoundManager) HP.SoundManager.play('harvest');
            HP.Notifications.success('🌿 Harvested ' + harvested + ' plant' + (harvested > 1 ? 's' : '') + '! (' + qualityStr + ')');
            checkAchievements();
        } else HP.Notifications.info('No plants ready to harvest');
        refreshUI();
    }

    function plantAllPlots() {
        var propertySelect = document.getElementById('property-select');
        if (!propertySelect) return;
        var propertyId = propertySelect.value, plots = HP.State.getPlots(propertyId), roomBonuses = HP.State.getRoomBonuses(propertyId), inventory = HP.State.getInventory();
        var bestSeed = null, allSeeds = HP.Data.Seeds.getAll();
        for (var seedId in allSeeds) {
            var seed = allSeeds[seedId];
            if (inventory.seeds[seedId] > 0 && (!bestSeed || seed.cost > bestSeed.cost)) bestSeed = seed;
        }
        if (!bestSeed) { HP.Notifications.error('No seeds in inventory!'); return; }
        var planted = 0;
        for (var i = 0; i < plots.length; i++) {
            var plot = plots[i];
            if ((plot.status === 'empty' || plot.status === 'setup') && HP.State.getSeeds(bestSeed.id) > 0) {
                var result = HP.Growing.plantSeed(plot, bestSeed.id, roomBonuses, propertyId);
                if (result.success) {
                    HP.State.removeSeeds(bestSeed.id, 1);
                    planted++;
                    if (HP.Progression && HP.Progression.calculateXPForPlanting) HP.State.addXP(HP.Progression.calculateXPForPlanting(bestSeed.id));
                    else if (HP.Data.Constants.XP_PER_SEED_PLANTED) HP.State.addXP(HP.Data.Constants.XP_PER_SEED_PLANTED);
                }
            }
        }
        if (planted > 0) HP.Notifications.success('🌱 Planted ' + planted + ' plot' + (planted > 1 ? 's' : '') + ' with ' + bestSeed.name);
        else HP.Notifications.info('No plots ready to plant');
        refreshUI();
    }

    function installBestEquipment() {
        var propertySelect = document.getElementById('property-select');
        if (!propertySelect) return;
        var propertyId = propertySelect.value, plots = HP.State.getPlots(propertyId), inventory = HP.State.getInventory(), playerLevel = HP.State.getLevel();
        var installed = 0, slots = ['pot', 'soil', 'light', 'fan', 'fertilizer'];
        for (var i = 0; i < plots.length; i++) {
            var plot = plots[i];
            if (plot.status !== 'empty' && plot.status !== 'setup') continue;
            for (var s = 0; s < slots.length; s++) {
                var slot = slots[s];
                if (plot.equipment[slot]) continue;
                var bestEquip = null, allEquip = HP.Data.Equipment.getAll();
                for (var equipId in allEquip) {
                    var equip = allEquip[equipId];
                    var equipSlot = equip.slot || HP.Growing.getEquipmentSlot(equip);
                    if (equipSlot === slot && inventory.equipment[equipId] > 0 && equip.unlockLevel <= playerLevel) {
                        if (!bestEquip || equip.cost > bestEquip.cost) bestEquip = equip;
                    }
                }
                if (bestEquip) {
                    var result = HP.Growing.installEquipment(plot, bestEquip.id);
                    if (result.success) { HP.State.removeEquipment(bestEquip.id, 1); installed++; }
                }
            }
        }
        if (installed > 0) HP.Notifications.success('⚙️ Installed ' + installed + ' equipment piece' + (installed > 1 ? 's' : ''));
        else HP.Notifications.info('No equipment to install or plots already equipped');
        refreshUI();
    }

    function bindRoomUpgradeToggle() {
        var openBtn = document.getElementById('btn-room-upgrades');
        var closeBtn = document.getElementById('btn-close-upgrades');
        if (openBtn) openBtn.addEventListener('click', function() { HP.Renderer.toggleRoomUpgradesPanel(true); });
        if (closeBtn) closeBtn.addEventListener('click', function() { HP.Renderer.toggleRoomUpgradesPanel(false); });
    }

    function installEquipment(propertyId, plotIndex, equipmentId) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) { HP.Notifications.error('Invalid plot'); return; }
        if (HP.State.getEquipment(equipmentId) < 1) { HP.Notifications.error('Equipment not in inventory'); return; }
        var result = HP.Growing.installEquipment(plot, equipmentId);
        if (result.success) {
            HP.State.removeEquipment(equipmentId, 1);
            HP.Notifications.success(result.message);
            if (HP.Progression && HP.Progression.calculateXPForEquipmentInstall) HP.State.addXP(HP.Progression.calculateXPForEquipmentInstall(equipmentId));
            else if (HP.Data.Constants.XP_PER_EQUIPMENT_INSTALL) HP.State.addXP(HP.Data.Constants.XP_PER_EQUIPMENT_INSTALL);
        } else HP.Notifications.error(result.message);
        refreshUI();
    }

    function plantSeed(propertyId, plotIndex, seedId) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) { HP.Notifications.error('Invalid plot'); return; }
        if (HP.State.getSeeds(seedId) < 1) { HP.Notifications.error('No seeds in inventory'); return; }
        var roomBonuses = HP.State.getRoomBonuses(propertyId);
        var result = HP.Growing.plantSeed(plot, seedId, roomBonuses, propertyId);
        if (result.success) {
            HP.State.removeSeeds(seedId, 1);
            HP.Notifications.success(result.message);
            if (HP.Progression && HP.Progression.calculateXPForPlanting) HP.State.addXP(HP.Progression.calculateXPForPlanting(seedId));
            else if (HP.Data.Constants.XP_PER_SEED_PLANTED) HP.State.addXP(HP.Data.Constants.XP_PER_SEED_PLANTED);
            if (HP.SoundManager) HP.SoundManager.play('plant');
            checkTutorialProgress();
        } else HP.Notifications.error(result.message);
        refreshUI();
    }

    function waterPlant(propertyId, plotIndex, canId) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) { HP.Notifications.error('Invalid plot'); return; }
        if (HP.State.getEquipment(canId) < 1) { HP.Notifications.error('No watering can in inventory'); return; }
        var can = HP.Data.Equipment.get(canId);
        if (!can || !can.waterAmount) { HP.Notifications.error('Invalid watering equipment'); return; }
        var waterCost = HP.Data.Constants && HP.Data.Constants.WATER_COST_PER_USE != null ? HP.Data.Constants.WATER_COST_PER_USE : 1;
        if (HP.State.getWaterReservoir().current < waterCost) { HP.Notifications.error('Out of water. Refill at the tap.'); return; }
        var result = HP.Growing.waterPlant(plot, can.waterAmount);
        if (result.success) {
            HP.State.useWater(waterCost);
            HP.State.incrementStat('plantsWatered', 1);
            HP.Notifications.success('💧 Watered! +' + can.waterAmount + 's hydration');
            if (HP.SoundManager) HP.SoundManager.play('water');
            checkTutorialProgress();
        } else HP.Notifications.error(result.message);
        refreshUI();
    }

    function harvestPlant(propertyId, plotIndex) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) { HP.Notifications.error('Invalid plot'); return; }
        var result = HP.Growing.harvestPlant(plot);
        if (result.success) {
            HP.State.addWeed(result.quality, result.yield);
            if (HP.Progression && HP.Progression.calculateXPForHarvest) HP.State.addXP(HP.Progression.calculateXPForHarvest(plot, result));
            else HP.State.addXP(HP.Data.Constants.XP_PER_HARVEST);
            HP.State.incrementStat('plantsGrown', 1);
            var stats = HP.State.getStats();
            if (result.yield > (stats.bestHarvest || 0)) HP.State.setStat('bestHarvest', result.yield);
            
            // Track strain mastery
            if (plot.plant && plot.plant.seedId && HP.State.incrementStrainHarvests) {
                var masteryResult = HP.State.incrementStrainHarvests(plot.plant.seedId);
                if (masteryResult.leveledUp) {
                    var seed = HP.Data.Seeds.get(plot.plant.seedId);
                    var seedName = seed ? seed.name : 'strain';
                    HP.Notifications.info('🌟 Mastery Level Up! ' + seedName + ' → Level ' + masteryResult.newLevel);
                }
            }
            
            var plotCard = document.querySelector('.plot-card[data-property="' + propertyId + '"][data-index="' + plotIndex + '"]');
            if (HP.Particles && plotCard) HP.Particles.emitHarvest({ element: plotCard });
            if (HP.SoundManager) HP.SoundManager.play('harvest');
            HP.Notifications.success(result.message);
            if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
            checkTutorialProgress();
            if (HP.Renderer && HP.Renderer.updateAfterHarvest) HP.Renderer.updateAfterHarvest();
        } else HP.Notifications.error(result.message);
        refreshUI();
        requestAnimationFrame(function() { refreshUI(); });
    }

    function clearDeadPlant(propertyId, plotIndex) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) return;
        HP.Growing.clearDeadPlant(plot);
        HP.Notifications.info('Cleared dead plant');
        refreshUI();
    }

    function uninstallEquipment(propertyId, plotIndex, slot) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) { HP.Notifications.error('Invalid plot'); return; }
        var result = HP.Growing.uninstallEquipment(plot, slot);
        if (result.success) {
            var equip = HP.Data.Equipment.get(result.equipmentId);
            if (equip && !equip.consumable) {
                HP.State.addEquipment(result.equipmentId, 1);
                HP.Notifications.success(result.message + ' - returned to inventory');
            } else HP.Notifications.info(result.message + ' - discarded');
        } else HP.Notifications.error(result.message);
        refreshUI();
    }

    function bindPlotActionDelegation() {
        document.body.addEventListener('click', function(e) {
            var target = e.target;
            if (!target.closest) return;
            var plotButtonsPanel = target.closest('#plot-buttons');
            if (!plotButtonsPanel) return;

            var harvestBtn = target.closest('.harvest-btn');
            if (harvestBtn) {
                e.preventDefault(); e.stopPropagation();
                var propId = harvestBtn.getAttribute('data-property');
                var plotIdx = parseInt(harvestBtn.getAttribute('data-plot-index'), 10);
                if (propId && !isNaN(plotIdx)) harvestPlant(propId, plotIdx);
                return;
            }

            var clearBtn = target.closest('.btn-clear-dead');
            if (clearBtn) {
                e.preventDefault(); e.stopPropagation();
                var propId = clearBtn.getAttribute('data-property');
                var plotIdx = parseInt(clearBtn.getAttribute('data-plot-index'), 10);
                if (propId && !isNaN(plotIdx)) clearDeadPlant(propId, plotIdx);
                return;
            }

            var sel = HP.Renderer && HP.Renderer.getSelectedPlot ? HP.Renderer.getSelectedPlot() : null;

            var plantBtn = target.closest('.plant-seed');
            if (plantBtn && sel) {
                e.preventDefault(); e.stopPropagation();
                var seedId = plantBtn.getAttribute('data-seed');
                if (seedId) plantSeed(sel.propertyId, sel.plotIndex, seedId);
                return;
            }

            var waterBtn = target.closest('.water-btn');
            if (waterBtn && sel) {
                e.preventDefault(); e.stopPropagation();
                var canId = waterBtn.getAttribute('data-can');
                if (canId) waterPlant(sel.propertyId, sel.plotIndex, canId);
                return;
            }

            var installBtn = target.closest('.install-equip');
            if (installBtn && sel) {
                e.preventDefault(); e.stopPropagation();
                var equipId = installBtn.getAttribute('data-equip');
                if (equipId) installEquipment(sel.propertyId, sel.plotIndex, equipId);
                return;
            }

            var uninstallBtn = target.closest('.uninstall-equip');
            if (uninstallBtn && sel) {
                e.preventDefault(); e.stopPropagation();
                var slot = uninstallBtn.getAttribute('data-slot');
                if (slot) uninstallEquipment(sel.propertyId, sel.plotIndex, slot);
                return;
            }

            var storeBtn = target.closest('.go-to-store-btn');
            if (storeBtn) {
                e.preventDefault(); e.stopPropagation();
                var view = storeBtn.getAttribute('data-view');
                if (view && HP.Renderer && HP.Renderer.switchView) HP.Renderer.switchView(view);
            }
        });
    }

    function bindQuickActions() {
        var waterAllBtn = document.getElementById('btn-water-all');
        var harvestAllBtn = document.getElementById('btn-harvest-all');
        var plantAllBtn = document.getElementById('btn-plant-all');
        var installBestBtn = document.getElementById('btn-install-best');
        var selectModeBtn = document.getElementById('btn-select-mode');
        var clearSelectionBtn = document.getElementById('btn-clear-selection');
        if (waterAllBtn) waterAllBtn.addEventListener('click', waterAllPlants);
        if (harvestAllBtn) harvestAllBtn.addEventListener('click', harvestAllPlants);
        if (plantAllBtn) plantAllBtn.addEventListener('click', plantAllPlots);
        if (installBestBtn) installBestBtn.addEventListener('click', installBestEquipment);
        if (selectModeBtn) selectModeBtn.addEventListener('click', function() { HP.Renderer.toggleBulkSelectMode(); });
        if (clearSelectionBtn) clearSelectionBtn.addEventListener('click', function() { HP.Renderer.clearSelection(); });
        var bulkWaterBtn = document.getElementById('btn-bulk-water');
        var bulkHarvestBtn = document.getElementById('btn-bulk-harvest');
        var bulkPlantBtn = document.getElementById('btn-bulk-plant');
        var bulkInstallBtn = document.getElementById('btn-bulk-install');
        var bulkClearBtn = document.getElementById('btn-bulk-clear');
        if (bulkWaterBtn) bulkWaterBtn.addEventListener('click', bulkWaterSelected);
        if (bulkHarvestBtn) bulkHarvestBtn.addEventListener('click', bulkHarvestSelected);
        if (bulkPlantBtn) bulkPlantBtn.addEventListener('click', bulkPlantSelected);
        if (bulkInstallBtn) bulkInstallBtn.addEventListener('click', bulkInstallEquipment);
        if (bulkClearBtn) bulkClearBtn.addEventListener('click', bulkClearSelected);
    }

    function bind() {
        bindPlotActionDelegation();
        bindQuickActions();
        bindRoomUpgradeToggle();
    }

    HP.Events.PlotActions = {
        bind: bind,
        installEquipment: installEquipment,
        uninstallEquipment: uninstallEquipment,
        plantSeed: plantSeed,
        waterPlant: waterPlant,
        harvestPlant: harvestPlant,
        clearDeadPlant: clearDeadPlant,
        waterAllPlants: waterAllPlants,
        harvestAllPlants: harvestAllPlants,
        plantAllPlots: plantAllPlots
    };
})();
