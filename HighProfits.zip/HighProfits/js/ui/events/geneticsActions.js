/**
 * Genetics (breeding lab) actions: parent selects, breed button, library filters.
 */
(function() {
    'use strict';
    var refreshUI = function() { HP.Events.refreshUI(); };
    var checkAchievements = function() { HP.Events.checkAchievements(); };

    function performBreeding() {
        var parent1Select = document.getElementById('parent1-select');
        var parent2Select = document.getElementById('parent2-select');
        if (!parent1Select || !parent2Select) return;
        var p1Id = parent1Select.value;
        var p2Id = parent2Select.value;
        if (!p1Id || !p2Id) { HP.Notifications.error('Select both parent seeds'); return; }
        if (p1Id === p2Id) { HP.Notifications.error('Parents must be different strains'); return; }
        var inventory = HP.State.getInventory();
        if (!inventory.seeds[p1Id] || inventory.seeds[p1Id] < 1) {
            HP.Notifications.error('Not enough ' + HP.Data.Seeds.get(p1Id).name);
            return;
        }
        if (!inventory.seeds[p2Id] || inventory.seeds[p2Id] < 1) {
            HP.Notifications.error('Not enough ' + HP.Data.Seeds.get(p2Id).name);
            return;
        }
        var result = HP.Genetics.breedStrains(p1Id, p2Id);
        if (!result.success) { HP.Notifications.error(result.error || 'Breeding failed'); return; }
        HP.State.removeSeeds(p1Id, 1);
        HP.State.removeSeeds(p2Id, 1);
        HP.State.addCustomStrain(result.hybrid);
        HP.State.addSeeds(result.hybrid.id, 1);
        if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
        var message = '🧬 Created ' + result.hybrid.name + '!';
        if (result.mutations && result.mutations.length > 0) message += ' ✨ ' + result.mutations.length + ' mutation(s)!';
        HP.Notifications.success(message);
        if (HP.SoundManager) HP.SoundManager.play('success');
        parent1Select.value = '';
        parent2Select.value = '';
        checkAchievements();
        if (HP.Tutorial) HP.Tutorial.checkProgress();
        refreshUI();
    }

    function bind() {
        var parent1Select = document.getElementById('parent1-select');
        var parent2Select = document.getElementById('parent2-select');
        var breedBtn = document.getElementById('btn-breed');
        var filterType = document.getElementById('library-filter-type');
        var filterQuality = document.getElementById('library-filter-quality');
        var librarySortBy = document.getElementById('library-sort-by');
        var librarySearch = document.getElementById('library-search');
        var updateLibrary = function() { if (HP.Renderer && HP.Renderer.update) HP.Renderer.update(); };
        if (filterType) filterType.addEventListener('change', updateLibrary);
        if (filterQuality) filterQuality.addEventListener('change', updateLibrary);
        if (librarySortBy) librarySortBy.addEventListener('change', updateLibrary);
        if (librarySearch) {
            librarySearch.addEventListener('input', updateLibrary);
            librarySearch.addEventListener('keydown', function(e) { e.stopPropagation(); });
        }
        if (parent1Select) parent1Select.addEventListener('change', function() { if (HP.Renderer && HP.Renderer.update) HP.Renderer.update(); });
        if (parent2Select) parent2Select.addEventListener('change', function() { if (HP.Renderer && HP.Renderer.update) HP.Renderer.update(); });
        if (breedBtn) breedBtn.addEventListener('click', performBreeding);
    }

    HP.Events.GeneticsActions = { bind: bind };
})();
