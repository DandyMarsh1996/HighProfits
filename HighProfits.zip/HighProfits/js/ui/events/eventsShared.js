/**
 * Shared helpers for event modules. Load first so domain modules can use HP.Events.refreshUI etc.
 */
var HP = HP || {};
HP.Events = HP.Events || {};

HP.Events.refreshUI = function() {
    if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
};

HP.Events.checkAchievements = function() {
    var newlyUnlocked = HP.State.checkAchievements();
    if (newlyUnlocked > 0) {
        var achievements = HP.State.getAchievements();
        var notifications = achievements.notifications;
        for (var i = 0; i < notifications.length; i++) {
            var achievement = HP.Data.Achievements.get(notifications[i]);
            if (achievement) {
                HP.Notifications.achievement(achievement);
            }
        }
        HP.State.clearAchievementNotifications();
    }
};

HP.Events.checkTutorialProgress = function() {
    if (HP.Tutorial && HP.Tutorial.isActive && HP.Tutorial.isActive()) {
        HP.Tutorial.checkProgress();
    }
};
