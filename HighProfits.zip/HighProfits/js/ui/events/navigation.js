/**
 * Navigation: nav buttons, property selector, keyboard shortcuts, arrow-key grid nav, modal focus, achievement/challenge filters.
 */
(function() {
    'use strict';

    function moveFocusInGrid(containerSelector, itemSelector, direction, onEnter) {
        var container = document.querySelector(containerSelector);
        if (!container) return;
        var items = container.querySelectorAll(itemSelector);
        if (items.length === 0) return;

        var current = container.querySelector(itemSelector + ':focus');
        var index = -1;
        if (current) {
            for (var i = 0; i < items.length; i++) { if (items[i] === current) { index = i; break; } }
        }
        if (index < 0) index = 0;

        var next = index + (direction === 'next' ? 1 : -1);
        if (next < 0) next = items.length - 1;
        if (next >= items.length) next = 0;
        items[next].focus();
    }

    function handleArrowKeyNav(e) {
        var view = HP.Renderer && HP.Renderer.getCurrentView ? HP.Renderer.getCurrentView() : '';
        var selector, containerSelector, onEnter;

        if (view === 'grow') {
            containerSelector = '#plots-grid';
            selector = '.plot-card';
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                e.preventDefault();
                var grid = document.querySelector(containerSelector);
                if (!grid) return;
                var cards = grid.querySelectorAll(selector);
                var propSelect = document.getElementById('property-select');
                var propertyId = propSelect ? propSelect.value : null;
                if (!propertyId || cards.length === 0) return;
                var sel = HP.Renderer.getSelectedPlot();
                var currentIdx = sel && sel.propertyId === propertyId ? sel.plotIndex : -1;
                var nextIdx = currentIdx + 1;
                if (nextIdx >= cards.length) nextIdx = 0;
                HP.Renderer.selectPlot(propertyId, nextIdx);
                if (cards[nextIdx]) cards[nextIdx].focus();
                return true;
            }
            if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                e.preventDefault();
                grid = document.querySelector(containerSelector);
                if (!grid) return;
                cards = grid.querySelectorAll(selector);
                propSelect = document.getElementById('property-select');
                propertyId = propSelect ? propSelect.value : null;
                if (!propertyId || cards.length === 0) return;
                sel = HP.Renderer.getSelectedPlot();
                currentIdx = sel && sel.propertyId === propertyId ? sel.plotIndex : -1;
                nextIdx = currentIdx <= 0 ? cards.length - 1 : currentIdx - 1;
                HP.Renderer.selectPlot(propertyId, nextIdx);
                if (cards[nextIdx]) cards[nextIdx].focus();
                return true;
            }
        }

        if (view === 'market') {
            containerSelector = '#customers-grid';
            selector = '.customer-card:not(.locked)';
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                e.preventDefault();
                moveFocusInGrid(containerSelector, selector, 'next');
                return true;
            }
            if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                e.preventDefault();
                moveFocusInGrid(containerSelector, selector, 'prev');
                return true;
            }
            if (e.key === 'Enter') {
                var focused = document.activeElement;
                if (focused && focused.classList && focused.classList.contains('customer-card') && !focused.classList.contains('locked')) {
                    var customerId = focused.getAttribute('data-customer');
                    if (customerId && HP.Renderer && HP.Renderer.openSaleModal) {
                        e.preventDefault();
                        HP.Renderer.openSaleModal(customerId);
                        return true;
                    }
                }
            }
        }

        if (view === 'hardware' || view === 'garden' || view === 'dealer' || view === 'realestate') {
            var viewContainers = { hardware: '#hardware-items', garden: '#garden-items', dealer: '#dealer-items', realestate: '#property-items' };
            containerSelector = viewContainers[view];
            if (view === 'realestate') {
                var propCont = document.querySelector('#property-items');
                var bizCont = document.querySelector('#business-items');
                containerSelector = (propCont && propCont.querySelector('.store-item')) ? '#property-items' : '#business-items';
            }
            if (containerSelector) {
                selector = '.store-item';
                if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                    e.preventDefault();
                    moveFocusInGrid(containerSelector, selector, 'next');
                    return true;
                }
                if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    moveFocusInGrid(containerSelector, selector, 'prev');
                    return true;
                }
                if (e.key === 'Enter') {
                    focused = document.activeElement;
                    if (focused && focused.classList && focused.classList.contains('store-item')) {
                        var buyBtn = focused.querySelector('.buy-btn:not([disabled])');
                        if (buyBtn) {
                            e.preventDefault();
                            buyBtn.click();
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    function bindNavigation() {
        var navBtns = document.querySelectorAll('.nav-btn');
        navBtns.forEach(function(btn) {
            btn.addEventListener('click', function() {
                var viewName = this.getAttribute('data-view');
                if (viewName) HP.Renderer.switchView(viewName);
                if (HP.SoundManager && HP.SoundManager.play) HP.SoundManager.play('click');
            });
        });
    }

    function bindPropertySelector() {
        var selector = document.getElementById('property-select');
        if (selector) selector.addEventListener('change', function() { HP.Renderer.update(); });
    }

    function bindKeyboardShortcuts() {
        document.addEventListener('keydown', function(e) {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) return;

            if (e.key === 'Enter') {
                var saleModal = document.getElementById('sale-modal');
                if (saleModal && !saleModal.classList.contains('hidden')) {
                    var sellBtn = document.getElementById('btn-sell');
                    if (sellBtn && !sellBtn.disabled) {
                        e.preventDefault();
                        sellBtn.click();
                        return;
                    }
                }
            }

            if (e.key === 'Escape') {
                if (HP.ConfirmDialog && HP.ConfirmDialog.isConfirmVisible()) { e.preventDefault(); HP.ConfirmDialog.closeConfirm(); return; }
                if (HP.ConfirmDialog && HP.ConfirmDialog.isInputVisible()) { e.preventDefault(); HP.ConfirmDialog.closeInput(); return; }
                var raidModal = document.getElementById('raid-modal');
                var heatModal = document.getElementById('heat-modal');
                var waterModal = document.getElementById('water-modal');
                var reputationModal = document.getElementById('reputation-modal');
                var statsInfoModal = document.getElementById('stats-explanation-modal');
                var saleModal = document.getElementById('sale-modal');
                var workerModal = document.getElementById('worker-assign-modal');
                if (raidModal && !raidModal.classList.contains('hidden')) { e.preventDefault(); if (HP.Renderer && HP.Renderer.closeRaidModal) HP.Renderer.closeRaidModal(); return; }
                if (heatModal && !heatModal.classList.contains('hidden')) { e.preventDefault(); if (HP.Events.HeatControls && HP.Events.HeatControls.closeHeatModal) HP.Events.HeatControls.closeHeatModal(); return; }
                if (waterModal && !waterModal.classList.contains('hidden')) { e.preventDefault(); if (HP.Events.HeatControls && HP.Events.HeatControls.closeWaterModal) HP.Events.HeatControls.closeWaterModal(); return; }
                if (reputationModal && !reputationModal.classList.contains('hidden')) { e.preventDefault(); if (HP.Events.MarketActions && HP.Events.MarketActions.closeReputationModal) HP.Events.MarketActions.closeReputationModal(); return; }
                if (statsInfoModal && !statsInfoModal.classList.contains('hidden')) { e.preventDefault(); if (HP.Events.HeatControls && HP.Events.HeatControls.closeStatsExplanationModal) HP.Events.HeatControls.closeStatsExplanationModal(); return; }
                var stockInfoModal = document.getElementById('stock-market-info-modal');
                var launderInfoModal = document.getElementById('launder-info-modal');
                var geneticsInfoModal = document.getElementById('genetics-info-modal');
                if (stockInfoModal && !stockInfoModal.classList.contains('hidden')) { e.preventDefault(); if (HP.Events.HeatControls && HP.Events.HeatControls.closeStockMarketInfoModal) HP.Events.HeatControls.closeStockMarketInfoModal(); return; }
                if (launderInfoModal && !launderInfoModal.classList.contains('hidden')) { e.preventDefault(); if (HP.Events.HeatControls && HP.Events.HeatControls.closeLaunderInfoModal) HP.Events.HeatControls.closeLaunderInfoModal(); return; }
                if (geneticsInfoModal && !geneticsInfoModal.classList.contains('hidden')) { e.preventDefault(); if (HP.Events.HeatControls && HP.Events.HeatControls.closeGeneticsInfoModal) HP.Events.HeatControls.closeGeneticsInfoModal(); return; }
                if (saleModal && !saleModal.classList.contains('hidden')) { e.preventDefault(); if (HP.Renderer && HP.Renderer.closeSaleModal) HP.Renderer.closeSaleModal(); return; }
                if (workerModal && !workerModal.classList.contains('hidden')) { e.preventDefault(); if (HP.Renderer && HP.Renderer.closeWorkerAssignModal) HP.Renderer.closeWorkerAssignModal(); return; }
                var roomPanel = document.getElementById('room-upgrades-panel');
                if (roomPanel && !roomPanel.classList.contains('hidden')) { e.preventDefault(); if (HP.Renderer && HP.Renderer.toggleRoomUpgradesPanel) HP.Renderer.toggleRoomUpgradesPanel(false); return; }
                var charCreate = document.getElementById('character-create-panel');
                var charDelete = document.getElementById('character-delete-modal');
                if (charCreate && !charCreate.classList.contains('hidden')) { e.preventDefault(); var cancelBtn = document.getElementById('btn-cancel-create'); if (cancelBtn) cancelBtn.click(); return; }
                if (charDelete && !charDelete.classList.contains('hidden')) { e.preventDefault(); var delCancel = document.getElementById('btn-delete-character-cancel'); if (delCancel) delCancel.click(); return; }
                return;
            }

            if (handleArrowKeyNav(e)) return;

            if (e.key >= '1' && e.key <= '9') {
                var views = ['grow', 'inventory', 'market', 'workers', 'genetics', 'achievements', 'challenges', 'stats', 'journal'];
                var index = parseInt(e.key) - 1;
                if (index < views.length) {
                    e.preventDefault();
                    HP.Renderer.switchView(views[index]);
                }
            }
            var key = e.key.toLowerCase();
            if (key === 'h') { e.preventDefault(); HP.Renderer.switchView('hardware'); }
            else if (key === 'g') { e.preventDefault(); HP.Renderer.switchView('garden'); }
            else if (key === 'd') { e.preventDefault(); HP.Renderer.switchView('dealer'); }
            else if (key === 'r') { e.preventDefault(); HP.Renderer.switchView('realestate'); }
            else if (key === 'b') { e.preventDefault(); HP.Renderer.switchView('genetics'); }
            else if (key === 's') { e.preventDefault(); HP.Renderer.switchView('settings'); }
        });
    }

    function bindAchievementChallengeFilters() {
        var achCat = document.getElementById('achievement-category-filter');
        var achSub = document.getElementById('achievement-sub-filter');
        var chCat = document.getElementById('challenge-category-filter');
        var chSub = document.getElementById('challenge-sub-filter');
        function refresh() { if (HP.Renderer) HP.Renderer.update(); }
        if (achCat) achCat.addEventListener('change', refresh);
        if (achSub) achSub.addEventListener('change', refresh);
        if (chCat) chCat.addEventListener('change', refresh);
        if (chSub) chSub.addEventListener('change', refresh);
    }

    function bindSkipLink() {
        var skip = document.getElementById('skip-to-main');
        var main = document.getElementById('main-content');
        if (skip && main) {
            skip.addEventListener('click', function(e) {
                main.focus({ preventScroll: false });
            });
        }
    }

    function bind() {
        bindSkipLink();
        bindNavigation();
        bindPropertySelector();
        bindKeyboardShortcuts();
        bindAchievementChallengeFilters();
    }

    HP.Events.Navigation = { bind: bind };
})();
