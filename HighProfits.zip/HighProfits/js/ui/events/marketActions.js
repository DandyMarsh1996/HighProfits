/**
 * Market/sale actions: sell modal, quick sell, customer cards.
 */
(function() {
    'use strict';
    var refreshUI = function() { HP.Events.refreshUI(); };
    var checkAchievements = function() { HP.Events.checkAchievements(); };
    var checkTutorialProgress = function() { HP.Events.checkTutorialProgress(); };

    function handleSell() {
        var customerId = HP.Renderer.getSelectedCustomer();
        if (!customerId) { HP.Notifications.error('No customer selected!'); return; }
        var customer = HP.Data.Customers.get(customerId);
        if (!customer || !customer.currentRequest) {
            HP.Notifications.error('No deal on the table. Try "New request" for a new offer.');
            return;
        }
        var quality = customer.currentRequest.quality;
        var amount = customer.currentRequest.amount;
        var available = HP.State.getWeed(quality);
        var minAllowed = customer.minAmount || 1;
        var maxAllowed = Math.min(available, customer.maxAmount || available);
        if (available < minAllowed) {
            HP.Notifications.error(customer.name + ' only buys ' + minAllowed + 'g+ (you have ' + available + 'g).');
            return;
        }
        if (amount < minAllowed) {
            HP.Notifications.error(customer.name + ' only buys ' + minAllowed + 'g or more.');
            return;
        }
        if (amount > maxAllowed) {
            HP.Notifications.error(customer.name + ' won\'t buy more than ' + customer.maxAmount + 'g at once.');
            return;
        }
        if (amount < 1) { HP.Notifications.error('Nothing to sell!'); return; }

        var priceInfo = HP.Data.Customers.calculatePrice(customerId, quality, amount);
        if (!priceInfo || priceInfo.total == null) {
            HP.Notifications.error('Could not calculate price for this deal.');
            return;
        }

        var dealEl = document.querySelector('.deal-type-btn.selected');
        var dealType = (dealEl && dealEl.getAttribute('data-deal')) || 'normal';
        var constants = HP.Data.Constants || {};
        var discountMult = constants.REP_DEAL_DISCOUNT_PRICE_MULT != null ? constants.REP_DEAL_DISCOUNT_PRICE_MULT : 0.85;
        var overchargeMult = constants.REP_DEAL_OVERCHARGE_PRICE_MULT != null ? constants.REP_DEAL_OVERCHARGE_PRICE_MULT : 1.20;
        var repDiscountGain = constants.REP_DEAL_DISCOUNT_REP_GAIN != null ? constants.REP_DEAL_DISCOUNT_REP_GAIN : 3;
        var repNormalGain = constants.REP_DEAL_NORMAL_REP_GAIN != null ? constants.REP_DEAL_NORMAL_REP_GAIN : 1;
        var repOverchargeLoss = constants.REP_DEAL_OVERCHARGE_REP_LOSS != null ? constants.REP_DEAL_OVERCHARGE_REP_LOSS : 2;

        var priceMult = 1, repDelta = 0;
        if (dealType === 'discount') { priceMult = discountMult; repDelta = repDiscountGain; }
        else if (dealType === 'overcharge') { priceMult = overchargeMult; repDelta = -repOverchargeLoss; }
        else repDelta = repNormalGain;

        var totalEarned = Math.floor(priceInfo.total * priceMult);
        var orderBonus = 0, hasOrder = false;
        if (HP.MarketOrders) {
            if (HP.MarketOrders.matchesOrder(customerId, quality, amount)) {
                orderBonus = HP.MarketOrders.getOrderBonus(customerId, quality, amount);
                HP.MarketOrders.fulfillOrder(customerId);
                hasOrder = true;
            }
        }
        totalEarned += orderBonus;

        if (HP.State.addCustomerReputation) HP.State.addCustomerReputation(customerId, repDelta);
        HP.State.removeWeed(quality, amount);
        HP.State.addCash(totalEarned);
        HP.State.incrementStat('totalSold', amount);
        if (totalEarned && HP.State.getStat('biggestSale') != null && totalEarned > HP.State.getStat('biggestSale')) HP.State.setStat('biggestSale', totalEarned);
        if (HP.Progression && HP.Progression.calculateXPForSale) HP.State.addXP(HP.Progression.calculateXPForSale(totalEarned, quality, amount, hasOrder));
        else HP.State.addXP(HP.Data.Constants.XP_PER_SALE * amount);

        customer.currentRequest = null;
        var message = 'Sold ' + amount + 'g ' + quality + ' to ' + customer.name + ' for $' + HP.Helpers.formatNumber(totalEarned);
        var moneyEl = document.getElementById('money-display');
        if (HP.Particles && moneyEl) HP.Particles.emitSale({ element: moneyEl });
        if (HP.SoundManager) HP.SoundManager.play('sale');
        if (hasOrder) { message += ' (+$' + HP.Helpers.formatNumber(orderBonus) + ' order bonus!)'; }
        HP.Notifications.success(message);
        HP.State.incrementStat('totalSales', 1);
        if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
        checkAchievements();
        checkTutorialProgress();
        if (HP.Renderer) { HP.Renderer.closeSaleModal(); HP.Renderer.updateAfterSale(); }
        refreshUI();
        requestAnimationFrame(function() { refreshUI(); });
    }

    function quickSellOrder(customerId, quality, amount) {
        var inventory = HP.State.getInventory();
        if (inventory.weed[quality] < amount) {
            HP.Notifications.error('Not enough ' + quality + ' quality product!');
            return;
        }
        var customer = HP.Data.Customers.get(customerId);
        if (!customer) return;
        var order = HP.MarketOrders.getOrder(customerId);
        if (!order) { HP.Notifications.error('Order expired!'); return; }

        var totalEarned = order.bonusPrice;
        HP.State.removeWeed(quality, amount);
        HP.State.addCash(totalEarned);
        HP.State.incrementStat('totalSold', amount);
        if (totalEarned && HP.State.getStat('biggestSale') != null && totalEarned > HP.State.getStat('biggestSale')) HP.State.setStat('biggestSale', totalEarned);
        if (HP.Progression && HP.Progression.calculateXPForSale) HP.State.addXP(HP.Progression.calculateXPForSale(totalEarned, quality, amount, true));
        else HP.State.addXP(HP.Data.Constants.XP_PER_SALE * amount);
        HP.MarketOrders.fulfillOrder(customerId);

        var orderBonus = order.bonusPrice - order.basePrice;
        var message = '✅ Sold ' + amount + 'g ' + quality + ' to ' + customer.name + ' for $' + HP.Helpers.formatNumber(totalEarned) + ' (+$' + HP.Helpers.formatNumber(orderBonus) + ' order bonus!)';
        var moneyEl = document.getElementById('money-display');
        if (HP.Particles && moneyEl) HP.Particles.emitSale({ element: moneyEl });
        if (HP.SoundManager) HP.SoundManager.play('sale');
        HP.Notifications.success(message);
        HP.State.incrementStat('totalSales', 1);
        if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
        checkAchievements();
        checkTutorialProgress();
        refreshUI();
        setTimeout(function() { refreshUI(); }, 0);
    }

    function openReputationModal() {
        var explanationEl = document.getElementById('reputation-explanation');
        var dealersEl = document.getElementById('reputation-dealers');
        var modalEl = document.getElementById('reputation-modal');
        if (!explanationEl || !dealersEl || !modalEl) return;

        var constants = HP.Data.Constants || {};
        var thresholds = (constants.REP_THRESHOLDS || [10, 25, 50, 100, 200]).slice();
        var bonusPerTier = (constants.REP_BONUS_PER_THRESHOLD != null) ? constants.REP_BONUS_PER_THRESHOLD : 0.03;
        var bonusPct = Math.round(bonusPerTier * 100);

        var explain = 'Reputation is earned separately with each dealer when you sell. Higher rep unlocks better sale prices with that dealer. ' +
            '<strong>Deal types:</strong> Normal (+1 rep), Give discount (+3 rep, sell 15% cheaper), Overcharge (−2 rep, charge 20% more). ' +
            'For each reputation threshold you pass (10, 25, 50, 100, 200), you get <strong>+' + bonusPct + '%</strong> to sale prices with that dealer.';
        explanationEl.innerHTML = explain;

        var allCustomers = HP.Data.Customers && HP.Data.Customers.getAll ? HP.Data.Customers.getAll() : {};
        var playerLevel = HP.State && HP.State.getLevel ? HP.State.getLevel() : 1;
        var html = '';
        for (var id in allCustomers) {
            var customer = allCustomers[id];
            if (customer.unlockLevel > playerLevel) continue;
            var rep = (HP.State && HP.State.getCustomerReputation) ? HP.State.getCustomerReputation(id) : 0;
            var repBonus = HP.Data.Customers.getReputationBonus ? HP.Data.Customers.getReputationBonus(id) : 1;
            var tiers = 0;
            for (var t = 0; t < thresholds.length; t++) { if (rep >= thresholds[t]) tiers++; }
            var nextThreshold = null;
            for (var n = 0; n < thresholds.length; n++) { if (rep < thresholds[n]) { nextThreshold = thresholds[n]; break; } }
            var tierLabel = nextThreshold != null ? 'Tier ' + tiers + ' (next: ' + nextThreshold + ')' : 'Max tier';
            var bonusLabel = tiers > 0 ? '+' + Math.round((repBonus - 1) * 100) + '% price' : '—';

            html += '<div class="reputation-dealer-row">';
            html += '<span class="dealer-icon">' + (customer.icon || '🤝') + '</span>';
            html += '<span class="dealer-name">' + (customer.name || id) + '</span>';
            html += '<span class="dealer-rep">' + rep + ' rep</span>';
            html += '<span class="dealer-tier">' + tierLabel + '</span>';
            html += '<span class="dealer-bonus">' + bonusLabel + '</span>';
            html += '</div>';
        }
        dealersEl.innerHTML = html || '<p class="empty-state">No dealers unlocked yet.</p>';
        modalEl.classList.remove('hidden');
    }

    function closeReputationModal() {
        var modalEl = document.getElementById('reputation-modal');
        if (modalEl) modalEl.classList.add('hidden');
    }

    function bindSellControls() {
        document.body.addEventListener('click', function(e) {
            var target = e.target;
            if (target.closest && target.closest('#btn-reputation')) {
                e.preventDefault(); e.stopPropagation();
                openReputationModal();
                return;
            }
            if (target.closest && target.closest('#btn-close-reputation')) {
                e.preventDefault(); e.stopPropagation();
                closeReputationModal();
                return;
            }
            if (target.closest && target.closest('#btn-sell')) {
                e.preventDefault(); e.stopPropagation();
                handleSell();
                return;
            }
            if (target.closest && target.closest('#btn-close-sale')) {
                e.preventDefault(); e.stopPropagation();
                if (HP.Renderer) HP.Renderer.closeSaleModal();
                return;
            }
            if (target.closest && target.closest('#btn-new-request')) {
                e.preventDefault(); e.stopPropagation();
                if (HP.Renderer && HP.Renderer.regenerateCustomerRequest) HP.Renderer.regenerateCustomerRequest();
                return;
            }
            if (target.closest && target.closest('.deal-type-btn')) {
                var btn = target.closest('.deal-type-btn');
                if (btn) {
                    e.preventDefault(); e.stopPropagation();
                    document.querySelectorAll('.deal-type-btn').forEach(function(b) { b.classList.remove('selected'); });
                    btn.classList.add('selected');
                    if (HP.Renderer && HP.Renderer.updateSellTotal) HP.Renderer.updateSellTotal();
                }
                return;
            }
            if (target.closest && target.closest('.btn-order-deal')) {
                var dealBtn = target.closest('.btn-order-deal');
                if (dealBtn) {
                    e.preventDefault(); e.stopPropagation();
                    var customerId = dealBtn.getAttribute('data-customer-id');
                    if (customerId && HP.Renderer && HP.Renderer.openSaleModal) HP.Renderer.openSaleModal(customerId);
                }
                return;
            }
            if (target.closest && target.closest('.btn-order-quick-sell')) {
                var qsBtn = target.closest('.btn-order-quick-sell');
                if (qsBtn) {
                    e.preventDefault(); e.stopPropagation();
                    var customerId = qsBtn.getAttribute('data-customer-id');
                    var quality = qsBtn.getAttribute('data-quality');
                    var amount = parseInt(qsBtn.getAttribute('data-amount'), 10);
                    if (customerId && quality && !isNaN(amount)) quickSellOrder(customerId, quality, amount);
                }
                return;
            }
            if (target.closest && target.closest('.customer-card:not(.locked)')) {
                var card = target.closest('.customer-card');
                if (card) {
                    e.preventDefault(); e.stopPropagation();
                    var customerId = card.getAttribute('data-customer');
                    if (customerId && HP.Renderer && HP.Renderer.openSaleModal) HP.Renderer.openSaleModal(customerId);
                }
            }
        });
    }

    HP.Events.MarketActions = {
        bind: bindSellControls,
        handleSell: handleSell,
        quickSellOrder: quickSellOrder
    };
})();
