/**
 * Market/sale actions: sell modal, quick sell, customer cards.
 */
(function() {
    'use strict';
    var refreshUI = function() { HP.Events.refreshUI(); };
    var checkAchievements = function() { HP.Events.checkAchievements(); };
    var checkTutorialProgress = function() { HP.Events.checkTutorialProgress(); };

    function handleSell() {
        var customerId = HP.Renderer.getSelectedCustomer();
        if (!customerId) { HP.Notifications.error('No customer selected!'); return; }
        var customer = HP.Data.Customers.get(customerId);
        if (!customer || !customer.currentRequest) {
            HP.Notifications.error('No deal on the table. Try "New request" for a new offer.');
            return;
        }
        var seedId = customer.currentRequest.seedId;
        var amount = customer.currentRequest.amount;
        var isMixed = seedId && seedId.indexOf('mixed:') === 0;
        var blendKey = isMixed ? seedId.slice(6) : null;
        var blend = isMixed && HP.State.getMixed ? HP.State.getMixed(blendKey) : null;
        var available = isMixed ? (blend ? blend.amount : 0) : (HP.State.getWeed(seedId) || 0);
        var minAllowed = customer.minAmount || 1;
        var maxAllowed = Math.min(available, customer.maxAmount || available);
        var seed = isMixed ? null : (HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedId) : null);
        var strainName;
        if (isMixed && blend) {
            var s1 = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(blend.seedId1) : null;
            var s2 = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(blend.seedId2) : null;
            strainName = (s1 ? (s1.strainName || s1.name) : blend.seedId1) + ' + ' + (s2 ? (s2.strainName || s2.name) : blend.seedId2);
        } else {
            strainName = seed ? (seed.strainName || seed.name) : seedId;
        }
        if (available < minAllowed) {
            HP.Notifications.error(customer.name + ' only buys ' + minAllowed + 'g+ (you have ' + available + 'g ' + strainName + ').');
            return;
        }
        if (amount < minAllowed) {
            HP.Notifications.error(customer.name + ' only buys ' + minAllowed + 'g or more.');
            return;
        }
        if (amount > maxAllowed) {
            HP.Notifications.error(customer.name + ' won\'t buy more than ' + customer.maxAmount + 'g at once.');
            return;
        }
        if (amount < 1) { HP.Notifications.error('Nothing to sell!'); return; }

        var priceInfo = isMixed && blend
            ? HP.Data.Customers.calculatePrice(customerId, null, amount, { quality: blend.quality, mixedMarkup: true })
            : HP.Data.Customers.calculatePrice(customerId, seedId, amount);
        if (!priceInfo || priceInfo.total == null) {
            HP.Notifications.error('Could not calculate price for this deal.');
            return;
        }

        var dealEl = document.querySelector('.deal-type-btn.selected');
        var dealType = (dealEl && dealEl.getAttribute('data-deal')) || 'normal';
        var constants = HP.Data.Constants || {};
        var discountMult = constants.REP_DEAL_DISCOUNT_PRICE_MULT != null ? constants.REP_DEAL_DISCOUNT_PRICE_MULT : 0.85;
        var overchargeMult = constants.REP_DEAL_OVERCHARGE_PRICE_MULT != null ? constants.REP_DEAL_OVERCHARGE_PRICE_MULT : 1.20;
        var repDiscountGain = constants.REP_DEAL_DISCOUNT_REP_GAIN != null ? constants.REP_DEAL_DISCOUNT_REP_GAIN : 3;
        var repNormalGain = constants.REP_DEAL_NORMAL_REP_GAIN != null ? constants.REP_DEAL_NORMAL_REP_GAIN : 1;
        var repOverchargeLoss = constants.REP_DEAL_OVERCHARGE_REP_LOSS != null ? constants.REP_DEAL_OVERCHARGE_REP_LOSS : 2;

        var priceMult = 1, repDelta = 0;
        if (dealType === 'discount') { priceMult = discountMult; repDelta = repDiscountGain; }
        else if (dealType === 'overcharge') { priceMult = overchargeMult; repDelta = -repOverchargeLoss; }
        else repDelta = repNormalGain;
        if (HP.Data.StrainEffects && HP.Data.StrainEffects.getRepBonus && seed) repDelta += HP.Data.StrainEffects.getRepBonus(seed);
        if (HP.State && HP.State.getRepBonus) repDelta += HP.State.getRepBonus();

        var totalEarned = Math.floor(priceInfo.total * priceMult);
        var orderBonus = 0, hasOrder = false;
        if (HP.MarketOrders && !isMixed) {
            if (HP.MarketOrders.matchesOrder(customerId, seedId, amount)) {
                orderBonus = HP.MarketOrders.getOrderBonus(customerId, seedId, amount);
                HP.MarketOrders.fulfillOrder(customerId);
                hasOrder = true;
            }
        }
        totalEarned += orderBonus;

        var heatGain = 0;
        if (HP.Heat && HP.Heat.calculateHeatGain && HP.State.addHeat) {
            heatGain = HP.Heat.calculateHeatGain('manual_sale', amount);
            if (heatGain > 0) HP.State.addHeat(heatGain);
        }

        if (HP.State.addCustomerReputation) HP.State.addCustomerReputation(customerId, repDelta);
        if (isMixed) HP.State.removeMixed(blendKey, amount);
        else HP.State.removeWeed(seedId, amount);
        HP.State.addCash(totalEarned);
        HP.State.incrementStat('totalSold', amount);
        if (totalEarned && HP.State.getStat('biggestSale') != null && totalEarned > HP.State.getStat('biggestSale')) HP.State.setStat('biggestSale', totalEarned);
        var qualityForXP = priceInfo.quality || (seed ? seed.quality : 'medium');
        if (HP.Progression && HP.Progression.calculateXPForSale) HP.State.addXP(HP.Progression.calculateXPForSale(totalEarned, qualityForXP, amount, hasOrder));
        else HP.State.addXP(HP.Data.Constants.XP_PER_SALE * amount);

        customer.currentRequest = null;
        var dealTotal = Math.floor(priceInfo.total * priceMult);
        var repBonusAmount = (priceInfo.reputationBonus > 1)
            ? Math.floor(dealTotal * (1 - 1 / priceInfo.reputationBonus)) : 0;
        var message = 'Sold ' + amount + 'g ' + strainName + ' to ' + customer.name + ' for $' + HP.Helpers.formatNumber(totalEarned);
        if (repBonusAmount > 0) message += ' (+$' + HP.Helpers.formatNumber(repBonusAmount) + ' rep bonus)';
        if (hasOrder) message += ' (+$' + HP.Helpers.formatNumber(orderBonus) + ' order bonus)';
        if (heatGain > 0) message += '. Heat +' + Math.round(heatGain) + '%';
        var moneyEl = document.getElementById('money-display');
        if (HP.Particles && moneyEl) HP.Particles.emitSale({ element: moneyEl });
        if (HP.SoundManager) HP.SoundManager.play('sale');
        HP.Notifications.success(message);
        HP.State.incrementStat('totalSales', 1);
        if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
        checkAchievements();
        checkTutorialProgress();
        if (HP.State.getDailyGoals && HP.State.addProgress) {
            var dg = HP.State.addProgress('sell_grams', amount);
            if (dg && dg.completed && HP.Notifications) HP.Notifications.success('🎯 Daily goal: +$' + HP.Helpers.formatNumber(dg.reward));
            var dg2 = HP.State.addProgress('earn_cash', totalEarned);
            if (dg2 && dg2.completed && HP.Notifications) HP.Notifications.success('🎯 Daily goal: +$' + HP.Helpers.formatNumber(dg2.reward));
        }
        if (HP.State.fulfillContract) {
            var quality = priceInfo.quality || (seed ? seed.quality : null);
            var cf = HP.State.fulfillContract(customerId, seedId, amount, quality);
            if (cf && cf.completed) {
                if (HP.State.incrementStat) HP.State.incrementStat('contractsCompleted', 1);
                if (HP.SoundManager) HP.SoundManager.play('contract');
                if (HP.Notifications) HP.Notifications.success('📋 Contract complete! +$' + HP.Helpers.formatNumber(cf.payout));
            }
        }
        if (HP.State.getSpecialRequest && HP.State.clearSpecialRequest) {
            var req = HP.State.getSpecialRequest(customerId);
            if (req && req.seedId === seedId && amount >= req.amount) {
                HP.State.addCash(req.payout);
                HP.State.clearSpecialRequest(customerId);
                if (HP.Notifications) HP.Notifications.success('⭐ Special request fulfilled! +$' + HP.Helpers.formatNumber(req.payout));
            }
        }
        if (HP.Renderer) { HP.Renderer.closeSaleModal(); HP.Renderer.updateAfterSale(); }
        refreshUI();
        requestAnimationFrame(function() { refreshUI(); });
    }

    function quickSellOrder(customerId, seedId, amount) {
        var available = HP.State.getWeed(seedId);
        if (available < amount) {
            var seed = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedId) : null;
            var strainName = seed ? (seed.strainName || seed.name) : seedId;
            HP.Notifications.error('Not enough ' + strainName + '!');
            return;
        }
        var customer = HP.Data.Customers.get(customerId);
        if (!customer) return;
        var order = HP.MarketOrders.getOrder(customerId);
        if (!order) { HP.Notifications.error('Order expired!'); return; }

        var totalEarned = order.bonusPrice;
        var heatGain = 0;
        if (HP.Heat && HP.Heat.calculateHeatGain && HP.State.addHeat) {
            heatGain = HP.Heat.calculateHeatGain('manual_sale', amount);
            if (heatGain > 0) HP.State.addHeat(heatGain);
        }
        HP.State.removeWeed(seedId, amount);
        HP.State.addCash(totalEarned);
        HP.State.incrementStat('totalSold', amount);
        if (totalEarned && HP.State.getStat('biggestSale') != null && totalEarned > HP.State.getStat('biggestSale')) HP.State.setStat('biggestSale', totalEarned);
        var seed = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedId) : null;
        var qualityForXP = seed ? seed.quality : 'medium';
        if (HP.Progression && HP.Progression.calculateXPForSale) HP.State.addXP(HP.Progression.calculateXPForSale(totalEarned, qualityForXP, amount, true));
        else HP.State.addXP(HP.Data.Constants.XP_PER_SALE * amount);
        HP.MarketOrders.fulfillOrder(customerId);

        if (HP.State.fulfillContract) {
            var quality = seed ? seed.quality : 'medium';
            var cf = HP.State.fulfillContract(customerId, seedId, amount, quality);
            if (cf && cf.completed) {
                if (HP.State.incrementStat) HP.State.incrementStat('contractsCompleted', 1);
                if (HP.SoundManager) HP.SoundManager.play('contract');
                if (HP.Notifications) HP.Notifications.success('📋 Contract complete! +$' + HP.Helpers.formatNumber(cf.payout));
            }
        }

        var strainName = seed ? (seed.strainName || seed.name) : seedId;
        var orderBonus = order.bonusPrice - order.basePrice;
        var message = '✅ Sold ' + amount + 'g ' + strainName + ' to ' + customer.name + ' for $' + HP.Helpers.formatNumber(totalEarned) + ' (+$' + HP.Helpers.formatNumber(orderBonus) + ' order bonus)';
        if (heatGain > 0) message += '. Heat +' + Math.round(heatGain) + '%';
        var moneyEl = document.getElementById('money-display');
        if (HP.Particles && moneyEl) HP.Particles.emitSale({ element: moneyEl });
        if (HP.SoundManager) HP.SoundManager.play('sale');
        HP.Notifications.success(message);
        HP.State.incrementStat('totalSales', 1);
        if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
        checkAchievements();
        checkTutorialProgress();
        refreshUI();
        setTimeout(function() { refreshUI(); }, 0);
    }

    function deliverContract(customerId, seedId, amount) {
        var isBlend = seedId && seedId.indexOf('mixed:') === 0;
        var blendKey = isBlend ? seedId.slice(6) : null;
        var available;
        var quality = 'medium';
        if (isBlend && blendKey) {
            var blend = HP.State.getMixed && HP.State.getMixed(blendKey);
            available = blend ? blend.amount : 0;
            if (blend && blend.quality) quality = blend.quality;
        } else {
            available = HP.State.getWeed(seedId);
            var seed = HP.Data.Seeds && HP.Data.Seeds.get ? HP.Data.Seeds.get(seedId) : null;
            if (seed && seed.quality) quality = seed.quality;
        }
        if (available < amount) {
            var label = isBlend ? 'blend' : (HP.Data.Seeds && HP.Data.Seeds.get(seedId) ? (HP.Data.Seeds.get(seedId).strainName || HP.Data.Seeds.get(seedId).name) : seedId);
            HP.Notifications.error('Not enough ' + label + ' (need ' + amount + 'g).');
            return;
        }
        if (isBlend && blendKey && HP.State.removeMixed) {
            HP.State.removeMixed(blendKey, amount);
        } else {
            HP.State.removeWeed(seedId, amount);
        }
        var cf = HP.State.fulfillContract(customerId, seedId, amount, quality);
        if (cf && cf.completed) {
            if (HP.State.incrementStat) HP.State.incrementStat('contractsCompleted', 1);
            if (HP.SoundManager) HP.SoundManager.play('contract');
            HP.Notifications.success('📋 Contract delivered! +$' + HP.Helpers.formatNumber(cf.payout));
        } else {
            HP.Notifications.info('Delivered ' + amount + 'g toward contract.');
        }
        if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
        refreshUI();
    }

    function openReputationModal() {
        var explanationEl = document.getElementById('reputation-explanation');
        var dealersEl = document.getElementById('reputation-dealers');
        var modalEl = document.getElementById('reputation-modal');
        if (!explanationEl || !dealersEl || !modalEl) return;

        var constants = HP.Data.Constants || {};
        var thresholds = (constants.REP_THRESHOLDS || [10, 25, 50, 100, 200]).slice();
        var bonusPerTier = (constants.REP_BONUS_PER_THRESHOLD != null) ? constants.REP_BONUS_PER_THRESHOLD : 0.03;
        var bonusPct = Math.round(bonusPerTier * 100);

        var explain = 'Reputation is earned separately with each dealer when you sell. Higher rep unlocks better sale prices with that dealer. ' +
            '<strong>Deal types:</strong> Normal (+1 rep), Give discount (+3 rep, sell 15% cheaper), Overcharge (−2 rep, charge 20% more). ' +
            'For each reputation threshold you pass (10, 25, 50, 100, 200), you get <strong>+' + bonusPct + '%</strong> to sale prices with that dealer.';
        explanationEl.innerHTML = explain;

        var allCustomers = HP.Data.Customers && HP.Data.Customers.getAll ? HP.Data.Customers.getAll() : {};
        var playerLevel = HP.State && HP.State.getLevel ? HP.State.getLevel() : 1;
        var html = '';
        for (var id in allCustomers) {
            var customer = allCustomers[id];
            if (customer.unlockLevel > playerLevel) continue;
            var rep = (HP.State && HP.State.getCustomerReputation) ? HP.State.getCustomerReputation(id) : 0;
            var repBonus = HP.Data.Customers.getReputationBonus ? HP.Data.Customers.getReputationBonus(id) : 1;
            var tiers = 0;
            for (var t = 0; t < thresholds.length; t++) { if (rep >= thresholds[t]) tiers++; }
            var nextThreshold = null;
            for (var n = 0; n < thresholds.length; n++) { if (rep < thresholds[n]) { nextThreshold = thresholds[n]; break; } }
            var tierLabel = nextThreshold != null ? 'Tier ' + tiers + ' (next: ' + nextThreshold + ')' : 'Max tier';
            var bonusLabel = tiers > 0 ? '+' + Math.round((repBonus - 1) * 100) + '% price' : '—';

            html += '<div class="reputation-dealer-row">';
            html += '<span class="dealer-icon">' + (customer.icon || '🤝') + '</span>';
            html += '<span class="dealer-name">' + (customer.name || id) + '</span>';
            html += '<span class="dealer-rep">' + rep + ' rep</span>';
            html += '<span class="dealer-tier">' + tierLabel + '</span>';
            html += '<span class="dealer-bonus">' + bonusLabel + '</span>';
            html += '</div>';
        }
        dealersEl.innerHTML = html || '<p class="empty-state">No dealers unlocked yet.</p>';
        modalEl.classList.remove('hidden');
    }

    function closeReputationModal() {
        var modalEl = document.getElementById('reputation-modal');
        if (modalEl) modalEl.classList.add('hidden');
    }

    function bindSellControls() {
        document.body.addEventListener('change', function(e) {
            if (e.target && e.target.id === 'sale-strain-select') {
                var customerId = HP.Renderer && HP.Renderer.getSelectedCustomer ? HP.Renderer.getSelectedCustomer() : null;
                if (!customerId) return;
                var customer = HP.Data.Customers.get(customerId);
                if (!customer || !customer.currentRequest) return;
                var seedId = e.target.value;
                if (seedId) {
                    customer.currentRequest.seedId = seedId;
                    if (HP.Renderer && HP.Renderer.updateSellTotal) HP.Renderer.updateSellTotal();
                }
            }
        });
        document.body.addEventListener('input', function(e) {
            if (e.target && e.target.id === 'sale-amount-input') {
                if (HP.Renderer && HP.Renderer.syncSaleAmountFromInput) HP.Renderer.syncSaleAmountFromInput();
                if (HP.Renderer && HP.Renderer.updateSellTotal) HP.Renderer.updateSellTotal();
            }
        });
        document.body.addEventListener('click', function(e) {
            var target = e.target;
            var minusBtn = target.closest && target.closest('#sale-amount-minus');
            var plusBtn = target.closest && target.closest('#sale-amount-plus');
            if (minusBtn || plusBtn) {
                var input = document.getElementById('sale-amount-input');
                if (input) {
                    var min = parseInt(input.getAttribute('min'), 10) || 1;
                    var max = parseInt(input.getAttribute('max'), 10) || 999;
                    var cur = parseInt(input.value, 10) || min;
                    var next = plusBtn ? Math.min(cur + 1, max) : Math.max(cur - 1, min);
                    if (next !== cur) {
                        input.value = next;
                        var customerId = HP.Renderer && HP.Renderer.getSelectedCustomer ? HP.Renderer.getSelectedCustomer() : null;
                        if (customerId) {
                            var customer = HP.Data.Customers.get(customerId);
                            if (customer && customer.currentRequest) customer.currentRequest.amount = next;
                        }
                        if (HP.Renderer && HP.Renderer.updateSellTotal) HP.Renderer.updateSellTotal();
                    }
                }
                e.preventDefault();
                e.stopPropagation();
                return;
            }
            if (target.closest && target.closest('#btn-reputation')) {
                e.preventDefault(); e.stopPropagation();
                openReputationModal();
                return;
            }
            if (target.closest && target.closest('#btn-close-reputation')) {
                e.preventDefault(); e.stopPropagation();
                closeReputationModal();
                return;
            }
            if (target.closest && target.closest('#btn-sell')) {
                e.preventDefault(); e.stopPropagation();
                handleSell();
                return;
            }
            if (target.closest && target.closest('#btn-close-sale')) {
                e.preventDefault(); e.stopPropagation();
                if (HP.Renderer) HP.Renderer.closeSaleModal();
                return;
            }
            if (target.closest && target.closest('#btn-new-request')) {
                e.preventDefault(); e.stopPropagation();
                if (HP.Renderer && HP.Renderer.regenerateCustomerRequest) HP.Renderer.regenerateCustomerRequest();
                return;
            }
            if (target.closest && target.closest('.deal-type-btn')) {
                var btn = target.closest('.deal-type-btn');
                if (btn) {
                    e.preventDefault(); e.stopPropagation();
                    document.querySelectorAll('.deal-type-btn').forEach(function(b) { b.classList.remove('selected'); });
                    btn.classList.add('selected');
                    if (HP.Renderer && HP.Renderer.updateSellTotal) HP.Renderer.updateSellTotal();
                }
                return;
            }
            if (target.closest && target.closest('.btn-order-deal')) {
                var dealBtn = target.closest('.btn-order-deal');
                if (dealBtn) {
                    e.preventDefault(); e.stopPropagation();
                    var customerId = dealBtn.getAttribute('data-customer-id');
                    if (customerId && HP.Renderer && HP.Renderer.openSaleModal) HP.Renderer.openSaleModal(customerId);
                }
                return;
            }
            if (target.closest && target.closest('.btn-order-quick-sell')) {
                var qsBtn = target.closest('.btn-order-quick-sell');
                if (qsBtn) {
                    e.preventDefault(); e.stopPropagation();
                    var customerId = qsBtn.getAttribute('data-customer-id');
                    var seedId = qsBtn.getAttribute('data-seed-id') || qsBtn.getAttribute('data-quality');
                    var amount = parseInt(qsBtn.getAttribute('data-amount'), 10);
                    if (customerId && seedId && !isNaN(amount)) quickSellOrder(customerId, seedId, amount);
                }
                return;
            }
            if (target.closest && target.closest('.btn-deliver-contract')) {
                var dcBtn = target.closest('.btn-deliver-contract');
                if (dcBtn) {
                    e.preventDefault(); e.stopPropagation();
                    var customerId = dcBtn.getAttribute('data-customer-id');
                    var seedId = dcBtn.getAttribute('data-seed-id');
                    var amount = parseInt(dcBtn.getAttribute('data-amount'), 10);
                    if (customerId && seedId && !isNaN(amount)) deliverContract(customerId, seedId, amount);
                }
                return;
            }
            if (target.closest && target.closest('.customer-card:not(.locked)')) {
                var card = target.closest('.customer-card');
                if (card) {
                    e.preventDefault(); e.stopPropagation();
                    var customerId = card.getAttribute('data-customer');
                    if (customerId && HP.Renderer && HP.Renderer.openSaleModal) HP.Renderer.openSaleModal(customerId);
                }
            }
        });
    }

    HP.Events.MarketActions = {
        bind: bindSellControls,
        handleSell: handleSell,
        quickSellOrder: quickSellOrder
    };
})();
