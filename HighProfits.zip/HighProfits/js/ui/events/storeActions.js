/**
 * Store actions: buy/sell equipment, seeds, property, water/heat upgrades, room upgrades; dealer filters.
 */
(function() {
    'use strict';
    var refreshUI = function() { HP.Events.refreshUI(); };
    var checkAchievements = function() { HP.Events.checkAchievements(); };
    var checkTutorialProgress = function() { HP.Events.checkTutorialProgress(); };

    function buyEquipment(equipmentId) {
        var equip = HP.Data.Equipment.get(equipmentId);
        if (!equip) return;
        var cost = equip.cost;
        if (HP.Events && HP.Events.Manager) {
            var costMult = HP.Events.Manager.getModifier('equipmentCost');
            cost = Math.floor(cost * costMult);
        }
        if (!HP.State.canAffordBank(cost)) { HP.Notifications.error('Not enough bank funds! Legitimate stores require clean money.'); return; }
        HP.State.spendBank(cost);
        HP.State.addEquipment(equipmentId, 1);
        HP.Notifications.success('Bought ' + equip.name);
        if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
        if (HP.WorkerAutomation && HP.WorkerAutomation.checkAndResumeWorkers) HP.WorkerAutomation.checkAndResumeWorkers();
        refreshUI();
    }

    function buySeed(seedId) {
        var seed = HP.Data.Seeds.get(seedId);
        if (!seed) return;
        if (!HP.State.canAffordCash(seed.cost)) { HP.Notifications.error('Not enough cash! Seed Dealer only takes cash.'); return; }
        HP.State.spendCash(seed.cost);
        HP.State.addSeeds(seedId, 1);
        HP.Notifications.success('Bought ' + seed.name);
        if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
        checkTutorialProgress();
        if (HP.WorkerAutomation && HP.WorkerAutomation.checkAndResumeWorkers) HP.WorkerAutomation.checkAndResumeWorkers();
        refreshUI();
    }

    function buyProperty(propertyId) {
        var result = HP.State.buyProperty(propertyId);
        if (result.success) {
            HP.Notifications.success(result.message);
            if (HP.Progression && HP.Progression.calculateXPForPropertyPurchase) HP.State.addXP(HP.Progression.calculateXPForPropertyPurchase(propertyId));
            else HP.State.addXP(HP.Data.Constants.XP_PER_PROPERTY);
            if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
            checkAchievements();
        } else HP.Notifications.error(result.message);
        refreshUI();
    }

    function buyBusiness(businessId) {
        if (!HP.State.buyBusiness) return;
        var result = HP.State.buyBusiness(businessId);
        if (result.success) {
            HP.Notifications.success(result.message);
            if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
        } else HP.Notifications.error(result.message);
        refreshUI();
    }

    function buyWaterUpgrade(upgradeId) {
        var up = HP.Data.WaterUpgrades && HP.Data.WaterUpgrades.get(upgradeId);
        if (!up) return;
        if (HP.State.getWaterUpgradesOwned && HP.State.getWaterUpgradesOwned().indexOf(upgradeId) !== -1) { HP.Notifications.info('Already owned'); return; }
        if (!HP.State.canAffordBank(up.cost)) { HP.Notifications.error('Not enough bank funds!'); return; }
        if (HP.State.buyWaterUpgrade(upgradeId)) {
            HP.Notifications.success('Bought ' + up.name + '. Water capacity increased!');
            if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
            refreshUI();
        }
    }

    function buyHeatReduction(itemId) {
        var item = HP.Data.HeatReduction && HP.Data.HeatReduction.get(itemId);
        if (!item) return;
        if (HP.State.getHeatReductionOwned && HP.State.getHeatReductionOwned().indexOf(itemId) !== -1) { HP.Notifications.info('Already owned'); return; }
        if (!HP.State.canAffordBank(item.cost)) { HP.Notifications.error('Not enough bank funds!'); return; }
        if (HP.State.buyHeatReduction(itemId)) {
            HP.Notifications.success('Bought ' + item.name + '. Heat builds slower while growing!');
            refreshUI();
        }
    }

    function sellEquipment(equipmentId) {
        if (HP.State.getEquipment(equipmentId) < 1) { HP.Notifications.error('Item not in inventory'); return; }
        var equip = HP.Data.Equipment.get(equipmentId);
        if (!equip) { HP.Notifications.error('Invalid item'); return; }
        var sellPrice = Math.floor(equip.cost * 0.5);
        HP.State.removeEquipment(equipmentId, 1);
        HP.State.addBank(sellPrice);
        HP.Notifications.success('Sold ' + equip.name + ' for $' + sellPrice);
        refreshUI();
    }

    function sellSeeds(seedId) {
        if (HP.State.getSeeds(seedId) < 1) { HP.Notifications.error('Seeds not in inventory'); return; }
        var seed = HP.Data.Seeds.get(seedId);
        if (!seed) { HP.Notifications.error('Invalid seeds'); return; }
        var sellPrice = Math.floor(seed.cost * 0.5);
        HP.State.removeSeeds(seedId, 1);
        HP.State.addCash(sellPrice);
        HP.Notifications.success('Sold ' + seed.name + ' for $' + sellPrice);
        refreshUI();
    }

    function buyRoomUpgrade(propertyId, upgradeId) {
        if (HP.State.hasRoomUpgrade(propertyId, upgradeId)) { HP.Notifications.error('Already installed!'); return; }
        var upgrade = HP.Data.RoomUpgrades.get(upgradeId);
        if (!upgrade) { HP.Notifications.error('Invalid upgrade'); return; }
        if (!HP.State.canAffordBank(upgrade.cost)) { HP.Notifications.error('Not enough bank funds!'); return; }
        HP.State.spendBank(upgrade.cost);
        HP.State.addRoomUpgrade(propertyId, upgradeId);
        HP.Notifications.success('Installed ' + upgrade.name);
        if (HP.Progression && HP.Progression.calculateXPForRoomUpgrade) HP.State.addXP(HP.Progression.calculateXPForRoomUpgrade(upgradeId));
        refreshUI();
    }

    function sellRoomUpgrade(propertyId, upgradeId) {
        if (!HP.State.hasRoomUpgrade(propertyId, upgradeId)) { HP.Notifications.error('Upgrade not installed'); return; }
        var upgrade = HP.Data.RoomUpgrades.get(upgradeId);
        if (!upgrade) { HP.Notifications.error('Invalid upgrade'); return; }
        var sellPrice = Math.floor(upgrade.cost * 0.5);
        HP.State.removeRoomUpgrade(propertyId, upgradeId);
        HP.State.addBank(sellPrice);
        HP.Notifications.success('Sold ' + upgrade.name + ' for $' + sellPrice);
        refreshUI();
    }

    function handleBuy(button) {
        var type = button.getAttribute('data-type');
        var id = button.getAttribute('data-id');
        if (!type || !id) return;
        if (type === 'equipment') buyEquipment(id);
        else if (type === 'seed') buySeed(id);
        else if (type === 'property') buyProperty(id);
        else if (type === 'business') buyBusiness(id);
        else if (type === 'water_upgrade') buyWaterUpgrade(id);
        else if (type === 'heat_reduction') buyHeatReduction(id);
    }

    function bindStoreContainer(containerId) {
        var container = document.getElementById(containerId);
        if (container) {
            container.addEventListener('click', function(e) {
                if (e.target.classList.contains('buy-btn') && !e.target.disabled) handleBuy(e.target);
            });
        }
    }

    function bindStoreButtons() {
        bindStoreContainer('hardware-items');
        bindStoreContainer('garden-items');
        bindStoreContainer('dealer-items');
        bindStoreContainer('property-items');
        bindStoreContainer('business-items');
    }

    function bindDealerFilters() {
        var filterQuality = document.getElementById('dealer-filter-quality');
        var filterAvailability = document.getElementById('dealer-filter-availability');
        var sortBy = document.getElementById('dealer-sort-by');
        var searchInput = document.getElementById('dealer-search');
        var updateDealer = function() { if (HP.Renderer && HP.Renderer.update) HP.Renderer.update(); };
        if (filterQuality) filterQuality.addEventListener('change', updateDealer);
        if (filterAvailability) filterAvailability.addEventListener('change', updateDealer);
        if (sortBy) sortBy.addEventListener('change', updateDealer);
        if (searchInput) {
            searchInput.addEventListener('input', updateDealer);
            searchInput.addEventListener('keydown', function(e) { e.stopPropagation(); });
        }
    }

    function bind() {
        bindStoreButtons();
        bindDealerFilters();
    }

    HP.Events.StoreActions = {
        bind: bind,
        buyRoomUpgrade: buyRoomUpgrade,
        sellRoomUpgrade: sellRoomUpgrade,
        sellEquipment: sellEquipment,
        sellSeeds: sellSeeds
    };
})();
