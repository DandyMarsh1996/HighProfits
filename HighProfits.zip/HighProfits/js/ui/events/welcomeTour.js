/**
 * Welcome Tour - Short guided intro for new characters.
 */
(function() {
    'use strict';

    var slides = [
        { title: 'Welcome!', message: "This is your Grow Room – plant seeds, water crops, and harvest here. Use the sidebar to switch views." },
        { title: 'Get Started', message: "Visit the Seed Dealer for seeds and Hardware for pots, soil, and lights. Then come back here to plant!" },
        { title: "Rais Has Your Back", message: "Your advisor Rais will guide you through your first steps. Click 'Got it!' when you're ready to begin. Good luck!" }
    ];

    function show() {
        var overlay = document.getElementById('welcome-tour');
        if (!overlay) return;
        overlay.classList.remove('hidden');
        renderSlide(0);
    }

    function hide() {
        var overlay = document.getElementById('welcome-tour');
        if (overlay) overlay.classList.add('hidden');
    }

    function renderSlide(index) {
        var titleEl = document.getElementById('welcome-tour-title');
        var messageEl = document.getElementById('welcome-tour-message');
        var dotsEl = document.getElementById('welcome-tour-dots');
        var nextBtn = document.getElementById('welcome-tour-next');
        if (!titleEl || !messageEl) return;

        var slide = slides[index];
        if (slide) {
            titleEl.textContent = slide.title;
            messageEl.textContent = slide.message;
        }
        if (dotsEl) {
            var html = '';
            for (var i = 0; i < slides.length; i++) {
                html += '<span class="welcome-dot' + (i === index ? ' active' : '') + '">•</span>';
            }
            dotsEl.innerHTML = html;
        }
        if (nextBtn) {
            nextBtn.textContent = index >= slides.length - 1 ? 'Start' : 'Next';
        }
    }

    function finish() {
        if (HP.State && HP.State.setTourCompleted) HP.State.setTourCompleted(true);
        if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
        hide();
        if (HP.Tutorial && HP.Tutorial.init) HP.Tutorial.init();
    }

    function bind() {
        var overlay = document.getElementById('welcome-tour');
        var skipBtn = document.getElementById('welcome-tour-skip');
        var nextBtn = document.getElementById('welcome-tour-next');
        if (!overlay) return;

        var currentSlide = 0;
        renderSlide(0);

        if (skipBtn) {
            skipBtn.addEventListener('click', function() {
                finish();
            });
        }
        if (nextBtn) {
            nextBtn.addEventListener('click', function() {
                currentSlide++;
                if (currentSlide >= slides.length) {
                    finish();
                } else {
                    renderSlide(currentSlide);
                }
            });
        }
    }

    HP.Events.WelcomeTour = { bind: bind, show: show, hide: hide };
})();
