/**
 * Save / Load / Reset / Export / Import buttons (in Settings).
 */
(function() {
    'use strict';
    var refreshUI = function() { HP.Events.refreshUI(); };

    function bind() {
        var saveBtn = document.getElementById('save-game');
        var loadBtn = document.getElementById('load-game');
        var resetBtn = document.getElementById('reset-game');
        var mainMenuBtn = document.getElementById('main-menu');
        var exportBtn = document.getElementById('export-save');
        var importBtn = document.getElementById('import-save');
        var importFileInput = document.getElementById('import-file-input');

        if (saveBtn) {
            saveBtn.addEventListener('click', function() {
                if (HP.SoundManager && HP.SoundManager.play) HP.SoundManager.play('click');
                HP.SaveManager.save();
                HP.Notifications.success('Game saved!');
            });
        }
        var saveStatusEl = document.getElementById('save-status');
        if (saveStatusEl) {
            saveStatusEl.addEventListener('click', function() {
                if (this.classList.contains('error') && HP.SaveManager && HP.SaveManager.save) {
                    HP.SaveManager.save();
                }
            });
        }
        if (loadBtn) {
            loadBtn.addEventListener('click', function() {
                if (HP.SoundManager && HP.SoundManager.play) HP.SoundManager.play('click');
                if (HP.SaveManager.load()) {
                    HP.Notifications.success('Game loaded!');
                    refreshUI();
                } else HP.Notifications.error('No saved game found!');
            });
        }
        if (resetBtn) {
            resetBtn.addEventListener('click', function() {
                HP.ConfirmDialog.showConfirm(
                    { message: 'Reset all progress for this character? All data will be lost. This cannot be undone.', confirmLabel: 'Reset', danger: true },
                    function() {
                        HP.State.reset();
                        HP.SaveManager.clear();
                        HP.Notifications.info('Progress reset!');
                        if (HP.App && HP.App.returnToMainMenu) HP.App.returnToMainMenu();
                    }
                );
            });
        }
        if (mainMenuBtn && HP.App && HP.App.returnToMainMenu) {
            mainMenuBtn.addEventListener('click', function() {
                HP.App.returnToMainMenu();
            });
        }
        if (exportBtn && HP.SaveManager && HP.SaveManager.exportToFile) {
            exportBtn.addEventListener('click', function() {
                HP.SaveManager.exportToFile();
                HP.Notifications.success('Save exported to file!');
            });
        }
        if (importBtn && importFileInput) {
            importBtn.addEventListener('click', function() {
                importFileInput.click();
            });
            importFileInput.addEventListener('change', function() {
                var file = this.files && this.files[0];
                if (!file) return;
                if (HP.SaveManager && HP.SaveManager.importFromFile) {
                    HP.SaveManager.importFromFile(file, function(success) {
                        if (success) {
                            HP.Notifications.success('Save imported! Returning to main menu...');
                            setTimeout(function() {
                                if (HP.App && HP.App.returnToMainMenu) HP.App.returnToMainMenu();
                            }, 500);
                        } else {
                            HP.Notifications.error('Failed to import save. Invalid file?');
                        }
                    });
                }
                importFileInput.value = '';
            });
        }
    }

    HP.Events.SaveLoad = { bind: bind };
})();
