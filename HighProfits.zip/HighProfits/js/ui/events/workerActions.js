/**
 * Worker actions: hire, assign, configure, remove.
 */
(function() {
    'use strict';
    var refreshUI = function() { HP.Events.refreshUI(); };

    function getHireCost(workerTypeId) {
        var workerType = HP.Data.GrowerWorkers.get(workerTypeId);
        if (!workerType) return 0;
        var workers = HP.State.getGrowerWorkers();
        var count = 0;
        for (var i = 0; i < workers.length; i++) {
            if (workers[i].workerTypeId === workerTypeId) count++;
        }
        var mult = (workerType.costMultiplier != null) ? workerType.costMultiplier : 1.2;
        return Math.floor(workerType.baseCost * Math.pow(mult, count));
    }

    /** Cost to upgrade from currentTypeId to nextTypeId (delta of base costs; paid from bank) */
    function getUpgradeCost(currentTypeId, nextTypeId) {
        var current = HP.Data.GrowerWorkers.get(currentTypeId);
        var next = HP.Data.GrowerWorkers.get(nextTypeId);
        if (!current || !next) return 0;
        var delta = Math.max(0, next.baseCost - current.baseCost);
        return delta;
    }

    function upgradeWorker(workerId) {
        var workers = HP.State.getGrowerWorkers();
        var worker = workers.find(function(w) { return w.id === workerId; });
        if (!worker) { HP.Notifications.error('Worker not found'); return; }
        var nextTier = HP.Data.GrowerWorkers.getNextTier && HP.Data.GrowerWorkers.getNextTier(worker.workerTypeId);
        if (!nextTier) { HP.Notifications.error('This worker is already at max tier'); return; }
        var playerLevel = HP.State.getLevel ? HP.State.getLevel() : 0;
        if (playerLevel < nextTier.unlockLevel) { HP.Notifications.error('Reach level ' + nextTier.unlockLevel + ' to unlock ' + nextTier.name); return; }
        var cost = getUpgradeCost(worker.workerTypeId, nextTier.id);
        if (cost > 0 && (!HP.State.canAffordBank || !HP.State.canAffordBank(cost))) {
            HP.Notifications.error('Not enough bank funds (need $' + HP.Helpers.formatNumber(cost) + ')');
            return;
        }
        if (cost > 0 && HP.State.spendBank) HP.State.spendBank(cost);
        if (HP.State.setWorkerTypeId && HP.State.setWorkerTypeId(workerId, nextTier.id)) {
            if (HP.State.incrementStat) HP.State.incrementStat('workerUpgradesCount', 1);
            HP.Notifications.success((worker.name || 'Worker') + ' upgraded to ' + nextTier.name + (cost > 0 ? ' ($' + HP.Helpers.formatNumber(cost) + ')' : ''));
            if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
            refreshUI();
        } else HP.Notifications.error('Failed to upgrade worker');
    }

    function hireWorker(workerTypeId) {
        var workerType = HP.Data.GrowerWorkers.get(workerTypeId);
        if (!workerType) { HP.Notifications.error('Invalid worker type'); return; }
        var cost = getHireCost(workerTypeId);
        if (!HP.State.canAffordBank(cost)) { HP.Notifications.error('Not enough bank funds!'); return; }
        HP.State.spendBank(cost);
        HP.Renderer.openWorkerAssignModal(workerTypeId);
        refreshUI();
    }

    function assignWorker() {
        var modal = document.getElementById('worker-assign-modal');
        if (!modal) return;
        var workerTypeId = modal.getAttribute('data-worker-type');
        if (!workerTypeId) return;
        var propertySelect = document.getElementById('worker-property-select');
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');
        if (!propertySelect || !propertySelect.value) { HP.Notifications.error('Please select a location'); return; }
        var propertyId = propertySelect.value.trim();
        var seedId = seedSelect ? (seedSelect.value || '').trim() : '';
        var soilId = soilSelect ? (soilSelect.value || '').trim() : '';
        var fertilizerId = fertilizerSelect ? (fertilizerSelect.value || '').trim() : '';
        if (!seedId) { HP.Notifications.error('Please select a seed'); return; }
        if (!soilId) { HP.Notifications.error('Please select soil'); return; }
        if (!fertilizerId) { HP.Notifications.error('Please select fertilizer'); return; }
        var config = { seedId: seedId, soilId: soilId, fertilizerId: fertilizerId };
        var worker = HP.State.addGrowerWorker(workerTypeId, propertyId, config);
        if (worker) {
            HP.Notifications.success('Hired and assigned ' + (worker.name || 'worker') + ' to location!');
            if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
            HP.Renderer.closeWorkerAssignModal();
            refreshUI();
        } else HP.Notifications.error('Failed to assign worker');
    }

    function configureWorker(workerId) {
        var workers = HP.State.getGrowerWorkers();
        var worker = workers.find(function(w) { return w.id === workerId; });
        if (!worker) return;
        var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
        HP.Renderer.openWorkerAssignModal(worker.workerTypeId);
        var propertySelect = document.getElementById('worker-property-select');
        if (propertySelect) {
            var propId = worker.assignedPropertyId != null ? worker.assignedPropertyId : (worker.assignedPlot && worker.assignedPlot.propertyId);
            propertySelect.value = propId || '';
            propertySelect.disabled = true;
        }
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');
        if (seedSelect) seedSelect.value = worker.config.seedId || '';
        if (soilSelect) soilSelect.value = worker.config.soilId || '';
        if (fertilizerSelect) fertilizerSelect.value = worker.config.fertilizerId || '';
        var assignBtn = document.getElementById('btn-assign-worker');
        if (assignBtn) {
            assignBtn.textContent = 'Update Configuration';
            assignBtn.setAttribute('data-update-worker', workerId);
        }
    }

    function updateWorkerConfig(workerId) {
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');
        var seedId = seedSelect ? (seedSelect.value || '').trim() : '';
        var soilId = soilSelect ? (soilSelect.value || '').trim() : '';
        var fertilizerId = fertilizerSelect ? (fertilizerSelect.value || '').trim() : '';
        if (!seedId) { HP.Notifications.error('Please select a seed'); return; }
        if (!soilId) { HP.Notifications.error('Please select soil'); return; }
        if (!fertilizerId) { HP.Notifications.error('Please select fertilizer'); return; }
        var config = { seedId: seedId, soilId: soilId, fertilizerId: fertilizerId };
        if (HP.State.updateWorkerConfig(workerId, config)) {
            HP.Notifications.success('Worker configuration updated');
            HP.Renderer.closeWorkerAssignModal();
            var assignBtn = document.getElementById('btn-assign-worker');
            if (assignBtn) assignBtn.removeAttribute('data-update-worker');
            refreshUI();
        } else HP.Notifications.error('Failed to update configuration');
    }

    function removeWorker(workerId) {
        HP.ConfirmDialog.showConfirm(
            { message: 'Remove this worker? They will stop working immediately.', confirmLabel: 'Remove', danger: true },
            function() {
                if (HP.State.removeGrowerWorker(workerId)) {
                    HP.Notifications.info('Worker removed');
                    refreshUI();
                } else HP.Notifications.error('Failed to remove worker');
            }
        );
    }

    function bind() {
        document.addEventListener('click', function(e) {
            if (e.target.id === 'workers-deposit-btn' || e.target.closest('#workers-deposit-btn')) {
                var inp = document.getElementById('workers-deposit-amount');
                var amount = inp ? parseInt(inp.value, 10) : 0;
                if (isNaN(amount) || amount < 1) { HP.Notifications.error('Enter a valid amount'); return; }
                if (HP.State.addToWorkerWageFund && HP.State.addToWorkerWageFund(amount)) {
                    HP.Notifications.success('Deposited $' + HP.Helpers.formatNumber(amount) + ' to wage fund');
                    if (inp) inp.value = '';
                    refreshUI();
                } else HP.Notifications.error('Not enough bank funds');
                return;
            }
            if (e.target.classList.contains('btn-hire-worker') && !e.target.disabled) {
                var workerTypeId = e.target.getAttribute('data-worker');
                hireWorker(workerTypeId);
            }
        });
        var assignBtn = document.getElementById('btn-assign-worker');
        if (assignBtn) {
            assignBtn.addEventListener('click', function() {
                var modal = document.getElementById('worker-assign-modal');
                var moveWorkerId = modal && modal.getAttribute('data-move-worker-id');
                if (moveWorkerId) {
                    doMoveWorker(moveWorkerId);
                    return;
                }
                var updateWorkerId = this.getAttribute('data-update-worker');
                if (updateWorkerId) updateWorkerConfig(updateWorkerId);
                else assignWorker();
            });
        }
        var closeBtn = document.getElementById('btn-close-worker-modal');
        if (closeBtn) closeBtn.addEventListener('click', function() { HP.Renderer.closeWorkerAssignModal(); });
        var presetSelect = document.getElementById('worker-preset-select');
        if (presetSelect) {
            presetSelect.addEventListener('change', function() {
                var idx = this.value;
                if (idx === '') return;
                try {
                    var presets = JSON.parse(localStorage.getItem('highprofits_worker_presets') || '[]');
                    var p = presets[parseInt(idx, 10)];
                    if (p) {
                        var seedEl = document.getElementById('worker-seed-select');
                        var soilEl = document.getElementById('worker-soil-select');
                        var fertEl = document.getElementById('worker-fertilizer-select');
                        if (seedEl) seedEl.value = p.seedId || '';
                        if (soilEl) soilEl.value = p.soilId || '';
                        if (fertEl) fertEl.value = p.fertilizerId || '';
                    }
                } catch (e) {}
            });
        }
        var savePresetBtn = document.getElementById('btn-save-worker-preset');
        if (savePresetBtn) {
            savePresetBtn.addEventListener('click', function() {
                HP.ConfirmDialog.showInput(
                    { title: 'Save preset', label: 'Preset name', value: '', placeholder: 'My preset', maxLength: 30 },
                    function(name) {
                        if (!name || !name.trim()) return;
                        var seedSelect = document.getElementById('worker-seed-select');
                        var soilSelect = document.getElementById('worker-soil-select');
                        var fertilizerSelect = document.getElementById('worker-fertilizer-select');
                        var config = {
                            name: name.trim().slice(0, 30),
                            seedId: seedSelect ? (seedSelect.value || null) : null,
                            soilId: soilSelect ? (soilSelect.value || null) : null,
                            fertilizerId: fertilizerSelect ? (fertilizerSelect.value || null) : null
                        };
                        try {
                            var presets = JSON.parse(localStorage.getItem('highprofits_worker_presets') || '[]');
                            presets.push(config);
                            if (presets.length > 20) presets = presets.slice(-20);
                            localStorage.setItem('highprofits_worker_presets', JSON.stringify(presets));
                            HP.Notifications.success('Preset saved');
                            refreshUI();
                        } catch (e) {
                            HP.Notifications.error('Failed to save preset');
                        }
                    }
                );
            });
        }
        document.addEventListener('click', function(e) {
            var target = e.target.closest ? (e.target.closest('.btn-upgrade-worker') || e.target.closest('.btn-configure-worker') || e.target.closest('.btn-remove-worker') || e.target.closest('.btn-move-worker')) : null;
            if (!target) return;
            if (target.classList.contains('btn-upgrade-worker') && !target.disabled) {
                e.preventDefault();
                upgradeWorker(target.getAttribute('data-worker'));
            } else if (target.classList.contains('btn-configure-worker')) {
                configureWorker(target.getAttribute('data-worker'));
            } else if (target.classList.contains('btn-remove-worker')) {
                removeWorker(target.getAttribute('data-worker'));
            } else if (target.classList.contains('btn-move-worker')) {
                moveWorker(target.getAttribute('data-worker'));
            }
        });
    }

    function moveWorker(workerId) {
        var workers = HP.State.getGrowerWorkers();
        var worker = workers.find(function(w) { return w.id === workerId; });
        if (!worker) return;
        var currentPropId = worker.assignedPropertyId != null ? worker.assignedPropertyId : (worker.assignedPlot && worker.assignedPlot.propertyId);
        HP.Renderer.openWorkerAssignModal(worker.workerTypeId, { moveWorkerId: workerId, currentPlot: currentPropId ? { propertyId: currentPropId } : null });
    }

    function doMoveWorker(workerId) {
        var propertySelect = document.getElementById('worker-property-select');
        if (!propertySelect || !propertySelect.value) {
            HP.Notifications.error('Please select a location');
            return;
        }
        var propertyId = propertySelect.value.trim();
        var worker = HP.State.getGrowerWorkers().find(function(w) { return w.id === workerId; });
        if (!worker) return;
        var currentPropId = worker.assignedPropertyId != null ? worker.assignedPropertyId : (worker.assignedPlot && worker.assignedPlot.propertyId);
        if (currentPropId === propertyId) {
            HP.Notifications.info('Worker is already at that location');
            HP.Renderer.closeWorkerAssignModal();
            refreshUI();
            return;
        }
        if (HP.State.setWorkerProperty(workerId, propertyId)) {
            HP.Notifications.success('Worker moved to new location');
            HP.Renderer.closeWorkerAssignModal();
            refreshUI();
        } else {
            HP.Notifications.error('Failed to move worker');
        }
    }

    HP.Events.WorkerActions = { bind: bind, getHireCost: getHireCost, getUpgradeCost: getUpgradeCost, upgradeWorker: upgradeWorker };
})();
