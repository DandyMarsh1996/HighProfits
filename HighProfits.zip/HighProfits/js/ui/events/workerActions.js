/**
 * Worker actions: hire, assign, configure, remove.
 */
(function() {
    'use strict';
    var refreshUI = function() { HP.Events.refreshUI(); };

    function getHireCost(workerTypeId) {
        var workerType = HP.Data.GrowerWorkers.get(workerTypeId);
        if (!workerType) return 0;
        var workers = HP.State.getGrowerWorkers();
        var count = 0;
        for (var i = 0; i < workers.length; i++) {
            if (workers[i].workerTypeId === workerTypeId) count++;
        }
        var mult = (workerType.costMultiplier != null) ? workerType.costMultiplier : 1.2;
        return Math.floor(workerType.baseCost * Math.pow(mult, count));
    }

    function hireWorker(workerTypeId) {
        var workerType = HP.Data.GrowerWorkers.get(workerTypeId);
        if (!workerType) { HP.Notifications.error('Invalid worker type'); return; }
        var cost = getHireCost(workerTypeId);
        if (!HP.State.canAffordBank(cost)) { HP.Notifications.error('Not enough bank funds!'); return; }
        HP.State.spendBank(cost);
        HP.Renderer.openWorkerAssignModal(workerTypeId);
        refreshUI();
    }

    function assignWorker() {
        var modal = document.getElementById('worker-assign-modal');
        if (!modal) return;
        var workerTypeId = modal.getAttribute('data-worker-type');
        if (!workerTypeId) return;
        var plotSelect = document.getElementById('worker-plot-select');
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');
        if (!plotSelect || !plotSelect.value) { HP.Notifications.error('Please select a plot'); return; }
        var plotParts = plotSelect.value.split(':');
        if (plotParts.length !== 2) { HP.Notifications.error('Invalid plot selection'); return; }
        var propertyId = plotParts[0];
        var plotIndex = parseInt(plotParts[1], 10);
        var existingWorker = HP.State.getWorkerByPlot(propertyId, plotIndex);
        if (existingWorker) { HP.Notifications.error('This plot already has a worker assigned'); return; }
        var config = {
            seedId: seedSelect ? (seedSelect.value || null) : null,
            soilId: soilSelect ? (soilSelect.value || null) : null,
            fertilizerId: fertilizerSelect ? (fertilizerSelect.value || null) : null
        };
        var worker = HP.State.addGrowerWorker(workerTypeId, { propertyId: propertyId, plotIndex: plotIndex }, config);
        if (worker) {
            var workerType = HP.Data.GrowerWorkers.get(workerTypeId);
            HP.Notifications.success('Hired and assigned ' + workerType.name + '!');
            if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
            HP.Renderer.closeWorkerAssignModal();
            refreshUI();
        } else HP.Notifications.error('Failed to assign worker');
    }

    function configureWorker(workerId) {
        var workers = HP.State.getGrowerWorkers();
        var worker = workers.find(function(w) { return w.id === workerId; });
        if (!worker) return;
        var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
        HP.Renderer.openWorkerAssignModal(worker.workerTypeId);
        var plotSelect = document.getElementById('worker-plot-select');
        if (plotSelect) {
            plotSelect.value = worker.assignedPlot.propertyId + ':' + worker.assignedPlot.plotIndex;
            plotSelect.disabled = true;
        }
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');
        if (seedSelect) seedSelect.value = worker.config.seedId || '';
        if (soilSelect) soilSelect.value = worker.config.soilId || '';
        if (fertilizerSelect) fertilizerSelect.value = worker.config.fertilizerId || '';
        var assignBtn = document.getElementById('btn-assign-worker');
        if (assignBtn) {
            assignBtn.textContent = 'Update Configuration';
            assignBtn.setAttribute('data-update-worker', workerId);
        }
    }

    function updateWorkerConfig(workerId) {
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');
        var config = {
            seedId: seedSelect ? (seedSelect.value || null) : null,
            soilId: soilSelect ? (soilSelect.value || null) : null,
            fertilizerId: fertilizerSelect ? (fertilizerSelect.value || null) : null
        };
        if (HP.State.updateWorkerConfig(workerId, config)) {
            HP.Notifications.success('Worker configuration updated');
            HP.Renderer.closeWorkerAssignModal();
            var assignBtn = document.getElementById('btn-assign-worker');
            if (assignBtn) assignBtn.removeAttribute('data-update-worker');
            refreshUI();
        } else HP.Notifications.error('Failed to update configuration');
    }

    function removeWorker(workerId) {
        HP.ConfirmDialog.showConfirm(
            { message: 'Remove this worker? They will stop working immediately.', confirmLabel: 'Remove', danger: true },
            function() {
                if (HP.State.removeGrowerWorker(workerId)) {
                    HP.Notifications.info('Worker removed');
                    refreshUI();
                } else HP.Notifications.error('Failed to remove worker');
            }
        );
    }

    function bind() {
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('btn-hire-worker') && !e.target.disabled) {
                var workerTypeId = e.target.getAttribute('data-worker');
                hireWorker(workerTypeId);
            }
        });
        var assignBtn = document.getElementById('btn-assign-worker');
        if (assignBtn) {
            assignBtn.addEventListener('click', function() {
                var modal = document.getElementById('worker-assign-modal');
                var moveWorkerId = modal && modal.getAttribute('data-move-worker-id');
                if (moveWorkerId) {
                    doMoveWorker(moveWorkerId);
                    return;
                }
                var updateWorkerId = this.getAttribute('data-update-worker');
                if (updateWorkerId) updateWorkerConfig(updateWorkerId);
                else assignWorker();
            });
        }
        var closeBtn = document.getElementById('btn-close-worker-modal');
        if (closeBtn) closeBtn.addEventListener('click', function() { HP.Renderer.closeWorkerAssignModal(); });
        var presetSelect = document.getElementById('worker-preset-select');
        if (presetSelect) {
            presetSelect.addEventListener('change', function() {
                var idx = this.value;
                if (idx === '') return;
                try {
                    var presets = JSON.parse(localStorage.getItem('highprofits_worker_presets') || '[]');
                    var p = presets[parseInt(idx, 10)];
                    if (p) {
                        var seedEl = document.getElementById('worker-seed-select');
                        var soilEl = document.getElementById('worker-soil-select');
                        var fertEl = document.getElementById('worker-fertilizer-select');
                        if (seedEl) seedEl.value = p.seedId || '';
                        if (soilEl) soilEl.value = p.soilId || '';
                        if (fertEl) fertEl.value = p.fertilizerId || '';
                    }
                } catch (e) {}
            });
        }
        var savePresetBtn = document.getElementById('btn-save-worker-preset');
        if (savePresetBtn) {
            savePresetBtn.addEventListener('click', function() {
                HP.ConfirmDialog.showInput(
                    { title: 'Save preset', label: 'Preset name', value: '', placeholder: 'My preset', maxLength: 30 },
                    function(name) {
                        if (!name || !name.trim()) return;
                        var seedSelect = document.getElementById('worker-seed-select');
                        var soilSelect = document.getElementById('worker-soil-select');
                        var fertilizerSelect = document.getElementById('worker-fertilizer-select');
                        var config = {
                            name: name.trim().slice(0, 30),
                            seedId: seedSelect ? (seedSelect.value || null) : null,
                            soilId: soilSelect ? (soilSelect.value || null) : null,
                            fertilizerId: fertilizerSelect ? (fertilizerSelect.value || null) : null
                        };
                        try {
                            var presets = JSON.parse(localStorage.getItem('highprofits_worker_presets') || '[]');
                            presets.push(config);
                            if (presets.length > 20) presets = presets.slice(-20);
                            localStorage.setItem('highprofits_worker_presets', JSON.stringify(presets));
                            HP.Notifications.success('Preset saved');
                            refreshUI();
                        } catch (e) {
                            HP.Notifications.error('Failed to save preset');
                        }
                    }
                );
            });
        }
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('btn-configure-worker')) {
                configureWorker(e.target.getAttribute('data-worker'));
            } else if (e.target.classList.contains('btn-remove-worker')) {
                removeWorker(e.target.getAttribute('data-worker'));
            } else if (e.target.classList.contains('btn-move-worker')) {
                moveWorker(e.target.getAttribute('data-worker'));
            }
        });
    }

    function moveWorker(workerId) {
        var workers = HP.State.getGrowerWorkers();
        var worker = workers.find(function(w) { return w.id === workerId; });
        if (!worker) return;
        HP.Renderer.openWorkerAssignModal(worker.workerTypeId, { moveWorkerId: workerId, currentPlot: worker.assignedPlot });
    }

    function doMoveWorker(workerId) {
        var plotSelect = document.getElementById('worker-plot-select');
        if (!plotSelect || !plotSelect.value) {
            HP.Notifications.error('Please select a plot');
            return;
        }
        var plotParts = plotSelect.value.split(':');
        if (plotParts.length !== 2) {
            HP.Notifications.error('Invalid plot selection');
            return;
        }
        var propertyId = plotParts[0];
        var plotIndex = parseInt(plotParts[1], 10);
        var worker = HP.State.getGrowerWorkers().find(function(w) { return w.id === workerId; });
        if (!worker) return;
        var isSame = worker.assignedPlot && worker.assignedPlot.propertyId === propertyId && worker.assignedPlot.plotIndex === plotIndex;
        if (isSame) {
            HP.Notifications.info('Worker is already on that plot');
            HP.Renderer.closeWorkerAssignModal();
            refreshUI();
            return;
        }
        var existing = HP.State.getWorkerByPlot(propertyId, plotIndex);
        if (existing && existing.id !== workerId) {
            HP.Notifications.error('That plot already has a worker');
            return;
        }
        if (HP.State.setWorkerPlot(workerId, propertyId, plotIndex)) {
            HP.Notifications.success('Worker moved to new plot');
            HP.Renderer.closeWorkerAssignModal();
            refreshUI();
        } else {
            HP.Notifications.error('Failed to move worker');
        }
    }

    HP.Events.WorkerActions = { bind: bind, getHireCost: getHireCost };
})();
