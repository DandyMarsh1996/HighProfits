/**
 * Worker actions: hire, assign, configure, remove.
 */
(function() {
    'use strict';
    var refreshUI = function() { HP.Events.refreshUI(); };

    function hireWorker(workerTypeId) {
        var workerType = HP.Data.GrowerWorkers.get(workerTypeId);
        if (!workerType) { HP.Notifications.error('Invalid worker type'); return; }
        if (!HP.State.canAffordBank(workerType.baseCost)) { HP.Notifications.error('Not enough bank funds!'); return; }
        HP.State.spendBank(workerType.baseCost);
        HP.Renderer.openWorkerAssignModal(workerTypeId);
        refreshUI();
    }

    function assignWorker() {
        var modal = document.getElementById('worker-assign-modal');
        if (!modal) return;
        var workerTypeId = modal.getAttribute('data-worker-type');
        if (!workerTypeId) return;
        var plotSelect = document.getElementById('worker-plot-select');
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');
        if (!plotSelect || !plotSelect.value) { HP.Notifications.error('Please select a plot'); return; }
        var plotParts = plotSelect.value.split(':');
        if (plotParts.length !== 2) { HP.Notifications.error('Invalid plot selection'); return; }
        var propertyId = plotParts[0];
        var plotIndex = parseInt(plotParts[1], 10);
        var existingWorker = HP.State.getWorkerByPlot(propertyId, plotIndex);
        if (existingWorker) { HP.Notifications.error('This plot already has a worker assigned'); return; }
        var config = {
            seedId: seedSelect ? (seedSelect.value || null) : null,
            soilId: soilSelect ? (soilSelect.value || null) : null,
            fertilizerId: fertilizerSelect ? (fertilizerSelect.value || null) : null
        };
        var worker = HP.State.addGrowerWorker(workerTypeId, { propertyId: propertyId, plotIndex: plotIndex }, config);
        if (worker) {
            var workerType = HP.Data.GrowerWorkers.get(workerTypeId);
            HP.Notifications.success('Hired and assigned ' + workerType.name + '!');
            if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
            HP.Renderer.closeWorkerAssignModal();
            refreshUI();
        } else HP.Notifications.error('Failed to assign worker');
    }

    function configureWorker(workerId) {
        var workers = HP.State.getGrowerWorkers();
        var worker = workers.find(function(w) { return w.id === workerId; });
        if (!worker) return;
        var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
        HP.Renderer.openWorkerAssignModal(worker.workerTypeId);
        var plotSelect = document.getElementById('worker-plot-select');
        if (plotSelect) {
            plotSelect.value = worker.assignedPlot.propertyId + ':' + worker.assignedPlot.plotIndex;
            plotSelect.disabled = true;
        }
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');
        if (seedSelect) seedSelect.value = worker.config.seedId || '';
        if (soilSelect) soilSelect.value = worker.config.soilId || '';
        if (fertilizerSelect) fertilizerSelect.value = worker.config.fertilizerId || '';
        var assignBtn = document.getElementById('btn-assign-worker');
        if (assignBtn) {
            assignBtn.textContent = 'Update Configuration';
            assignBtn.setAttribute('data-update-worker', workerId);
        }
    }

    function updateWorkerConfig(workerId) {
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');
        var config = {
            seedId: seedSelect ? (seedSelect.value || null) : null,
            soilId: soilSelect ? (soilSelect.value || null) : null,
            fertilizerId: fertilizerSelect ? (fertilizerSelect.value || null) : null
        };
        if (HP.State.updateWorkerConfig(workerId, config)) {
            HP.Notifications.success('Worker configuration updated');
            HP.Renderer.closeWorkerAssignModal();
            var assignBtn = document.getElementById('btn-assign-worker');
            if (assignBtn) assignBtn.removeAttribute('data-update-worker');
            refreshUI();
        } else HP.Notifications.error('Failed to update configuration');
    }

    function removeWorker(workerId) {
        if (confirm('Remove this worker? They will stop working immediately.')) {
            if (HP.State.removeGrowerWorker(workerId)) {
                HP.Notifications.info('Worker removed');
                refreshUI();
            } else HP.Notifications.error('Failed to remove worker');
        }
    }

    function bind() {
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('btn-hire-worker') && !e.target.disabled) {
                var workerTypeId = e.target.getAttribute('data-worker');
                hireWorker(workerTypeId);
            }
        });
        var assignBtn = document.getElementById('btn-assign-worker');
        if (assignBtn) {
            assignBtn.addEventListener('click', function() {
                var updateWorkerId = this.getAttribute('data-update-worker');
                if (updateWorkerId) updateWorkerConfig(updateWorkerId);
                else assignWorker();
            });
        }
        var closeBtn = document.getElementById('btn-close-worker-modal');
        if (closeBtn) closeBtn.addEventListener('click', function() { HP.Renderer.closeWorkerAssignModal(); });
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('btn-configure-worker')) {
                var workerId = e.target.getAttribute('data-worker');
                configureWorker(workerId);
            } else if (e.target.classList.contains('btn-remove-worker')) {
                var workerId = e.target.getAttribute('data-worker');
                removeWorker(workerId);
            }
        });
    }

    HP.Events.WorkerActions = { bind: bind };
})();
