/**
 * Stock Market: buy and sell shares (event delegation).
 */
(function() {
    'use strict';

    function bind() {
        document.body.addEventListener('click', function(e) {
            var btn = e.target && e.target.closest && e.target.closest('[data-action="stock-buy"], [data-action="stock-sell"]');
            if (!btn) return;
            e.preventDefault();
            e.stopPropagation();
            var action = btn.getAttribute('data-action');
            var stockId = btn.getAttribute('data-stock-id');
            var sharesStr = btn.getAttribute('data-shares');
            if (!stockId || !sharesStr) return;
            var shares = parseInt(sharesStr, 10);
            if (isNaN(shares) || shares < 1) return;
            if (!HP.State.buy || !HP.State.sell) return;

            if (action === 'stock-buy') {
                var result = HP.State.buy(stockId, shares);
                if (result.success) {
                    if (HP.Notifications) HP.Notifications.success('Bought ' + shares + ' share(s). Cost $' + (HP.Helpers && HP.Helpers.formatNumber ? HP.Helpers.formatNumber(result.cost) : result.cost) + '.');
                    if (HP.SoundManager && HP.SoundManager.play) HP.SoundManager.play('success');
                    if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
                } else if (result.message && HP.Notifications) HP.Notifications.error(result.message);
            } else if (action === 'stock-sell') {
                var needConfirm = btn.getAttribute('data-confirm-sell-all') === '1';
                var stock = HP.Data.Stocks && HP.Data.Stocks.get ? HP.Data.Stocks.get(stockId) : null;
                var stockName = stock ? stock.name : stockId;
                var doSell = function() {
                    var res = HP.State.sell(stockId, shares);
                    if (res.success) {
                        if (HP.Notifications) HP.Notifications.success('Sold ' + shares + ' share(s). Proceeds $' + (HP.Helpers && HP.Helpers.formatNumber ? HP.Helpers.formatNumber(res.proceeds) : res.proceeds) + '.');
                        if (HP.SoundManager && HP.SoundManager.play) HP.SoundManager.play('success');
                        if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
                    } else if (res.message && HP.Notifications) HP.Notifications.error(res.message);
                    if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
                };
                if (needConfirm && HP.ConfirmDialog && HP.ConfirmDialog.showConfirm) {
                    HP.ConfirmDialog.showConfirm(
                        { message: 'Sell all ' + shares + ' share(s) of ' + stockName + '? You\'ll receive the current price per share.' },
                        doSell
                    );
                } else {
                    doSell();
                }
                return;
            }
            if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
        });
    }

    HP.Events = HP.Events || {};
    HP.Events.StockMarketActions = { bind: bind };
})();
