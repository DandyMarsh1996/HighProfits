/**
 * Heat controls: reduce heat button, payoff panel, payoff actions, heat info modal.
 */
(function() {
    'use strict';

    function openHeatModal() {
        var explanationEl = document.getElementById('heat-explanation');
        var modalEl = document.getElementById('heat-modal');
        if (!explanationEl || !modalEl) return;

        var constants = HP.Data.Constants || {};
        var raidMoney = (constants.RAID_MONEY_LOSS_PERCENT != null) ? constants.RAID_MONEY_LOSS_PERCENT : 25;
        var raidProduct = (constants.RAID_PRODUCT_LOSS_PERCENT != null) ? constants.RAID_PRODUCT_LOSS_PERCENT : 30;

        var explain = '<strong>Heat</strong> is how much attention the authorities are paying to you. The more you grow and sell, the higher it gets. ' +
            'If heat reaches <strong>100%</strong>, you get raided: you lose <strong>' + raidMoney + '%</strong> of your cash and <strong>' + raidProduct + '%</strong> of your product. ' +
            'Heat does not go down on its own — you have to pay it off. Use <strong>Reduce heat</strong> to bribe, lay low, or hire cleaners; each option costs more the more you use it until the next raid. ' +
            'Security upgrades (room upgrades and hardware) reduce how fast heat builds from growing. Keep an eye on the bar and pay off before it hits 100%.';
        explanationEl.innerHTML = explain;
        modalEl.classList.remove('hidden');
    }

    function closeHeatModal() {
        var modalEl = document.getElementById('heat-modal');
        if (modalEl) modalEl.classList.add('hidden');
    }

    function openWaterModal() {
        var explanationEl = document.getElementById('water-explanation');
        var modalEl = document.getElementById('water-modal');
        if (!explanationEl || !modalEl) return;

        var explain = '<strong>Water reservoir</strong> – The tank at the top (Grow view) holds water. It refills over time from the tap; watch the "Next" timer. ' +
            '<strong>Watering can</strong> – Buy one from Hardware and equip it on a plot (or use it from inventory). Click "Water" on a plant to give it water from the reservoir. ' +
            'Plants need water to grow; each one drains water over time. If a plant runs <strong>dry</strong> for too long, it can <strong>die</strong>. Keep the reservoir topped up and water your crops regularly.';
        explanationEl.innerHTML = explain;
        modalEl.classList.remove('hidden');
    }

    function closeWaterModal() {
        var modalEl = document.getElementById('water-modal');
        if (modalEl) modalEl.classList.add('hidden');
    }

    function bind() {
        var reduceBtn = document.getElementById('heat-reduce-btn');
        var panel = document.getElementById('heat-reduce-panel');
        if (reduceBtn && panel) {
            reduceBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                panel.classList.toggle('hidden');
                if (!panel.classList.contains('hidden') && HP.Renderer && HP.Renderer.update) HP.Renderer.update();
            });
        }
        document.addEventListener('click', function() {
            if (panel && !panel.classList.contains('hidden')) panel.classList.add('hidden');
        });
        if (panel) panel.addEventListener('click', function(e) { e.stopPropagation(); });
        document.querySelectorAll('.heat-payoff-btn').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                var action = this.getAttribute('data-action');
                if (!action || !HP.State || !HP.State.applyHeatReduction) return;
                var result = HP.State.applyHeatReduction(action);
                if (result.success) {
                    if (HP.Notifications) HP.Notifications.success('Heat reduced by ' + result.reduction + '. Cost: $' + (result.cost || 0) + '.');
                    if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
                    if (panel) panel.classList.add('hidden');
                    if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
                } else if (result.reason === 'cant_afford' && HP.Notifications) {
                    HP.Notifications.error('Not enough cash. Heat payoffs require cash. Need $' + (result.cost || 0) + '.');
                }
            });
        });

        var heatInfoBtn = document.getElementById('btn-heat-info');
        var closeHeatBtn = document.getElementById('btn-close-heat');
        if (heatInfoBtn) heatInfoBtn.addEventListener('click', function(e) { e.stopPropagation(); openHeatModal(); });
        if (closeHeatBtn) closeHeatBtn.addEventListener('click', function(e) { e.stopPropagation(); closeHeatModal(); });

        var waterInfoBtn = document.getElementById('btn-water-info');
        var closeWaterBtn = document.getElementById('btn-close-water');
        if (waterInfoBtn) waterInfoBtn.addEventListener('click', function(e) { e.stopPropagation(); openWaterModal(); });
        if (closeWaterBtn) closeWaterBtn.addEventListener('click', function(e) { e.stopPropagation(); closeWaterModal(); });

        var closeRaidBtn = document.getElementById('btn-close-raid');
        var ackRaidBtn = document.getElementById('btn-raid-ack');
        if (closeRaidBtn) closeRaidBtn.addEventListener('click', function(e) { e.stopPropagation(); if (HP.Renderer && HP.Renderer.closeRaidModal) HP.Renderer.closeRaidModal(); });
        if (ackRaidBtn) ackRaidBtn.addEventListener('click', function(e) { e.stopPropagation(); if (HP.Renderer && HP.Renderer.closeRaidModal) HP.Renderer.closeRaidModal(); });

        var statsInfoBtn = document.getElementById('btn-stats-info');
        var closeStatsInfoBtn = document.getElementById('btn-close-stats-info');
        if (statsInfoBtn) statsInfoBtn.addEventListener('click', function(e) { e.stopPropagation(); openStatsExplanationModal(); });
        if (closeStatsInfoBtn) closeStatsInfoBtn.addEventListener('click', function(e) { e.stopPropagation(); closeStatsExplanationModal(); });

        var btnStockInfo = document.getElementById('btn-stock-market-info');
        var closeStockInfo = document.getElementById('btn-close-stock-info');
        if (btnStockInfo) btnStockInfo.addEventListener('click', function(e) { e.stopPropagation(); openStockMarketInfoModal(); });
        if (closeStockInfo) closeStockInfo.addEventListener('click', function(e) { e.stopPropagation(); closeStockMarketInfoModal(); });

        var btnLaunderInfo = document.getElementById('btn-launder-info');
        var closeLaunderInfo = document.getElementById('btn-close-launder-info');
        if (btnLaunderInfo) btnLaunderInfo.addEventListener('click', function(e) { e.stopPropagation(); openLaunderInfoModal(); });
        if (closeLaunderInfo) closeLaunderInfo.addEventListener('click', function(e) { e.stopPropagation(); closeLaunderInfoModal(); });

        var btnGeneticsInfo = document.getElementById('btn-genetics-info');
        var closeGeneticsInfo = document.getElementById('btn-close-genetics-info');
        if (btnGeneticsInfo) btnGeneticsInfo.addEventListener('click', function(e) { e.stopPropagation(); openGeneticsInfoModal(); });
        if (closeGeneticsInfo) closeGeneticsInfo.addEventListener('click', function(e) { e.stopPropagation(); closeGeneticsInfoModal(); });
    }

    function openStockMarketInfoModal() {
        var textEl = document.getElementById('stock-market-info-text');
        var modalEl = document.getElementById('stock-market-info-modal');
        if (!textEl || !modalEl) return;
        var interval = (HP.Data && HP.Data.Constants && HP.Data.Constants.STOCK_TICK_INTERVAL_SEC) || 60;
        textEl.innerHTML = '<strong>Prices</strong> drift over time (every ' + interval + ' seconds) and tend to move back toward each stock\'s base value. <strong>Buy low, sell high.</strong> ' +
            'When you buy, the price goes up slightly; when you sell, it goes down. There\'s a small broker fee on buys. Use bank funds only.';
        modalEl.classList.remove('hidden');
    }
    function closeStockMarketInfoModal() {
        var modalEl = document.getElementById('stock-market-info-modal');
        if (modalEl) modalEl.classList.add('hidden');
    }
    function openLaunderInfoModal() {
        var textEl = document.getElementById('launder-info-text');
        var modalEl = document.getElementById('launder-info-modal');
        if (!textEl || !modalEl) return;
        textEl.innerHTML = '<strong>Grey contact:</strong> Always available; higher fee and adds a bit of heat. <strong>Your businesses:</strong> Lower fee and no heat, but each has limited daily capacity (resets each day). ' +
            'Choose a channel, then launder. Withdraw moves bank → cash for free.';
        modalEl.classList.remove('hidden');
    }
    function closeLaunderInfoModal() {
        var modalEl = document.getElementById('launder-info-modal');
        if (modalEl) modalEl.classList.add('hidden');
    }
    function openGeneticsInfoModal() {
        var textEl = document.getElementById('genetics-info-text');
        var modalEl = document.getElementById('genetics-info-modal');
        if (!textEl || !modalEl) return;
        textEl.innerHTML = 'Select two <strong>parent seeds</strong> from your inventory. The game combines their traits to create a new hybrid strain. ' +
            'Traits are inherited with some variance. There\'s a small chance for <strong>rare mutations</strong>. New strains are added to your library and can be planted like any seed.';
        modalEl.classList.remove('hidden');
    }
    function closeGeneticsInfoModal() {
        var modalEl = document.getElementById('genetics-info-modal');
        if (modalEl) modalEl.classList.add('hidden');
    }

    function openStatsExplanationModal() {
        var textEl = document.getElementById('stats-explanation-text');
        var modalEl = document.getElementById('stats-explanation-modal');
        if (!textEl || !modalEl) return;
        var html = '<strong>Economy:</strong> Total earned (all time), current cash, biggest single sale, total product sold. ' +
            '<strong>Growing:</strong> Plants grown (harvested), plants died (neglected), best harvest (single plant), total harvested. ' +
            '<strong>Quality breakdown:</strong> Harvested amounts by quality (low / medium / good / premium). ' +
            '<strong>Heat & security:</strong> Current heat %, raids survived, pay-offs used, heat gain reduction from security. ' +
            '<strong>Time:</strong> Play time, level, rank, properties owned.';
        textEl.innerHTML = html;
        modalEl.classList.remove('hidden');
    }

    function closeStatsExplanationModal() {
        var modalEl = document.getElementById('stats-explanation-modal');
        if (modalEl) modalEl.classList.add('hidden');
    }

    HP.Events.HeatControls = {
        bind: bind,
        openHeatModal: openHeatModal,
        closeHeatModal: closeHeatModal,
        openWaterModal: openWaterModal,
        closeWaterModal: closeWaterModal,
        openStatsExplanationModal: openStatsExplanationModal,
        closeStatsExplanationModal: closeStatsExplanationModal,
        closeStockMarketInfoModal: closeStockMarketInfoModal,
        closeLaunderInfoModal: closeLaunderInfoModal,
        closeGeneticsInfoModal: closeGeneticsInfoModal
    };
})();
