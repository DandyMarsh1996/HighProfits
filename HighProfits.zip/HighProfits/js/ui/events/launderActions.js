/**
 * Launder (cash → bank) and Withdraw (bank → cash). Strategic: choose channel (contact vs business).
 * Contact: always available, higher fee, adds heat. Businesses: daily capacity, lower fee, no heat.
 */
(function() {
    'use strict';

    var CHANNEL_CONTACT = 'contact';

    function getConstants() {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        return {
            baseFee: (c.LAUNDERING_FEE_PERCENT != null) ? c.LAUNDERING_FEE_PERCENT : 25,
            contactFee: (c.LAUNDER_CONTACT_FEE_PERCENT != null) ? c.LAUNDER_CONTACT_FEE_PERCENT : 28,
            contactHeatPer1000: (c.LAUNDER_CONTACT_HEAT_PER_1000 != null) ? c.LAUNDER_CONTACT_HEAT_PER_1000 : 0.4
        };
    }

    /** Fee % for a channel: 'contact' or businessId. */
    function getFeePercent(channel) {
        var c = getConstants();
        if (channel === CHANNEL_CONTACT) return c.contactFee;
        var biz = HP.Data.Businesses && HP.Data.Businesses.get ? HP.Data.Businesses.get(channel) : null;
        if (!biz) return c.contactFee;
        var reduction = (biz.launderFeeReduction != null) ? biz.launderFeeReduction : 0;
        return Math.max(0, c.baseFee - reduction);
    }

    /** List channels: contact + each owned business, with fee and capacity remaining. */
    function getChannels() {
        var list = [{ id: CHANNEL_CONTACT, label: 'Grey contact', feePercent: getFeePercent(CHANNEL_CONTACT), capacityRemaining: null, capacityMax: null }];
        if (!HP.State.getBusinessesOwned || !HP.Data.Businesses) return list;
        var owned = HP.State.getBusinessesOwned();
        for (var i = 0; i < owned.length; i++) {
            var biz = HP.Data.Businesses.get(owned[i]);
            if (!biz) continue;
            var remaining = HP.State.getLaunderCapacityRemaining ? HP.State.getLaunderCapacityRemaining(owned[i]) : 0;
            var max = (biz.dailyLaunderCapacity != null) ? biz.dailyLaunderCapacity : 0;
            list.push({ id: biz.id, label: biz.name, feePercent: getFeePercent(biz.id), capacityRemaining: remaining, capacityMax: max });
        }
        return list;
    }

    function launder(amount, channel) {
        if (!HP.State || !HP.State.spendCash || !HP.State.addBank) return false;
        var cash = HP.State.getCash ? HP.State.getCash() : 0;
        if (amount < 1 || cash < amount) return false;
        channel = channel || CHANNEL_CONTACT;

        if (channel !== CHANNEL_CONTACT) {
            var capacityLeft = HP.State.getLaunderCapacityRemaining ? HP.State.getLaunderCapacityRemaining(channel) : 0;
            if (capacityLeft <= 0) {
                if (HP.Notifications) HP.Notifications.error('No capacity left today for this business. Use Grey contact or wait until tomorrow.');
                return false;
            }
            if (amount > capacityLeft) {
                if (HP.Notifications) HP.Notifications.error('Only $' + HP.Helpers.formatNumber(capacityLeft) + ' capacity left today for this channel.');
                return false;
            }
        }

        var feePct = getFeePercent(channel) / 100;
        var fee = Math.floor(amount * feePct);
        var clean = amount - fee;
        HP.State.spendCash(amount);
        HP.State.addBank(clean);
        if (channel !== CHANNEL_CONTACT && HP.State.recordLaunder) HP.State.recordLaunder(channel, amount);
        if (HP.State.incrementStat) HP.State.incrementStat('laundersTotal', 1);

        var c = getConstants();
        if (channel === CHANNEL_CONTACT && c.contactHeatPer1000 > 0 && HP.State.addHeat) {
            var heat = (amount / 1000) * c.contactHeatPer1000;
            if (heat > 0) HP.State.addHeat(heat);
        }

        if (HP.SoundManager && HP.SoundManager.play) HP.SoundManager.play('success');
        var channelLabel = channel === CHANNEL_CONTACT ? 'contact' : (HP.Data.Businesses && HP.Data.Businesses.get ? (HP.Data.Businesses.get(channel).name || channel) : channel);
        if (HP.Notifications) HP.Notifications.success('Laundered $' + HP.Helpers.formatNumber(amount) + ' via ' + channelLabel + ' → $' + HP.Helpers.formatNumber(clean) + ' bank (fee $' + HP.Helpers.formatNumber(fee) + ')');
        if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
        return true;
    }

    function withdraw(amount) {
        if (!HP.State || !HP.State.spendBank || !HP.State.addCash) return false;
        var bank = HP.State.getBank ? HP.State.getBank() : 0;
        if (amount < 1 || bank < amount) return false;
        HP.State.spendBank(amount);
        HP.State.addCash(amount);
        if (HP.SoundManager && HP.SoundManager.play) HP.SoundManager.play('success');
        if (HP.Notifications) HP.Notifications.success('Withdrew $' + HP.Helpers.formatNumber(amount) + ' from bank → cash');
        if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
        return true;
    }

    function getFallbackHustleConfig() {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        return {
            amount: (c.FALLBACK_HUSTLE_CASH != null) ? c.FALLBACK_HUSTLE_CASH : 75,
            cooldownMs: (c.FALLBACK_HUSTLE_COOLDOWN_MS != null) ? c.FALLBACK_HUSTLE_COOLDOWN_MS : 300000,
            threshold: (c.FALLBACK_HUSTLE_THRESHOLD != null) ? c.FALLBACK_HUSTLE_THRESHOLD : 100
        };
    }

    function getFallbackHustleStatus() {
        if (!HP.State) return { visible: false, canUse: false, cooldownRemainingMs: 0, amount: 75, threshold: 100 };
        var total = (HP.State.getCash ? HP.State.getCash() : 0) + (HP.State.getBank ? HP.State.getBank() : 0);
        var config = getFallbackHustleConfig();
        if (total >= config.threshold) {
            return { visible: false, canUse: false, cooldownRemainingMs: 0, amount: config.amount, threshold: config.threshold };
        }
        var lastAt = HP.State.getLastFallbackHustleAt ? HP.State.getLastFallbackHustleAt() : 0;
        var now = Date.now();
        var elapsed = now - lastAt;
        var cooldownRemainingMs = Math.max(0, config.cooldownMs - elapsed);
        var canUse = cooldownRemainingMs <= 0;
        return { visible: true, canUse: canUse, cooldownRemainingMs: cooldownRemainingMs, amount: config.amount, threshold: config.threshold };
    }

    function doFallbackHustle() {
        if (!HP.State || !HP.State.addCash || !HP.State.setLastFallbackHustleAt) return { success: false, message: 'Not available.' };
        var status = getFallbackHustleStatus();
        if (!status.visible) {
            return { success: false, message: 'Emergency cash is only available when total money is under $' + HP.Helpers.formatNumber(status.threshold) + '.' };
        }
        if (!status.canUse) {
            var mins = Math.ceil(status.cooldownRemainingMs / 60000);
            return { success: false, message: 'You can do another quick hustle in ' + mins + ' min.' };
        }
        HP.State.addCash(status.amount);
        HP.State.setLastFallbackHustleAt(Date.now());
        if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
        if (HP.SoundManager && HP.SoundManager.play) HP.SoundManager.play('success');
        if (HP.Notifications) HP.Notifications.success('Quick hustle: +$' + HP.Helpers.formatNumber(status.amount) + ' cash. Use it to buy seeds and get back on your feet.');
        return { success: true, message: '' };
    }

    function bind() {
        var btn100 = document.getElementById('launder-100');
        var btn500 = document.getElementById('launder-500');
        var btn1000 = document.getElementById('launder-1000');
        var btnAll = document.getElementById('launder-all');
        var customInput = document.getElementById('launder-custom-input');
        var customBtn = document.getElementById('launder-custom-btn');
        var wBtn100 = document.getElementById('withdraw-100');
        var wBtn500 = document.getElementById('withdraw-500');
        var wBtn1000 = document.getElementById('withdraw-1000');
        var wBtnAll = document.getElementById('withdraw-all');
        var wCustomInput = document.getElementById('withdraw-custom-input');
        var wCustomBtn = document.getElementById('withdraw-custom-btn');

        function getSelectedChannel() {
            var el = document.getElementById('launder-channel');
            return (el && el.value) || CHANNEL_CONTACT;
        }

        function doLaunder(amount) {
            var cash = HP.State.getCash ? HP.State.getCash() : 0;
            var toLaunder = amount === -1 ? cash : Math.min(amount, cash);
            var channel = getSelectedChannel();
            if (amount === -1 && toLaunder >= 1) {
                HP.ConfirmDialog.showConfirm(
                    { message: 'Launder all $' + HP.Helpers.formatNumber(cash) + ' to bank via ' + (channel === CHANNEL_CONTACT ? 'contact' : channel) + '? You will lose the laundering fee on the full amount.' },
                    function() {
                        launder(toLaunder, channel);
                        if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
                        if (HP.Events && HP.Events.refreshUI) HP.Events.refreshUI();
                    }
                );
                return;
            }
            if (toLaunder >= 1) {
                launder(toLaunder, channel);
                if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
                if (HP.Events && HP.Events.refreshUI) HP.Events.refreshUI();
            }
        }

        function doWithdraw(amount) {
            var bank = HP.State.getBank ? HP.State.getBank() : 0;
            var toWithdraw = amount === -1 ? bank : Math.min(amount, bank);
            if (amount === -1 && toWithdraw >= 1) {
                HP.ConfirmDialog.showConfirm(
                    { message: 'Withdraw all $' + HP.Helpers.formatNumber(bank) + ' from bank to cash? You can use it for seeds and heat payoffs.' },
                    function() {
                        withdraw(toWithdraw);
                        if (HP.Events && HP.Events.refreshUI) HP.Events.refreshUI();
                    }
                );
                return;
            }
            if (toWithdraw >= 1) {
                withdraw(toWithdraw);
                if (HP.Events && HP.Events.refreshUI) HP.Events.refreshUI();
            }
        }

        document.body.addEventListener('click', function(e) {
            var channelBtn = e.target && e.target.closest && e.target.closest('.launder-channel-btn');
            if (channelBtn) {
                e.preventDefault();
                var ch = channelBtn.getAttribute('data-channel');
                if (ch) {
                    var input = document.getElementById('launder-channel');
                    if (input) input.value = ch;
                    var list = document.getElementById('launder-channel-list');
                    if (list) {
                        list.querySelectorAll('.launder-channel-btn').forEach(function(b) { b.classList.remove('launder-channel-selected'); });
                        channelBtn.classList.add('launder-channel-selected');
                    }
                    if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
                }
            }
        });

        if (btn100) btn100.addEventListener('click', function() { doLaunder(100); });
        if (btn500) btn500.addEventListener('click', function() { doLaunder(500); });
        if (btn1000) btn1000.addEventListener('click', function() { doLaunder(1000); });
        if (btnAll) btnAll.addEventListener('click', function() { doLaunder(-1); });
        
        if (customBtn && customInput) {
            customBtn.addEventListener('click', function() {
                var amount = parseInt(customInput.value, 10);
                if (isNaN(amount) || amount < 1) {
                    if (HP.Notifications) HP.Notifications.error('Enter a valid amount');
                    return;
                }
                doLaunder(amount);
                customInput.value = '';
            });
            customInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') customBtn.click();
            });
        }

        if (wBtn100) wBtn100.addEventListener('click', function() { doWithdraw(100); });
        if (wBtn500) wBtn500.addEventListener('click', function() { doWithdraw(500); });
        if (wBtn1000) wBtn1000.addEventListener('click', function() { doWithdraw(1000); });
        if (wBtnAll) wBtnAll.addEventListener('click', function() { doWithdraw(-1); });
        
        if (wCustomBtn && wCustomInput) {
            wCustomBtn.addEventListener('click', function() {
                var amount = parseInt(wCustomInput.value, 10);
                if (isNaN(amount) || amount < 1) {
                    if (HP.Notifications) HP.Notifications.error('Enter a valid amount');
                    return;
                }
                doWithdraw(amount);
                wCustomInput.value = '';
            });
            wCustomInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') wCustomBtn.click();
            });
        }

        var btnFallback = document.getElementById('btn-fallback-hustle');
        if (btnFallback) {
            btnFallback.addEventListener('click', function() {
                var result = doFallbackHustle();
                if (!result.success && result.message && HP.Notifications) HP.Notifications.warning(result.message);
                if (result.success && HP.Events && HP.Events.refreshUI) HP.Events.refreshUI();
            });
        }
    }

    HP.Events.LaunderActions = {
        bind: bind,
        launder: launder,
        withdraw: withdraw,
        getFeePercent: getFeePercent,
        getChannels: getChannels,
        getFallbackHustleConfig: getFallbackHustleConfig,
        getFallbackHustleStatus: getFallbackHustleStatus,
        doFallbackHustle: doFallbackHustle
    };
})();
