/**
 * Launder (cash → bank) and Withdraw (bank → cash). Legitimate stores require bank funds.
 */
(function() {
    'use strict';

    function getFeePercent() {
        var c = HP.Data && HP.Data.Constants ? HP.Data.Constants : {};
        var base = (c.LAUNDERING_FEE_PERCENT != null) ? c.LAUNDERING_FEE_PERCENT : 25;
        var reduction = 0;
        if (HP.State && HP.State.getBusinessesOwned && HP.Data && HP.Data.Businesses) {
            var owned = HP.State.getBusinessesOwned();
            for (var i = 0; i < owned.length; i++) {
                var b = HP.Data.Businesses.get(owned[i]);
                if (b && b.launderFeeReduction != null) reduction += b.launderFeeReduction;
            }
        }
        return Math.max(0, base - reduction);
    }

    function launder(amount) {
        if (!HP.State || !HP.State.spendCash || !HP.State.addBank) return false;
        var cash = HP.State.getCash ? HP.State.getCash() : 0;
        if (amount < 1 || cash < amount) return false;
        var feePct = getFeePercent() / 100;
        var fee = Math.floor(amount * feePct);
        var clean = amount - fee;
        HP.State.spendCash(amount);
        HP.State.addBank(clean);
        if (HP.State.incrementStat) HP.State.incrementStat('laundersTotal', 1);
        if (HP.SoundManager && HP.SoundManager.play) HP.SoundManager.play('success');
        if (HP.Notifications) HP.Notifications.success('Laundered $' + HP.Helpers.formatNumber(amount) + ' → $' + HP.Helpers.formatNumber(clean) + ' bank (lost $' + HP.Helpers.formatNumber(fee) + ' fee)');
        if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
        return true;
    }

    function withdraw(amount) {
        if (!HP.State || !HP.State.spendBank || !HP.State.addCash) return false;
        var bank = HP.State.getBank ? HP.State.getBank() : 0;
        if (amount < 1 || bank < amount) return false;
        HP.State.spendBank(amount);
        HP.State.addCash(amount);
        if (HP.SoundManager && HP.SoundManager.play) HP.SoundManager.play('success');
        if (HP.Notifications) HP.Notifications.success('Withdrew $' + HP.Helpers.formatNumber(amount) + ' from bank → cash');
        if (HP.SaveManager && HP.SaveManager.save) HP.SaveManager.save();
        return true;
    }

    function bind() {
        var btn100 = document.getElementById('launder-100');
        var btn500 = document.getElementById('launder-500');
        var btn1000 = document.getElementById('launder-1000');
        var btnAll = document.getElementById('launder-all');
        var customInput = document.getElementById('launder-custom-input');
        var customBtn = document.getElementById('launder-custom-btn');
        var wBtn100 = document.getElementById('withdraw-100');
        var wBtn500 = document.getElementById('withdraw-500');
        var wBtn1000 = document.getElementById('withdraw-1000');
        var wBtnAll = document.getElementById('withdraw-all');
        var wCustomInput = document.getElementById('withdraw-custom-input');
        var wCustomBtn = document.getElementById('withdraw-custom-btn');

        function doLaunder(amount) {
            var cash = HP.State.getCash ? HP.State.getCash() : 0;
            var toLaunder = amount === -1 ? cash : Math.min(amount, cash);
            if (amount === -1 && toLaunder >= 1 && !confirm('Launder all $' + HP.Helpers.formatNumber(cash) + ' to bank? You will lose the laundering fee on the full amount.')) return;
            if (toLaunder >= 1) launder(toLaunder);
            if (HP.Journal && HP.Journal.checkAll) HP.Journal.checkAll();
            if (HP.Events && HP.Events.refreshUI) HP.Events.refreshUI();
        }

        function doWithdraw(amount) {
            var bank = HP.State.getBank ? HP.State.getBank() : 0;
            var toWithdraw = amount === -1 ? bank : Math.min(amount, bank);
            if (amount === -1 && toWithdraw >= 1 && !confirm('Withdraw all $' + HP.Helpers.formatNumber(bank) + ' from bank to cash?')) return;
            if (toWithdraw >= 1) withdraw(toWithdraw);
            if (HP.Events && HP.Events.refreshUI) HP.Events.refreshUI();
        }

        if (btn100) btn100.addEventListener('click', function() { doLaunder(100); });
        if (btn500) btn500.addEventListener('click', function() { doLaunder(500); });
        if (btn1000) btn1000.addEventListener('click', function() { doLaunder(1000); });
        if (btnAll) btnAll.addEventListener('click', function() { doLaunder(-1); });
        
        if (customBtn && customInput) {
            customBtn.addEventListener('click', function() {
                var amount = parseInt(customInput.value, 10);
                if (isNaN(amount) || amount < 1) {
                    if (HP.Notifications) HP.Notifications.error('Enter a valid amount');
                    return;
                }
                doLaunder(amount);
                customInput.value = '';
            });
            customInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') customBtn.click();
            });
        }
        
        if (wBtn100) wBtn100.addEventListener('click', function() { doWithdraw(100); });
        if (wBtn500) wBtn500.addEventListener('click', function() { doWithdraw(500); });
        if (wBtn1000) wBtn1000.addEventListener('click', function() { doWithdraw(1000); });
        if (wBtnAll) wBtnAll.addEventListener('click', function() { doWithdraw(-1); });
        
        if (wCustomBtn && wCustomInput) {
            wCustomBtn.addEventListener('click', function() {
                var amount = parseInt(wCustomInput.value, 10);
                if (isNaN(amount) || amount < 1) {
                    if (HP.Notifications) HP.Notifications.error('Enter a valid amount');
                    return;
                }
                doWithdraw(amount);
                wCustomInput.value = '';
            });
            wCustomInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') wCustomBtn.click();
            });
        }
    }

    HP.Events.LaunderActions = { bind: bind, launder: launder, withdraw: withdraw, getFeePercent: getFeePercent };
})();
