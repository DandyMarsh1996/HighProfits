/**
 * Property upgrade actions - security, ventilation, auto-water
 */
(function() {
    'use strict';

    function refreshUI() {
        if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
    }

    function upgradePropertySecurity(propertyId) {
        if (!HP.State.upgradePropertySecurity) return;
        var result = HP.State.upgradePropertySecurity(propertyId);
        if (result.success) {
            HP.Notifications.success(result.message);
            if (HP.SoundManager) HP.SoundManager.play('success');
        } else {
            HP.Notifications.error(result.message);
        }
        refreshUI();
    }

    function upgradePropertyVentilation(propertyId) {
        if (!HP.State.upgradePropertyVentilation) return;
        var result = HP.State.upgradePropertyVentilation(propertyId);
        if (result.success) {
            HP.Notifications.success(result.message);
            if (HP.SoundManager) HP.SoundManager.play('success');
        } else {
            HP.Notifications.error(result.message);
        }
        refreshUI();
    }

    function installAutoWater(propertyId) {
        if (!HP.State.installAutoWater) return;
        var result = HP.State.installAutoWater(propertyId);
        if (result.success) {
            HP.Notifications.success(result.message);
            if (HP.SoundManager) HP.SoundManager.play('success');
        } else {
            HP.Notifications.error(result.message);
        }
        refreshUI();
    }

    function bindPropertyUpgradePanel() {
        var openBtn = document.getElementById('btn-property-upgrades');
        var closeBtn = document.getElementById('btn-close-property-upgrades');
        var panel = document.getElementById('property-upgrades-panel');

        if (openBtn) {
            openBtn.addEventListener('click', function() {
                if (panel) panel.classList.remove('hidden');
                refreshUI();
            });
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                if (panel) panel.classList.add('hidden');
            });
        }
    }

    function bind() {
        bindPropertyUpgradePanel();

        // Delegate clicks for upgrade buttons
        var content = document.getElementById('property-upgrades-content');
        if (content) {
            content.addEventListener('click', function(e) {
                var btn = e.target.closest('.upgrade-btn');
                if (!btn) return;

                var propertyId = btn.getAttribute('data-property');
                var upgradeType = btn.getAttribute('data-upgrade-type');

                if (!propertyId || !upgradeType) return;

                if (upgradeType === 'security') {
                    upgradePropertySecurity(propertyId);
                } else if (upgradeType === 'ventilation') {
                    upgradePropertyVentilation(propertyId);
                } else if (upgradeType === 'autowater') {
                    installAutoWater(propertyId);
                }
            });
        }
    }

    HP.Events.PropertyUpgradeActions = {
        bind: bind,
        upgradePropertySecurity: upgradePropertySecurity,
        upgradePropertyVentilation: upgradePropertyVentilation,
        installAutoWater: installAutoWater
    };
})();
