/**
 * Character select & create – list characters, new character, create panel.
 */
(function() {
    'use strict';

    var pendingDeleteId = null;
    var pendingDeleteName = '';

    function refreshCharacterList() {
        var listEl = document.getElementById('character-list');
        if (!listEl) return;
        var list = HP.SaveManager && HP.SaveManager.getCharacterList ? HP.SaveManager.getCharacterList() : [];
        if (list.length === 0) {
            listEl.innerHTML = '<p class="character-list-empty">No characters yet. Create one to start.</p>';
            return;
        }
        var html = '';
        for (var i = 0; i < list.length; i++) {
            var c = list[i];
            var name = c.name || 'Player';
            var lastPlayed = c.lastPlayed ? new Date(c.lastPlayed).toLocaleDateString() : 'Never';
            var notes = (c.notes && c.notes.trim()) ? escapeHtml(c.notes) : '';
            html += '<div class="character-card" data-character-id="' + c.id + '" data-character-name="' + escapeHtml(name) + '">';
            html += '<div class="character-card-info">';
            html += '<span class="character-card-name">' + escapeHtml(name) + '</span>';
            html += '<span class="character-card-meta">Last played: ' + lastPlayed + '</span>';
            if (notes) html += '<span class="character-card-notes">' + notes + '</span>';
            html += '</div>';
            html += '<div class="character-card-actions">';
            html += '<button type="button" class="character-card-note" title="Add or edit note" aria-label="Edit note">📝</button>';
            html += '<button type="button" class="character-card-delete" title="Delete character" aria-label="Delete character">🗑️</button>';
            html += '</div>';
            html += '</div>';
        }
        listEl.innerHTML = html;
        listEl.querySelectorAll('.character-card').forEach(function(card) {
            var cardInfo = card.querySelector('.character-card-info');
            var deleteBtn = card.querySelector('.character-card-delete');
            var noteBtn = card.querySelector('.character-card-note');
            if (cardInfo) {
                cardInfo.addEventListener('click', function() {
                    var id = card.getAttribute('data-character-id');
                    if (!id || !HP.SaveManager.selectCharacter(id)) return;
                    hideCharacterSelect();
                    if (HP.App && HP.App.startGame) HP.App.startGame();
                });
            }
            if (noteBtn) {
                noteBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var id = card.getAttribute('data-character-id');
                    var list = HP.SaveManager.getCharacterList ? HP.SaveManager.getCharacterList() : [];
                    var ch = list.filter(function(x) { return x.id === id; })[0];
                    var current = (ch && ch.notes) ? ch.notes : '';
                    var note = prompt('Note for this save (optional, max 80 chars):', current);
                    if (note !== null && HP.SaveManager.setCharacterNote(id, note)) {
                        refreshCharacterList();
                    }
                });
            }
            if (deleteBtn) {
                deleteBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    pendingDeleteId = card.getAttribute('data-character-id');
                    pendingDeleteName = (card.getAttribute('data-character-name') || 'Player').trim();
                    openDeleteModal(pendingDeleteId, pendingDeleteName);
                });
            }
        });
    }

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function openDeleteModal(id, name) {
        pendingDeleteId = id;
        pendingDeleteName = name;
        var modal = document.getElementById('character-delete-modal');
        var messageEl = document.getElementById('character-delete-message');
        var inputEl = document.getElementById('character-delete-confirm-input');
        var confirmBtn = document.getElementById('btn-delete-character-confirm');
        if (messageEl) messageEl.textContent = 'Delete "' + name + '"? This cannot be undone. Type the character name below to confirm.';
        if (inputEl) { inputEl.value = ''; inputEl.placeholder = 'Type "' + name + '" to confirm'; }
        if (confirmBtn) confirmBtn.disabled = true;
        if (modal) modal.classList.remove('hidden');
        if (inputEl) inputEl.focus();
    }

    function closeDeleteModal() {
        pendingDeleteId = null;
        pendingDeleteName = '';
        var modal = document.getElementById('character-delete-modal');
        var inputEl = document.getElementById('character-delete-confirm-input');
        var confirmBtn = document.getElementById('btn-delete-character-confirm');
        if (modal) modal.classList.add('hidden');
        if (inputEl) inputEl.value = '';
        if (confirmBtn) confirmBtn.disabled = true;
    }

    var MODAL_IDS = [
        'welcome-tour',
        'tutorial-advisor',
        'sale-modal',
        'heat-modal',
        'reputation-modal',
        'worker-assign-modal',
        'raid-modal',
        'water-modal',
        'stats-explanation-modal'
    ];

    function closeAllModals() {
        MODAL_IDS.forEach(function(id) {
            var el = document.getElementById(id);
            if (el) el.classList.add('hidden');
        });
    }

    function refreshChangelog() {
        var el = document.getElementById('changelog-content');
        if (!el || !HP.Data || !HP.Data.Changelog) return;
        var entries = HP.Data.Changelog.getAll();
        if (entries.length === 0) {
            el.innerHTML = '<p class="changelog-placeholder">Patch notes will appear here in future updates.</p>';
            return;
        }
        var html = '';
        for (var i = 0; i < entries.length; i++) {
            var e = entries[i];
            html += '<div class="changelog-entry">';
            html += '<div class="changelog-version">v' + escapeHtml(e.version) + ' <span class="changelog-date">' + escapeHtml(e.date) + '</span></div>';
            html += '<ul class="changelog-list">';
            for (var j = 0; j < (e.changes || []).length; j++) {
                html += '<li>' + escapeHtml(e.changes[j]) + '</li>';
            }
            html += '</ul></div>';
        }
        el.innerHTML = html;
    }

    function showCharacterSelect() {
        closeAllModals();
        var screen = document.getElementById('character-select-screen');
        var game = document.getElementById('game-container');
        if (screen) screen.classList.remove('hidden');
        if (game) game.classList.add('hidden');
        refreshCharacterList();
        refreshChangelog();
        var createPanel = document.getElementById('character-create-panel');
        if (createPanel) createPanel.classList.add('hidden');
        var deleteModal = document.getElementById('character-delete-modal');
        if (deleteModal) deleteModal.classList.add('hidden');
    }

    function hideCharacterSelect() {
        var screen = document.getElementById('character-select-screen');
        var game = document.getElementById('game-container');
        if (screen) screen.classList.add('hidden');
        if (game) game.classList.remove('hidden');
    }

    function bind() {
        var btnNew = document.getElementById('btn-new-character');
        var createPanel = document.getElementById('character-create-panel');
        var nameInput = document.getElementById('character-name-input');
        var btnCreate = document.getElementById('btn-create-character');
        var btnCancel = document.getElementById('btn-cancel-create');

        if (btnNew) {
            btnNew.addEventListener('click', function() {
                if (createPanel) createPanel.classList.remove('hidden');
                if (nameInput) { nameInput.value = ''; nameInput.focus(); }
            });
        }
        if (btnCreate && nameInput) {
            btnCreate.addEventListener('click', function() {
                var name = nameInput.value.trim() || 'Player';
                if (!HP.SaveManager || !HP.SaveManager.createCharacter(name)) return;
                hideCharacterSelect();
                if (HP.App && HP.App.startGame) HP.App.startGame();
            });
        }
        if (btnCancel && createPanel) {
            btnCancel.addEventListener('click', function() {
                createPanel.classList.add('hidden');
            });
        }

        var deleteModal = document.getElementById('character-delete-modal');
        var deleteConfirmInput = document.getElementById('character-delete-confirm-input');
        var deleteConfirmBtn = document.getElementById('btn-delete-character-confirm');
        var deleteCancelBtn = document.getElementById('btn-delete-character-cancel');
        if (deleteConfirmInput && deleteConfirmBtn) {
            deleteConfirmInput.addEventListener('input', function() {
                var typed = deleteConfirmInput.value.trim();
                var match = typed === pendingDeleteName || (typed && pendingDeleteName && typed.toLowerCase() === pendingDeleteName.toLowerCase());
                deleteConfirmBtn.disabled = !match;
            });
        }
        if (deleteConfirmBtn) {
            deleteConfirmBtn.addEventListener('click', function() {
                if (pendingDeleteId && HP.SaveManager && HP.SaveManager.deleteCharacter(pendingDeleteId)) {
                    closeDeleteModal();
                    refreshCharacterList();
                }
            });
        }
        if (deleteCancelBtn) {
            deleteCancelBtn.addEventListener('click', closeDeleteModal);
        }
    }

    HP.Events.CharacterSelect = { bind: bind, showCharacterSelect: showCharacterSelect, hideCharacterSelect: hideCharacterSelect, refreshCharacterList: refreshCharacterList };
})();
