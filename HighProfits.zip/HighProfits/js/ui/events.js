/**
 * HighProfits - Events Module (init only; domain modules in js/ui/events/).
 * Handles all user interactions. See docs/ARCHITECTURE.md for split guidelines.
 */
var HP = HP || {};
HP.Events = HP.Events || {};

(function() {
    'use strict';

    function init() {
        HP.Events.PlotActions.bind();
        HP.Events.StoreActions.bind();
        HP.Events.MarketActions.bind();
        HP.Events.WorkerActions.bind();
        HP.Events.GeneticsActions.bind();
        if (HP.Events.MixingActions && HP.Events.MixingActions.bind) HP.Events.MixingActions.bind();
        HP.Events.Navigation.bind();
        HP.Events.HeatControls.bind();
        HP.Events.SaveLoad.bind();
        HP.Events.LaunderActions.bind();
        HP.Events.SmokeActions.bind();
        if (HP.Events.StockMarketActions && HP.Events.StockMarketActions.bind) HP.Events.StockMarketActions.bind();
        HP.Events.WelcomeTour.bind();
        HP.Events.PropertyUpgradeActions.bind();
        if (HP.Events.CharacterSelect && HP.Events.CharacterSelect.bind) HP.Events.CharacterSelect.bind();
        console.log('[Events] Initialized');
    }

    // Preserve game-events Manager from systems/events.js (loaded before this)
    var existingManager = (typeof HP !== 'undefined' && HP.Events.Manager) ? HP.Events.Manager : undefined;

    // Re-export public API (used by renderer and other modules)
    HP.Events.init = init;
    HP.Events.installEquipment = function(propertyId, plotIndex, equipmentId) {
        return HP.Events.PlotActions.installEquipment(propertyId, plotIndex, equipmentId);
    };
    HP.Events.uninstallEquipment = function(propertyId, plotIndex, slot) {
        return HP.Events.PlotActions.uninstallEquipment(propertyId, plotIndex, slot);
    };
    HP.Events.plantSeed = function(propertyId, plotIndex, seedId) {
        return HP.Events.PlotActions.plantSeed(propertyId, plotIndex, seedId);
    };
    HP.Events.waterPlant = function(propertyId, plotIndex, canId) {
        return HP.Events.PlotActions.waterPlant(propertyId, plotIndex, canId);
    };
    HP.Events.harvestPlant = function(propertyId, plotIndex) {
        return HP.Events.PlotActions.harvestPlant(propertyId, plotIndex);
    };
    HP.Events.clearDeadPlant = function(propertyId, plotIndex) {
        return HP.Events.PlotActions.clearDeadPlant(propertyId, plotIndex);
    };
    HP.Events.sellEquipment = function(equipmentId) {
        return HP.Events.StoreActions.sellEquipment(equipmentId);
    };
    HP.Events.sellSeeds = function(seedId) {
        return HP.Events.StoreActions.sellSeeds(seedId);
    };
    HP.Events.buyRoomUpgrade = function(propertyId, upgradeId) {
        return HP.Events.StoreActions.buyRoomUpgrade(propertyId, upgradeId);
    };
    HP.Events.sellRoomUpgrade = function(propertyId, upgradeId) {
        return HP.Events.StoreActions.sellRoomUpgrade(propertyId, upgradeId);
    };
    HP.Events.quickSellOrder = function(customerId, quality, amount) {
        return HP.Events.MarketActions.quickSellOrder(customerId, quality, amount);
    };
    HP.Events.Manager = existingManager;
})();
