/**
 * HighProfits - Events Module
 * Handles all user interactions
 */
var HP = HP || {};

HP.Events = (function() {
    'use strict';

    function init() {
        bindNavigation();
        bindPropertySelector();
        bindStoreButtons();
        bindSellControls();
        bindSaveLoadButtons();
        bindDealerFilters();
        bindRoomUpgradeToggle();
        bindQuickActions();
        bindKeyboardShortcuts();
        bindWorkerControls();
        bindAchievementChallengeFilters();
        bindHeatControls();

        console.log('[Events] Initialized');
    }

    /**
     * Bind heat meter and pay-off buttons (bribe, lay low, cleaners)
     */
    function bindHeatControls() {
        var reduceBtn = document.getElementById('heat-reduce-btn');
        var panel = document.getElementById('heat-reduce-panel');
        if (reduceBtn && panel) {
            reduceBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                panel.classList.toggle('hidden');
                if (!panel.classList.contains('hidden') && HP.Renderer && HP.Renderer.update) {
                    HP.Renderer.update();
                }
            });
        }
        document.addEventListener('click', function() {
            if (panel && !panel.classList.contains('hidden')) {
                panel.classList.add('hidden');
            }
        });
        if (panel) {
            panel.addEventListener('click', function(e) { e.stopPropagation(); });
        }
        document.querySelectorAll('.heat-payoff-btn').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                var action = this.getAttribute('data-action');
                if (!action || !HP.State || !HP.State.applyHeatReduction) return;
                var result = HP.State.applyHeatReduction(action);
                if (result.success) {
                    if (HP.Notifications) HP.Notifications.success('Heat reduced by ' + result.reduction + '. Cost: $' + (result.cost || 0) + '.');
                    if (panel) panel.classList.add('hidden');
                    if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
                } else if (result.reason === 'cant_afford' && HP.Notifications) {
                    HP.Notifications.error('Not enough money. Need $' + (result.cost || 0) + '.');
                }
            });
        });
    }

    /**
     * Bind keyboard shortcuts
     */
    function bindKeyboardShortcuts() {
        document.addEventListener('keydown', function(e) {
            // Don't trigger shortcuts when typing in inputs
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) {
                return;
            }

            // Number keys for navigation (1-7)
            if (e.key >= '1' && e.key <= '7') {
                var views = ['grow', 'inventory', 'market', 'achievements', 'hardware', 'garden', 'dealer'];
                var index = parseInt(e.key) - 1;
                if (index < views.length) {
                    e.preventDefault();
                    HP.Renderer.switchView(views[index]);
                }
            }

            // Letter keys for stores (H/G/D/R)
            var key = e.key.toLowerCase();
            if (key === 'h') {
                e.preventDefault();
                HP.Renderer.switchView('hardware');
            } else if (key === 'g') {
                e.preventDefault();
                HP.Renderer.switchView('garden');
            } else if (key === 'd') {
                e.preventDefault();
                HP.Renderer.switchView('dealer');
            } else if (key === 'r') {
                e.preventDefault();
                HP.Renderer.switchView('realestate');
            }

            // Space for harvest all (when in grow view)
            if (e.key === ' ' && HP.Renderer.getCurrentView() === 'grow') {
                e.preventDefault();
                harvestAllPlants();
            }

            // W for water all
            if (e.key === 'w' || e.key === 'W') {
                if (HP.Renderer.getCurrentView() === 'grow') {
                    e.preventDefault();
                    waterAllPlants();
                }
            }

            // P for plant all
            if (e.key === 'p' || e.key === 'P') {
                if (HP.Renderer.getCurrentView() === 'grow') {
                    e.preventDefault();
                    plantAllPlots();
                }
            }

            // Escape to close modals
            if (e.key === 'Escape') {
                var saleModal = document.getElementById('sale-modal');
                if (saleModal && !saleModal.classList.contains('hidden')) {
                    HP.Renderer.closeSaleModal();
                }
                var upgradesPanel = document.getElementById('room-upgrades-panel');
                if (upgradesPanel && !upgradesPanel.classList.contains('hidden')) {
                    HP.Renderer.toggleRoomUpgradesPanel(false);
                }
                var heatPanel = document.getElementById('heat-reduce-panel');
                if (heatPanel && !heatPanel.classList.contains('hidden')) {
                    heatPanel.classList.add('hidden');
                }
            }

            // S for save (Ctrl+S)
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                if (HP.SaveManager) {
                    HP.SaveManager.save();
                    HP.Notifications.success('💾 Game saved!');
                }
            }
        });
    }

    /**
     * Bind quick action buttons (Water All, Harvest All)
     */
    function bindQuickActions() {
        var waterAllBtn = document.getElementById('btn-water-all');
        var harvestAllBtn = document.getElementById('btn-harvest-all');
        var plantAllBtn = document.getElementById('btn-plant-all');
        var installBestBtn = document.getElementById('btn-install-best');
        var selectModeBtn = document.getElementById('btn-select-mode');
        var clearSelectionBtn = document.getElementById('btn-clear-selection');

        if (waterAllBtn) {
            waterAllBtn.addEventListener('click', waterAllPlants);
        }

        if (harvestAllBtn) {
            harvestAllBtn.addEventListener('click', harvestAllPlants);
        }

        if (plantAllBtn) {
            plantAllBtn.addEventListener('click', plantAllPlots);
        }

        if (installBestBtn) {
            installBestBtn.addEventListener('click', installBestEquipment);
        }

        if (selectModeBtn) {
            selectModeBtn.addEventListener('click', function() {
                HP.Renderer.toggleBulkSelectMode();
            });
        }

        if (clearSelectionBtn) {
            clearSelectionBtn.addEventListener('click', function() {
                HP.Renderer.clearSelection();
            });
        }

        // Bulk action buttons
        var bulkWaterBtn = document.getElementById('btn-bulk-water');
        var bulkHarvestBtn = document.getElementById('btn-bulk-harvest');
        var bulkPlantBtn = document.getElementById('btn-bulk-plant');
        var bulkInstallBtn = document.getElementById('btn-bulk-install');
        var bulkClearBtn = document.getElementById('btn-bulk-clear');

        if (bulkWaterBtn) {
            bulkWaterBtn.addEventListener('click', bulkWaterSelected);
        }
        if (bulkHarvestBtn) {
            bulkHarvestBtn.addEventListener('click', bulkHarvestSelected);
        }
        if (bulkPlantBtn) {
            bulkPlantBtn.addEventListener('click', bulkPlantSelected);
        }
        if (bulkInstallBtn) {
            bulkInstallBtn.addEventListener('click', bulkInstallEquipment);
        }
        if (bulkClearBtn) {
            bulkClearBtn.addEventListener('click', bulkClearSelected);
        }
    }

    /**
     * Bulk action: Water selected plots
     */
    function bulkWaterSelected() {
        var selected = HP.Renderer.getSelectedPlots();
        if (selected.length === 0) {
            HP.Notifications.info('No plots selected');
            return;
        }

        var watered = 0;
        var inventory = HP.State.getInventory();
        var wateringCans = HP.Data.Equipment.getWateringCans();
        
        // Find best watering can
        var bestCan = null;
        for (var i = 0; i < wateringCans.length; i++) {
            var can = wateringCans[i];
            if (inventory.equipment[can.id] > 0) {
                if (!bestCan || can.waterAmount > bestCan.waterAmount) {
                    bestCan = can;
                }
            }
        }

        if (!bestCan) {
            HP.Notifications.error('No watering can in inventory!');
            return;
        }

        var waterCost = HP.Data.Constants && HP.Data.Constants.WATER_COST_PER_USE != null ? HP.Data.Constants.WATER_COST_PER_USE : 1;
        var reservoir = HP.State.getWaterReservoir();

        for (var i = 0; i < selected.length; i++) {
            var plotData = selected[i];
            var plot = HP.State.getPlot(plotData.propertyId, plotData.plotIndex);
            if (plot && plot.status === 'growing' && plot.plant) {
                if (reservoir.current < waterCost) {
                    HP.Notifications.error('Out of water after ' + watered + ' plot' + (watered !== 1 ? 's' : '') + '. Refill at the tap.');
                    break;
                }
                var result = HP.Growing.waterPlant(plot, bestCan.waterAmount);
                if (result.success) {
                    HP.State.useWater(waterCost);
                    watered++;
                    reservoir = HP.State.getWaterReservoir();
                }
            }
        }

        if (watered > 0) {
            if (HP.SoundManager) HP.SoundManager.play('water');
            HP.Notifications.success('💧 Watered ' + watered + ' selected plot' + (watered > 1 ? 's' : ''));
        } else {
            HP.Notifications.info('No plots needed watering');
        }

        refreshUI();
    }

    /**
     * Bulk action: Harvest selected plots
     */
    function bulkHarvestSelected() {
        var selected = HP.Renderer.getSelectedPlots();
        if (selected.length === 0) {
            HP.Notifications.info('No plots selected');
            return;
        }

        var harvested = 0;
        var totalYield = 0;
        var qualities = {};

        for (var i = 0; i < selected.length; i++) {
            var plotData = selected[i];
            var plot = HP.State.getPlot(plotData.propertyId, plotData.plotIndex);
            if (plot && plot.status === 'harvest') {
                var result = HP.Growing.harvestPlant(plot);
                if (result.success) {
                    HP.State.addWeed(result.quality, result.yield);
                    if (HP.Progression && HP.Progression.calculateXPForHarvest) {
                        HP.State.addXP(HP.Progression.calculateXPForHarvest(plot, result));
                    } else {
                        HP.State.addXP(HP.Data.Constants.XP_PER_HARVEST);
                    }
                    HP.State.incrementStat('plantsGrown', 1);
                    harvested++;
                    totalYield += result.yield;
                    qualities[result.quality] = (qualities[result.quality] || 0) + result.yield;
                }
            }
        }

        if (harvested > 0) {
            var qualityStr = Object.keys(qualities).map(function(q) {
                return qualities[q] + 'g ' + q;
            }).join(', ');
            if (HP.SoundManager) HP.SoundManager.play('harvest');
            HP.Notifications.success('🌿 Harvested ' + harvested + ' plot' + (harvested > 1 ? 's' : '') + '! (' + qualityStr + ')');
            checkAchievements();
        } else {
            HP.Notifications.info('No plots ready to harvest');
        }

        refreshUI();
    }

    /**
     * Bulk action: Plant seeds in selected plots
     */
    function bulkPlantSelected() {
        var selected = HP.Renderer.getSelectedPlots();
        if (selected.length === 0) {
            HP.Notifications.info('No plots selected');
            return;
        }

        var inventory = HP.State.getInventory();
        var bestSeed = null;
        var bestSeedId = null;

        // Find best available seed
        var allSeeds = HP.Data.Seeds.getAll();
        for (var seedId in allSeeds) {
            if (inventory.seeds[seedId] > 0) {
                var seed = allSeeds[seedId];
                if (!bestSeed || seed.cost > bestSeed.cost) {
                    bestSeed = seed;
                    bestSeedId = seedId;
                }
            }
        }

        if (!bestSeed) {
            HP.Notifications.error('No seeds in inventory!');
            return;
        }

        var planted = 0;
        var propertyId = elements.propertySelect ? elements.propertySelect.value : null;
        var roomBonuses = propertyId ? HP.State.getRoomBonuses(propertyId) : {growth: 0, yield: 0, quality: 0};

        for (var i = 0; i < selected.length; i++) {
            var plotData = selected[i];
            var plot = HP.State.getPlot(plotData.propertyId, plotData.plotIndex);
            if (plot && (plot.status === 'empty' || plot.status === 'setup')) {
                var result = HP.Growing.plantSeed(plot, bestSeedId, roomBonuses);
                if (result.success) {
                    HP.State.removeSeeds(bestSeedId, 1);
                    planted++;
                }
            }
        }

        if (planted > 0) {
            if (HP.SoundManager) HP.SoundManager.play('plant');
            HP.Notifications.success('🌱 Planted ' + planted + ' plot' + (planted > 1 ? 's' : '') + ' with ' + bestSeed.name);
            if (HP.Progression && HP.Progression.calculateXPForPlanting) {
                HP.State.addXP(planted * HP.Progression.calculateXPForPlanting(bestSeedId));
            } else if (HP.Data.Constants.XP_PER_SEED_PLANTED) {
                HP.State.addXP(planted * HP.Data.Constants.XP_PER_SEED_PLANTED);
            }
        } else {
            HP.Notifications.info('No plots ready to plant');
        }

        refreshUI();
    }

    /**
     * Bulk action: Install equipment in selected plots
     */
    function bulkInstallEquipment() {
        var selected = HP.Renderer.getSelectedPlots();
        if (selected.length === 0) {
            HP.Notifications.info('No plots selected');
            return;
        }

        var inventory = HP.State.getInventory();
        var playerLevel = HP.State.getLevel();
        var installed = 0;

        for (var i = 0; i < selected.length; i++) {
            var plotData = selected[i];
            var plot = HP.State.getPlot(plotData.propertyId, plotData.plotIndex);
            if (!plot || (plot.status !== 'empty' && plot.status !== 'setup')) continue;

            var slots = ['pot', 'soil', 'light', 'fan', 'fertilizer'];
            for (var s = 0; s < slots.length; s++) {
                var slot = slots[s];
                if (plot.equipment[slot]) continue;

                var bestEquip = null;
                var allEquip = HP.Data.Equipment.getAll();
                for (var equipId in allEquip) {
                    var equip = allEquip[equipId];
                    var equipSlot = equip.slot || HP.Growing.getEquipmentSlot(equip);
                    if (equipSlot === slot && inventory.equipment[equipId] > 0 && equip.unlockLevel <= playerLevel) {
                        if (!bestEquip || equip.cost > bestEquip.cost) {
                            bestEquip = equip;
                        }
                    }
                }

                if (bestEquip) {
                    var result = HP.Growing.installEquipment(plot, bestEquip.id);
                    if (result.success) {
                        HP.State.removeEquipment(bestEquip.id, 1);
                        installed++;
                        if (HP.Progression && HP.Progression.calculateXPForEquipmentInstall) {
                            HP.State.addXP(HP.Progression.calculateXPForEquipmentInstall(bestEquip.id));
                        } else if (HP.Data.Constants.XP_PER_EQUIPMENT_INSTALL) {
                            HP.State.addXP(HP.Data.Constants.XP_PER_EQUIPMENT_INSTALL);
                        }
                    }
                }
            }
        }

        if (installed > 0) {
            HP.Notifications.success('⚙️ Installed ' + installed + ' equipment piece' + (installed > 1 ? 's' : ''));
        } else {
            HP.Notifications.info('No equipment to install or plots already equipped');
        }

        refreshUI();
    }

    /**
     * Bulk action: Clear dead plants from selected plots
     */
    function bulkClearSelected() {
        var selected = HP.Renderer.getSelectedPlots();
        if (selected.length === 0) {
            HP.Notifications.info('No plots selected');
            return;
        }

        var cleared = 0;
        for (var i = 0; i < selected.length; i++) {
            var plotData = selected[i];
            var plot = HP.State.getPlot(plotData.propertyId, plotData.plotIndex);
            if (plot && plot.status === 'dead') {
                HP.Growing.clearDeadPlant(plot);
                cleared++;
            }
        }

        if (cleared > 0) {
            HP.Notifications.success('🗑️ Cleared ' + cleared + ' dead plant' + (cleared > 1 ? 's' : ''));
        } else {
            HP.Notifications.info('No dead plants to clear');
        }

        refreshUI();
    }

    /**
     * Water all plants that need water in current property
     */
    function waterAllPlants() {
        var propertySelect = document.getElementById('property-select');
        if (!propertySelect) return;

        var propertyId = propertySelect.value;
        var plots = HP.State.getPlots(propertyId);
        var inventory = HP.State.getInventory();

        // Find best watering can in inventory
        var wateringCans = HP.Data.Equipment.getWateringCans();
        var bestCan = null;
        var bestWaterAmount = 0;

        for (var i = 0; i < wateringCans.length; i++) {
            var can = wateringCans[i];
            var count = inventory.equipment[can.id] || 0;
            if (count > 0 && can.waterAmount > bestWaterAmount) {
                bestCan = can;
                bestWaterAmount = can.waterAmount;
            }
        }

        if (!bestCan) {
            HP.Notifications.error('No watering can in inventory!');
            return;
        }

        var waterCost = HP.Data.Constants && HP.Data.Constants.WATER_COST_PER_USE != null ? HP.Data.Constants.WATER_COST_PER_USE : 1;
        var reservoir = HP.State.getWaterReservoir();

        var watered = 0;
        for (var i = 0; i < plots.length; i++) {
            var plot = plots[i];
            if (plot.status === 'growing' && plot.plant && !plot.plant.isHydrated) {
                if (reservoir.current < waterCost) {
                    HP.Notifications.error('Out of water after ' + watered + ' plant' + (watered !== 1 ? 's' : '') + '. Refill at the tap.');
                    break;
                }
                var result = HP.Growing.waterPlant(plot, bestCan.waterAmount);
                if (result && result.success) {
                    HP.State.useWater(waterCost);
                    watered++;
                    reservoir = HP.State.getWaterReservoir();
                }
            }
        }

        if (watered > 0) {
            HP.Notifications.success('💧 Watered ' + watered + ' plant' + (watered > 1 ? 's' : '') + '!');
        } else {
            HP.Notifications.info('No plants need water right now');
        }

        refreshUI();
    }

    /**
     * Harvest all ready plants in current property
     */
    function harvestAllPlants() {
        var propertySelect = document.getElementById('property-select');
        if (!propertySelect) return;

        var propertyId = propertySelect.value;
        var plots = HP.State.getPlots(propertyId);
        var roomBonuses = HP.State.getRoomBonuses(propertyId);

        var harvested = 0;
        var totalYield = 0;
        var qualities = {};

        for (var i = 0; i < plots.length; i++) {
            var plot = plots[i];
            if (plot.status === 'harvest') {
                var result = HP.Growing.harvestPlant(plot);
                if (result.success) {
                    HP.State.addWeed(result.quality, result.yield);
                    if (HP.Progression && HP.Progression.calculateXPForHarvest) {
                        HP.State.addXP(HP.Progression.calculateXPForHarvest(plot, result));
                    } else {
                        HP.State.addXP(HP.Data.Constants.XP_PER_HARVEST);
                    }
                    HP.State.incrementStat('plantsGrown', 1);
                    if (result.yield && HP.State.getStat('bestHarvest') != null && result.yield > HP.State.getStat('bestHarvest')) {
                        HP.State.setStat('bestHarvest', result.yield);
                    }
                    if (result.quality && HP.State.getStat('harvestedByQuality') != null) {
                        var byQual = HP.State.getStat('harvestedByQuality');
                        byQual[result.quality] = (byQual[result.quality] || 0) + result.yield;
                        HP.State.setStat('harvestedByQuality', byQual);
                    }
                    harvested++;
                    totalYield += result.yield;
                    qualities[result.quality] = (qualities[result.quality] || 0) + result.yield;
                    
                }
            }
        }

        if (harvested > 0) {
            var qualityStr = Object.keys(qualities).map(function(q) {
                return qualities[q] + 'g ' + q;
            }).join(', ');
            var plotsEl = document.getElementById('plots-grid');
            if (HP.Particles && plotsEl) HP.Particles.emitHarvest({ element: plotsEl });
            if (HP.SoundManager) HP.SoundManager.play('harvest');
            HP.Notifications.success('🌿 Harvested ' + harvested + ' plant' + (harvested > 1 ? 's' : '') + '! (' + qualityStr + ')');
            
            // Check achievements after harvest
            checkAchievements();
        } else {
            HP.Notifications.info('No plants ready to harvest');
        }

        refreshUI();
    }

    /**
     * Plant seeds in all empty/setup plots
     */
    function plantAllPlots() {
        var propertySelect = document.getElementById('property-select');
        if (!propertySelect) return;

        var propertyId = propertySelect.value;
        var plots = HP.State.getPlots(propertyId);
        var roomBonuses = HP.State.getRoomBonuses(propertyId);
        var inventory = HP.State.getInventory();

        // Find best available seed
        var bestSeed = null;
        var allSeeds = HP.Data.Seeds.getAll();
        for (var seedId in allSeeds) {
            var seed = allSeeds[seedId];
            if (inventory.seeds[seedId] > 0) {
                if (!bestSeed || seed.cost > bestSeed.cost) {
                    bestSeed = seed;
                }
            }
        }

        if (!bestSeed) {
            HP.Notifications.error('No seeds in inventory!');
            return;
        }

        var planted = 0;
        for (var i = 0; i < plots.length; i++) {
            var plot = plots[i];
            if ((plot.status === 'empty' || plot.status === 'setup') && HP.State.getSeeds(bestSeed.id) > 0) {
                var result = HP.Growing.plantSeed(plot, bestSeed.id, roomBonuses);
                if (result.success) {
                    HP.State.removeSeeds(bestSeed.id, 1);
                    planted++;
                    if (HP.Progression && HP.Progression.calculateXPForPlanting) {
                        HP.State.addXP(HP.Progression.calculateXPForPlanting(bestSeed.id));
                    } else if (HP.Data.Constants.XP_PER_SEED_PLANTED) {
                        HP.State.addXP(HP.Data.Constants.XP_PER_SEED_PLANTED);
                    }
                }
            }
        }

        if (planted > 0) {
            HP.Notifications.success('🌱 Planted ' + planted + ' plot' + (planted > 1 ? 's' : '') + ' with ' + bestSeed.name);
        } else {
            HP.Notifications.info('No plots ready to plant');
        }

        refreshUI();
    }

    /**
     * Install best available equipment on all empty plots
     */
    function installBestEquipment() {
        var propertySelect = document.getElementById('property-select');
        if (!propertySelect) return;

        var propertyId = propertySelect.value;
        var plots = HP.State.getPlots(propertyId);
        var inventory = HP.State.getInventory();
        var playerLevel = HP.State.getLevel();

        var installed = 0;
        var slots = ['pot', 'soil', 'light', 'fan', 'fertilizer'];

        for (var i = 0; i < plots.length; i++) {
            var plot = plots[i];
            if (plot.status !== 'empty' && plot.status !== 'setup') continue;

            for (var s = 0; s < slots.length; s++) {
                var slot = slots[s];
                if (plot.equipment[slot]) continue; // Already has equipment

                // Find best available equipment for this slot
                var bestEquip = null;
                var allEquip = HP.Data.Equipment.getAll();
                for (var equipId in allEquip) {
                    var equip = allEquip[equipId];
                    var equipSlot = equip.slot || HP.Growing.getEquipmentSlot(equip);
                    if (equipSlot === slot && inventory.equipment[equipId] > 0 && equip.unlockLevel <= playerLevel) {
                        if (!bestEquip || equip.cost > bestEquip.cost) {
                            bestEquip = equip;
                        }
                    }
                }

                if (bestEquip) {
                    var result = HP.Growing.installEquipment(plot, bestEquip.id);
                    if (result.success) {
                        HP.State.removeEquipment(bestEquip.id, 1);
                        installed++;
                    }
                }
            }
        }

        if (installed > 0) {
            HP.Notifications.success('⚙️ Installed ' + installed + ' equipment piece' + (installed > 1 ? 's' : ''));
        } else {
            HP.Notifications.info('No equipment to install or plots already equipped');
        }

        refreshUI();
    }

    function bindRoomUpgradeToggle() {
        var openBtn = document.getElementById('btn-room-upgrades');
        var closeBtn = document.getElementById('btn-close-upgrades');

        if (openBtn) {
            openBtn.addEventListener('click', function() {
                HP.Renderer.toggleRoomUpgradesPanel(true);
            });
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                HP.Renderer.toggleRoomUpgradesPanel(false);
            });
        }
    }

    function bindAchievementChallengeFilters() {
        var achCat = document.getElementById('achievement-category-filter');
        var achSub = document.getElementById('achievement-sub-filter');
        var chCat = document.getElementById('challenge-category-filter');
        var chSub = document.getElementById('challenge-sub-filter');

        function refresh() {
            if (HP.Renderer) HP.Renderer.update();
        }

        if (achCat) achCat.addEventListener('change', refresh);
        if (achSub) achSub.addEventListener('change', refresh);
        if (chCat) chCat.addEventListener('change', refresh);
        if (chSub) chSub.addEventListener('change', refresh);
    }

    function bindNavigation() {
        var navBtns = document.querySelectorAll('.nav-btn');
        navBtns.forEach(function(btn) {
            btn.addEventListener('click', function() {
                var viewName = this.getAttribute('data-view');
                if (viewName) {
                    HP.Renderer.switchView(viewName);
                }
            });
        });
    }

    function bindPropertySelector() {
        var selector = document.getElementById('property-select');
        if (selector) {
            selector.addEventListener('change', function() {
                HP.Renderer.update();
            });
        }
    }

    function bindStoreButtons() {
        bindStoreContainer('hardware-items');
        bindStoreContainer('garden-items');
        bindStoreContainer('dealer-items');
        bindStoreContainer('property-items');
    }

    function bindStoreContainer(containerId) {
        var container = document.getElementById(containerId);
        if (container) {
            container.addEventListener('click', function(e) {
                if (e.target.classList.contains('buy-btn') && !e.target.disabled) {
                    handleBuy(e.target);
                }
            });
        }
    }

    function handleBuy(button) {
        var type = button.getAttribute('data-type');
        var id = button.getAttribute('data-id');

        if (!type || !id) return;

        if (type === 'equipment') {
            buyEquipment(id);
        } else if (type === 'seed') {
            buySeed(id);
        } else if (type === 'property') {
            buyProperty(id);
        } else if (type === 'water_upgrade') {
            buyWaterUpgrade(id);
        } else if (type === 'heat_reduction') {
            buyHeatReduction(id);
        }
    }

    function buyHeatReduction(itemId) {
        var item = HP.Data.HeatReduction && HP.Data.HeatReduction.get(itemId);
        if (!item) return;
        if (HP.State.getHeatReductionOwned && HP.State.getHeatReductionOwned().indexOf(itemId) !== -1) {
            HP.Notifications.info('Already owned');
            return;
        }
        if (!HP.State.canAfford(item.cost)) {
            HP.Notifications.error('Not enough money!');
            return;
        }
        if (HP.State.buyHeatReduction(itemId)) {
            HP.Notifications.success('Bought ' + item.name + '. Heat builds slower while growing!');
            refreshUI();
        }
    }

    function buyWaterUpgrade(upgradeId) {
        var up = HP.Data.WaterUpgrades && HP.Data.WaterUpgrades.get(upgradeId);
        if (!up) return;
        if (HP.State.getWaterUpgradesOwned && HP.State.getWaterUpgradesOwned().indexOf(upgradeId) !== -1) {
            HP.Notifications.info('Already owned');
            return;
        }
        if (!HP.State.canAfford(up.cost)) {
            HP.Notifications.error('Not enough money!');
            return;
        }
        if (HP.State.buyWaterUpgrade(upgradeId)) {
            HP.Notifications.success('Bought ' + up.name + '. Water capacity increased!');
            refreshUI();
        }
    }

    // Helper to refresh UI after user actions
    function refreshUI() {
        HP.Renderer.update();
    }

    function buyEquipment(equipmentId) {
        var equip = HP.Data.Equipment.get(equipmentId);
        if (!equip) return;

        // Apply event cost modifier (supply shortage)
        var cost = equip.cost;
        if (HP.Events && HP.Events.Manager) {
            var costMult = HP.Events.Manager.getModifier('equipmentCost');
            cost = Math.floor(cost * costMult);
        }

        if (!HP.State.canAfford(cost)) {
            HP.Notifications.error('Not enough money!');
            return;
        }

        HP.State.spendMoney(cost);
        HP.State.addEquipment(equipmentId, 1);
        HP.Notifications.success('Bought ' + equip.name);
        refreshUI();
    }

    function buySeed(seedId) {
        var seed = HP.Data.Seeds.get(seedId);
        if (!seed) return;

        if (!HP.State.canAfford(seed.cost)) {
            HP.Notifications.error('Not enough money!');
            return;
        }

        HP.State.spendMoney(seed.cost);
        HP.State.addSeeds(seedId, 1);
        HP.Notifications.success('Bought ' + seed.name);
        
        // Check tutorial progress (buying seeds is step 0)
        checkTutorialProgress();
        
        refreshUI();
    }

    function buyProperty(propertyId) {
        var result = HP.State.buyProperty(propertyId);

        if (result.success) {
            HP.Notifications.success(result.message);
            if (HP.Progression && HP.Progression.calculateXPForPropertyPurchase) {
                HP.State.addXP(HP.Progression.calculateXPForPropertyPurchase(propertyId));
            } else {
                HP.State.addXP(HP.Data.Constants.XP_PER_PROPERTY);
            }
            
            // Check achievements after property purchase
            checkAchievements();
        } else {
            HP.Notifications.error(result.message);
        }

        refreshUI();
    }
    
    /**
     * Check and unlock achievements
     */
    function checkAchievements() {
        var newlyUnlocked = HP.State.checkAchievements();
        if (newlyUnlocked > 0) {
            var achievements = HP.State.getAchievements();
            var notifications = achievements.notifications;
            for (var i = 0; i < notifications.length; i++) {
                var achievement = HP.Data.Achievements.get(notifications[i]);
                if (achievement) {
                    HP.Notifications.achievement(achievement);
                }
            }
            HP.State.clearAchievementNotifications();
        }
    }

    function installEquipment(propertyId, plotIndex, equipmentId) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) {
            HP.Notifications.error('Invalid plot');
            return;
        }

        if (HP.State.getEquipment(equipmentId) < 1) {
            HP.Notifications.error('Equipment not in inventory');
            return;
        }

        var result = HP.Growing.installEquipment(plot, equipmentId);

        if (result.success) {
            HP.State.removeEquipment(equipmentId, 1);
            HP.Notifications.success(result.message);
            if (HP.Progression && HP.Progression.calculateXPForEquipmentInstall) {
                HP.State.addXP(HP.Progression.calculateXPForEquipmentInstall(equipmentId));
            } else if (HP.Data.Constants.XP_PER_EQUIPMENT_INSTALL) {
                HP.State.addXP(HP.Data.Constants.XP_PER_EQUIPMENT_INSTALL);
            }
        } else {
            HP.Notifications.error(result.message);
        }

        refreshUI();
    }

    function plantSeed(propertyId, plotIndex, seedId) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) {
            HP.Notifications.error('Invalid plot');
            return;
        }

        if (HP.State.getSeeds(seedId) < 1) {
            HP.Notifications.error('No seeds in inventory');
            return;
        }

        // Get room bonuses for this property
        var roomBonuses = HP.State.getRoomBonuses(propertyId);
        var result = HP.Growing.plantSeed(plot, seedId, roomBonuses);

        if (result.success) {
            HP.State.removeSeeds(seedId, 1);
            HP.Notifications.success(result.message);
            if (HP.Progression && HP.Progression.calculateXPForPlanting) {
                HP.State.addXP(HP.Progression.calculateXPForPlanting(seedId));
            } else if (HP.Data.Constants.XP_PER_SEED_PLANTED) {
                HP.State.addXP(HP.Data.Constants.XP_PER_SEED_PLANTED);
            }
            if (HP.SoundManager) HP.SoundManager.play('plant');
            
            // Check tutorial progress (planting is step 1)
            checkTutorialProgress();
        } else {
            HP.Notifications.error(result.message);
        }

        refreshUI();
    }

    /**
     * Water a plant using a watering can (consumes water from reservoir)
     */
    function waterPlant(propertyId, plotIndex, canId) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) {
            HP.Notifications.error('Invalid plot');
            return;
        }

        if (HP.State.getEquipment(canId) < 1) {
            HP.Notifications.error('No watering can in inventory');
            return;
        }

        var can = HP.Data.Equipment.get(canId);
        if (!can || !can.waterAmount) {
            HP.Notifications.error('Invalid watering equipment');
            return;
        }

        var waterCost = HP.Data.Constants && HP.Data.Constants.WATER_COST_PER_USE != null ? HP.Data.Constants.WATER_COST_PER_USE : 1;
        var reservoir = HP.State.getWaterReservoir();
        if (reservoir.current < waterCost) {
            HP.Notifications.error('Out of water. Refill at the tap.');
            return;
        }

        var result = HP.Growing.waterPlant(plot, can.waterAmount);

        if (result.success) {
            HP.State.useWater(waterCost);
            HP.State.incrementStat('plantsWatered', 1);
            HP.Notifications.success('💧 Watered! +' + can.waterAmount + 's hydration');
            if (HP.SoundManager) HP.SoundManager.play('water');
            checkTutorialProgress();
        } else {
            HP.Notifications.error(result.message);
        }

        refreshUI();
    }

    function harvestPlant(propertyId, plotIndex) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) {
            HP.Notifications.error('Invalid plot');
            return;
        }

        var result = HP.Growing.harvestPlant(plot);

        if (result.success) {
            HP.State.addWeed(result.quality, result.yield);
            if (HP.Progression && HP.Progression.calculateXPForHarvest) {
                HP.State.addXP(HP.Progression.calculateXPForHarvest(plot, result));
            } else {
                HP.State.addXP(HP.Data.Constants.XP_PER_HARVEST);
            }
            HP.State.incrementStat('plantsGrown', 1);
            
            // Update best harvest stat
            var stats = HP.State.getStats();
            if (result.yield > (stats.bestHarvest || 0)) {
                HP.State.setStat('bestHarvest', result.yield);
            }
            
            var plotCard = document.querySelector('.plot-card[data-property="' + propertyId + '"][data-index="' + plotIndex + '"]');
            if (HP.Particles && plotCard) HP.Particles.emitHarvest({ element: plotCard });
            if (HP.SoundManager) HP.SoundManager.play('harvest');
            HP.Notifications.success(result.message);
            
            // Check tutorial progress (harvesting is step 4)
            checkTutorialProgress();
        } else {
            HP.Notifications.error(result.message);
        }

        refreshUI();
    }

    function clearDeadPlant(propertyId, plotIndex) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) return;

        HP.Growing.clearDeadPlant(plot);
        HP.Notifications.info('Cleared dead plant');
        refreshUI();
    }

    /**
     * Uninstall equipment from a plot
     */
    function uninstallEquipment(propertyId, plotIndex, slot) {
        var plot = HP.State.getPlot(propertyId, plotIndex);
        if (!plot) {
            HP.Notifications.error('Invalid plot');
            return;
        }

        var result = HP.Growing.uninstallEquipment(plot, slot);

        if (result.success) {
            // Return equipment to inventory (unless consumable like soil)
            var equip = HP.Data.Equipment.get(result.equipmentId);
            if (equip && !equip.consumable) {
                HP.State.addEquipment(result.equipmentId, 1);
                HP.Notifications.success(result.message + ' - returned to inventory');
            } else {
                HP.Notifications.info(result.message + ' - discarded');
            }
        } else {
            HP.Notifications.error(result.message);
        }

        refreshUI();
    }

    /**
     * Sell equipment back to store
     */
    function sellEquipment(equipmentId) {
        var count = HP.State.getEquipment(equipmentId);
        if (count < 1) {
            HP.Notifications.error('Item not in inventory');
            return;
        }

        var equip = HP.Data.Equipment.get(equipmentId);
        if (!equip) {
            HP.Notifications.error('Invalid item');
            return;
        }

        // Sell for 50% of original price
        var sellPrice = Math.floor(equip.cost * 0.5);
        
        HP.State.removeEquipment(equipmentId, 1);
        HP.State.addMoney(sellPrice);
        HP.Notifications.success('Sold ' + equip.name + ' for $' + sellPrice);
        refreshUI();
    }

    /**
     * Sell seeds back to dealer
     */
    function sellSeeds(seedId) {
        var count = HP.State.getSeeds(seedId);
        if (count < 1) {
            HP.Notifications.error('Seeds not in inventory');
            return;
        }

        var seed = HP.Data.Seeds.get(seedId);
        if (!seed) {
            HP.Notifications.error('Invalid seeds');
            return;
        }

        // Sell for 50% of original price
        var sellPrice = Math.floor(seed.cost * 0.5);
        
        HP.State.removeSeeds(seedId, 1);
        HP.State.addMoney(sellPrice);
        HP.Notifications.success('Sold ' + seed.name + ' for $' + sellPrice);
        refreshUI();
    }

    /**
     * Buy and install a room upgrade
     */
    function buyRoomUpgrade(propertyId, upgradeId) {
        if (HP.State.hasRoomUpgrade(propertyId, upgradeId)) {
            HP.Notifications.error('Already installed!');
            return;
        }

        var upgrade = HP.Data.RoomUpgrades.get(upgradeId);
        if (!upgrade) {
            HP.Notifications.error('Invalid upgrade');
            return;
        }

        if (!HP.State.canAfford(upgrade.cost)) {
            HP.Notifications.error('Not enough money!');
            return;
        }

        HP.State.spendMoney(upgrade.cost);
        HP.State.addRoomUpgrade(propertyId, upgradeId);
        HP.Notifications.success('Installed ' + upgrade.name);
        if (HP.Progression && HP.Progression.calculateXPForRoomUpgrade) {
            HP.State.addXP(HP.Progression.calculateXPForRoomUpgrade(upgradeId));
        }
        refreshUI();
    }

    /**
     * Sell/remove a room upgrade
     */
    function sellRoomUpgrade(propertyId, upgradeId) {
        if (!HP.State.hasRoomUpgrade(propertyId, upgradeId)) {
            HP.Notifications.error('Upgrade not installed');
            return;
        }

        var upgrade = HP.Data.RoomUpgrades.get(upgradeId);
        if (!upgrade) {
            HP.Notifications.error('Invalid upgrade');
            return;
        }

        // Sell for 50% of original price
        var sellPrice = Math.floor(upgrade.cost * 0.5);
        
        HP.State.removeRoomUpgrade(propertyId, upgradeId);
        HP.State.addMoney(sellPrice);
        HP.Notifications.success('Sold ' + upgrade.name + ' for $' + sellPrice);
        refreshUI();
    }

    function bindSellControls() {
        var sellBtn = document.getElementById('btn-sell');
        var closeBtn = document.getElementById('btn-close-sale');
        var newRequestBtn = document.getElementById('btn-new-request');

        if (sellBtn) {
            sellBtn.addEventListener('click', handleSell);
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                HP.Renderer.closeSaleModal();
            });
        }

        if (newRequestBtn && HP.Renderer.regenerateCustomerRequest) {
            newRequestBtn.addEventListener('click', function() {
                HP.Renderer.regenerateCustomerRequest();
            });
        }

        document.querySelectorAll('.deal-type-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.deal-type-btn').forEach(function(b) { b.classList.remove('selected'); });
                this.classList.add('selected');
                if (HP.Renderer && HP.Renderer.updateSellTotal) HP.Renderer.updateSellTotal();
            });
        });
    }

    function handleSell() {
        var customerId = HP.Renderer.getSelectedCustomer();
        if (!customerId) {
            HP.Notifications.error('No customer selected!');
            return;
        }

        var customer = HP.Data.Customers.get(customerId);
        if (!customer || !customer.currentRequest) {
            HP.Notifications.error('No deal on the table. Try "New request" for a new offer.');
            return;
        }

        var quality = customer.currentRequest.quality;
        var amount = customer.currentRequest.amount;
        var available = HP.State.getWeed(quality);

        var minAllowed = customer.minAmount || 1;
        var maxAllowed = Math.min(available, customer.maxAmount || available);

        // Enforce customer purchase rules
        if (available < minAllowed) {
            HP.Notifications.error(customer.name + ' only buys ' + minAllowed + 'g+ (you have ' + available + 'g).');
            return;
        }
        if (amount < minAllowed) {
            HP.Notifications.error(customer.name + ' only buys ' + minAllowed + 'g or more.');
            return;
        }
        if (amount > maxAllowed) {
            HP.Notifications.error(customer.name + ' won’t buy more than ' + customer.maxAmount + 'g at once.');
            return;
        }

        if (amount < 1) {
            HP.Notifications.error('Nothing to sell!');
            return;
        }

        var priceInfo = HP.Data.Customers.calculatePrice(customerId, quality, amount);
        if (!priceInfo || priceInfo.total == null) {
            HP.Notifications.error('Could not calculate price for this deal.');
            return;
        }

        var dealEl = document.querySelector('.deal-type-btn.selected');
        var dealType = (dealEl && dealEl.getAttribute('data-deal')) || 'normal';
        var constants = HP.Data.Constants || {};
        var discountMult = constants.REP_DEAL_DISCOUNT_PRICE_MULT != null ? constants.REP_DEAL_DISCOUNT_PRICE_MULT : 0.85;
        var overchargeMult = constants.REP_DEAL_OVERCHARGE_PRICE_MULT != null ? constants.REP_DEAL_OVERCHARGE_PRICE_MULT : 1.20;
        var repDiscountGain = constants.REP_DEAL_DISCOUNT_REP_GAIN != null ? constants.REP_DEAL_DISCOUNT_REP_GAIN : 3;
        var repNormalGain = constants.REP_DEAL_NORMAL_REP_GAIN != null ? constants.REP_DEAL_NORMAL_REP_GAIN : 1;
        var repOverchargeLoss = constants.REP_DEAL_OVERCHARGE_REP_LOSS != null ? constants.REP_DEAL_OVERCHARGE_REP_LOSS : 2;

        var priceMult = 1;
        var repDelta = 0;
        if (dealType === 'discount') {
            priceMult = discountMult;
            repDelta = repDiscountGain;
        } else if (dealType === 'overcharge') {
            priceMult = overchargeMult;
            repDelta = -repOverchargeLoss;
        } else {
            repDelta = repNormalGain;
        }

        var totalEarned = Math.floor(priceInfo.total * priceMult);

        // Check for order bonus
        var orderBonus = 0;
        var hasOrder = false;
        if (HP.MarketOrders) {
            if (HP.MarketOrders.matchesOrder(customerId, quality, amount)) {
                orderBonus = HP.MarketOrders.getOrderBonus(customerId, quality, amount);
                HP.MarketOrders.fulfillOrder(customerId);
                hasOrder = true;
            }
        }

        totalEarned += orderBonus;

        if (HP.State.addCustomerReputation) {
            HP.State.addCustomerReputation(customerId, repDelta);
        }

        HP.State.removeWeed(quality, amount);
        HP.State.addMoney(totalEarned);
        HP.State.incrementStat('totalSold', amount);
        if (totalEarned && HP.State.getStat('biggestSale') != null && totalEarned > HP.State.getStat('biggestSale')) {
            HP.State.setStat('biggestSale', totalEarned);
        }
        if (HP.Progression && HP.Progression.calculateXPForSale) {
            HP.State.addXP(HP.Progression.calculateXPForSale(totalEarned, quality, amount, hasOrder));
        } else {
            HP.State.addXP(HP.Data.Constants.XP_PER_SALE * amount);
        }

        // Clear the customer request so a new one is generated next time
        customer.currentRequest = null;
        
        var message = 'Sold ' + amount + 'g ' + quality + ' to ' + customer.name + ' for $' + HP.Helpers.formatNumber(totalEarned);
        var moneyEl = document.getElementById('money-display');
        if (HP.Particles && moneyEl) HP.Particles.emitSale({ element: moneyEl });
        if (HP.SoundManager) HP.SoundManager.play('sale');
        if (hasOrder) {
            message += ' (+$' + HP.Helpers.formatNumber(orderBonus) + ' order bonus!)';
            HP.Notifications.success(message);
        } else {
            HP.Notifications.success(message);
        }
        
        // Track total sales count for tutorial
        HP.State.incrementStat('totalSales', 1);
        
        // Check achievements after sale
        checkAchievements();
        
        // Check tutorial progress (selling is step 5)
        checkTutorialProgress();
        
        HP.Renderer.closeSaleModal();
        refreshUI();
    }

    function bindSaveLoadButtons() {
        var saveBtn = document.getElementById('save-game');
        var loadBtn = document.getElementById('load-game');
        var resetBtn = document.getElementById('reset-game');

        if (saveBtn) {
            saveBtn.addEventListener('click', function() {
                HP.SaveManager.save();
                HP.Notifications.success('Game saved!');
            });
        }

        if (loadBtn) {
            loadBtn.addEventListener('click', function() {
                if (HP.SaveManager.load()) {
                    HP.Notifications.success('Game loaded!');
                    refreshUI();
                } else {
                    HP.Notifications.error('No saved game found!');
                }
            });
        }

        if (resetBtn) {
            resetBtn.addEventListener('click', function() {
                if (confirm('Reset all progress?')) {
                    HP.State.reset();
                    HP.SaveManager.clear();
                    HP.Notifications.info('Game reset!');
                    refreshUI();
                }
            });
        }
    }

    return {
        init: init,
        installEquipment: installEquipment,
        uninstallEquipment: uninstallEquipment,
        plantSeed: plantSeed,
        waterPlant: waterPlant,
        harvestPlant: harvestPlant,
        clearDeadPlant: clearDeadPlant,
        sellEquipment: sellEquipment,
        sellSeeds: sellSeeds,
        buyRoomUpgrade: buyRoomUpgrade,
        sellRoomUpgrade: sellRoomUpgrade
    };

    /**
     * Bind worker controls
     */
    function bindWorkerControls() {
        // Hire worker buttons
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('btn-hire-worker') && !e.target.disabled) {
                var workerTypeId = e.target.getAttribute('data-worker');
                hireWorker(workerTypeId);
            }
        });

        // Assign worker button
        var assignBtn = document.getElementById('btn-assign-worker');
        if (assignBtn) {
            assignBtn.addEventListener('click', function() {
                var updateWorkerId = this.getAttribute('data-update-worker');
                if (updateWorkerId) {
                    updateWorkerConfig(updateWorkerId);
                } else {
                    assignWorker();
                }
            });
        }

        // Close modal button
        var closeBtn = document.getElementById('btn-close-worker-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                HP.Renderer.closeWorkerAssignModal();
            });
        }

        // Configure and remove worker buttons
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('btn-configure-worker')) {
                var workerId = e.target.getAttribute('data-worker');
                configureWorker(workerId);
            } else if (e.target.classList.contains('btn-remove-worker')) {
                var workerId = e.target.getAttribute('data-worker');
                removeWorker(workerId);
            }
        });
    }

    /**
     * Hire a new worker
     */
    function hireWorker(workerTypeId) {
        var workerType = HP.Data.GrowerWorkers.get(workerTypeId);
        if (!workerType) {
            HP.Notifications.error('Invalid worker type');
            return;
        }

        if (!HP.State.canAfford(workerType.baseCost)) {
            HP.Notifications.error('Not enough money!');
            return;
        }

        HP.State.spendMoney(workerType.baseCost);
        HP.Renderer.openWorkerAssignModal(workerTypeId);
        refreshUI();
    }

    /**
     * Assign worker to plot
     */
    function assignWorker() {
        var modal = document.getElementById('worker-assign-modal');
        if (!modal) return;

        var workerTypeId = modal.getAttribute('data-worker-type');
        if (!workerTypeId) return;

        var plotSelect = document.getElementById('worker-plot-select');
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');

        if (!plotSelect || !plotSelect.value) {
            HP.Notifications.error('Please select a plot');
            return;
        }

        var plotParts = plotSelect.value.split(':');
        if (plotParts.length !== 2) {
            HP.Notifications.error('Invalid plot selection');
            return;
        }

        var propertyId = plotParts[0];
        var plotIndex = parseInt(plotParts[1], 10);

        // Check if plot already has a worker
        var existingWorker = HP.State.getWorkerByPlot(propertyId, plotIndex);
        if (existingWorker) {
            HP.Notifications.error('This plot already has a worker assigned');
            return;
        }

        var config = {
            seedId: seedSelect ? (seedSelect.value || null) : null,
            soilId: soilSelect ? (soilSelect.value || null) : null,
            fertilizerId: fertilizerSelect ? (fertilizerSelect.value || null) : null
        };

        var worker = HP.State.addGrowerWorker(workerTypeId, {
            propertyId: propertyId,
            plotIndex: plotIndex
        }, config);

        if (worker) {
            var workerType = HP.Data.GrowerWorkers.get(workerTypeId);
            HP.Notifications.success('Hired and assigned ' + workerType.name + '!');
            HP.Renderer.closeWorkerAssignModal();
            refreshUI();
        } else {
            HP.Notifications.error('Failed to assign worker');
        }
    }

    /**
     * Configure worker settings
     */
    function configureWorker(workerId) {
        var workers = HP.State.getGrowerWorkers();
        var worker = workers.find(function(w) { return w.id === workerId; });
        if (!worker) return;

        // Open modal with current settings
        var workerType = HP.Data.GrowerWorkers.get(worker.workerTypeId);
        HP.Renderer.openWorkerAssignModal(worker.workerTypeId);

        // Pre-select current plot (but disable it)
        var plotSelect = document.getElementById('worker-plot-select');
        if (plotSelect) {
            var plotValue = worker.assignedPlot.propertyId + ':' + worker.assignedPlot.plotIndex;
            plotSelect.value = plotValue;
            plotSelect.disabled = true; // Can't change plot assignment
        }

        // Pre-select current config
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');

        if (seedSelect) {
            seedSelect.value = worker.config.seedId || '';
        }
        if (soilSelect) {
            soilSelect.value = worker.config.soilId || '';
        }
        if (fertilizerSelect) {
            fertilizerSelect.value = worker.config.fertilizerId || '';
        }

        // Change button to "Update" instead of "Assign"
        var assignBtn = document.getElementById('btn-assign-worker');
        if (assignBtn) {
            assignBtn.textContent = 'Update Configuration';
            // Store worker ID for update
            assignBtn.setAttribute('data-update-worker', workerId);
        }
    }

    /**
     * Update worker configuration
     */
    function updateWorkerConfig(workerId) {
        var seedSelect = document.getElementById('worker-seed-select');
        var soilSelect = document.getElementById('worker-soil-select');
        var fertilizerSelect = document.getElementById('worker-fertilizer-select');

        var config = {
            seedId: seedSelect ? (seedSelect.value || null) : null,
            soilId: soilSelect ? (soilSelect.value || null) : null,
            fertilizerId: fertilizerSelect ? (fertilizerSelect.value || null) : null
        };

        if (HP.State.updateWorkerConfig(workerId, config)) {
            HP.Notifications.success('Worker configuration updated');
            HP.Renderer.closeWorkerAssignModal();
            
            // Clear update worker attribute
            var assignBtn = document.getElementById('btn-assign-worker');
            if (assignBtn) {
                assignBtn.removeAttribute('data-update-worker');
            }
            
            refreshUI();
        } else {
            HP.Notifications.error('Failed to update configuration');
        }
    }

    /**
     * Remove worker
     */
    function removeWorker(workerId) {
        if (confirm('Remove this worker? They will stop working immediately.')) {
            if (HP.State.removeGrowerWorker(workerId)) {
                HP.Notifications.info('Worker removed');
                refreshUI();
            } else {
                HP.Notifications.error('Failed to remove worker');
            }
        }
    }

    /**
     * Quick sell to fulfill market order (no modal)
     */
    function quickSellOrder(customerId, quality, amount) {
        var inventory = HP.State.getInventory();
        if (inventory.weed[quality] < amount) {
            HP.Notifications.error('Not enough ' + quality + ' quality product!');
            return;
        }

        var customer = HP.Data.Customers.get(customerId);
        if (!customer) return;

        // Get the order and calculate price with bonus
        var order = HP.MarketOrders.getOrder(customerId);
        if (!order) {
            HP.Notifications.error('Order expired!');
            return;
        }

        var totalEarned = order.bonusPrice;
        var orderBonus = order.bonusPrice - order.basePrice;

        // Process sale
        HP.State.removeWeed(quality, amount);
        HP.State.addMoney(totalEarned);
        HP.State.incrementStat('totalSold', amount);
        if (totalEarned && HP.State.getStat('biggestSale') != null && totalEarned > HP.State.getStat('biggestSale')) {
            HP.State.setStat('biggestSale', totalEarned);
        }
        if (HP.Progression && HP.Progression.calculateXPForSale) {
            HP.State.addXP(HP.Progression.calculateXPForSale(totalEarned, quality, amount, true));
        } else {
            HP.State.addXP(HP.Data.Constants.XP_PER_SALE * amount);
        }

        // Clear the order
        HP.MarketOrders.clearOrder(customerId);

        var message = '✅ Sold ' + amount + 'g ' + quality + ' to ' + customer.name + ' for $' + HP.Helpers.formatNumber(totalEarned) + ' (+$' + HP.Helpers.formatNumber(orderBonus) + ' order bonus!)';
        var moneyEl = document.getElementById('money-display');
        if (HP.Particles && moneyEl) HP.Particles.emitSale({ element: moneyEl });
        if (HP.SoundManager) HP.SoundManager.play('sale');
        HP.Notifications.success(message);

        // Track total sales count for tutorial
        HP.State.incrementStat('totalSales', 1);

        // Check achievements after sale
        checkAchievements();

        // Check tutorial progress (selling is step 5)
        checkTutorialProgress();

        refreshUI();
    }

    /**
     * Bind seed dealer filter/sort controls
     */
    function bindDealerFilters() {
        var filterQuality = document.getElementById('dealer-filter-quality');
        var filterAvailability = document.getElementById('dealer-filter-availability');
        var sortBy = document.getElementById('dealer-sort-by');
        var searchInput = document.getElementById('dealer-search');

        var updateDealer = function() {
            if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
        };

        if (filterQuality) filterQuality.addEventListener('change', updateDealer);
        if (filterAvailability) filterAvailability.addEventListener('change', updateDealer);
        if (sortBy) sortBy.addEventListener('change', updateDealer);
        if (searchInput) {
            searchInput.addEventListener('input', updateDealer);
            // Prevent keyboard shortcuts from triggering while typing
            searchInput.addEventListener('keydown', function(e) {
                e.stopPropagation();
            });
        }
    }

    /**
     * Bind genetics/breeding controls
     */
    function bindGeneticsControls() {
        var parent1Select = document.getElementById('parent1-select');
        var parent2Select = document.getElementById('parent2-select');
        var breedBtn = document.getElementById('btn-breed');

        // Library filter/sort controls
        var filterType = document.getElementById('library-filter-type');
        var filterQuality = document.getElementById('library-filter-quality');
        var librarySortBy = document.getElementById('library-sort-by');
        var librarySearch = document.getElementById('library-search');

        var updateLibrary = function() {
            if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
        };

        if (filterType) filterType.addEventListener('change', updateLibrary);
        if (filterQuality) filterQuality.addEventListener('change', updateLibrary);
        if (librarySortBy) librarySortBy.addEventListener('change', updateLibrary);
        if (librarySearch) {
            librarySearch.addEventListener('input', updateLibrary);
            librarySearch.addEventListener('keydown', function(e) {
                e.stopPropagation();
            });
        }

        if (parent1Select) {
            parent1Select.addEventListener('change', function() {
                if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
            });
        }

        if (parent2Select) {
            parent2Select.addEventListener('change', function() {
                if (HP.Renderer && HP.Renderer.update) HP.Renderer.update();
            });
        }

        if (breedBtn) {
            breedBtn.addEventListener('click', performBreeding);
        }
    }

    /**
     * Perform breeding
     */
    function performBreeding() {
        var parent1Select = document.getElementById('parent1-select');
        var parent2Select = document.getElementById('parent2-select');
        var hybridNameInput = document.getElementById('hybrid-name');
        var statusEl = document.getElementById('breed-status');

        if (!parent1Select || !parent2Select || !hybridNameInput) return;

        var p1Id = parent1Select.value;
        var p2Id = parent2Select.value;
        var customName = hybridNameInput.value.trim();

        if (!p1Id || !p2Id) {
            HP.Notifications.error('Select both parent seeds');
            return;
        }

        if (p1Id === p2Id) {
            HP.Notifications.error('Parents must be different strains');
            return;
        }

        // Check inventory
        var inventory = HP.State.getInventory();
        if (!inventory.seeds[p1Id] || inventory.seeds[p1Id] < 1) {
            HP.Notifications.error('Not enough ' + HP.Data.Seeds.get(p1Id).name);
            return;
        }
        if (!inventory.seeds[p2Id] || inventory.seeds[p2Id] < 1) {
            HP.Notifications.error('Not enough ' + HP.Data.Seeds.get(p2Id).name);
            return;
        }

        // Perform breeding
        var result = HP.Genetics.breedStrains(p1Id, p2Id, customName);

        if (!result.success) {
            HP.Notifications.error(result.error || 'Breeding failed');
            return;
        }

        // Consume parent seeds
        HP.State.removeSeeds(p1Id, 1);
        HP.State.removeSeeds(p2Id, 1);

        // Add hybrid to state
        HP.State.addCustomStrain(result.hybrid);

        // Add 1 seed of the new hybrid to inventory
        HP.State.addSeeds(result.hybrid.id, 1);

        // Show success message
        var message = '🧬 Created ' + result.hybrid.name + '!';
        if (result.mutations && result.mutations.length > 0) {
            message += ' ✨ ' + result.mutations.length + ' mutation(s)!';
        }
        HP.Notifications.success(message);

        // Play sound
        if (HP.SoundManager) HP.SoundManager.play('success');

        // Clear inputs
        parent1Select.value = '';
        parent2Select.value = '';
        hybridNameInput.value = '';

        // Check achievements
        checkAchievements();

        // Check tutorial progress
        if (HP.Tutorial) HP.Tutorial.checkProgress();

        refreshUI();
    }

    /**
     * Check tutorial progress after any game action
     */
    function checkTutorialProgress() {
        if (HP.Tutorial && HP.Tutorial.isActive()) {
            HP.Tutorial.checkProgress();
        }
    }

    // Public API
    window.HP = window.HP || {};
    window.HP.Events = {
        quickSellOrder: quickSellOrder
    };
})();
