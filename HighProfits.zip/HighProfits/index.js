// open collapsable buttons
document.querySelectorAll('.toggle-button').forEach(button => {
    button.addEventListener('click', () => {
        const targetId = button.getAttribute('data-target');
        const target = document.getElementById(targetId);
        if (target) {
            target.classList.toggle('open');
        }
    });
});

// Get the sidebar and mobile menu button
const sidebar = document.getElementById('left-sidebar');
const mobileMenuBtn = document.getElementById('mobile-menu-btn');

// Toggle sidebar visibility on mobile
mobileMenuBtn.addEventListener('click', () => {
    sidebar.classList.toggle('open');
});

//toggle news feed height
const toggleBtn = document.getElementById("toggle-news-btn");
const newsContainer = document.getElementById("news-container");

toggleBtn.addEventListener("click", () => {
    const isCollapsed = newsContainer.classList.toggle("collapsed");
    toggleBtn.textContent = isCollapsed ? "▲" : "▼";
});














